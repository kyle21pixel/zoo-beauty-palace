-- Create a dedicated user for the application
CREATE USER IF NOT EXISTS 'zooadmin'@'localhost' IDENTIFIED BY 'secure_pass_123';

-- Grant all privileges to this user
GRANT ALL PRIVILEGES ON *.* TO 'zooadmin'@'localhost' WITH GRANT OPTION;

-- Flush privileges to apply changes
FLUSH PRIVILEGES;

-- Ensure database exists
CREATE DATABASE IF NOT EXISTS zoobeauty CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
