const mongoose = require('mongoose');
const User = require('./models/User.mongo');
const Provider = require('./models/Provider.mongo');
const { connectDB } = require('./config/mongodb');

// Connect to database
connectDB();

// Test data
const testUsers = [
  {
    email: 'testclient@example.com',
    password: 'password123',
    role: 'client',
    firstName: 'John',
    lastName: 'Client',
    phone: '555-0001'
  },
  {
    email: 'testprovider@example.com',
    password: 'password123',
    role: 'provider',
    firstName: 'Jane',
    lastName: 'Provider',
    phone: '555-0002'
  },
  {
    email: 'testbeautician@example.com',
    password: 'password123',
    role: 'beautician',
    firstName: 'Sam',
    lastName: 'Beautician',
    phone: '555-0003'
  }
];

const providerProfile = {
  businessName: 'Jane\'s Beauty Salon',
  bio: 'Professional beauty services with 10 years of experience',
  specializations: ['Makeup', 'Skincare', 'Hair Styling'],
  serviceType: 'both',
  address: '123 Beauty Street',
  city: 'Los Angeles',
  state: 'CA',
  country: 'USA',
  zipCode: '90210'
};

async function setupTestUsers() {
  try {
    console.log('Setting up test users...\n');
    
    // Create users
    for (let i = 0; i < testUsers.length; i++) {
      const userData = testUsers[i];
      
      // Check if user already exists
      const existingUser = await User.findOne({ email: userData.email });
      if (existingUser) {
        console.log(`⚠️  User ${userData.email} already exists`);
        continue;
      }
      
      // Create user
      const user = new User({
        email: userData.email,
        password: userData.password,
        role: userData.role
      });
      
      await user.save();
      console.log(`✅ Created ${userData.role}: ${userData.email}`);
      
      // Update profile for all users
      user.firstName = userData.firstName;
      user.lastName = userData.lastName;
      user.phone = userData.phone;
      user.isProfileComplete = true;
      
      await user.save();
      console.log(`✅ Updated profile for ${userData.email}\n`);
      
      // For provider, also create provider profile
      if (userData.role === 'provider') {
        const provider = new Provider({
          userId: user._id,
          ...providerProfile
        });
        
        await provider.save();
        console.log(`✅ Created provider profile for ${userData.email}\n`);
      }
    }
    
    console.log('🎉 All test users created successfully!');
    console.log('\nTest Credentials:');
    console.log('--------------------');
    testUsers.forEach(user => {
      console.log(`${user.role.toUpperCase()}:`);
      console.log(`  Email: ${user.email}`);
      console.log(`  Password: ${user.password}\n`);
    });
    
    console.log('Provider Profile:');
    console.log(`  Business: ${providerProfile.businessName}`);
    console.log(`  Specializations: ${providerProfile.specializations.join(', ')}`);
    
    // Close connection
    mongoose.connection.close();
    
  } catch (error) {
    console.log('❌ Setup failed with error:', error.message);
    mongoose.connection.close();
  }
}

// Run the setup
setupTestUsers();