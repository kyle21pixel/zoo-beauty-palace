const { sequelize } = require('./config/database');
const { User, Provider } = require('./models');
const bcrypt = require('bcryptjs');
require('dotenv').config();

const resetProviders = async () => {
    try {
        await sequelize.authenticate();
        console.log('Database Connected...');

        // Sync models
        await sequelize.sync();
        console.log('Models synced...');

        // Delete existing providers first (due to foreign key constraints)
        await Provider.destroy({ truncate: true, restartIdentity: true });
        // Delete existing provider users
        await User.destroy({ where: { role: 'provider' }, force: true });
        await User.destroy({ where: { role: 'beautician' }, force: true });
        console.log('Existing providers removed...');

        // Create provider users with known passwords
        const providerPassword = await bcrypt.hash('provider123', 10);
        const beauticianPassword = await bcrypt.hash('beautician123', 10);

        // Create provider user
        const providerUser = await User.create({
            firstName: 'Test',
            lastName: 'Provider',
            email: 'provider@test.com',
            password: providerPassword,
            role: 'provider',
            isActive: true,
            isVerified: true,
            phone: '+254712345678'
        });

        // Create beautician user
        const beauticianUser = await User.create({
            firstName: 'Test',
            lastName: 'Beautician',
            email: 'beautician@test.com',
            password: beauticianPassword,
            role: 'beautician',
            isActive: true,
            isVerified: true,
            phone: '+254723456789'
        });

        console.log('Created provider users with known passwords:');
        console.log('- Provider:', providerUser.email, '(password: provider123)');
        console.log('- Beautician:', beauticianUser.email, '(password: beautician123)');

        // Create provider profiles
        const providerProfile = await Provider.create({
            userId: providerUser.id,
            businessName: 'Test Provider Salon',
            bio: 'Test provider for development purposes',
            specializations: ['Hair', 'Makeup'],
            location: { type: 'Point', coordinates: [36.8219, -1.2921] },
            serviceType: 'both',
            services: [
                { name: 'Haircut', description: 'Basic haircut', duration: 30, price: 1000, category: 'Hair' },
                { name: 'Makeup', description: 'Basic makeup', duration: 60, price: 2000, category: 'Makeup' }
            ],
            portfolio: [],
            rating: { average: 4.5, count: 10 },
            stats: { totalBookings: 20, completedBookings: 18, totalEarnings: 20000 },
            isVisible: true
        });

        const beauticianProfile = await Provider.create({
            userId: beauticianUser.id,
            businessName: 'Test Beautician Studio',
            bio: 'Test beautician for development purposes',
            specializations: ['Nails', 'Spa'],
            location: { type: 'Point', coordinates: [36.8219, -1.2921] },
            serviceType: 'studio',
            services: [
                { name: 'Manicure', description: 'Basic manicure', duration: 30, price: 500, category: 'Nails' },
                { name: 'Massage', description: 'Relaxing massage', duration: 60, price: 1500, category: 'Spa' }
            ],
            portfolio: [],
            rating: { average: 4.8, count: 15 },
            stats: { totalBookings: 25, completedBookings: 24, totalEarnings: 30000 },
            isVisible: true
        });

        console.log('Created provider profiles:');
        console.log('- Provider:', providerProfile.businessName);
        console.log('- Beautician:', beauticianProfile.businessName);

        console.log('\n✅ Reset completed successfully!');
        console.log('\nYou can now login to the provider dashboard with:');
        console.log('- Provider:', providerUser.email, '(password: provider123)');
        console.log('- Beautician:', beauticianUser.email, '(password: beautician123)');
        process.exit(0);
    } catch (error) {
        console.error('Error resetting providers:', error);
        process.exit(1);
    }
};

resetProviders();