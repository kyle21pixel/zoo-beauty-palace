const { sequelize } = require('./config/database');
const User = require('./models/User');
const Provider = require('./models/Provider');
const Booking = require('./models/Booking');
const crypto = require('crypto');

const createTestData = async () => {
    try {
        await sequelize.authenticate();
        console.log('Database connected.');

        // Sync database to apply model changes (e.g. Provider location type change)
        await sequelize.sync({ alter: true });
        console.log('Database synced.');

        const randomSuffix = Math.floor(Math.random() * 10000);

        // 1. Create Provider User
        const providerUser = await User.create({
            firstName: 'Test',
            lastName: 'Provider',
            email: `provider_${Date.now()}_${randomSuffix}@test.com`,
            password: 'password123',
            phone: `+254700${Math.floor(Math.random() * 1000000)}`,
            role: 'provider',
            isActive: true
        });

        const providerProfile = await Provider.create({
            userId: providerUser.id,
            businessName: 'Test Salon',
            serviceType: 'on-site',
            specializations: ['Hair', 'Nails'],
            rating: { average: 4.5, count: 10 },
            services: [{ name: 'Manicure', price: 1500, duration: 60 }],
            location: { type: 'Point', coordinates: [36.8219, -1.2921] }, // Nairobi
            isOnline: true,
            isVisible: true
        });

        console.log(`Created Provider: ${providerUser.email} / password123`);

        // 2. Create Beautician User
        const beauticianUser = await User.create({
            firstName: 'Test',
            lastName: 'Beautician',
            email: `beautician_${Date.now()}_${randomSuffix}@test.com`,
            password: 'password123',
            phone: `+254701${Math.floor(Math.random() * 1000000)}`,
            role: 'beautician',
            isActive: true
        });

        const beauticianProfile = await Provider.create({
            userId: beauticianUser.id,
            businessName: 'Test Beautician Services',
            serviceType: 'on-route',
            specializations: ['Makeup', 'Massage'],
            rating: { average: 4.8, count: 5 },
            services: [{ name: 'Full Makeup', price: 3000, duration: 90 }],
            location: { type: 'Point', coordinates: [36.8172, -1.2864] },
            isOnline: true,
            isVisible: true
        });

        console.log(`Created Beautician: ${beauticianUser.email} / password123`);

        // 3. Create Client User
        const clientUser = await User.create({
            firstName: 'Test',
            lastName: 'Client',
            email: `client_${Date.now()}_${randomSuffix}@test.com`,
            password: 'password123',
            phone: `+254702${Math.floor(Math.random() * 1000000)}`,
            role: 'client',
            isActive: true
        });

        console.log(`Created Client: ${clientUser.email} / password123`);

        // 4. Create Booking for Provider
        await Booking.create({
            clientId: clientUser.id,
            providerId: providerProfile.id,
            service: { name: 'Manicure', price: 1500 },
            scheduledDate: new Date().toISOString().split('T')[0],
            scheduledTime: '10:00 AM',
            location: { address: 'Test Salon Location' },
            status: 'pending',
            payment: { amount: 1500, status: 'pending' }
        });

        console.log('Created Booking for Provider');

        // 5. Create Booking for Beautician
        await Booking.create({
            clientId: clientUser.id,
            providerId: beauticianProfile.id,
            service: { name: 'Full Makeup', price: 3000 },
            scheduledDate: new Date().toISOString().split('T')[0],
            scheduledTime: '02:00 PM',
            location: { address: 'Client Home Location' },
            status: 'pending',
            payment: { amount: 3000, status: 'pending' }
        });

        console.log('Created Booking for Beautician');

        console.log('Verification Data Created Successfully!');
        process.exit(0);

    } catch (error) {
        console.error('Error creating test data:', error);
        process.exit(1);
    }
};

createTestData();
