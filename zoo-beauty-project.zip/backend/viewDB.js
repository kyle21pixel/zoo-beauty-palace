const { Sequelize } = require('sequelize');
const path = require('path');
const User = require('./models/User');
const Provider = require('./models/Provider');
require('dotenv').config();

// Connect to SQLite
const sequelize = new Sequelize({
    dialect: 'sqlite',
    storage: path.join(__dirname, 'database.sqlite'),
    logging: false
});

const viewDatabase = async () => {
    try {
        await sequelize.authenticate();
        console.log('\n📊 --- DATABASE CONTENTS --- 📊\n');

        // 1. View Users
        const users = await User.findAll({ raw: true });
        console.log(`👥 USERS (${users.length}):`);
        console.table(users.map(u => ({
            ID: u.id,
            Name: `${u.firstName} ${u.lastName}`,
            Email: u.email,
            Role: u.role,
            Active: u.isActive ? '✅' : '❌'
        })));

        // 2. View Providers
        const providers = await Provider.findAll({ raw: true });
        console.log(`\n💼 PROVIDERS (${providers.length}):`);
        if (providers.length > 0) {
            console.table(providers.map(p => ({
                ID: p.id,
                UserID: p.userId,
                Business: p.businessName
            })));
        } else {
            console.log("No providers found.");
        }

        console.log('\n-----------------------------\n');
        process.exit(0);
    } catch (error) {
        console.error('Error viewing database:', error);
        process.exit(1);
    }
};

viewDatabase();
