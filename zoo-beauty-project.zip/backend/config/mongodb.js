const mongoose = require('mongoose');
const dotenv = require('dotenv');

dotenv.config();

const connectDB = async () => {
  try {
    // Check if MONGODB_URI is set
    const mongoURI = process.env.MONGODB_URI || 'mongodb://localhost:27017/zoobeauty';
    
    console.log('Attempting to connect to MongoDB...');
    console.log(`MongoDB URI: ${mongoURI.replace(/\/\/.*@/, '//****:****@')}`); // Hide credentials in logs
    
    // Connect to MongoDB
    const conn = await mongoose.connect(mongoURI);

    console.log(`✅ MongoDB Connected: ${conn.connection.host}`);
    return true;
  } catch (error) {
    console.error('❌ MongoDB connection failed:', error.message);
    console.error('❌ Full error:', error);
    
    // Provide specific error guidance
    if (error.message.includes('ECONNREFUSED')) {
      console.error('❌ Connection refused - check if MongoDB is running');
    } else if (error.message.includes('ENOTFOUND')) {
      console.error('❌ Host not found - check your MongoDB host configuration');
    } else if (error.message.includes('AuthenticationFailed')) {
      console.error('❌ Authentication failed - check your MongoDB credentials');
    }
    
    return false;
  }
};

// Export for use in other modules
module.exports = { connectDB };

// For immediate testing
if (require.main === module) {
  connectDB().then(success => {
    if (success) {
      console.log('✅ MongoDB connection test successful');
    } else {
      console.log('❌ MongoDB connection test failed');
    }
    process.exit(success ? 0 : 1);
  });
}