const redis = require('redis');

// Create Redis client
const redisClient = redis.createClient({
  host: process.env.REDIS_HOST || '127.0.0.1',
  port: process.env.REDIS_PORT || 6379,
  // Add password if needed
  // password: process.env.REDIS_PASSWORD,
  retry_strategy: (options) => {
    if (options.error && options.error.code === 'ECONNREFUSED') {
      // End reconnecting on a specific error and flush all commands with
      // a individual error
      return new Error('The server refused the connection');
    }
    if (options.total_retry_time > 1000 * 60 * 60) {
      // End reconnecting after a specific timeout and flush all commands
      // with a individual error
      return new Error('Retry time exhausted');
    }
    if (options.attempt > 10) {
      // End reconnecting with built in error
      return undefined;
    }
    // reconnect after
    return Math.min(options.attempt * 100, 3000);
  }
});

// Handle Redis connection events
redisClient.on('connect', () => {
  console.log('Redis client connected');
});

redisClient.on('error', (err) => {
  console.log('Redis client error:', err);
});

// Promisify Redis methods for easier async/await usage
const getAsync = (key) => {
  return new Promise((resolve, reject) => {
    redisClient.get(key, (err, result) => {
      if (err) reject(err);
      else resolve(result);
    });
  });
};

const setAsync = (key, value, expiry = 300) => {
  return new Promise((resolve, reject) => {
    if (expiry) {
      redisClient.setex(key, expiry, value, (err, result) => {
        if (err) reject(err);
        else resolve(result);
      });
    } else {
      redisClient.set(key, value, (err, result) => {
        if (err) reject(err);
        else resolve(result);
      });
    }
  });
};

const delAsync = (key) => {
  return new Promise((resolve, reject) => {
    redisClient.del(key, (err, result) => {
      if (err) reject(err);
      else resolve(result);
    });
  });
};

module.exports = {
  redisClient,
  getAsync,
  setAsync,
  delAsync
};