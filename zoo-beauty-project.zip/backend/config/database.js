const { Sequelize } = require('sequelize');
const dotenv = require('dotenv');
const path = require('path');

dotenv.config();

// Database configuration
// Priority:
// 1. DATABASE_URL (Supabase/Postgres)
// 2. Local SQLite fallback

let sequelize;

if (process.env.DATABASE_URL && process.env.DATABASE_URL.includes('supabase')) {
    // Supabase / PostgreSQL Connection
    sequelize = new Sequelize(process.env.DATABASE_URL, {
        dialect: 'postgres',
        logging: console.log, // Enable logging to see connection details
        dialectOptions: {
            ssl: {
                require: true,
                rejectUnauthorized: false // Required for Supabase in some environments
            }
        },
        pool: {
            max: 5,
            min: 0,
            acquire: 30000,
            idle: 10000
        }
    });
} else if (process.env.DATABASE_URL) {
    // Other PostgreSQL Connection
    sequelize = new Sequelize(process.env.DATABASE_URL, {
        dialect: 'postgres',
        logging: console.log,
        pool: {
            max: 5,
            min: 0,
            acquire: 30000,
            idle: 10000
        }
    });
} else {
    // Fallback to SQLite (Development)
    sequelize = new Sequelize({
        dialect: 'sqlite',
        storage: path.join(__dirname, '..', 'database.sqlite'),
        logging: console.log
    });
}

const connectDB = async () => {
    try {
        console.log('Attempting to connect to database...');
        
        // Test the connection
        await sequelize.authenticate();

        // Determine database type for logging
        const dbType = sequelize.getDialect();
        console.log(`✅ ${dbType.toUpperCase()} Database Connected Successfully`);
        
        // Log connection details for debugging
        if (process.env.DATABASE_URL) {
            console.log(`Connected to: ${process.env.DATABASE_URL.split('@')[1]}`);
        }

        // Sync models with database
        console.log('Syncing database models...');
        await sequelize.sync({ alter: true });
        console.log('✅ Database Models Synced');
        return true;
    } catch (error) {
        console.error('❌ Database connection failed:', error.message);
        console.error('❌ Full error:', error);
        console.error('❌ To fix: Check database configuration');
        
        // Try to provide more specific error information
        if (error.message.includes('connect ECONNREFUSED')) {
            console.error('❌ Connection refused - check if your database server is running');
        } else if (error.message.includes('ENOTFOUND')) {
            console.error('❌ Host not found - check your database host configuration');
        } else if (error.message.includes('password authentication failed')) {
            console.error('❌ Authentication failed - check your database credentials');
        } else if (error.message.includes('SSL')) {
            console.error('❌ SSL connection issue - check your SSL configuration');
        }
        
        return false;
    }
};
// Export for use in other modules
module.exports = { sequelize, connectDB };

// For immediate testing
if (require.main === module) {
    connectDB().then(success => {
        if (success) {
            console.log('✅ Database connection test successful');
        } else {
            console.log('❌ Database connection test failed');
        }
        process.exit(success ? 0 : 1);
    });
}