
const { sequelize } = require('./config/database');
const User = require('./models/User');

async function checkUsers() {
    try {
        const users = await User.findAll();
        console.log('--- Current Users ---');
        users.forEach(u => console.log(`${u.id}: ${u.email} (${u.role})`));

        // Check if admin exists
        const admin = users.find(u => u.email === 'admin@test.com');
        if (!admin) {
            console.log('\nCreating Admin...');
            await User.create({
                email: 'admin@test.com',
                password: 'password123',
                role: 'admin',
                firstName: 'Super',
                lastName: 'Admin',
                phone: '+254700000000',
                avatar: 'https://i.pravatar.cc/150?img=15',
                isActive: true,
                isVerified: true
            });
            console.log('Admin created successfully.');
        } else {
            console.log('\nAdmin already exists.');
        }
    } catch (e) {
        console.error(e);
    } finally {
        await sequelize.close();
    }
}

checkUsers();
