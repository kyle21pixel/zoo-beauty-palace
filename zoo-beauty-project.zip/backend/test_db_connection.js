const { Sequelize } = require('sequelize');
const dotenv = require('dotenv');
const path = require('path');

// Load environment variables
const result = dotenv.config();

if (result.error) {
    console.error('❌ Error loading .env file:', result.error);
}

console.log('--- Database Connection Test ---');
console.log('DATABASE_URL starts with:', process.env.DATABASE_URL ? process.env.DATABASE_URL.substring(0, 15) + '...' : 'undefined');

if (!process.env.DATABASE_URL) {
    console.error('❌ DATABASE_URL is not set in your .env file.');
    console.error('Please add it like: DATABASE_URL=postgresql://postgres:password@db.subdomain.supabase.co:5432/postgres');
    process.exit(1);
}

const sequelize = new Sequelize(process.env.DATABASE_URL, {
    dialect: 'postgres',
    logging: console.log, // Enable logging to see what's happening
    dialectOptions: {
        ssl: {
            require: true,
            rejectUnauthorized: false
        }
    }
});

async function testConnection() {
    try {
        await sequelize.authenticate();
        console.log('✅ Connection has been established successfully.');
    } catch (error) {
        console.error('❌ Unable to connect to the database:', error);
    } finally {
        await sequelize.close();
    }
}

testConnection();
