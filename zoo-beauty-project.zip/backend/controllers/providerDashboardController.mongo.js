const Provider = require('../models/Provider.mongo');
const User = require('../models/User.mongo');
const Booking = require('../models/Booking.mongo');
const Assignment = require('../models/Assignment.mongo');
const asyncHandler = require('../middleware/asyncHandler');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const { getAsync, setAsync } = require('../config/cache');

// ==========================================
// DASHBOARD OVERVIEW & ANALYTICS
// ==========================================

// @desc    Get dashboard overview stats
// @route   GET /api/providers/dashboard/overview
// @access  Private (Provider)
exports.getDashboardOverview = asyncHandler(async (req, res) => {
    const provider = await Provider.findOne({ userId: req.user.id });

    if (!provider) {
        return res.status(404).json({
            success: false,
            message: 'Provider profile not found'
        });
    }

    // Try to get cached data first
    const cacheKey = `provider_dashboard_${provider._id}`;
    try {
        const cachedData = await getAsync(cacheKey);
        if (cachedData) {
            const parsedData = JSON.parse(cachedData);
            return res.json({
                success: true,
                data: parsedData
            });
        }
    } catch (cacheErr) {
        console.warn('Cache read error:', cacheErr);
    }

    // Get current date ranges
    const now = new Date();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const startOfWeek = new Date(now.setDate(now.getDate() - now.getDay()));
    const startOfToday = new Date(now.setHours(0, 0, 0, 0));

    // Total Revenue (All completed bookings)
    const totalRevenueResult = await Booking.aggregate([
        {
            $match: {
                providerId: provider._id,
                status: 'completed'
            }
        },
        {
            $group: {
                _id: null,
                totalRevenue: { $sum: '$payment.providerEarnings' }
            }
        }
    ]);

    // This Month Earnings
    const monthEarningsResult = await Booking.aggregate([
        {
            $match: {
                providerId: provider._id,
                status: 'completed',
                createdAt: { $gte: startOfMonth }
            }
        },
        {
            $group: {
                _id: null,
                monthEarnings: { $sum: '$payment.providerEarnings' }
            }
        }
    ]);

    // This Week Earnings
    const weekEarningsResult = await Booking.aggregate([
        {
            $match: {
                providerId: provider._id,
                status: 'completed',
                createdAt: { $gte: startOfWeek }
            }
        },
        {
            $group: {
                _id: null,
                weekEarnings: { $sum: '$payment.providerEarnings' }
            }
        }
    ]);

    // Today Earnings
    const todayEarningsResult = await Booking.aggregate([
        {
            $match: {
                providerId: provider._id,
                status: 'completed',
                createdAt: { $gte: startOfToday }
            }
        },
        {
            $group: {
                _id: null,
                todayEarnings: { $sum: '$payment.providerEarnings' }
            }
        }
    ]);

    // Active Staff Count (Beauticians assigned to this provider)
    const activeStaffCount = await Assignment.countDocuments({
        providerId: provider._id,
        status: { $in: ['pending', 'accepted', 'in-progress'] }
    });

    // Pending Bookings
    const pendingBookingsCount = await Booking.countDocuments({
        providerId: provider._id,
        status: 'pending'
    });

    // Upcoming Bookings (Accepted, scheduled for future)
    const upcomingBookingsCount = await Booking.countDocuments({
        providerId: provider._id,
        status: { $in: ['accepted', 'confirmed'] },
        scheduledDate: { $gte: new Date() }
    });

    // Total Bookings
    const totalBookings = await Booking.countDocuments({
        providerId: provider._id
    });

    // Completed Bookings
    const completedBookings = await Booking.countDocuments({
        providerId: provider._id,
        status: 'completed'
    });

    // Acceptance Rate
    const acceptedBookings = await Booking.countDocuments({
        providerId: provider._id,
        status: { $in: ['accepted', 'completed', 'in-progress'] }
    });
    const acceptanceRate = totalBookings > 0 ? ((acceptedBookings / totalBookings) * 100).toFixed(1) : 0;

    const responseData = {
        stats: {
            totalRevenue: parseFloat(totalRevenueResult[0]?.totalRevenue || 0),
            monthEarnings: parseFloat(monthEarningsResult[0]?.monthEarnings || 0),
            weekEarnings: parseFloat(weekEarningsResult[0]?.weekEarnings || 0),
            todayEarnings: parseFloat(todayEarningsResult[0]?.todayEarnings || 0),
            activeStaff: activeStaffCount,
            pendingBookings: pendingBookingsCount,
            upcomingBookings: upcomingBookingsCount,
            totalBookings,
            completedBookings,
            acceptanceRate: parseFloat(acceptanceRate)
        },
        provider: {
            businessName: provider.businessName,
            rating: provider.rating,
            reviewCount: provider.reviewCount,
            isOnline: provider.isOnline
        }
    };

    // Cache the response for 5 minutes
    try {
        await setAsync(cacheKey, JSON.stringify(responseData), 300);
    } catch (cacheErr) {
        console.warn('Cache write error:', cacheErr);
    }

    res.json({
        success: true,
        data: responseData
    });
});

// @desc    Get performance chart data
// @route   GET /api/providers/dashboard/chart
// @access  Private (Provider)
exports.getPerformanceChart = asyncHandler(async (req, res) => {
    const provider = await Provider.findOne({ userId: req.user.id });

    if (!provider) {
        return res.status(404).json({
            success: false,
            message: 'Provider profile not found'
        });
    }

    const { period = 'week' } = req.query; // week, month, year

    let startDate, groupFormat, dateFormat;
    
    const now = new Date();
    
    if (period === 'week') {
        startDate = new Date(now.setDate(now.getDate() - 7));
        groupFormat = { $dateToString: { format: '%Y-%m-%d', date: '$createdAt' } };
        dateFormat = 'YYYY-MM-DD';
    } else if (period === 'month') {
        startDate = new Date(now.setMonth(now.getMonth() - 1));
        groupFormat = { $dateToString: { format: '%Y-%m-%d', date: '$createdAt' } };
        dateFormat = 'YYYY-MM-DD';
    } else {
        startDate = new Date(now.setFullYear(now.getFullYear() - 1));
        groupFormat = { $dateToString: { format: '%Y-%m', date: '$createdAt' } };
        dateFormat = 'YYYY-MM';
    }

    // Get bookings data
    const bookingsData = await Booking.aggregate([
        {
            $match: {
                providerId: provider._id,
                createdAt: { $gte: startDate }
            }
        },
        {
            $group: {
                _id: groupFormat,
                bookings: { $sum: 1 },
                earnings: { $sum: '$payment.providerEarnings' }
            }
        },
        {
            $sort: { _id: 1 }
        }
    ]);

    // Get reviews data
    const reviewsData = await Booking.aggregate([
        {
            $match: {
                providerId: provider._id,
                status: 'completed',
                reviewId: { $exists: true, $ne: null },
                createdAt: { $gte: startDate }
            }
        },
        {
            $lookup: {
                from: 'reviews',
                localField: 'reviewId',
                foreignField: '_id',
                as: 'review'
            }
        },
        {
            $unwind: '$review'
        },
        {
            $group: {
                _id: groupFormat,
                avgRating: { $avg: '$review.rating' },
                reviewCount: { $sum: 1 }
            }
        },
        {
            $sort: { _id: 1 }
        }
    ]);

    // Format the data for the chart
    const chartData = [];
    const currentDate = new Date(startDate);
    
    // Generate all dates in the range
    while (currentDate <= now) {
        const dateStr = period === 'year' 
            ? `${currentDate.getFullYear()}-${String(currentDate.getMonth() + 1).padStart(2, '0')}`
            : `${currentDate.getFullYear()}-${String(currentDate.getMonth() + 1).padStart(2, '0')}-${String(currentDate.getDate()).padStart(2, '0')}`;
            
        const bookingEntry = bookingsData.find(b => b._id === dateStr);
        const reviewEntry = reviewsData.find(r => r._id === dateStr);
        
        chartData.push({
            date: dateStr,
            bookings: bookingEntry ? bookingEntry.bookings : 0,
            earnings: bookingEntry ? bookingEntry.earnings : 0,
            avgRating: reviewEntry ? reviewEntry.avgRating : 0
        });
        
        if (period === 'week' || period === 'month') {
            currentDate.setDate(currentDate.getDate() + 1);
        } else {
            currentDate.setMonth(currentDate.getMonth() + 1);
        }
    }

    res.json({
        success: true,
        data: {
            chartData,
            period
        }
    });
});

// @desc    Get advanced analytics
// @route   GET /api/providers/analytics/advanced
// @access  Private (Provider)
exports.getAdvancedAnalytics = asyncHandler(async (req, res) => {
    const provider = await Provider.findOne({ userId: req.user.id });

    if (!provider) {
        return res.status(404).json({
            success: false,
            message: 'Provider profile not found'
        });
    }

    // Top services
    const topServices = await Booking.aggregate([
        {
            $match: {
                providerId: provider._id,
                status: 'completed'
            }
        },
        {
            $group: {
                _id: '$service',
                count: { $sum: 1 },
                totalEarnings: { $sum: '$payment.providerEarnings' }
            }
        },
        {
            $sort: { count: -1 }
        },
        {
            $limit: 10
        }
    ]);

    // Client metrics
    const clientMetrics = await Booking.aggregate([
        {
            $match: {
                providerId: provider._id,
                status: 'completed'
            }
        },
        {
            $group: {
                _id: '$clientId',
                bookingCount: { $sum: 1 },
                totalSpent: { $sum: '$payment.amount' }
            }
        },
        {
            $sort: { bookingCount: -1 }
        },
        {
            $limit: 10
        },
        {
            $lookup: {
                from: 'users',
                localField: '_id',
                foreignField: '_id',
                as: 'clientInfo'
            }
        },
        {
            $unwind: '$clientInfo'
        },
        {
            $project: {
                clientId: '$_id',
                firstName: '$clientInfo.firstName',
                lastName: '$clientInfo.lastName',
                bookingCount: 1,
                totalSpent: 1
            }
        }
    ]);

    // Peak hours analysis
    const peakHours = await Booking.aggregate([
        {
            $match: {
                providerId: provider._id,
                status: 'completed'
            }
        },
        {
            $project: {
                hour: { $hour: '$scheduledDate' }
            }
        },
        {
            $group: {
                _id: '$hour',
                count: { $sum: 1 }
            }
        },
        {
            $sort: { count: -1 }
        },
        {
            $limit: 10
        }
    ]);

    // Monthly growth
    const monthlyGrowth = await Booking.aggregate([
        {
            $match: {
                providerId: provider._id,
                status: 'completed'
            }
        },
        {
            $group: {
                _id: {
                    year: { $year: '$createdAt' },
                    month: { $month: '$createdAt' }
                },
                count: { $sum: 1 },
                earnings: { $sum: '$payment.providerEarnings' }
            }
        },
        {
            $sort: { '_id.year': 1, '_id.month': 1 }
        }
    ]);

    res.json({
        success: true,
        data: {
            topServices,
            clientMetrics,
            peakHours,
            monthlyGrowth
        }
    });
});

// ==========================================
// STAFF MANAGEMENT
// ==========================================

// @desc    Get staff members
// @route   GET /api/providers/staff
// @access  Private (Provider)
exports.getStaff = asyncHandler(async (req, res) => {
    const { status, page = 1, limit = 20 } = req.query;

    const where = {
        providerId: req.user.id
    };

    if (status) {
        where.status = status;
    }

    const offset = (parseInt(page) - 1) * parseInt(limit);

    const [count, staff] = await Promise.all([
        Assignment.countDocuments(where),
        Assignment.find(where)
            .populate('assignedToId', 'firstName lastName email phone avatar')
            .sort({ createdAt: -1 })
            .skip(offset)
            .limit(parseInt(limit))
    ]);

    res.json({
        success: true,
        data: {
            staff,
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total: count,
                pages: Math.ceil(count / parseInt(limit))
            }
        }
    });
});

// @desc    Add staff member
// @route   POST /api/providers/staff
// @access  Private (Provider)
exports.addStaff = asyncHandler(async (req, res) => {
    const { beauticianId, role, permissions } = req.body;

    // Check if assignment already exists
    const existingAssignment = await Assignment.findOne({
        providerId: req.user.id,
        assignedToId: beauticianId
    });

    if (existingAssignment) {
        return res.status(400).json({
            success: false,
            message: 'This beautician is already assigned to your business'
        });
    }

    // Create assignment
    const assignment = new Assignment({
        providerId: req.user.id,
        assignedToId: beauticianId,
        role: role || 'beautician',
        permissions: permissions || [],
        status: 'pending'
    });

    await assignment.save();

    // Populate the assigned beautician details
    await assignment.populate('assignedToId', 'firstName lastName email phone avatar');

    res.status(201).json({
        success: true,
        message: 'Staff member added successfully',
        data: { assignment }
    });
});

// @desc    Get staff member
// @route   GET /api/providers/staff/:id
// @access  Private (Provider)
exports.getStaffMember = asyncHandler(async (req, res) => {
    const assignment = await Assignment.findById(req.params.id)
        .populate('assignedToId', 'firstName lastName email phone avatar');

    if (!assignment || assignment.providerId.toString() !== req.user.id) {
        return res.status(404).json({
            success: false,
            message: 'Staff member not found'
        });
    }

    res.json({
        success: true,
        data: { assignment }
    });
});

// @desc    Update staff member
// @route   PUT /api/providers/staff/:id
// @access  Private (Provider)
exports.updateStaff = asyncHandler(async (req, res) => {
    const { role, permissions, status } = req.body;

    const assignment = await Assignment.findById(req.params.id);

    if (!assignment || assignment.providerId.toString() !== req.user.id) {
        return res.status(404).json({
            success: false,
            message: 'Staff member not found'
        });
    }

    // Update assignment
    if (role !== undefined) assignment.role = role;
    if (permissions !== undefined) assignment.permissions = permissions;
    if (status !== undefined) assignment.status = status;

    await assignment.save();

    // Populate the assigned beautician details
    await assignment.populate('assignedToId', 'firstName lastName email phone avatar');

    res.json({
        success: true,
        message: 'Staff member updated successfully',
        data: { assignment }
    });
});

// @desc    Remove staff member
// @route   DELETE /api/providers/staff/:id
// @access  Private (Provider)
exports.removeStaff = asyncHandler(async (req, res) => {
    const assignment = await Assignment.findById(req.params.id);

    if (!assignment || assignment.providerId.toString() !== req.user.id) {
        return res.status(404).json({
            success: false,
            message: 'Staff member not found'
        });
    }

    await assignment.remove();

    res.json({
        success: true,
        message: 'Staff member removed successfully'
    });
});

// ==========================================
// BOOKING DISPATCH
// ==========================================

// @desc    Get available staff
// @route   GET /api/providers/bookings/available-staff
// @access  Private (Provider)
exports.getAvailableStaff = asyncHandler(async (req, res) => {
    const availableStaff = await Assignment.find({
        providerId: req.user.id,
        status: 'accepted'
    }).populate('assignedToId', 'firstName lastName email phone avatar rating reviewCount');

    res.json({
        success: true,
        data: { availableStaff }
    });
});

// @desc    Assign booking to staff
// @route   POST /api/providers/bookings/:id/assign
// @access  Private (Provider)
exports.assignBooking = asyncHandler(async (req, res) => {
    const { beauticianId } = req.body;

    // Find the booking
    const booking = await Booking.findById(req.params.id);

    if (!booking) {
        return res.status(404).json({
            success: false,
            message: 'Booking not found'
        });
    }

    if (booking.providerId.toString() !== req.user.id) {
        return res.status(403).json({
            success: false,
            message: 'Not authorized to assign this booking'
        });
    }

    // Update booking with assigned beautician
    booking.assignedToId = beauticianId;
    booking.status = 'assigned';

    await booking.save();

    res.json({
        success: true,
        message: 'Booking assigned successfully',
        data: { booking }
    });
});

// @desc    Reassign booking
// @route   PUT /api/providers/bookings/:id/reassign
// @access  Private (Provider)
exports.reassignBooking = asyncHandler(async (req, res) => {
    const { newBeauticianId, reason } = req.body;

    // Find the booking
    const booking = await Booking.findById(req.params.id);

    if (!booking) {
        return res.status(404).json({
            success: false,
            message: 'Booking not found'
        });
    }

    if (booking.providerId.toString() !== req.user.id) {
        return res.status(403).json({
            success: false,
            message: 'Not authorized to reassign this booking'
        });
    }

    // Update booking with new assigned beautician
    booking.assignedToId = newBeauticianId;
    booking.reassignmentReason = reason;
    booking.reassignedAt = new Date();

    await booking.save();

    res.json({
        success: true,
        message: 'Booking reassigned successfully',
        data: { booking }
    });
});

// ==========================================
// FINANCIAL
// ==========================================

// @desc    Get revenue data
// @route   GET /api/providers/revenue
// @access  Private (Provider)
exports.getRevenue = asyncHandler(async (req, res) => {
    const { page = 1, limit = 20 } = req.query;

    const where = {
        providerId: req.user.id,
        status: 'completed'
    };

    const offset = (parseInt(page) - 1) * parseInt(limit);

    const [count, revenue] = await Promise.all([
        Booking.countDocuments(where),
        Booking.find(where)
            .populate('clientId', 'firstName lastName email')
            .sort({ createdAt: -1 })
            .skip(offset)
            .limit(parseInt(limit))
    ]);

    res.json({
        success: true,
        data: {
            revenue,
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total: count,
                pages: Math.ceil(count / parseInt(limit))
            }
        }
    });
});

// @desc    Request payout
// @route   POST /api/providers/payout/request
// @access  Private (Provider)
exports.requestPayout = asyncHandler(async (req, res) => {
    const { amount, notes } = req.body;

    const provider = await Provider.findOne({ userId: req.user.id });

    if (!provider) {
        return res.status(404).json({
            success: false,
            message: 'Provider profile not found'
        });
    }

    // In a real implementation, you would integrate with a payment processor here
    // For now, we'll just record the payout request

    res.json({
        success: true,
        message: 'Payout request submitted successfully',
        data: {
            requestId: crypto.randomBytes(16).toString('hex'),
            amount,
            notes,
            status: 'pending',
            requestedAt: new Date()
        }
    });
});