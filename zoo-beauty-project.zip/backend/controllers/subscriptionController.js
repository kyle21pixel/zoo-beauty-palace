const SubscriptionPlan = require('../models/SubscriptionPlan');
const Provider = require('../models/Provider');
const Payment = require('../models/Payment');
const Notification = require('../models/Notification');
const { asyncHandler } = require('../middleware/errorHandler');

// @desc    Get all subscription plans
// @route   GET /api/subscriptions/plans
// @access  Public
exports.getPlans = asyncHandler(async (req, res) => {
    const plans = await SubscriptionPlan.getActivePlans();

    res.json({
        success: true,
        data: { plans }
    });
});

// @desc    Subscribe to a plan
// @route   POST /api/subscriptions/subscribe
// @access  Private (Provider)
exports.subscribe = asyncHandler(async (req, res) => {
    const { planId, paymentMethodId } = req.body;

    const plan = await SubscriptionPlan.findByPk(planId);

    if (!plan || !plan.isActive) {
        return res.status(404).json({
            success: false,
            message: 'Subscription plan not found'
        });
    }

    const provider = await Provider.findOne({ where: { userId: req.user.id } });

    if (!provider) {
        return res.status(404).json({
            success: false,
            message: 'Provider profile not found'
        });
    }

    // TODO: Process payment with Stripe/PayStack
    // For now, we'll simulate successful payment

    const transactionId = Payment.generateTransactionId(); // Assuming Payment.generateTransactionId is sync or awaited

    // Create payment record
    const payment = await Payment.create({
        transactionId,
        type: 'subscription',
        userId: req.user.id,
        relatedId: planId,
        amount: plan.price,
        currency: plan.currency,
        status: 'completed',
        paymentMethod: 'card',
        gateway: 'stripe'
    });

    // Update provider subscription
    const startDate = new Date();
    const endDate = new Date();
    endDate.setDate(endDate.getDate() + plan.duration);

    provider.subscription = {
        planId: plan.id, // Ensure plan.id is used
        status: 'active',
        startDate,
        endDate,
        autoRenew: true
    };
    // provider.isVisible is handled by beforeSave hook in Provider model
    await provider.save();

    // Create notification
    await Notification.createNotification(
        req.user.id,
        'subscription_activated',
        'Subscription Activated',
        `Your ${plan.name} subscription is now active`,
        { planId, endDate },
        '/subscription'
    );

    res.json({
        success: true,
        message: 'Subscription activated successfully',
        data: {
            subscription: provider.subscription,
            payment
        }
    });
});

// @desc    Get current subscription
// @route   GET /api/subscriptions/current
// @access  Private (Provider)
exports.getCurrentSubscription = asyncHandler(async (req, res) => {
    const provider = await Provider.findOne({
        where: { userId: req.user.id }
    });

    if (!provider) {
        return res.status(404).json({
            success: false,
            message: 'Provider profile not found'
        });
    }

    let subscriptionData = provider.subscription;
    if (subscriptionData && subscriptionData.planId) {
        const plan = await SubscriptionPlan.findByPk(subscriptionData.planId);
        if (plan) {
            subscriptionData.planDetails = plan; // Attach plan details to the subscription object
        }
    }

    res.json({
        success: true,
        data: { subscription: subscriptionData }
    });
});

// @desc    Cancel subscription
// @route   PUT /api/subscriptions/cancel
// @access  Private (Provider)
exports.cancelSubscription = asyncHandler(async (req, res) => {
    const provider = await Provider.findOne({ where: { userId: req.user.id } });

    if (!provider) {
        return res.status(404).json({
            success: false,
            message: 'Provider profile not found'
        });
    }

    if (!provider.subscription || provider.subscription.status !== 'active') {
        return res.status(400).json({
            success: false,
            message: 'No active subscription to cancel'
        });
    }

    const subscription = { ...provider.subscription }; // Create a copy
    subscription.autoRenew = false;
    provider.subscription = subscription;
    await provider.save();

    res.json({
        success: true,
        message: 'Subscription will not auto-renew. You can continue using the service until the end date.',
        data: { subscription: provider.subscription }
    });
});

// @desc    Renew subscription
// @route   POST /api/subscriptions/renew
// @access  Private (Provider)
exports.renewSubscription = asyncHandler(async (req, res) => {
    const { planId } = req.body;

    const provider = await Provider.findOne({ where: { userId: req.user.id } });

    if (!provider) {
        return res.status(404).json({
            success: false,
            message: 'Provider profile not found'
        });
    }

    const plan = await SubscriptionPlan.findByPk(planId || (provider.subscription ? provider.subscription.planId : null));

    if (!plan || !plan.isActive) {
        return res.status(404).json({
            success: false,
            message: 'Subscription plan not found'
        });
    }

    // TODO: Process payment

    const transactionId = Payment.generateTransactionId();

    await Payment.create({
        transactionId,
        type: 'subscription',
        userId: req.user.id,
        relatedId: plan.id,
        amount: plan.price,
        currency: plan.currency,
        status: 'completed',
        paymentMethod: 'card',
        gateway: 'stripe'
    });

    // Update subscription
    const startDate = new Date();
    const endDate = new Date();
    endDate.setDate(endDate.getDate() + plan.duration);

    provider.subscription = {
        planId: plan.id,
        status: 'active',
        startDate,
        endDate,
        autoRenew: true
    };
    // provider.isVisible is handled by beforeSave hook in Provider model
    await provider.save();

    res.json({
        success: true,
        message: 'Subscription renewed successfully',
        data: { subscription: provider.subscription }
    });
});

// @desc    Toggle auto-renewal
// @route   PUT /api/subscriptions/auto-renew
// @access  Private (Provider)
exports.toggleAutoRenew = asyncHandler(async (req, res) => {
    const provider = await Provider.findOne({ where: { userId: req.user.id } });

    if (!provider) {
        return res.status(404).json({
            success: false,
            message: 'Provider profile not found'
        });
    }
    const subscription = { ...provider.subscription }; // Create a copy
    subscription.autoRenew = !subscription.autoRenew;
    provider.subscription = subscription;

    await provider.save();

    res.json({
        success: true,
        message: `Auto-renewal ${provider.subscription.autoRenew ? 'enabled' : 'disabled'}`,
        data: { autoRenew: provider.subscription.autoRenew }
    });
});
