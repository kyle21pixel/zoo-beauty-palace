// Add this to adminController.js after the deleteUser function

// @desc    Reset user password (Admin only)
// @route   POST /api/admin/users/:id/reset-password
// @access  Private (Admin)
exports.resetUserPassword = asyncHandler(async (req, res) => {
    const user = await User.findByPk(req.params.id);

    if (!user) {
        return res.status(404).json({
            success: false,
            message: 'User not found'
        });
    }

    // Generate a temporary password
    const tempPassword = `Temp${Math.random().toString(36).slice(-8)}@${Date.now().toString().slice(-4)}`;

    // Update user's password (will be hashed by the beforeUpdate hook)
    user.password = tempPassword;
    await user.save();

    res.json({
        success: true,
        message: 'Password reset successfully',
        data: {
            userId: user.id,
            email: user.email,
            temporaryPassword: tempPassword, // Show this to admin
            note: 'Please provide this temporary password to the user. They should change it after logging in.'
        }
    });
});
