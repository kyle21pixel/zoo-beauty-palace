const { Op, sequelize } = require('sequelize');
const User = require('../models/User');
const Provider = require('../models/Provider');
const Service = require('../models/Service');
const Booking = require('../models/Booking');
const Review = require('../models/Review');
const Analytics = require('../models/Analytics');
const Assignment = require('../models/Assignment');
const Dispute = require('../models/Dispute');
const Payment = require('../models/Payment');
const ActivityLog = require('../models/ActivityLog');
const { asyncHandler } = require('../middleware/errorHandler');

// User Management Functions

// Helper function to log admin activities
const logActivity = async (userId, action, entityType, entityId, description, metadata = {}, req = null) => {
    try {
        // Get IP address and user agent from request if available
        const ipAddress = req ? (req.ip || req.connection.remoteAddress) : null;
        const userAgent = req ? req.get('User-Agent') : null;

        await ActivityLog.create({
            userId,
            action,
            entityType,
            entityId,
            description,
            metadata,
            ipAddress,
            userAgent
        });
    } catch (error) {
        console.error('Error logging activity:', error);
    }
};

// @desc    Get dashboard stats
// @route   GET /api/admin/dashboard
// @access  Private (Admin)
exports.getDashboardStats = asyncHandler(async (req, res) => {
    try {
        // Get total users (excluding clients)
        const totalUsers = await User.count({
            where: {
                role: {
                    [Op.in]: ['provider', 'beautician', 'admin']
                }
            }
        });

        // Get total providers
        const totalProviders = await Provider.count();

        // Get total bookings
        const totalBookings = await Booking.count();

        // Get pending disputes
        const pendingDisputes = await Dispute.count({
            where: {
                status: 'pending'
            }
        });

        // Calculate platform fees from payments table
        const completedPayments = await Payment.findAll({
            where: {
                status: 'completed',
                type: 'booking'
            },
            attributes: [
                [sequelize.fn('SUM', sequelize.col('amount')), 'totalAmount'],
                [sequelize.fn('SUM', sequelize.col('platformFee')), 'totalPlatformFee']
            ],
            raw: true
        });

        const totalRevenue = parseFloat(completedPayments[0]?.totalAmount || 0);
        const platformFee = parseFloat(completedPayments[0]?.totalPlatformFee || 0);

        res.json({
            success: true,
            data: {
                totalUsers,
                totalProviders,
                totalBookings,
                platformFee,
                totalRevenue,
                pendingDisputes
            }
        });
    } catch (error) {
        console.error('Error fetching dashboard stats:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch dashboard stats'
        });
    }
});

// @desc    Get all users
// @route   GET /api/admin/users
// @access  Private (Admin)
exports.getUsers = asyncHandler(async (req, res) => {
    const { role, isActive, search, page = 1, limit = 20 } = req.query;

    const where = {};
    if (role) where.role = role;
    if (isActive !== undefined) where.isActive = isActive === 'true';
    
    // Add search functionality
    if (search) {
        where[Op.or] = [
            { firstName: { [Op.like]: `%${search}%` } },
            { lastName: { [Op.like]: `%${search}%` } },
            { email: { [Op.like]: `%${search}%` } }
        ];
    }

    const offset = (parseInt(page) - 1) * parseInt(limit);

    const { count, rows: users } = await User.findAndCountAll({
        where,
        attributes: { exclude: ['password'] },
        order: [['createdAt', 'DESC']],
        limit: parseInt(limit),
        offset
    });

    res.json({
        success: true,
        data: {
            users,
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total: count,
                pages: Math.ceil(count / parseInt(limit))
            }
        }
    });
});

// @desc    Get user by ID
// @route   GET /api/admin/users/:id
// @access  Private (Admin)
exports.getUserById = asyncHandler(async (req, res) => {
    const user = await User.findByPk(req.params.id, {
        attributes: { exclude: ['password'] }
    });

    if (!user) {
        return res.status(404).json({
            success: false,
            message: 'User not found'
        });
    }

    res.json({
        success: true,
        data: { user }
    });
});

// @desc    Create user
// @route   POST /api/admin/users
// @access  Private (Admin)
exports.createUser = asyncHandler(async (req, res) => {
    const { email, password, role, firstName, lastName, phone, businessName, serviceType } = req.body;

    // Check if user exists
    const userExists = await User.findOne({ where: { email } });
    if (userExists) {
        return res.status(400).json({
            success: false,
            message: 'User with this email already exists'
        });
    }

    // Use transaction to ensure data consistency
    const transaction = await sequelize.transaction();
    
    try {
        // Create user
        const user = await User.create({
            email,
            password,
            role,
            firstName,
            lastName,
            phone
        }, { transaction });

        // If role is provider or beautician, also create provider profile
        let provider = null;
        if (role === 'provider' || role === 'beautician') {
            provider = await Provider.create({
                userId: user.id,
                businessName: businessName || `${firstName}'s Business`,
                serviceType: serviceType || (role === 'beautician' ? 'mobile' : 'studio'),
                // Set default values for other required fields
                specializations: [],
                services: [],
                isVisible: true
            }, { transaction });
        }

        // Commit transaction
        await transaction.commit();

        // Log activity
        await logActivity(
            req.user.id,
            'CREATE_USER',
            'User',
            user.id,
            `Created new ${role}: ${firstName} ${lastName}`,
            { email, role, businessName, serviceType },
            req
        );

        res.status(201).json({
            success: true,
            message: 'User created successfully',
            data: {
                user: {
                    id: user.id,
                    email: user.email,
                    role: user.role,
                    firstName: user.firstName,
                    lastName: user.lastName
                },
                provider: provider ? {
                    id: provider.id,
                    businessName: provider.businessName,
                    serviceType: provider.serviceType
                } : null
            }
        });
    } catch (error) {
        // Rollback transaction on error
        await transaction.rollback();
        console.error('Error creating user:', error);
        return res.status(500).json({
            success: false,
            message: 'Failed to create user and provider profile'
        });
    }
});

// @desc    Update user
// @route   PUT /api/admin/users/:id
// @access  Private (Admin)
exports.updateUser = asyncHandler(async (req, res) => {
    const user = await User.findByPk(req.params.id);

    if (!user) {
        return res.status(404).json({
            success: false,
            message: 'User not found'
        });
    }

    const { firstName, lastName, phone, isActive } = req.body;

    user.firstName = firstName || user.firstName;
    user.lastName = lastName || user.lastName;
    user.phone = phone || user.phone;
    user.isActive = isActive !== undefined ? isActive : user.isActive;

    await user.save();

    // Log activity
    await logActivity(
        req.user.id,
        'UPDATE_USER',
        'User',
        user.id,
        `Updated user: ${user.firstName} ${user.lastName}`,
        { firstName, lastName, phone, isActive },
        req
    );

    res.json({
        success: true,
        message: 'User updated successfully',
        data: {
            user: {
                id: user.id,
                email: user.email,
                role: user.role,
                firstName: user.firstName,
                lastName: user.lastName,
                isActive: user.isActive
            }
        }
    });
});

// @desc    Delete user
// @route   DELETE /api/admin/users/:id
// @access  Private (Admin)
exports.deleteUser = asyncHandler(async (req, res) => {
    const user = await User.findByPk(req.params.id);

    if (!user) {
        return res.status(404).json({
            success: false,
            message: 'User not found'
        });
    }

    // Log activity before deletion
    await logActivity(
        req.user.id,
        'DELETE_USER',
        'User',
        user.id,
        `Deleted user: ${user.firstName} ${user.lastName} (${user.email})`,
        {},
        req
    );

    await user.destroy();

    res.json({
        success: true,
        message: 'User deleted successfully'
    });
});

// @desc    Bulk delete users
// @route   DELETE /api/admin/users/bulk
// @access  Private (Admin)
exports.bulkDeleteUsers = asyncHandler(async (req, res) => {
    const { userIds } = req.body;

    if (!userIds || !Array.isArray(userIds) || userIds.length === 0) {
        return res.status(400).json({
            success: false,
            message: 'User IDs are required'
        });
    }

    try {
        // Log activity before deletion
        await logActivity(
            req.user.id,
            'BULK_DELETE_USERS',
            'User',
            null,
            `Bulk deleted ${userIds.length} users`,
            { userIds },
            req
        );

        const deletedCount = await User.destroy({
            where: { id: userIds }
        });

        res.json({
            success: true,
            message: `${deletedCount} users deleted successfully`,
            data: { deletedCount }
        });
    } catch (error) {
        console.error('Error deleting users:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to delete users'
        });
    }
});

// @desc    Reset user password
// @route   PUT /api/admin/users/:id/reset-password
// @access  Private (Admin)
exports.resetUserPassword = asyncHandler(async (req, res) => {
    const user = await User.findByPk(req.params.id);

    if (!user) {
        return res.status(404).json({
            success: false,
            message: 'User not found'
        });
    }

    // Set a temporary password
    const tempPassword = 'TempPass123!';
    user.password = tempPassword;
    await user.save();

    // Log activity
    await logActivity(
        req.user.id,
        'RESET_USER_PASSWORD',
        'User',
        user.id,
        `Reset password for user: ${user.firstName} ${user.lastName}`,
        {},
        req
    );

    res.json({
        success: true,
        message: 'Password reset successfully',
        data: { tempPassword }
    });
});

// Provider Management Functions

// @desc    Get all providers
// @route   GET /api/admin/providers
// @access  Private (Admin)
exports.getProviders = asyncHandler(async (req, res) => {
    const { status, search, page = 1, limit = 20 } = req.query;

    const where = {};
    if (status) where.status = status;
    
    // Add search functionality
    if (search) {
        where[Op.or] = [
            { businessName: { [Op.like]: `%${search}%` } }
        ];
    }

    const offset = (parseInt(page) - 1) * parseInt(limit);

    const { count, rows: providers } = await Provider.findAndCountAll({
        where,
        include: [{ model: User, attributes: ['firstName', 'lastName', 'email'] }],
        order: [['createdAt', 'DESC']],
        limit: parseInt(limit),
        offset
    });

    res.json({
        success: true,
        data: {
            providers,
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total: count,
                pages: Math.ceil(count / parseInt(limit))
            }
        }
    });
});

// @desc    Get provider by ID
// @route   GET /api/admin/providers/:id
// @access  Private (Admin)
exports.getProviderById = asyncHandler(async (req, res) => {
    const provider = await Provider.findByPk(req.params.id, {
        include: [{ model: User, attributes: ['firstName', 'lastName', 'email'] }]
    });

    if (!provider) {
        return res.status(404).json({
            success: false,
            message: 'Provider not found'
        });
    }

    res.json({
        success: true,
        data: { provider }
    });
});

// @desc    Create provider
// @route   POST /api/admin/providers
// @access  Private (Admin)
exports.createProvider = asyncHandler(async (req, res) => {
    const { businessName, businessType, description, phone, email, address, userId } = req.body;

    // Check if provider exists for this user
    const providerExists = await Provider.findOne({ where: { userId } });
    if (providerExists) {
        return res.status(400).json({
            success: false,
            message: 'Provider already exists for this user'
        });
    }

    // Create provider
    const provider = await Provider.create({
        businessName,
        businessType,
        description,
        phone,
        email,
        address,
        userId
    });

    res.status(201).json({
        success: true,
        message: 'Provider created successfully',
        data: { provider }
    });
});

// @desc    Update provider
// @route   PUT /api/admin/providers/:id
// @access  Private (Admin)
exports.updateProvider = asyncHandler(async (req, res) => {
    const provider = await Provider.findByPk(req.params.id);

    if (!provider) {
        return res.status(404).json({
            success: false,
            message: 'Provider not found'
        });
    }

    const { businessName, businessType, description, phone, email, address, status } = req.body;

    provider.businessName = businessName || provider.businessName;
    provider.businessType = businessType || provider.businessType;
    provider.description = description || provider.description;
    provider.phone = phone || provider.phone;
    provider.email = email || provider.email;
    provider.address = address || provider.address;
    provider.status = status || provider.status;

    await provider.save();

    // Log activity
    await logActivity(
        req.user.id,
        'UPDATE_PROVIDER',
        'Provider',
        provider.id,
        `Updated provider: ${provider.businessName}`,
        { businessName, businessType, description, phone, email, address, status },
        req
    );

    res.json({
        success: true,
        message: 'Provider updated successfully',
        data: { provider }
    });
});

// @desc    Delete provider
// @route   DELETE /api/admin/providers/:id
// @access  Private (Admin)
exports.deleteProvider = asyncHandler(async (req, res) => {
    const provider = await Provider.findByPk(req.params.id);

    if (!provider) {
        return res.status(404).json({
            success: false,
            message: 'Provider not found'
        });
    }

    // Log activity before deletion
    await logActivity(
        req.user.id,
        'DELETE_PROVIDER',
        'Provider',
        provider.id,
        `Deleted provider: ${provider.businessName}`,
        {},
        req
    );

    await provider.destroy();

    res.json({
        success: true,
        message: 'Provider deleted successfully'
    });
});

// @desc    Approve provider
// @route   PUT /api/admin/providers/:id/approve
// @access  Private (Admin)
exports.approveProvider = asyncHandler(async (req, res) => {
    const provider = await Provider.findByPk(req.params.id);

    if (!provider) {
        return res.status(404).json({
            success: false,
            message: 'Provider not found'
        });
    }

    provider.status = 'approved';
    await provider.save();

    // Log activity
    await logActivity(
        req.user.id,
        'APPROVE_PROVIDER',
        'Provider',
        provider.id,
        `Approved provider: ${provider.businessName}`,
        {},
        req
    );

    res.json({
        success: true,
        message: 'Provider approved successfully',
        data: { provider }
    });
});

// @desc    Reject provider
// @route   PUT /api/admin/providers/:id/reject
// @access  Private (Admin)
exports.rejectProvider = asyncHandler(async (req, res) => {
    const provider = await Provider.findByPk(req.params.id);

    if (!provider) {
        return res.status(404).json({
            success: false,
            message: 'Provider not found'
        });
    }

    provider.status = 'rejected';
    await provider.save();

    // Log activity
    await logActivity(
        req.user.id,
        'REJECT_PROVIDER',
        'Provider',
        provider.id,
        `Rejected provider: ${provider.businessName}`,
        {},
        req
    );

    res.json({
        success: true,
        message: 'Provider rejected successfully',
        data: { provider }
    });
});

// Service Management Functions

// @desc    Get all services
// @route   GET /api/admin/services
// @access  Private (Admin)
exports.getServices = asyncHandler(async (req, res) => {
    const { category, isActive, page = 1, limit = 20 } = req.query;

    const where = {};
    if (category) where.category = category;
    if (isActive !== undefined) where.isActive = isActive === 'true';

    const offset = (parseInt(page) - 1) * parseInt(limit);

    const { count, rows: services } = await Service.findAndCountAll({
        where,
        include: [{ model: Provider, attributes: ['businessName'] }],
        order: [['createdAt', 'DESC']],
        limit: parseInt(limit),
        offset
    });

    res.json({
        success: true,
        data: {
            services,
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total: count,
                pages: Math.ceil(count / parseInt(limit))
            }
        }
    });
});

// @desc    Get service by ID
// @route   GET /api/admin/services/:id
// @access  Private (Admin)
exports.getServiceById = asyncHandler(async (req, res) => {
    const service = await Service.findByPk(req.params.id, {
        include: [{ model: Provider, attributes: ['businessName'] }]
    });

    if (!service) {
        return res.status(404).json({
            success: false,
            message: 'Service not found'
        });
    }

    res.json({
        success: true,
        data: { service }
    });
});

// @desc    Create service
// @route   POST /api/admin/services
// @access  Private (Admin)
exports.createService = asyncHandler(async (req, res) => {
    const { name, description, price, duration, category, providerId } = req.body;

    // Create service
    const service = await Service.create({
        name,
        description,
        price,
        duration,
        category,
        providerId
    });

    res.status(201).json({
        success: true,
        message: 'Service created successfully',
        data: { service }
    });
});

// @desc    Update service
// @route   PUT /api/admin/services/:id
// @access  Private (Admin)
exports.updateService = asyncHandler(async (req, res) => {
    const service = await Service.findByPk(req.params.id);

    if (!service) {
        return res.status(404).json({
            success: false,
            message: 'Service not found'
        });
    }

    const { name, description, price, duration, category, isActive } = req.body;

    service.name = name || service.name;
    service.description = description || service.description;
    service.price = price || service.price;
    service.duration = duration || service.duration;
    service.category = category || service.category;
    service.isActive = isActive !== undefined ? isActive : service.isActive;

    await service.save();

    res.json({
        success: true,
        message: 'Service updated successfully',
        data: { service }
    });
});

// @desc    Delete service
// @route   DELETE /api/admin/services/:id
// @access  Private (Admin)
exports.deleteService = asyncHandler(async (req, res) => {
    const service = await Service.findByPk(req.params.id);

    if (!service) {
        return res.status(404).json({
            success: false,
            message: 'Service not found'
        });
    }

    await service.destroy();

    res.json({
        success: true,
        message: 'Service deleted successfully'
    });
});

// Booking Management Functions

// @desc    Get all bookings
// @route   GET /api/admin/bookings
// @access  Private (Admin)
exports.getBookings = asyncHandler(async (req, res) => {
    const { status, search, page = 1, limit = 20 } = req.query;

    const where = {};
    if (status) where.status = status;
    
    // Add search functionality
    if (search) {
        where[Op.or] = [
            { service: { [Op.like]: `%${search}%` } }
        ];
    }

    const offset = (parseInt(page) - 1) * parseInt(limit);

    const { count, rows: bookings } = await Booking.findAndCountAll({
        where,
        include: [
            { model: User, as: 'client', attributes: ['firstName', 'lastName', 'email'] },
            { model: User, as: 'beautician', attributes: ['firstName', 'lastName', 'email'], required: false },
            { model: Provider, as: 'provider', attributes: ['businessName'] }
        ],
        order: [['createdAt', 'DESC']],
        limit: parseInt(limit),
        offset
    });

    res.json({
        success: true,
        data: {
            bookings,
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total: count,
                pages: Math.ceil(count / parseInt(limit))
            }
        }
    });
});

// @desc    Get booking by ID
// @route   GET /api/admin/bookings/:id
// @access  Private (Admin)
exports.getBookingById = asyncHandler(async (req, res) => {
    const booking = await Booking.findByPk(req.params.id, {
        include: [
            { model: User, as: 'client', attributes: ['firstName', 'lastName', 'email'] },
            { model: User, as: 'beautician', attributes: ['firstName', 'lastName', 'email'] },
            { model: Service, attributes: ['name'] },
            { model: Provider, attributes: ['businessName'] }
        ]
    });

    if (!booking) {
        return res.status(404).json({
            success: false,
            message: 'Booking not found'
        });
    }

    res.json({
        success: true,
        data: { booking }
    });
});

// @desc    Update booking status
// @route   PUT /api/admin/bookings/:id/status
// @access  Private (Admin)
exports.updateBookingStatus = asyncHandler(async (req, res) => {
    const { status } = req.body;

    const booking = await Booking.findByPk(req.params.id);
    if (!booking) {
        return res.status(404).json({
            success: false,
            message: 'Booking not found'
        });
    }

    booking.status = status;
    await booking.save();

    // Log activity
    await logActivity(
        req.user.id,
        'UPDATE_BOOKING_STATUS',
        'Booking',
        booking.id,
        `Updated booking status to: ${status}`,
        { status },
        req
    );

    res.json({
        success: true,
        message: 'Booking status updated successfully',
        data: { booking }
    });
});

// @desc    Cancel booking
// @route   PUT /api/admin/bookings/:id/cancel
// @access  Private (Admin)
exports.cancelBooking = asyncHandler(async (req, res) => {
    const booking = await Booking.findByPk(req.params.id);
    if (!booking) {
        return res.status(404).json({
            success: false,
            message: 'Booking not found'
        });
    }

    booking.status = 'cancelled';
    await booking.save();

    // Log activity
    await logActivity(
        req.user.id,
        'CANCEL_BOOKING',
        'Booking',
        booking.id,
        `Cancelled booking: ${booking.service}`,
        {},
        req
    );

    res.json({
        success: true,
        message: 'Booking cancelled successfully',
        data: { booking }
    });
});

// Review Management Functions

// @desc    Get all reviews
// @route   GET /api/admin/reviews
// @access  Private (Admin)
exports.getReviews = asyncHandler(async (req, res) => {
    const { rating, page = 1, limit = 20 } = req.query;

    const where = {};
    if (rating) where.rating = rating;

    const offset = (parseInt(page) - 1) * parseInt(limit);

    const { count, rows: reviews } = await Review.findAndCountAll({
        where,
        include: [
            { model: User, as: 'reviewer', attributes: ['firstName', 'lastName', 'email'] },
            { model: User, as: 'reviewee', attributes: ['firstName', 'lastName', 'email'] },
            { model: Service, attributes: ['name'] }
        ],
        order: [['createdAt', 'DESC']],
        limit: parseInt(limit),
        offset
    });

    res.json({
        success: true,
        data: {
            reviews,
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total: count,
                pages: Math.ceil(count / parseInt(limit))
            }
        }
    });
});

// @desc    Get review by ID
// @route   GET /api/admin/reviews/:id
// @access  Private (Admin)
exports.getReviewById = asyncHandler(async (req, res) => {
    const review = await Review.findByPk(req.params.id, {
        include: [
            { model: User, as: 'reviewer', attributes: ['firstName', 'lastName', 'email'] },
            { model: User, as: 'reviewee', attributes: ['firstName', 'lastName', 'email'] },
            { model: Service, attributes: ['name'] }
        ]
    });

    if (!review) {
        return res.status(404).json({
            success: false,
            message: 'Review not found'
        });
    }

    res.json({
        success: true,
        data: { review }
    });
});

// @desc    Update review
// @route   PUT /api/admin/reviews/:id
// @access  Private (Admin)
exports.updateReview = asyncHandler(async (req, res) => {
    const review = await Review.findByPk(req.params.id);

    if (!review) {
        return res.status(404).json({
            success: false,
            message: 'Review not found'
        });
    }

    const { rating, comment } = req.body;

    review.rating = rating || review.rating;
    review.comment = comment || review.comment;

    await review.save();

    res.json({
        success: true,
        message: 'Review updated successfully',
        data: { review }
    });
});

// @desc    Delete review
// @route   DELETE /api/admin/reviews/:id
// @access  Private (Admin)
exports.deleteReview = asyncHandler(async (req, res) => {
    const review = await Review.findByPk(req.params.id);

    if (!review) {
        return res.status(404).json({
            success: false,
            message: 'Review not found'
        });
    }

    await review.destroy();

    res.json({
        success: true,
        message: 'Review deleted successfully'
    });
});

// Analytics Functions

// @desc    Get analytics data
// @route   GET /api/admin/analytics
// @access  Private (Admin)
exports.getAnalytics = asyncHandler(async (req, res) => {
    const days = req.query.days || 30;
    const startDate = new Date(Date.now() - days * 24 * 60 * 60 * 1000);
    const endDate = new Date();

    // Get user statistics
    const userStats = await User.count({
        where: {
            createdAt: {
                [Op.gte]: startDate
            }
        },
        group: ['role']
    });

    // Get booking statistics
    const bookingStats = await Booking.count({
        where: {
            createdAt: {
                [Op.gte]: startDate
            }
        },
        group: ['status']
    });

    // Get revenue statistics from payments
    const [revenueStats, platformFeeStats] = await Promise.all([
        Payment.sum('amount', {
            where: {
                createdAt: {
                    [Op.gte]: startDate
                },
                status: 'completed',
                type: 'booking'
            }
        }),
        Payment.sum('platformFee', {
            where: {
                createdAt: {
                    [Op.gte]: startDate
                },
                status: 'completed',
                type: 'booking'
            }
        })
    ]);

    // Get provider statistics
    const providerStats = await Provider.count({
        where: {
            createdAt: {
                [Op.gte]: startDate
            }
        }
    });

    // Get recent analytics records
    const recentAnalytics = await Analytics.findAll({
        where: {
            date: {
                [Op.gte]: startDate
            }
        },
        order: [['date', 'ASC']]
    });

    // Calculate platform fees from payments table
    const totalRevenue = revenueStats || 0;
    const platformFees = platformFeeStats || 0;

    res.json({
        success: true,
        data: {
            period: {
                startDate: startDate.toISOString().split('T')[0],
                endDate: endDate.toISOString().split('T')[0]
            },
            summary: {
                totalRevenue,
                platformFees,
                newUserRegistrations: userStats.reduce((sum, stat) => sum + (stat.count || 0), 0),
                newProviders: providerStats,
                totalBookings: bookingStats.reduce((sum, stat) => sum + (stat.count || 0), 0)
            },
            userStats,
            bookingStats,
            dailyMetrics: recentAnalytics.map(record => ({
                date: record.date,
                ...record.metrics
            }))
        }
    });
});

// @desc    Get date range analytics
// @route   GET /api/admin/analytics/date-range
// @access  Private (Admin)
exports.getDateRange = asyncHandler(async (req, res) => {
    const { startDate, endDate } = req.query;

    const start = startDate ? new Date(startDate) : new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    const end = endDate ? new Date(endDate) : new Date();

    const analytics = await Analytics.findAll({
        where: {
            date: {
                [Op.between]: [start, end]
            }
        },
        order: [['date', 'ASC']]
    });

    res.json({
        success: true,
        data: { analytics }
    });
});

// @desc    Export analytics report as CSV
// @route   GET /api/admin/analytics/export
// @access  Private (Admin)
exports.exportAnalyticsReport = asyncHandler(async (req, res) => {
    const { startDate, endDate, format = 'csv' } = req.query;

    const start = startDate ? new Date(startDate) : new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    const end = endDate ? new Date(endDate) : new Date();

    // Get analytics data
    const analytics = await Analytics.getDateRange(start, end);
    
    // Get additional statistics
    const [userStats, providerStats, bookingStats, revenueStats, platformFeeStats] = await Promise.all([
        // User statistics
        User.count({
            where: {
                createdAt: {
                    [Op.between]: [start, end]
                }
            },
            group: ['role']
        }),
        // Provider statistics
        Provider.count({
            where: {
                createdAt: {
                    [Op.between]: [start, end]
                }
            }
        }),
        // Booking statistics
        Booking.count({
            where: {
                createdAt: {
                    [Op.between]: [start, end]
                }
            },
            group: ['status']
        }),
        // Revenue statistics
        Payment.sum('amount', {
            where: {
                createdAt: {
                    [Op.between]: [start, end]
                },
                status: 'completed',
                type: 'booking'
            }
        }),
        // Platform fee statistics
        Payment.sum('platformFee', {
            where: {
                createdAt: {
                    [Op.between]: [start, end]
                },
                status: 'completed',
                type: 'booking'
            }
        })
    ]);
    
    // Calculate platform fees from payments table
    const totalRevenue = revenueStats || 0;
    const platformFees = platformFeeStats || 0;
    
    // Prepare data for export
    const reportData = {
        period: {
            startDate: start.toISOString().split('T')[0],
            endDate: end.toISOString().split('T')[0]
        },
        summary: {
            totalRevenue,
            platformFees,
            newUserRegistrations: userStats.reduce((sum, stat) => sum + stat.count, 0),
            newProviders: providerStats,
            totalBookings: bookingStats.reduce((sum, stat) => sum + stat.count, 0)
        },
        userStats,
        bookingStats,
        dailyMetrics: analytics.map(record => ({
            date: record.date,
            ...record.metrics
        }))
    };

    if (format === 'csv') {
        // Convert to CSV format
        let csv = 'Date,New Users,New Providers,New Clients,Total Bookings,Completed Bookings,Cancelled Bookings,Revenue,Platform Fees,Active Subscriptions\n';
        
        analytics.forEach(record => {
            const metrics = record.metrics;
            csv += `${record.date},${metrics.newUsers},${metrics.newProviders},${metrics.newClients},${metrics.totalBookings},${metrics.completedBookings},${metrics.cancelledBookings},${metrics.revenue},${metrics.platformFees},${metrics.activeSubscriptions}\n`;
        });
        
        res.header('Content-Type', 'text/csv');
        res.attachment('analytics-report.csv');
        return res.send(csv);
    } else {
        // Return JSON format
        res.json({
            success: true,
            data: reportData
        });
    }
});

// Assignment Management Functions

// @desc    Assign task to beautician
// @route   POST /api/admin/assignments
// @access  Private (Admin)
exports.assignTask = asyncHandler(async (req, res) => {
    const { title, description, assignedToId, providerId, priority = 'medium', dueDate } = req.body;
    
    // Validate assignedToId
    const assignedToUser = await User.findByPk(assignedToId);
    if (!assignedToUser || assignedToUser.role !== 'beautician') {
        return res.status(400).json({
            success: false,
            message: 'Invalid beautician ID'
        });
    }
    
    // Create assignment
    const assignment = await Assignment.create({
        title,
        description,
        assignedToId,
        assignedById: req.user.id,
        providerId,
        priority,
        dueDate
    });
    
    // Send notification to the assigned beautician
    const notificationService = require('../services/notificationService');
    await notificationService.sendAssignmentNotification(assignedToId, assignment);
    
    res.status(201).json({
        success: true,
        message: 'Task assigned successfully',
        data: { assignment }
    });
});

// @desc    Get all assignments
// @route   GET /api/admin/assignments
// @access  Private (Admin)
exports.getAssignments = asyncHandler(async (req, res) => {
    const { status, assignedToId, assignedById, providerId, priority, search, page = 1, limit = 20 } = req.query;

    const where = {};
    if (status) where.status = status;
    if (assignedToId) where.assignedToId = assignedToId;
    if (assignedById) where.assignedById = assignedById;
    if (providerId) where.providerId = providerId;
    if (priority) where.priority = priority;
    
    // Add search functionality
    if (search) {
        where[Op.or] = [
            { title: { [Op.like]: `%${search}%` } },
            { description: { [Op.like]: `%${search}%` } }
        ];
    }

    const offset = (parseInt(page) - 1) * parseInt(limit);

    const { count, rows: assignments } = await Assignment.findAndCountAll({
        where,
        include: [
            { model: User, as: 'assignedBy', attributes: ['firstName', 'lastName', 'email'] },
            { model: User, as: 'assignedTo', attributes: ['firstName', 'lastName', 'email'] },
            { model: Provider, as: 'provider', attributes: ['businessName'] }
        ],
        order: [['createdAt', 'DESC']],
        limit: parseInt(limit),
        offset
    });

    res.json({
        success: true,
        data: {
            assignments,
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total: count,
                pages: Math.ceil(count / parseInt(limit))
            }
        }
    });
});

// @desc    Update assignment status
// @route   PUT /api/admin/assignments/:id/status
// @access  Private (Admin)
exports.updateAssignmentStatus = asyncHandler(async (req, res) => {
    const { status } = req.body;

    const assignment = await Assignment.findByPk(req.params.id, {
        include: [
            { model: User, as: 'assignedTo', attributes: ['id'] }
        ]
    });
    if (!assignment) {
        return res.status(404).json({
            success: false,
            message: 'Assignment not found'
        });
    }

    assignment.status = status;
    if (status === 'completed') {
        assignment.completedAt = new Date();
    }
    await assignment.save();

    // Send notification to the assigned beautician about status change
    if (assignment.assignedTo) {
        const notificationService = require('../services/notificationService');
        await notificationService.sendNotification(
            assignment.assignedTo.id,
            'assignment_status',
            'Assignment Status Updated',
            `Your assignment "${assignment.title}" status has been updated to ${status}`,
            { assignmentId: assignment.id, status: status },
            `/dashboard/assignments/${assignment.id}`
        );
    }

    res.json({
        success: true,
        message: 'Assignment status updated successfully',
        data: { assignment }
    });
});

// @desc    Bulk update assignment statuses
// @route   PUT /api/admin/assignments/bulk-status
// @access  Private (Admin)
exports.bulkUpdateAssignmentStatus = asyncHandler(async (req, res) => {
    const { assignmentIds, status } = req.body;

    if (!assignmentIds || !Array.isArray(assignmentIds) || assignmentIds.length === 0) {
        return res.status(400).json({
            success: false,
            message: 'Assignment IDs are required'
        });
    }

    if (!status) {
        return res.status(400).json({
            success: false,
            message: 'Status is required'
        });
    }

    try {
        // Update all assignments
        const [updatedCount] = await Assignment.update(
            { status: status },
            { where: { id: assignmentIds } }
        );

        // If status is completed, set completedAt
        if (status === 'completed') {
            await Assignment.update(
                { completedAt: new Date() },
                { where: { id: assignmentIds } }
            );
        }

        // Send notifications to assigned beauticians
        const assignments = await Assignment.findAll({
            where: { id: assignmentIds },
            include: [
                { model: User, as: 'assignedTo', attributes: ['id'] }
            ]
        });

        const notificationService = require('../services/notificationService');
        for (const assignment of assignments) {
            if (assignment.assignedTo) {
                await notificationService.sendNotification(
                    assignment.assignedTo.id,
                    'assignment_status',
                    'Assignment Status Updated',
                    `Your assignment "${assignment.title}" status has been updated to ${status}`, 
                    { assignmentId: assignment.id, status: status },
                    `/dashboard/assignments/${assignment.id}`
                );
            }
        }

        res.json({
            success: true,
            message: `${updatedCount} assignments updated successfully`,
            data: { updatedCount }
        });
    } catch (error) {
        console.error('Error updating assignments:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to update assignments'
        });
    }
});

// @desc    Bulk delete assignments
// @route   DELETE /api/admin/assignments/bulk
// @access  Private (Admin)
exports.bulkDeleteAssignments = asyncHandler(async (req, res) => {
    const { assignmentIds } = req.body;

    if (!assignmentIds || !Array.isArray(assignmentIds) || assignmentIds.length === 0) {
        return res.status(400).json({
            success: false,
            message: 'Assignment IDs are required'
        });
    }

    try {
        const deletedCount = await Assignment.destroy({
            where: { id: assignmentIds }
        });

        res.json({
            success: true,
            message: `${deletedCount} assignments deleted successfully`,
            data: { deletedCount }
        });
    } catch (error) {
        console.error('Error deleting assignments:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to delete assignments'
        });
    }
});

// Dispute Management Functions

// @desc    Get all disputes
// @route   GET /api/admin/disputes
// @access  Private (Admin)
exports.getDisputes = asyncHandler(async (req, res) => {
    const { status, search, page = 1, limit = 20 } = req.query;

    const where = {};
    if (status) where.status = status;
    
    // Add search functionality
    if (search) {
        where[Op.or] = [
            { reason: { [Op.like]: `%${search}%` } },
            { description: { [Op.like]: `%${search}%` } }
        ];
    }

    const offset = (parseInt(page) - 1) * parseInt(limit);

    const { count, rows: disputes } = await Dispute.findAndCountAll({
        where,
        include: [
            { model: Booking, as: 'booking' },
            { model: User, as: 'reporter', attributes: ['firstName', 'lastName', 'email'] },
            { model: User, as: 'respondent', attributes: ['firstName', 'lastName', 'email'] },
            { model: User, as: 'assignedTo', attributes: ['firstName', 'lastName'], required: false }
        ],
        order: [['createdAt', 'DESC']],
        limit: parseInt(limit),
        offset
    });

    res.json({
        success: true,
        data: {
            disputes,
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total: count,
                pages: Math.ceil(count / parseInt(limit))
            }
        }
    });
});

// @desc    Resolve dispute
// @route   PUT /api/admin/disputes/:id/resolve
// @access  Private (Admin)
exports.resolveDispute = asyncHandler(async (req, res) => {
    const { action, note } = req.body;

    const dispute = await Dispute.findByPk(req.params.id);

    if (!dispute) {
        return res.status(404).json({
            success: false,
            message: 'Dispute not found'
        });
    }

    await dispute.resolve(action, note, req.user.id);

    // Log activity
    await logActivity(
        req.user.id,
        'RESOLVE_DISPUTE',
        'Dispute',
        dispute.id,
        `Resolved dispute with action: ${action}`,
        { action, note },
        req
    );

    res.json({
        success: true,
        message: 'Dispute resolved successfully',
        data: { dispute }
    });
});

module.exports = exports;