const Notification = require('../models/Notification');
const User = require('../models/User');
const asyncHandler = require('../middleware/asyncHandler');

// @desc    Get user notifications
// @route   GET /api/notifications
// @access  Private
exports.getNotifications = asyncHandler(async (req, res) => {
    const { page = 1, limit = 20, unreadOnly = false } = req.query;
    
    const where = { userId: req.user.id };
    if (unreadOnly === 'true') {
        where.isRead = false;
    }
    
    const offset = (parseInt(page) - 1) * parseInt(limit);
    
    const { count, rows: notifications } = await Notification.findAndCountAll({
        where,
        order: [['createdAt', 'DESC']],
        limit: parseInt(limit),
        offset
    });
    
    res.json({
        success: true,
        data: {
            notifications,
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total: count,
                pages: Math.ceil(count / parseInt(limit))
            }
        }
    });
});

// @desc    Mark notification as read
// @route   PUT /api/notifications/:id/read
// @access  Private
exports.markAsRead = asyncHandler(async (req, res) => {
    const notification = await Notification.findOne({
        where: {
            id: req.params.id,
            userId: req.user.id
        }
    });
    
    if (!notification) {
        return res.status(404).json({
            success: false,
            message: 'Notification not found'
        });
    }
    
    await notification.markAsRead();
    
    res.json({
        success: true,
        message: 'Notification marked as read',
        data: { notification }
    });
});

// @desc    Mark all notifications as read
// @route   PUT /api/notifications/read-all
// @access  Private
exports.markAllAsRead = asyncHandler(async (req, res) => {
    const updated = await Notification.markAllAsRead(req.user.id);
    
    res.json({
        success: true,
        message: 'All notifications marked as read',
        data: { updatedCount: updated[0] }
    });
});

// @desc    Delete notification
// @route   DELETE /api/notifications/:id
// @access  Private
exports.deleteNotification = asyncHandler(async (req, res) => {
    const notification = await Notification.findOne({
        where: {
            id: req.params.id,
            userId: req.user.id
        }
    });
    
    if (!notification) {
        return res.status(404).json({
            success: false,
            message: 'Notification not found'
        });
    }
    
    await notification.destroy();
    
    res.json({
        success: true,
        message: 'Notification deleted successfully'
    });
});