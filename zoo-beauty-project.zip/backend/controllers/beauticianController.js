const User = require('../models/User.mongo');
const Assignment = require('../models/Assignment.mongo');
const asyncHandler = require('../middleware/asyncHandler');

// @desc    Get current beautician profile
// @route   GET /api/beauticians/me/profile
// @access  Private (Beautician)
exports.getMyProfile = asyncHandler(async (req, res) => {
    // For beauticians, the user document contains all profile information
    const user = await User.findById(req.user.id).select('-password -verificationToken -resetPasswordToken -resetPasswordExpires');
    
    if (!user) {
        return res.status(404).json({
            success: false,
            message: 'Beautician profile not found'
        });
    }
    
    res.json({
        success: true,
        data: { user }
    });
});

// @desc    Setup/Update beautician profile
// @route   POST /api/beauticians/setup-profile
// @access  Private (Beautician)
exports.setupProfile = asyncHandler(async (req, res) => {
    const {
        firstName,
        lastName,
        phone,
        specializations,
        experience,
        certifications
    } = req.body;
    
    // Validate required fields
    if (!firstName || !lastName) {
        return res.status(400).json({
            success: false,
            message: 'First name and last name are required'
        });
    }
    
    // Update user profile
    const user = await User.findById(req.user.id);
    
    if (!user) {
        return res.status(404).json({
            success: false,
            message: 'User not found'
        });
    }
    
    // Update user fields
    user.firstName = firstName;
    user.lastName = lastName;
    user.phone = phone || user.phone;
    
    // Add beautician specific fields to preferences or a new field
    if (specializations) user.preferences.specializations = specializations;
    if (experience) user.preferences.experience = experience;
    if (certifications) user.preferences.certifications = certifications;
    
    // Mark profile as complete
    user.isProfileComplete = true;
    
    await user.save();
    
    res.json({
        success: true,
        message: 'Beautician profile updated successfully',
        data: { 
            user: {
                id: user._id,
                email: user.email,
                firstName: user.firstName,
                lastName: user.lastName,
                phone: user.phone,
                isProfileComplete: user.isProfileComplete,
                preferences: user.preferences
            }
        }
    });
});

// @desc    Get beautician assignments
// @route   GET /api/beauticians/assignments
// @access  Private (Beautician)
exports.getAssignments = asyncHandler(async (req, res) => {
    const { page = 1, limit = 20 } = req.query;
    
    const offset = (parseInt(page) - 1) * parseInt(limit);
    
    const [count, assignments] = await Promise.all([
        Assignment.countDocuments({ assignedToId: req.user.id }),
        Assignment.find({ assignedToId: req.user.id })
            .populate('providerId', 'businessName')
            .populate('bookingId')
            .sort({ createdAt: -1 })
            .skip(offset)
            .limit(parseInt(limit))
    ]);
    
    res.json({
        success: true,
        data: {
            assignments,
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total: count,
                pages: Math.ceil(count / parseInt(limit))
            }
        }
    });
});

// @desc    Accept assignment
// @route   PUT /api/beauticians/assignments/:id/accept
// @access  Private (Beautician)
exports.acceptAssignment = asyncHandler(async (req, res) => {
    const assignment = await Assignment.findById(req.params.id);
    
    if (!assignment) {
        return res.status(404).json({
            success: false,
            message: 'Assignment not found'
        });
    }
    
    if (assignment.assignedToId.toString() !== req.user.id) {
        return res.status(403).json({
            success: false,
            message: 'Not authorized to accept this assignment'
        });
    }
    
    // Update assignment status
    assignment.status = 'accepted';
    assignment.acceptedAt = new Date();
    
    await assignment.save();
    
    res.json({
        success: true,
        message: 'Assignment accepted successfully',
        data: { assignment }
    });
});

// @desc    Complete assignment
// @route   PUT /api/beauticians/assignments/:id/complete
// @access  Private (Beautician)
exports.completeAssignment = asyncHandler(async (req, res) => {
    const assignment = await Assignment.findById(req.params.id);
    
    if (!assignment) {
        return res.status(404).json({
            success: false,
            message: 'Assignment not found'
        });
    }
    
    if (assignment.assignedToId.toString() !== req.user.id) {
        return res.status(403).json({
            success: false,
            message: 'Not authorized to complete this assignment'
        });
    }
    
    // Update assignment status
    assignment.status = 'completed';
    assignment.completedAt = new Date();
    
    await assignment.save();
    
    res.json({
        success: true,
        message: 'Assignment completed successfully',
        data: { assignment }
    });
});

// @desc    Update beautician profile
// @route   PUT /api/beauticians/profile
// @access  Private (Beautician)
exports.updateProfile = asyncHandler(async (req, res) => {
    const {
        firstName,
        lastName,
        phone,
        specializations,
        experience,
        certifications
    } = req.body;
    
    // Update user profile
    const user = await User.findById(req.user.id);
    
    if (!user) {
        return res.status(404).json({
            success: false,
            message: 'User not found'
        });
    }
    
    // Update user fields (only if provided)
    if (firstName) user.firstName = firstName;
    if (lastName) user.lastName = lastName;
    if (phone) user.phone = phone;
    
    // Update beautician specific fields
    if (specializations) user.preferences.specializations = specializations;
    if (experience) user.preferences.experience = experience;
    if (certifications) user.preferences.certifications = certifications;
    
    await user.save();
    
    res.json({
        success: true,
        message: 'Beautician profile updated successfully',
        data: { 
            user: {
                id: user._id,
                email: user.email,
                firstName: user.firstName,
                lastName: user.lastName,
                phone: user.phone,
                isProfileComplete: user.isProfileComplete,
                preferences: user.preferences
            }
        }
    });
});