const User = require('../models/User.mongo');
const { asyncHandler } = require('../middleware/errorHandler');

// @desc    Get current client profile
// @route   GET /api/clients/me/profile
// @access  Private (Client)
exports.getMyProfile = asyncHandler(async (req, res) => {
    // For clients, the user document contains all profile information
    const user = await User.findById(req.user.id).select('-password -verificationToken -resetPasswordToken -resetPasswordExpires');
    
    if (!user) {
        return res.status(404).json({
            success: false,
            message: 'Client profile not found'
        });
    }
    
    res.json({
        success: true,
        data: { user }
    });
});

// @desc    Setup/Update client profile
// @route   POST /api/clients/setup-profile
// @access  Private (Client)
exports.setupProfile = asyncHandler(async (req, res) => {
    const {
        firstName,
        lastName,
        phone,
        address,
        city,
        state,
        country,
        zipCode
    } = req.body;
    
    // Validate required fields
    if (!firstName || !lastName) {
        return res.status(400).json({
            success: false,
            message: 'First name and last name are required'
        });
    }
    
    // Update user profile
    const user = await User.findById(req.user.id);
    
    if (!user) {
        return res.status(404).json({
            success: false,
            message: 'User not found'
        });
    }
    
    // Update user fields
    user.firstName = firstName;
    user.lastName = lastName;
    user.phone = phone || user.phone;
    
    // Mark profile as complete
    user.isProfileComplete = true;
    
    await user.save();
    
    res.json({
        success: true,
        message: 'Client profile updated successfully',
        data: { 
            user: {
                id: user._id,
                email: user.email,
                firstName: user.firstName,
                lastName: user.lastName,
                phone: user.phone,
                isProfileComplete: user.isProfileComplete
            }
        }
    });
});

// @desc    Update client profile
// @route   PUT /api/clients/profile
// @access  Private (Client)
exports.updateProfile = asyncHandler(async (req, res) => {
    const {
        firstName,
        lastName,
        phone,
        address,
        city,
        state,
        country,
        zipCode
    } = req.body;
    
    // Update user profile
    const user = await User.findById(req.user.id);
    
    if (!user) {
        return res.status(404).json({
            success: false,
            message: 'User not found'
        });
    }
    
    // Update user fields (only if provided)
    if (firstName) user.firstName = firstName;
    if (lastName) user.lastName = lastName;
    if (phone) user.phone = phone;
    
    await user.save();
    
    res.json({
        success: true,
        message: 'Client profile updated successfully',
        data: { 
            user: {
                id: user._id,
                email: user.email,
                firstName: user.firstName,
                lastName: user.lastName,
                phone: user.phone,
                isProfileComplete: user.isProfileComplete
            }
        }
    });
});