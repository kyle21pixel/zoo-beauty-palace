const User = require('../models/User.mongo');
const Provider = require('../models/Provider.mongo');
const Booking = require('../models/Booking.mongo');
const Payment = require('../models/Payment.mongo');
const Review = require('../models/Review.mongo');
const Dispute = require('../models/Dispute.mongo');
const Analytics = require('../models/Analytics.mongo');
const SubscriptionPlan = require('../models/SubscriptionPlan.mongo');
const asyncHandler = require('../middleware/asyncHandler');

// @desc    Get dashboard stats
// @route   GET /api/admin/dashboard
// @access  Private (Admin)
exports.getDashboardStats = asyncHandler(async (req, res) => {
    try {
        // Get counts for different user types
        const [
            totalUsers,
            totalProviders,
            totalClients,
            totalBeauticians,
            totalBookings,
            completedBookings,
            totalRevenueResult,
            activeSubscriptions
        ] = await Promise.all([
            User.countDocuments(),
            User.countDocuments({ role: 'provider' }),
            User.countDocuments({ role: 'client' }),
            User.countDocuments({ role: 'beautician' }),
            Booking.countDocuments(),
            Booking.countDocuments({ status: 'completed' }),
            Payment.aggregate([
                {
                    $match: {
                        status: 'completed',
                        type: 'booking'
                    }
                },
                {
                    $group: {
                        _id: null,
                        totalPlatformFee: { $sum: '$platformFee' }
                    }
                }
            ]),
            Provider.countDocuments({
                'subscription.status': 'active'
            })
        ]);

        const totalRevenue = totalRevenueResult[0] ? totalRevenueResult[0].totalPlatformFee : 0;

        // Get recent activity
        const [recentBookings, recentUsers] = await Promise.all([
            Booking.find()
                .sort({ createdAt: -1 })
                .limit(10)
                .populate('clientId', 'firstName lastName')
                .populate({
                    path: 'providerId',
                    populate: {
                        path: 'userId',
                        select: 'firstName lastName'
                    }
                }),
            User.find({}, 'firstName lastName email role createdAt')
                .sort({ createdAt: -1 })
                .limit(10)
        ]);

        res.json({
            success: true,
            data: {
                stats: {
                    totalUsers,
                    totalProviders,
                    totalClients,
                    totalBeauticians,
                    totalBookings,
                    completedBookings,
                    totalRevenue,
                    activeSubscriptions
                },
                recentBookings,
                recentUsers
            }
        });
    } catch (error) {
        console.error('Error fetching dashboard stats:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch dashboard stats'
        });
    }
});

// @desc    Get all providers
// @route   GET /api/admin/providers
// @access  Private (Admin)
exports.getProviders = asyncHandler(async (req, res) => {
    const { status, page = 1, limit = 20 } = req.query;

    const where = {};
    if (status) {
        where.isVisible = status === 'active';
    }

    const offset = (parseInt(page) - 1) * parseInt(limit);

    const [count, providers] = await Promise.all([
        Provider.countDocuments(where),
        Provider.find(where)
            .populate('userId', 'firstName lastName email phone avatar isActive createdAt')
            .sort({ createdAt: -1 })
            .skip(offset)
            .limit(parseInt(limit))
    ]);

    res.json({
        success: true,
        data: {
            providers,
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total: count,
                pages: Math.ceil(count / parseInt(limit))
            }
        }
    });
});

// @desc    Get all users
// @route   GET /api/admin/users
// @access  Private (Admin)
exports.getUsers = asyncHandler(async (req, res) => {
    const { role, status, search, page = 1, limit = 20 } = req.query;

    const where = {};

    if (role) where.role = role;
    if (status) where.isActive = status === 'active';
    
    if (search) {
        where.$or = [
            { email: { $regex: search, $options: 'i' } },
            { firstName: { $regex: search, $options: 'i' } },
            { lastName: { $regex: search, $options: 'i' } }
        ];
    }

    const offset = (parseInt(page) - 1) * parseInt(limit);

    const [count, users] = await Promise.all([
        User.countDocuments(where),
        User.find(where, { password: 0 }) // Exclude password field
            .sort({ createdAt: -1 })
            .skip(offset)
            .limit(parseInt(limit))
    ]);

    res.json({
        success: true,
        data: {
            users,
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total: count,
                pages: Math.ceil(count / parseInt(limit))
            }
        }
    });
});

// @desc    Get user by ID
// @route   GET /api/admin/users/:id
// @access  Private (Admin)
exports.getUserById = asyncHandler(async (req, res) => {
    const user = await User.findById(req.params.id, { password: 0 });

    if (!user) {
        return res.status(404).json({
            success: false,
            message: 'User not found'
        });
    }

    res.json({
        success: true,
        data: { user }
    });
});

// @desc    Create new user
// @route   POST /api/admin/users
// @access  Private (Admin)
exports.createUser = asyncHandler(async (req, res) => {
    const { firstName, lastName, email, password, phone, role } = req.body;

    // Check if user exists
    const userExists = await User.findOne({ email });
    if (userExists) {
        return res.status(400).json({
            success: false,
            message: 'User already exists'
        });
    }

    // Create user
    const user = await User.create({
        firstName,
        lastName,
        email,
        password, // Hook will hash this
        phone,
        role,
        isActive: true,
        isVerified: true
    });

    // If provider or beautician, create provider profile
    if (role === 'provider' || role === 'beautician') {
        await Provider.create({
            userId: user._id,
            businessName: role === 'beautician' ? `${firstName} ${lastName}` : (req.body.businessName || `${firstName}'s Business`),
            specializations: [],
            serviceType: role === 'beautician' ? 'mobile' : 'studio'
        });
    }

    res.status(201).json({
        success: true,
        message: 'User created successfully',
        data: { user }
    });
});

// @desc    Update user
// @route   PUT /api/admin/users/:id
// @access  Private (Admin)
exports.updateUser = asyncHandler(async (req, res) => {
    const { firstName, lastName, email, phone, role, isActive, isVerified } = req.body;

    const user = await User.findById(req.params.id);

    if (!user) {
        return res.status(404).json({
            success: false,
            message: 'User not found'
        });
    }

    // Update user fields
    if (firstName !== undefined) user.firstName = firstName;
    if (lastName !== undefined) user.lastName = lastName;
    if (email !== undefined) user.email = email;
    if (phone !== undefined) user.phone = phone;
    if (role !== undefined) user.role = role;
    if (isActive !== undefined) user.isActive = isActive;
    if (isVerified !== undefined) user.isVerified = isVerified;

    await user.save();

    res.json({
        success: true,
        message: 'User updated successfully',
        data: { user }
    });
});

// @desc    Delete user
// @route   DELETE /api/admin/users/:id
// @access  Private (Admin)
exports.deleteUser = asyncHandler(async (req, res) => {
    const user = await User.findById(req.params.id);

    if (!user) {
        return res.status(404).json({
            success: false,
            message: 'User not found'
        });
    }

    // If user is a provider, delete provider profile
    if (user.role === 'provider' || user.role === 'beautician') {
        await Provider.deleteOne({ userId: user._id });
    }

    await user.remove();

    res.json({
        success: true,
        message: 'User deleted successfully'
    });
});

// @desc    Get all bookings
// @route   GET /api/admin/bookings
// @access  Private (Admin)
exports.getBookings = asyncHandler(async (req, res) => {
    const { status, page = 1, limit = 20 } = req.query;

    const where = {};
    if (status) {
        where.status = status;
    }

    const offset = (parseInt(page) - 1) * parseInt(limit);

    const [count, bookings] = await Promise.all([
        Booking.countDocuments(where),
        Booking.find(where)
            .populate('clientId', 'firstName lastName email')
            .populate({
                path: 'providerId',
                populate: {
                    path: 'userId',
                    select: 'firstName lastName email'
                }
            })
            .sort({ createdAt: -1 })
            .skip(offset)
            .limit(parseInt(limit))
    ]);

    res.json({
        success: true,
        data: {
            bookings,
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total: count,
                pages: Math.ceil(count / parseInt(limit))
            }
        }
    });
});

// @desc    Get all disputes
// @route   GET /api/admin/disputes
// @access  Private (Admin)
exports.getDisputes = asyncHandler(async (req, res) => {
    const { status, page = 1, limit = 20 } = req.query;

    const where = {};
    if (status) {
        where.status = status;
    }

    const offset = (parseInt(page) - 1) * parseInt(limit);

    const [count, disputes] = await Promise.all([
        Dispute.countDocuments(where),
        Dispute.find(where)
            .populate('clientId', 'firstName lastName email')
            .populate({
                path: 'providerId',
                populate: {
                    path: 'userId',
                    select: 'firstName lastName email'
                }
            })
            .populate('bookingId')
            .sort({ createdAt: -1 })
            .skip(offset)
            .limit(parseInt(limit))
    ]);

    res.json({
        success: true,
        data: {
            disputes,
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total: count,
                pages: Math.ceil(count / parseInt(limit))
            }
        }
    });
});

// @desc    Resolve dispute
// @route   PUT /api/admin/disputes/:id/resolve
// @access  Private (Admin)
exports.resolveDispute = asyncHandler(async (req, res) => {
    const { resolution, refundAmount } = req.body;
    
    const dispute = await Dispute.findById(req.params.id);
    
    if (!dispute) {
        return res.status(404).json({
            success: false,
            message: 'Dispute not found'
        });
    }
    
    // Update dispute
    dispute.status = 'resolved';
    dispute.resolution = resolution;
    dispute.resolvedAt = new Date();
    
    await dispute.save();
    
    res.json({
        success: true,
        message: 'Dispute resolved successfully',
        data: { dispute }
    });
});

// @desc    Get analytics
// @route   GET /api/admin/analytics
// @access  Private (Admin)
exports.getAnalytics = asyncHandler(async (req, res) => {
    try {
        // Get booking statistics
        const bookingStats = await Booking.aggregate([
            {
                $group: {
                    _id: '$status',
                    count: { $sum: 1 }
                }
            }
        ]);
        
        // Get revenue statistics
        const revenueStats = await Payment.aggregate([
            {
                $match: {
                    status: 'completed',
                    type: 'booking'
                }
            },
            {
                $group: {
                    _id: null,
                    totalRevenue: { $sum: '$amount' },
                    platformFee: { $sum: '$platformFee' }
                }
            }
        ]);
        
        // Get user growth
        const userGrowth = await User.aggregate([
            {
                $group: {
                    _id: { $dateToString: { format: '%Y-%m', date: '$createdAt' } },
                    count: { $sum: 1 }
                }
            },
            { $sort: { _id: 1 } }
        ]);
        
        res.json({
            success: true,
            data: {
                bookingStats,
                revenueStats: revenueStats[0] || { totalRevenue: 0, platformFee: 0 },
                userGrowth
            }
        });
    } catch (error) {
        console.error('Error fetching analytics:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch analytics'
        });
    }
});

// @desc    Reset user password
// @route   POST /api/admin/users/:id/reset-password
// @access  Private (Admin)
exports.resetUserPassword = asyncHandler(async (req, res) => {
    const user = await User.findById(req.params.id);
    
    if (!user) {
        return res.status(404).json({
            success: false,
            message: 'User not found'
        });
    }
    
    // Generate temporary password
    const tempPassword = 'TempPass123!';
    user.password = tempPassword; // This will be hashed by the pre-save hook
    
    await user.save();
    
    res.json({
        success: true,
        message: 'Password reset successfully. Temporary password: ' + tempPassword
    });
});