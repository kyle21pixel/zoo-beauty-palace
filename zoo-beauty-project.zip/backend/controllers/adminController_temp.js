const User = require('../models/User');
const Provider = require('../models/Provider');
const Booking = require('../models/Booking');
const Payment = require('../models/Payment');
const Review = require('../models/Review');
const Dispute = require('../models/Dispute');
const Analytics = require('../models/Analytics');
const SubscriptionPlan = require('../models/SubscriptionPlan'); // Import SubscriptionPlan
const Assignment = require('../models/Assignment'); // Import Assignment model
const Service = require('../models/Service'); // Import Service model
const { Op, fn, col, literal, Sequelize } = require('sequelize'); // Import Sequelize operators and functions
const asyncHandler = require('../middleware/asyncHandler');

// @desc    Get dashboard stats
// @route   GET /api/admin/dashboard
// @access  Private (Admin)
exports.getDashboardStats = asyncHandler(async (req, res) => {
    const [
        totalUsers,
        totalProviders,
        totalClients,
        totalBookings,
        completedBookings,
        totalRevenueResult, // Renamed to avoid conflict with `totalRevenue` from Mongoose aggregate
        activeSubscriptions
    ] = await Promise.all([
        User.count(),
        User.count({ where: { role: 'provider' } }),
        User.count({ where: { role: 'client' } }),
        Booking.count(),
        Booking.count({ where: { status: 'completed' } }),
        Payment.findAll({
            attributes: [
                [fn('SUM', col('platformFee')), 'totalPlatformFee']
            ],
            where: { status: 'completed', type: 'booking' },
            raw: true
        }),
        Provider.count({
            where: {
                'subscription.status': 'active' // Access JSON field
            }
        })
    ]);

    const totalRevenue = totalRevenueResult[0] ? parseFloat(totalRevenueResult[0].totalPlatformFee) : 0;

    // Get recent activity
    const recentBookings = await Booking.findAll({
        include: [
            { model: User, as: 'client', attributes: ['firstName', 'lastName'] },
            {
                model: Provider,
                as: 'provider',
                include: [{ model: User, as: 'user', attributes: ['firstName', 'lastName'] }]
            }
        ],
        order: [['createdAt', 'DESC']],
        limit: 10
    });

    const recentUsers = await User.findAll({
        attributes: ['firstName', 'lastName', 'email', 'role', 'createdAt'],
        order: [['createdAt', 'DESC']],
        limit: 10
    });

    res.json({
        success: true,
        data: {
            stats: {
                totalUsers,
                totalProviders,
                totalClients,
                totalBookings,
                completedBookings,
                totalRevenue,
                activeSubscriptions
            },
            recentBookings,
            recentUsers
        }
    });
});

// @desc    Get all providers
// @route   GET /api/admin/providers
// @access  Private (Admin)
exports.getProviders = asyncHandler(async (req, res) => {
    const { status, page = 1, limit = 20 } = req.query;

    const where = {};
    if (status) {
        // Assuming 'status' refers to 'isVisible' for providers
        // Or if it refers to user's isActive status, we need a join
        // For now, let's filter by provider's isVisible status
        where.isVisible = status === 'active';
    }

    const offset = (parseInt(page) - 1) * parseInt(limit);

    const { count, rows: providers } = await Provider.findAndCountAll({
        where,
        include: [{
            model: User,
            as: 'user',
            attributes: ['firstName', 'lastName', 'email', 'phone', 'avatar', 'isActive', 'createdAt']
        }],
        order: [['createdAt', 'DESC']],
        limit: parseInt(limit),
        offset
    });

    res.json({
        success: true,
        data: {
            providers,
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total: count,
                pages: Math.ceil(count / parseInt(limit))
            }
        }
    });
});

// @desc    Get all users
// @route   GET /api/admin/users
// @access  Private (Admin)
exports.getUsers = asyncHandler(async (req, res) => {
    const { role, status, search, page = 1, limit = 20 } = req.query;

    const where = {};

    if (role) where.role = role;
    if (status) where.isActive = status === 'active';
    if (search) {
        where[Op.or] = [
            { email: { [Op.like]: `%${search}%` } },
            { firstName: { [Op.like]: `%${search}%` } },
            { lastName: { [Op.like]: `%${search}%` } }
        ];
    }

    const offset = (parseInt(page) - 1) * parseInt(limit);

    const { count, rows: users } = await User.findAndCountAll({
        where,
        attributes: { exclude: ['password'] },
        order: [['createdAt', 'DESC']],
        limit: parseInt(limit),
        offset
    });

    res.json({
        success: true,
        data: {
            users,
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total: count,
                pages: Math.ceil(count / parseInt(limit))
            }
        }
    });
});

// @desc    Create new user
// @route   POST /api/admin/users
// @access  Private (Admin)
exports.createUser = asyncHandler(async (req, res) => {
    const { firstName, lastName, email, password, phone, role } = req.body;

    // Check if user exists
    const userExists = await User.findOne({ where: { email } });
    if (userExists) {
        return res.status(400).json({
            success: false,
            message: 'User already exists'
        });
    }

    // Create user
    const user = await User.create({
        firstName,
        lastName,
        email,
        password, // Hook will hash this
        phone,
        role,
        isActive: true,
        isVerified: true
    });

    // If provider or beautician, create provider profile
    if (role === 'provider' || role === 'beautician') {
        await Provider.create({
            userId: user.id,
            businessName: `${firstName} ${lastName}'s Business`,
            bio: '',
            specializations: [],
            serviceType: role === 'provider' ? 'fullService' : 'specialist',
            isVisible: true
        });
    }

    res.status(201).json({
        success: true,
        message: 'User created successfully',
        data: { user }
    });
});

// @desc    Get user details
// @route   GET /api/admin/users/:id
// @access  Private (Admin)
exports.getUserDetails = asyncHandler(async (req, res) => {
    const user = await User.findByPk(req.params.id, {
        attributes: { exclude: ['password'] }
    });

    if (!user) {
        return res.status(404).json({
            success: false,
            message: 'User not found'
        });
    }

    res.json({
        success: true,
        data: { user }
    });
});

// @desc    Update user
// @route   PUT /api/admin/users/:id
// @access  Private (Admin)
exports.updateUser = asyncHandler(async (req, res) => {
    const { firstName, lastName, email, phone, role, isActive } = req.body;

    const user = await User.findByPk(req.params.id);

    if (!user) {
        return res.status(404).json({
            success: false,
            message: 'User not found'
        });
    }

    // Update user
    await user.update({
        firstName,
        lastName,
        email,
        phone,
        role,
        isActive
    });

    res.json({
        success: true,
        message: 'User updated successfully',
        data: { user }
    });
});

// @desc    Delete user
// @route   DELETE /api/admin/users/:id
// @access  Private (Admin)
exports.deleteUser = asyncHandler(async (req, res) => {
    const user = await User.findByPk(req.params.id);

    if (!user) {
        return res.status(404).json({
            success: false,
            message: 'User not found'
        });
    }

    // If user is a provider or beautician, delete their provider profile too
    if (user.role === 'provider' || user.role === 'beautician') {
        await Provider.destroy({ where: { userId: user.id } });
    }

    await user.destroy();

    res.json({
        success: true,
        message: 'User deleted successfully'
    });
});

// @desc    Get all disputes
// @route   GET /api/admin/disputes
// @access  Private (Admin)
exports.getDisputes = asyncHandler(async (req, res) => {
    const { status, page = 1, limit = 20 } = req.query;

    const where = {};
    if (status) where.status = status;

    const offset = (parseInt(page) - 1) * parseInt(limit);

    const { count, rows: disputes } = await Dispute.findAndCountAll({
        where,
        include: [
            { model: User, as: 'client', attributes: ['firstName', 'lastName'] },
            { model: Provider, as: 'provider', attributes: ['businessName'] },
            { model: Booking, as: 'booking', attributes: ['amount', 'status'] }
        ],
        order: [['createdAt', 'DESC']],
        limit: parseInt(limit),
        offset
    });

    res.json({
        success: true,
        data: {
            disputes,
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total: count,
                pages: Math.ceil(count / parseInt(limit))
            }
        }
    });
});

// @desc    Resolve dispute
// @route   PUT /api/admin/disputes/:id/resolve
// @access  Private (Admin)
exports.resolveDispute = asyncHandler(async (req, res) => {
    const { action, note } = req.body;

    const dispute = await Dispute.findByPk(req.params.id, {
        include: [
            { model: User, as: 'client' },
            { model: Provider, as: 'provider' },
            { model: Booking, as: 'booking' }
        ]
    });

    if (!dispute) {
        return res.status(404).json({
            success: false,
            message: 'Dispute not found'
        });
    }

    // Update dispute
    dispute.status = 'resolved';
    dispute.resolution = {
        action,
        note,
        resolvedBy: req.user.id,
        resolvedAt: new Date()
    };
    await dispute.save();

    // Handle refund if needed
    if (action === 'refund') {
        // In a real app, you would integrate with a payment processor here
        // For now, we'll just update the booking status
        if (dispute.booking) {
            dispute.booking.status = 'refunded';
            await dispute.booking.save();
        }
    }

    res.json({
        success: true,
        message: 'Dispute resolved successfully',
        data: { dispute }
    });
});

// @desc    Get analytics data
// @route   GET /api/admin/analytics
// @access  Private (Admin)
exports.getAnalytics = asyncHandler(async (req, res) => {
    const { startDate, endDate } = req.query;

    const start = startDate ? new Date(startDate) : new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    const end = endDate ? new Date(endDate) : new Date();

    // Get analytics data
    const analytics = await Analytics.getDateRange(start, end);

    res.json({
        success: true,
        data: { analytics }
    });
});

// @desc    Get detailed analytics data
// @route   GET /api/admin/analytics/detailed
// @access  Private (Admin)
exports.getDetailedAnalytics = asyncHandler(async (req, res) => {
    const { startDate, endDate } = req.query;

    const start = startDate ? new Date(startDate) : new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    const end = endDate ? new Date(endDate) : new Date();

    // Get analytics data
    const analytics = await Analytics.getDateRange(start, end);
    
    // Get additional statistics
    const [userStats, providerStats, bookingStats, revenueStats] = await Promise.all([
        // User statistics
        User.count({
            where: {
                createdAt: {
                    [Op.between]: [start, end]
                }
            },
            group: ['role']
        }),
        // Provider statistics
        Provider.count({
            where: {
                createdAt: {
                    [Op.between]: [start, end]
                }
            }
        }),
        // Booking statistics
        Booking.count({
            where: {
                createdAt: {
                    [Op.between]: [start, end]
                }
            },
            group: ['status']
        }),
        // Revenue statistics
        Booking.sum('amount', {
            where: {
                createdAt: {
                    [Op.between]: [start, end]
                },
                status: 'completed'
            }
        })
    ]);
    
    // Calculate platform fees (10% of revenue)
    const totalRevenue = revenueStats || 0;
    const platformFees = totalRevenue * 0.1;
    
    res.json({
        success: true,
        data: {
            period: {
                startDate: start.toISOString().split('T')[0],
                endDate: end.toISOString().split('T')[0]
            },
            summary: {
                totalRevenue,
                platformFees,
                newUserRegistrations: userStats.reduce((sum, stat) => sum + stat.count, 0),
                newProviders: providerStats,
                totalBookings: bookingStats.reduce((sum, stat) => sum + stat.count, 0)
            },
            userStats,
            bookingStats,
            dailyMetrics: analytics.map(record => ({
                date: record.date,
                ...record.metrics
            }))
        }
    });
});

// @desc    Export analytics report as CSV
// @route   GET /api/admin/analytics/export
// @access  Private (Admin)
exports.exportAnalyticsReport = asyncHandler(async (req, res) => {
    const { startDate, endDate, format = 'csv' } = req.query;

    const start = startDate ? new Date(startDate) : new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    const end = endDate ? new Date(endDate) : new Date();

    // Get analytics data
    const analytics = await Analytics.getDateRange(start, end);
    
    // Get additional statistics
    const [userStats, providerStats, bookingStats, revenueStats] = await Promise.all([
        // User statistics
        User.count({
            where: {
                createdAt: {
                    [Op.between]: [start, end]
                }
            },
            group: ['role']
        }),
        // Provider statistics
        Provider.count({
            where: {
                createdAt: {
                    [Op.between]: [start, end]
                }
            }
        }),
        // Booking statistics
        Booking.count({
            where: {
                createdAt: {
                    [Op.between]: [start, end]
                }
            },
            group: ['status']
        }),
        // Revenue statistics
        Booking.sum('amount', {
            where: {
                createdAt: {
                    [Op.between]: [start, end]
                },
                status: 'completed'
            }
        })
    ]);
    
    // Calculate platform fees (10% of revenue)
    const totalRevenue = revenueStats || 0;
    const platformFees = totalRevenue * 0.1;
    
    // Prepare data for export
    const reportData = {
        period: {
            startDate: start.toISOString().split('T')[0],
            endDate: end.toISOString().split('T')[0]
        },
        summary: {
            totalRevenue,
            platformFees,
            newUserRegistrations: userStats.reduce((sum, stat) => sum + stat.count, 0),
            newProviders: providerStats,
            totalBookings: bookingStats.reduce((sum, stat) => sum + stat.count, 0)
        },
        userStats,
        bookingStats,
        dailyMetrics: analytics.map(record => ({
            date: record.date,
            ...record.metrics
        }))
    };

    if (format === 'csv') {
        // Convert to CSV format
        let csv = 'Date,New Users,New Providers,New Clients,Total Bookings,Completed Bookings,Cancelled Bookings,Revenue,Platform Fees,Active Subscriptions\n';
        
        analytics.forEach(record => {
            const metrics = record.metrics;
            csv += `${record.date},${metrics.newUsers},${metrics.newProviders},${metrics.newClients},${metrics.totalBookings},${metrics.completedBookings},${metrics.cancelledBookings},${metrics.revenue},${metrics.platformFees},${metrics.activeSubscriptions}\n`;
        });
        
        res.header('Content-Type', 'text/csv');
        res.attachment('analytics-report.csv');
        return res.send(csv);
    } else {
        // Return JSON format
        res.json({
            success: true,
            data: reportData
        });
    }
});

// @desc    Get all bookings
// @route   GET /api/admin/bookings
// @access  Private (Admin)
exports.getBookings = asyncHandler(async (req, res) => {
    const { status, page = 1, limit = 20 } = req.query;

    const where = {};
    if (status) where.status = status;

    const offset = (parseInt(page) - 1) * parseInt(limit);

    const { count, rows: bookings } = await Booking.findAndCountAll({
        where,
        include: [
            { model: User, as: 'client', attributes: ['firstName', 'lastName'] },
            {
                model: Provider,
                as: 'provider',
                include: [{ model: User, as: 'user', attributes: ['firstName', 'lastName'] }]
            }
        ],
        order: [['createdAt', 'DESC']],
        limit: parseInt(limit),
        offset
    });

    res.json({
        success: true,
        data: {
            bookings,
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total: count,
                pages: Math.ceil(count / parseInt(limit))
            }
        }
    });
});

// @desc    Reset user password
// @route   POST /api/admin/users/:id/reset-password
// @access  Private (Admin)
exports.resetUserPassword = asyncHandler(async (req, res) => {
    const user = await User.findByPk(req.params.id);

    if (!user) {
        return res.status(404).json({
            success: false,
            message: 'User not found'
        });
    }

    // Generate temporary password
    const temporaryPassword = Math.random().toString(36).slice(-8);
    
    // Update user password (will be hashed by hook)
    user.password = temporaryPassword;
    await user.save();

    res.json({
        success: true,
        message: 'Password reset successfully',
        data: { temporaryPassword }
    });
});

// @desc    Assign task to provider/beautician
// @route   POST /api/admin/assignments
// @access  Private (Admin)
exports.assignTask = asyncHandler(async (req, res) => {
    const { title, description, assignedToId, providerId, priority = 'medium', dueDate } = req.body;
    const assignedById = req.user.id;

    // Validate assignedTo user exists and is a provider or beautician
    const assignedToUser = await User.findByPk(assignedToId);
    if (!assignedToUser || (assignedToUser.role !== 'provider' && assignedToUser.role !== 'beautician')) {
        return res.status(400).json({
            success: false,
            message: 'Assigned user must be a provider or beautician'
        });
    }

    // Validate provider exists
    const provider = await Provider.findByPk(providerId);
    if (!provider) {
        return res.status(400).json({
            success: false,
            message: 'Provider not found'
        });
    }

    // Create assignment
    const assignment = await Assignment.create({
        title,
        description,
        assignedToId,
        assignedById,
        providerId,
        priority,
        dueDate,
        status: 'pending'
    });

    // Send notification to the assigned beautician
    const notificationService = require('../services/notificationService');
    await notificationService.sendAssignmentNotification(assignedToId, assignment);

    res.status(201).json({
        success: true,
        message: 'Task assigned successfully',
        data: { assignment }
    });
});

// @desc    Get all assignments
// @route   GET /api/admin/assignments
// @access  Private (Admin)
exports.getAssignments = asyncHandler(async (req, res) => {
    const { status, assignedToId, assignedById, providerId, priority, page = 1, limit = 20 } = req.query;

    const where = {};
    if (status) where.status = status;
    if (assignedToId) where.assignedToId = assignedToId;
    if (assignedById) where.assignedById = assignedById;
    if (providerId) where.providerId = providerId;
    if (priority) where.priority = priority;

    const offset = (parseInt(page) - 1) * parseInt(limit);

    const { count, rows: assignments } = await Assignment.findAndCountAll({
        where,
        include: [
            { model: User, as: 'assignedBy', attributes: ['firstName', 'lastName', 'email'] },
            { model: User, as: 'assignedTo', attributes: ['firstName', 'lastName', 'email'] },
            { model: Provider, as: 'provider', attributes: ['businessName'] }
        ],
        order: [['createdAt', 'DESC']],
        limit: parseInt(limit),
        offset
    });

    res.json({
        success: true,
        data: {
            assignments,
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total: count,
                pages: Math.ceil(count / parseInt(limit))
            }
        }
    });
});

// @desc    Update assignment status
// @route   PUT /api/admin/assignments/:id/status
// @access  Private (Admin)
exports.updateAssignmentStatus = asyncHandler(async (req, res) => {
    const { status } = req.body;

    const assignment = await Assignment.findByPk(req.params.id, {
        include: [
            { model: User, as: 'assignedTo', attributes: ['id'] }
        ]
    });
    if (!assignment) {
        return res.status(404).json({
            success: false,
            message: 'Assignment not found'
        });
    }

    assignment.status = status;
    if (status === 'completed') {
        assignment.completedAt = new Date();
    }
    await assignment.save();

    // Send notification to the assigned beautician about status change
    if (assignment.assignedTo) {
        const notificationService = require('../services/notificationService');
        await notificationService.sendNotification(
            assignment.assignedTo.id,
            'assignment_status',
            'Assignment Status Updated',
            `Your assignment "${assignment.title}" status has been updated to ${status}`,
            { assignmentId: assignment.id, status: status },
            `/dashboard/assignments/${assignment.id}`
        );
    }

    res.json({
        success: true,
        message: 'Assignment status updated successfully',
        data: { assignment }
    });
});

// @desc    Bulk update assignment statuses
// @route   PUT /api/admin/assignments/bulk-status
// @access  Private (Admin)
exports.bulkUpdateAssignmentStatus = asyncHandler(async (req, res) => {
    const { assignmentIds, status } = req.body;

    if (!assignmentIds || !Array.isArray(assignmentIds) || assignmentIds.length === 0) {
        return res.status(400).json({
            success: false,
            message: 'Assignment IDs are required'
        });
    }

    if (!status) {
        return res.status(400).json({
            success: false,
            message: 'Status is required'
        });
    }

    try {
        // Update all assignments
        const [updatedCount] = await Assignment.update(
            { status: status },
            { where: { id: assignmentIds } }
        );

        // If status is completed, set completedAt
        if (status === 'completed') {
            await Assignment.update(
                { completedAt: new Date() },
                { where: { id: assignmentIds } }
            );
        }

        // Send notifications to assigned beauticians
        const assignments = await Assignment.findAll({
            where: { id: assignmentIds },
            include: [
                { model: User, as: 'assignedTo', attributes: ['id'] }
            ]
        });

        const notificationService = require('../services/notificationService');
        for (const assignment of assignments) {
            if (assignment.assignedTo) {
                await notificationService.sendNotification(
                    assignment.assignedTo.id,
                    'assignment_status',
                    'Assignment Status Updated',
                    `Your assignment "${assignment.title}" status has been updated to ${status}`, 
                    { assignmentId: assignment.id, status: status },
                    `/dashboard/assignments/${assignment.id}`
                );
            }
        }

        res.json({
            success: true,
            message: `${updatedCount} assignments updated successfully`,
            data: { updatedCount }
        });
    } catch (error) {
        console.error('Error updating assignments:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to update assignments'
        });
    }
});

// @desc    Bulk delete assignments
// @route   DELETE /api/admin/assignments/bulk
// @access  Private (Admin)
exports.bulkDeleteAssignments = asyncHandler(async (req, res) => {
    const { assignmentIds } = req.body;

    if (!assignmentIds || !Array.isArray(assignmentIds) || assignmentIds.length === 0) {
        return res.status(400).json({
            success: false,
            message: 'Assignment IDs are required'
        });
    }

    try {
        const deletedCount = await Assignment.destroy({
            where: { id: assignmentIds }
        });

        res.json({
            success: true,
            message: `${deletedCount} assignments deleted successfully`,
            data: { deletedCount }
        });
    } catch (error) {
        console.error('Error deleting assignments:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to delete assignments'
        });
    }
});