const { Op, fn, col, literal } = require('sequelize');
const Message = require('../models/Message');
const User = require('../models/User');
const { asyncHandler } = require('../middleware/errorHandler');

// @desc    Get conversations
// @route   GET /api/chat/conversations
// @access  Private
exports.getConversations = asyncHandler(async (req, res) => {
    const userId = req.user.id;

    // Find all messages involving the user, excluding those where user has "deleted" the conversation
    const userMessages = await Message.findAll({
        where: {
            [Op.or]: [{ senderId: userId }, { receiverId: userId }],
            // Ensure userId is not in the deletedBy array for the message
            deletedBy: { [Op.notJsonContains]: [userId] } // Use Op.notJsonContains for JSON array
        },
        order: [['createdAt', 'DESC']]
    });

    const conversationsMap = new Map();

    for (const message of userMessages) {
        if (!conversationsMap.has(message.conversationId)) {
            conversationsMap.set(message.conversationId, message);
        }
    }

    const conversations = Array.from(conversationsMap.values());

    // Populate sender and receiver for each conversation
    await Promise.all(conversations.map(async (conv) => {
        conv.sender = await User.findByPk(conv.senderId, { attributes: ['firstName', 'lastName', 'avatar'] });
        conv.receiver = await User.findByPk(conv.receiverId, { attributes: ['firstName', 'lastName', 'avatar'] });
    }));

    const unreadCounts = await Message.findAll({
        attributes: [
            'conversationId',
            [fn('COUNT', col('id')), 'unreadCount']
        ],
        where: {
            receiverId: userId,
            isRead: false,
            deletedBy: { [Op.notJsonContains]: [userId] } // Consider deletedBy for unread count
        },
        group: ['conversationId']
    });

    const unreadCountMap = unreadCounts.reduce((acc, item) => {
        acc[item.conversationId] = item.get('unreadCount');
        return acc;
    }, {});

    const results = conversations.map(conv => {
        const conversation = conv.toJSON();
        conversation.unreadCount = unreadCountMap[conversation.conversationId] || 0;
        return conversation;
    });

    res.json({
        success: true,
        data: { conversations: results }
    });
});

// @desc    Get messages in a conversation
// @route   GET /api/chat/messages/:userId
// @access  Private
exports.getMessages = asyncHandler(async (req, res) => {
    const { userId } = req.params; // This userId is the OTHER user's ID
    const { page = 1, limit = 50 } = req.query;

    const conversationId = Message.generateConversationId(req.user.id, userId);
    const offset = (parseInt(page) - 1) * parseInt(limit);

    const { count, rows: messages } = await Message.findAndCountAll({
        where: {
            conversationId,
            deletedBy: { [Op.notJsonContains]: [req.user.id] } // Use Op.notJsonContains for JSON array
        },
        include: [
            { model: User, as: 'sender', attributes: ['firstName', 'lastName', 'avatar'] },
            { model: User, as: 'receiver', attributes: ['firstName', 'lastName', 'avatar'] }
        ],
        order: [['createdAt', 'ASC']], // Order ascending for chat history
        limit: parseInt(limit),
        offset
    });

    // Mark messages as read by the current user
    await Message.update(
        { isRead: true, readAt: new Date() },
        {
            where: {
                conversationId,
                receiverId: req.user.id,
                isRead: false,
                deletedBy: { [Op.notJsonContains]: [req.user.id] }
            }
        }
    );

    res.json({
        success: true,
        data: {
            messages: messages, // Messages are already in ascending order
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total: count,
                pages: Math.ceil(count / parseInt(limit))
            }
        }
    });
});

// @desc    Send message
// @route   POST /api/chat/send
// @access  Private
exports.sendMessage = asyncHandler(async (req, res) => {
    const { receiverId, message, type, attachments } = req.body;

    // Check if receiver exists
    const recipient = await User.findByPk(receiverId);
    if (!recipient) {
        return res.status(404).json({
            success: false,
            message: 'Recipient not found'
        });
    }

    const conversationId = Message.generateConversationId(req.user.id, receiverId);

    const newMessage = await Message.create({
        conversationId,
        senderId: req.user.id,
        receiverId,
        content: message, // Changed from 'message' to 'content' to match model
        type: type || 'text',
        attachments
    });

    const fullMessage = await Message.findByPk(newMessage.id, {
        include: [
            { model: User, as: 'sender', attributes: ['firstName', 'lastName', 'avatar'] },
            { model: User, as: 'receiver', attributes: ['firstName', 'lastName', 'avatar'] }
        ]
    });

    // Emit socket event for real-time delivery
    const io = req.app.get('io');
    if (io) {
        io.to(receiverId.toString()).emit('new_message', fullMessage);
        io.to(req.user.id.toString()).emit('message_sent', fullMessage); // Notify sender as well
    }


    res.status(201).json({
        success: true,
        message: 'Message sent successfully',
        data: { message: fullMessage }
    });
});

// @desc    Mark messages as read
// @route   PUT /api/chat/mark-read/:conversationId
// @access  Private
exports.markAsRead = asyncHandler(async (req, res) => {
    const { conversationId } = req.params;

    await Message.update(
        { isRead: true, readAt: new Date() },
        { where: { conversationId, receiverId: req.user.id, isRead: false } }
    );

    res.json({
        success: true,
        message: 'Messages marked as read'
    });
});

// @desc    Delete conversation for a user (soft delete for one user)
// @route   DELETE /api/chat/conversation/:conversationId
// @access  Private
exports.deleteConversation = asyncHandler(async (req, res) => {
    const { conversationId } = req.params;
    const userId = req.user.id;

    // Find all messages in the conversation not yet deleted by this user
    const messages = await Message.findAll({
        where: {
            conversationId,
            deletedBy: { [Op.notJsonContains]: [userId] }
        }
    });

    // Update each message's deletedBy array
    for (const message of messages) {
        let deletedBy = message.deletedBy || [];
        if (!deletedBy.includes(userId)) {
            deletedBy.push(userId);
            message.deletedBy = deletedBy; // Reassign to trigger Sequelize JSON setter
            await message.save();
        }
    }

    res.json({
        success: true,
        message: 'Conversation deleted for this user'
    });
});
