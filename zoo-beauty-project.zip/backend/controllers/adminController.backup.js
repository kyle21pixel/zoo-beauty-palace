const User = require('../models/User');
const Provider = require('../models/Provider');
const Booking = require('../models/Booking');
const Payment = require('../models/Payment');
const Review = require('../models/Review');
const Dispute = require('../models/Dispute');
const Analytics = require('../models/Analytics');
const SubscriptionPlan = require('../models/SubscriptionPlan'); // Import SubscriptionPlan
const Assignment = require('../models/Assignment'); // Import Assignment model
const Service = require('../models/Service'); // Import Service model
const { Op, fn, col, literal, Sequelize } = require('sequelize'); // Import Sequelize operators and functions
const asyncHandler = require('../middleware/asyncHandler');

// @desc    Get dashboard stats
// @route   GET /api/admin/dashboard
// @access  Private (Admin)
exports.getDashboardStats = asyncHandler(async (req, res) => {
    const [
        totalUsers,
        totalProviders,
        totalClients,
        totalBookings,
        completedBookings,
        totalRevenueResult, // Renamed to avoid conflict with `totalRevenue` from Mongoose aggregate
        activeSubscriptions
    ] = await Promise.all([
        User.count(),
        User.count({ where: { role: 'provider' } }),
        User.count({ where: { role: 'client' } }),
        Booking.count(),
        Booking.count({ where: { status: 'completed' } }),
        Payment.findAll({
            attributes: [
                [fn('SUM', col('platformFee')), 'totalPlatformFee']
            ],
            where: { status: 'completed', type: 'booking' },
            raw: true
        }),
        Provider.count({
            where: {
                'subscription.status': 'active' // Access JSON field
            }
        })
    ]);

    const totalRevenue = totalRevenueResult[0] ? parseFloat(totalRevenueResult[0].totalPlatformFee) : 0;

    // Get recent activity
    const recentBookings = await Booking.findAll({
        include: [
            { model: User, as: 'client', attributes: ['firstName', 'lastName'] },
            {
                model: Provider,
                as: 'provider',
                include: [{ model: User, as: 'user', attributes: ['firstName', 'lastName'] }]
            }
        ],
        order: [['createdAt', 'DESC']],
        limit: 10
    });

    const recentUsers = await User.findAll({
        attributes: ['firstName', 'lastName', 'email', 'role', 'createdAt'],
        order: [['createdAt', 'DESC']],
        limit: 10
    });

    res.json({
        success: true,
        data: {
            stats: {
                totalUsers,
                totalProviders,
                totalClients,
                totalBookings,
                completedBookings,
                totalRevenue,
                activeSubscriptions
            },
            recentBookings,
            recentUsers
        }
    });
});

// @desc    Get all providers
// @route   GET /api/admin/providers
// @access  Private (Admin)
exports.getProviders = asyncHandler(async (req, res) => {
    const { status, page = 1, limit = 20 } = req.query;

    const where = {};
    if (status) {
        // Assuming 'status' refers to 'isVisible' for providers
        // Or if it refers to user's isActive status, we need a join
        // For now, let's filter by provider's isVisible status
        where.isVisible = status === 'active';
    }

    const offset = (parseInt(page) - 1) * parseInt(limit);

    const { count, rows: providers } = await Provider.findAndCountAll({
        where,
        include: [{
            model: User,
            as: 'user',
            attributes: ['firstName', 'lastName', 'email', 'phone', 'avatar', 'isActive', 'createdAt']
        }],
        order: [['createdAt', 'DESC']],
        limit: parseInt(limit),
        offset
    });

    res.json({
        success: true,
        data: {
            providers,
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total: count,
                pages: Math.ceil(count / parseInt(limit))
            }
        }
    });
});

// @desc    Get all users
// @route   GET /api/admin/users
// @access  Private (Admin)
exports.getUsers = asyncHandler(async (req, res) => {
    const { role, status, search, page = 1, limit = 20 } = req.query;

    const where = {};

    if (role) where.role = role;
    if (status) where.isActive = status === 'active';
    if (search) {
        where[Op.or] = [
            { email: { [Op.like]: `%${search}%` } },
            { firstName: { [Op.like]: `%${search}%` } },
            { lastName: { [Op.like]: `%${search}%` } }
        ];
    }

    const offset = (parseInt(page) - 1) * parseInt(limit);

    const { count, rows: users } = await User.findAndCountAll({
        where,
        attributes: { exclude: ['password'] },
        order: [['createdAt', 'DESC']],
        limit: parseInt(limit),
        offset
    });

    res.json({
        success: true,
        data: {
            users,
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total: count,
                pages: Math.ceil(count / parseInt(limit))
            }
        }
    });
});

// @desc    Create new user
// @route   POST /api/admin/users
// @access  Private (Admin)
exports.createUser = asyncHandler(async (req, res) => {
    const { firstName, lastName, email, password, phone, role } = req.body;

    // Check if user exists
    const userExists = await User.findOne({ where: { email } });
    if (userExists) {
        return res.status(400).json({
            success: false,
            message: 'User already exists'
        });
    }

    // Create user
    const user = await User.create({
        firstName,
        lastName,
        email,
        password, // Hook will hash this
        phone,
        role,
        isActive: true,
        isVerified: true
    });

    // If provider or beautician, create provider profile
    if (role === 'provider' || role === 'beautician') {
        await Provider.create({
            userId: user.id,
            businessName: role === 'beautician' ? `${firstName} ${lastName}` : (req.body.businessName || `${firstName}'s Business`),
            specializations: [],
            services: [],
            availability: {
                monday: { isAvailable: true, slots: [] },
                tuesday: { isAvailable: true, slots: [] },
                wednesday: { isAvailable: true, slots: [] },
                thursday: { isAvailable: true, slots: [] },
                friday: { isAvailable: true, slots: [] },
                saturday: { isAvailable: true, slots: [] },
                sunday: { isAvailable: false, slots: [] }
            }
        });
    }

    res.status(201).json({
        success: true,
        data: {
            user: {
                id: user.id,
                firstName: user.firstName,
                lastName: user.lastName,
                email: user.email,
                role: user.role
            }
        }
    });
});

// @desc    Get user details
// @route   GET /api/admin/users/:id
// @access  Private (Admin)
exports.getUserDetails = asyncHandler(async (req, res) => {
    const user = await User.findByPk(req.params.id, {
        attributes: { exclude: ['password'] }
    });

    if (!user) {
        return res.status(404).json({
            success: false,
            message: 'User not found'
        });
    }

    let additionalData = {};

    if (user.role === 'provider') {
        const provider = await Provider.findOne({ where: { userId: user.id } });
        if (provider && provider.subscription && provider.subscription.planId) {
            const plan = await SubscriptionPlan.findByPk(provider.subscription.planId);
            // Attach plan details to the provider's subscription object if needed in the frontend
            const providerWithPlan = {
                ...provider.toJSON(),
                subscription: {
                    ...provider.subscription,
                    planDetails: plan ? plan.toJSON() : null
                }
            };
            additionalData.providerProfile = providerWithPlan;
        } else {
            additionalData.providerProfile = provider ? provider.toJSON() : null;
        }
    }

    // Get user's bookings
    const bookings = await Booking.findAll({
        where: {
            [Op.or]: [
                { clientId: user.id },
                // If providerId in booking refers to provider's table ID, not userId
                { '$provider.userId$': user.id } // Use dot notation for nested include conditions
            ]
        },
        include: [{ model: Provider, as: 'provider', attributes: [] }], // Include Provider to enable join condition
        limit: 10,
        order: [['createdAt', 'DESC']]
    });

    additionalData.recentBookings = bookings;

    res.json({
        success: true,
        data: {
            user,
            ...additionalData
        }
    });
});

// @desc    Update user
// @route   PUT /api/admin/users/:id
// @access  Private (Admin)
exports.updateUser = asyncHandler(async (req, res) => {
    const allowedFields = ['firstName', 'lastName', 'phone', 'isActive', 'isVerified', 'role']; // Added 'role'
    const updates = {};

    allowedFields.forEach(field => {
        if (req.body[field] !== undefined) {
            updates[field] = req.body[field];
        }
    });

    const [updated] = await User.update(
        updates,
        {
            where: { id: req.params.id },
            returning: true // For PostgreSQL, not typically supported by MySQL with Sequelize for update
        }
    );

    if (updated === 0) { // Sequelize update returns array [affectedRows]
        return res.status(404).json({
            success: false,
            message: 'User not found'
        });
    }

    const user = await User.findByPk(req.params.id, {
        attributes: { exclude: ['password'] }
    });

    res.json({
        success: true,
        message: 'User updated successfully',
        data: { user }
    });
});

// @desc    Delete user
// @route   DELETE /api/admin/users/:id
// @access  Private (Admin)
exports.deleteUser = asyncHandler(async (req, res) => {
    const user = await User.findByPk(req.params.id);

    if (!user) {
        return res.status(404).json({
            success: false,
            message: 'User not found'
        });
    }

    await user.destroy();

    res.json({
        success: true,
        message: 'User deleted successfully'
    });
});

// @desc    Reset user password (Admin only)
// @route   POST /api/admin/users/:id/reset-password
// @access  Private (Admin)
exports.resetUserPassword = asyncHandler(async (req, res) => {
    const user = await User.findByPk(req.params.id);

    if (!user) {
        return res.status(404).json({
            success: false,
            message: 'User not found'
        });
    }

    // Generate a temporary password
    const tempPassword = `Temp${Math.random().toString(36).slice(-8)}@${Date.now().toString().slice(-4)}`;

    // Update user's password (will be hashed by the beforeUpdate hook)
    user.password = tempPassword;
    await user.save();

    res.json({
        success: true,
        message: 'Password reset successfully',
        data: {
            userId: user.id,
            email: user.email,
            temporaryPassword: tempPassword, // Show this to admin
            note: 'Please provide this temporary password to the user. They should change it after logging in.'
        }
    });
});

// @desc    Get all disputes
// @route   GET /api/admin/disputes
// @access  Private (Admin)
exports.getDisputes = asyncHandler(async (req, res) => {
    const { status, page = 1, limit = 20 } = req.query;

    const where = {};
    if (status) where.status = status;

    const offset = (parseInt(page) - 1) * parseInt(limit);

    const { count, rows: disputes } = await Dispute.findAndCountAll({
        where,
        include: [
            { model: Booking, as: 'booking' },
            { model: User, as: 'reportedBy', attributes: ['firstName', 'lastName', 'email'] },
            { model: User, as: 'reportedAgainst', attributes: ['firstName', 'lastName', 'email'] },
            { model: User, as: 'assignedTo', attributes: ['firstName', 'lastName'], required: false } // assignedTo can be null
        ],
        order: [['createdAt', 'DESC']],
        limit: parseInt(limit),
        offset
    });

    res.json({
        success: true,
        data: {
            disputes,
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total: count,
                pages: Math.ceil(count / parseInt(limit))
            }
        }
    });
});

// @desc    Resolve dispute
// @route   PUT /api/admin/disputes/:id/resolve
// @access  Private (Admin)
exports.resolveDispute = asyncHandler(async (req, res) => {
    const { action, note } = req.body;

    const dispute = await Dispute.findByPk(req.params.id);

    if (!dispute) {
        return res.status(404).json({
            success: false,
            message: 'Dispute not found'
        });
    }

    await dispute.resolve(action, note, req.user.id); // Assuming resolve method exists on Dispute model

    res.json({
        success: true,
        message: 'Dispute resolved successfully',
        data: { dispute }
    });
});

// @desc    Get detailed analytics
// @route   GET /api/admin/analytics/detailed
// @access  Private (Admin)
exports.getDetailedAnalytics = asyncHandler(async (req, res) => {
    const { startDate, endDate } = req.query;

    const start = startDate ? new Date(startDate) : new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    const end = endDate ? new Date(endDate) : new Date();

    // Get analytics data
    const analytics = await Analytics.getDateRange(start, end);
    
    // Get additional statistics
    const [userStats, providerStats, bookingStats, revenueStats] = await Promise.all([
        // User statistics
        User.count({
            where: {
                createdAt: {
                    [Op.between]: [start, end]
                }
            },
            group: ['role']
        }),
        // Provider statistics
        Provider.count({
            where: {
                createdAt: {
                    [Op.between]: [start, end]
                }
            }
        }),
        // Booking statistics
        Booking.count({
            where: {
                createdAt: {
                    [Op.between]: [start, end]
                }
            },
            group: ['status']
        }),
        // Revenue statistics
        Booking.sum('amount', {
            where: {
                createdAt: {
                    [Op.between]: [start, end]
                },
                status: 'completed'
            }
        })
    ]);
    
    // Calculate platform fees (10% of revenue)
    const totalRevenue = revenueStats || 0;
    const platformFees = totalRevenue * 0.1;
    
    // Get top providers by bookings
    const topProviders = await Provider.findAll({
        include: [
            {
                model: User,
                as: 'user',
                attributes: ['firstName', 'lastName']
            }
        ],
        order: [[Sequelize.col('stats.totalBookings'), 'DESC']],
        limit: 10
    });
    
    // Get top services (we'll need to calculate this differently since Service model doesn't have bookingCount)
    // For now, we'll just get all active services
    const topServices = await Service.findAll({
        where: { isActive: true },
        limit: 10
    });

    res.json({
        success: true,
        data: { 
            analytics,
            userStats,
            providerStats,
            bookingStats,
            totalRevenue,
            platformFees,
            topProviders,
            topServices
        }
    });
});

// @desc    Export analytics report as CSV
// @route   GET /api/admin/analytics/export
// @access  Private (Admin)
exports.exportAnalyticsReport = asyncHandler(async (req, res) => {
    const { startDate, endDate, format = 'csv' } = req.query;

    const start = startDate ? new Date(startDate) : new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    const end = endDate ? new Date(endDate) : new Date();

    // Get analytics data
    const analytics = await Analytics.getDateRange(start, end);
    
    // Get additional statistics
    const [userStats, providerStats, bookingStats, revenueStats] = await Promise.all([
        // User statistics
        User.count({
            where: {
                createdAt: {
                    [Op.between]: [start, end]
                }
            },
            group: ['role']
        }),
        // Provider statistics
        Provider.count({
            where: {
                createdAt: {
                    [Op.between]: [start, end]
                }
            }
        }),
        // Booking statistics
        Booking.count({
            where: {
                createdAt: {
                    [Op.between]: [start, end]
                }
            },
            group: ['status']
        }),
        // Revenue statistics
        Booking.sum('amount', {
            where: {
                createdAt: {
                    [Op.between]: [start, end]
                },
                status: 'completed'
            }
        })
    ]);
    
    // Calculate platform fees (10% of revenue)
    const totalRevenue = revenueStats || 0;
    const platformFees = totalRevenue * 0.1;
    
    // Prepare data for export
    const reportData = {
        period: {
            startDate: start.toISOString().split('T')[0],
            endDate: end.toISOString().split('T')[0]
        },
        summary: {
            totalRevenue,
            platformFees,
            newUserRegistrations: userStats.reduce((sum, stat) => sum + stat.count, 0),
            newProviders: providerStats,
            totalBookings: bookingStats.reduce((sum, stat) => sum + stat.count, 0)
        },
        userStats,
        bookingStats,
        dailyMetrics: analytics.map(record => ({
            date: record.date,
            ...record.metrics
        }))
    };

    if (format === 'csv') {
        // Convert to CSV format
        let csv = 'Date,New Users,New Providers,New Clients,Total Bookings,Completed Bookings,Cancelled Bookings,Revenue,Platform Fees,Active Subscriptions\n';
        
        analytics.forEach(record => {
            const metrics = record.metrics;
            csv += `${record.date},${metrics.newUsers},${metrics.newProviders},${metrics.newClients},${metrics.totalBookings},${metrics.completedBookings},${metrics.cancelledBookings},${metrics.revenue},${metrics.platformFees},${metrics.activeSubscriptions}\n`;
        });
        
        res.header('Content-Type', 'text/csv');
        res.attachment('analytics-report.csv');
        return res.send(csv);
    } else {
        // Return JSON format
        res.json({
            success: true,
            data: reportData
        });
    }
});

// @desc    Get all bookings
// @route   GET /api/admin/bookings
// @access  Private (Admin)
exports.getBookings = asyncHandler(async (req, res) => {
    const { status, page = 1, limit = 20 } = req.query;

    const where = {};
    if (status) where.status = status;

    const offset = (parseInt(page) - 1) * parseInt(limit);

    const { count, rows: bookings } = await Booking.findAndCountAll({
        where,
        include: [
            { model: User, as: 'client', attributes: ['firstName', 'lastName', 'email'] },
            {
                model: Provider,
                as: 'provider',
                include: [{ model: User, as: 'user', attributes: ['firstName', 'lastName'] }]
            }
        ],
        order: [['createdAt', 'DESC']],
        limit: parseInt(limit),
        offset
    });

    res.json({
        success: true,
        data: {
            bookings,
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total: count,
                pages: Math.ceil(count / parseInt(limit))
            }
        }
    });
});

// @desc    Assign task to beautician
// @route   POST /api/admin/assignments
// @access  Private (Admin)
exports.assignTask = asyncHandler(async (req, res) => {
    const { title, description, assignedToId, providerId, priority, dueDate } = req.body;

    // Validate assignedToId is a beautician
    const beautician = await User.findByPk(assignedToId);
    if (!beautician || beautician.role !== 'beautician') {
        return res.status(400).json({
            success: false,
            message: 'Assigned user must be a beautician'
        });
    }

    // Generate unique taskId
    const taskId = `TASK-${Date.now()}-${Math.floor(Math.random() * 1000)}`;

    // Create assignment
    const assignment = await Assignment.create({
        taskId,
        title,
        description,
        assignedById: req.user.id, // Admin assigning the task
        assignedToId,
        providerId,
        priority,
        dueDate
    });

    // Send notification to the assigned beautician
    const notificationService = require('../services/notificationService');
    await notificationService.sendAssignmentNotification(assignedToId, assignment);

    res.status(201).json({
        success: true,
        message: 'Task assigned successfully',
        data: { assignment }
    });
};

// @desc    Get all assignments
// @route   GET /api/admin/assignments
// @access  Private (Admin)
exports.getAssignments = asyncHandler(async (req, res) => {
    const { status, assignedToId, assignedById, providerId, priority, page = 1, limit = 20 } = req.query;

    const where = {};
    if (status) where.status = status;
    if (assignedToId) where.assignedToId = assignedToId;
    if (assignedById) where.assignedById = assignedById;
    if (providerId) where.providerId = providerId;
    if (priority) where.priority = priority;

    const offset = (parseInt(page) - 1) * parseInt(limit);

    const { count, rows: assignments } = await Assignment.findAndCountAll({
        where,
        include: [
            { model: User, as: 'assignedBy', attributes: ['firstName', 'lastName', 'email'] },
            { model: User, as: 'assignedTo', attributes: ['firstName', 'lastName', 'email'] },
            { model: Provider, as: 'provider', attributes: ['businessName'] }
        ],
        order: [['createdAt', 'DESC']],
        limit: parseInt(limit),
        offset
    });

    res.json({
        success: true,
        data: {
            assignments,
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total: count,
                pages: Math.ceil(count / parseInt(limit))
            }
        }
    });
});

// @desc    Update assignment status
// @route   PUT /api/admin/assignments/:id/status
// @access  Private (Admin)
exports.updateAssignmentStatus = asyncHandler(async (req, res) => {
    const { status } = req.body;

    const assignment = await Assignment.findByPk(req.params.id, {
        include: [
            { model: User, as: 'assignedTo', attributes: ['id'] }
        ]
    });
    if (!assignment) {
        return res.status(404).json({
            success: false,
            message: 'Assignment not found'
        });
    }

    assignment.status = status;
    if (status === 'completed') {
        assignment.completedAt = new Date();
    }
    await assignment.save();

    // Send notification to the assigned beautician about status change
    if (assignment.assignedTo) {
        const notificationService = require('../services/notificationService');
        await notificationService.sendNotification(
            assignment.assignedTo.id,
            'assignment_status',
            'Assignment Status Updated',
            `Your assignment "${assignment.title}" status has been updated to ${status}`,
            { assignmentId: assignment.id, status: status },
            `/dashboard/assignments/${assignment.id}`
        );
    }

    res.json({
        success: true,
        message: 'Assignment status updated successfully',
        data: { assignment }
    });
});

// @desc    Bulk update assignment statuses
// @route   PUT /api/admin/assignments/bulk-status
// @access  Private (Admin)
exports.bulkUpdateAssignmentStatus = asyncHandler(async (req, res) => {
    const { assignmentIds, status } = req.body;

    if (!assignmentIds || !Array.isArray(assignmentIds) || assignmentIds.length === 0) {
        return res.status(400).json({
            success: false,
            message: 'Assignment IDs are required'
        });
    }

    if (!status) {
        return res.status(400).json({
            success: false,
            message: 'Status is required'
        });
    }

    try {
        // Update all assignments
        const [updatedCount] = await Assignment.update(
            { status: status },
            { where: { id: assignmentIds } }
        );

        // If status is completed, set completedAt
        if (status === 'completed') {
            await Assignment.update(
                { completedAt: new Date() },
                { where: { id: assignmentIds } }
            );
        }

        // Send notifications to assigned beauticians
        const assignments = await Assignment.findAll({
            where: { id: assignmentIds },
            include: [
                { model: User, as: 'assignedTo', attributes: ['id'] }
            ]
        });

        const notificationService = require('../services/notificationService');
        for (const assignment of assignments) {
            if (assignment.assignedTo) {
                await notificationService.sendNotification(
                    assignment.assignedTo.id,
                    'assignment_status',
                    'Assignment Status Updated',
                    `Your assignment "${assignment.title}" status has been updated to ${status}`, 
                    { assignmentId: assignment.id, status: status },
                    `/dashboard/assignments/${assignment.id}`
                );
            }
        }

        res.json({
            success: true,
            message: `${updatedCount} assignments updated successfully`,
            data: { updatedCount }
        });
    } catch (error) {
        console.error('Error updating assignments:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to update assignments'
        });
    }
});

// @desc    Bulk delete assignments
// @route   DELETE /api/admin/assignments/bulk
// @access  Private (Admin)
exports.bulkDeleteAssignments = asyncHandler(async (req, res) => {
    const { assignmentIds } = req.body;

    if (!assignmentIds || !Array.isArray(assignmentIds) || assignmentIds.length === 0) {
        return res.status(400).json({
            success: false,
            message: 'Assignment IDs are required'
        });
    }

    try {
        const deletedCount = await Assignment.destroy({
            where: { id: assignmentIds }
        });

        res.json({
            success: true,
            message: `${deletedCount} assignments deleted successfully`,
            data: { deletedCount }
        });
    } catch (error) {
        console.error('Error deleting assignments:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to delete assignments'
        });
    }
});m o d u l e . e x p o r t s   =   { 
         / /   U s e r   M a n a g e m e n t 
         g e t U s e r s , 
         g e t U s e r B y I d , 
         c r e a t e U s e r , 
         u p d a t e U s e r , 
         d e l e t e U s e r , 
         b u l k D e l e t e U s e r s , 
         r e s e t U s e r P a s s w o r d , 
         
         / /   P r o v i d e r   M a n a g e m e n t 
         g e t P r o v i d e r s , 
         g e t P r o v i d e r B y I d , 
         c r e a t e P r o v i d e r , 
         u p d a t e P r o v i d e r , 
         d e l e t e P r o v i d e r , 
         a p p r o v e P r o v i d e r , 
         r e j e c t P r o v i d e r , 
         
         / /   S e r v i c e   M a n a g e m e n t 
         g e t S e r v i c e s , 
         g e t S e r v i c e B y I d , 
         c r e a t e S e r v i c e , 
         u p d a t e S e r v i c e , 
         d e l e t e S e r v i c e , 
         
         / /   B o o k i n g   M a n a g e m e n t 
         g e t B o o k i n g s , 
         g e t B o o k i n g B y I d , 
         u p d a t e B o o k i n g S t a t u s , 
         c a n c e l B o o k i n g , 
         
         / /   R e v i e w   M a n a g e m e n t 
         g e t R e v i e w s , 
         g e t R e v i e w B y I d , 
         u p d a t e R e v i e w , 
         d e l e t e R e v i e w , 
         
         / /   A n a l y t i c s 
         g e t A n a l y t i c s , 
         g e t D a t e R a n g e , 
         e x p o r t A n a l y t i c s R e p o r t , 
         
         / /   A s s i g n m e n t   M a n a g e m e n t 
         a s s i g n T a s k , 
         g e t A s s i g n m e n t s , 
         u p d a t e A s s i g n m e n t S t a t u s , 
         b u l k U p d a t e A s s i g n m e n t S t a t u s , 
         b u l k D e l e t e A s s i g n m e n t s 
 } ;  
 