const { Op } = require('sequelize');
const Review = require('../models/Review');
const Booking = require('../models/Booking');
const Provider = require('../models/Provider');
const User = require('../models/User');
const Notification = require('../models/Notification');
const { asyncHandler } = require('../middleware/errorHandler');

// Helper function to update provider rating
async function updateProviderRating(providerId) {
    const { count, rows } = await Review.findAndCountAll({
        where: { providerId, isVisible: true }
    });

    if (count === 0) {
        await Provider.update({ rating: 0, reviewCount: 0 }, { where: { id: providerId } });
        return;
    }

    const totalRating = rows.reduce((sum, review) => sum + review.rating, 0);
    const averageRating = totalRating / count;

    await Provider.update(
        { rating: averageRating, reviewCount: count },
        { where: { id: providerId } }
    );
}

// @desc    Create review
// @route   POST /api/reviews
// @access  Private (Client)
exports.createReview = asyncHandler(async (req, res) => {
    const { bookingId, rating, review, comment, images } = req.body;

    // Check if booking exists and is completed
    const booking = await Booking.findByPk(bookingId);

    if (!booking) {
        return res.status(404).json({
            success: false,
            message: 'Booking not found'
        });
    }

    if (booking.clientId !== req.user.id) {
        return res.status(403).json({
            success: false,
            message: 'Not authorized to review this booking'
        });
    }

    if (booking.status !== 'completed') {
        return res.status(400).json({
            success: false,
            message: 'Can only review completed bookings'
        });
    }

    // Check if review already exists
    const existingReview = await Review.findOne({ where: { bookingId } });
    if (existingReview) {
        return res.status(400).json({
            success: false,
            message: 'Review already exists for this booking'
        });
    }

    // Create review
    const newReview = await Review.create({
        bookingId,
        clientId: req.user.id,
        providerId: booking.providerId,
        rating,
        review,
        comment,
        images
    });

    // Update provider rating
    await updateProviderRating(booking.providerId);

    const provider = await Provider.findByPk(booking.providerId);

    // Notify provider
    await Notification.createNotification(
        provider.userId,
        'new_review',
        'New Review Received',
        `You received a ${rating}-star review`,
        { reviewId: newReview.id },
        `/reviews/${newReview.id}`
    );

    res.status(201).json({
        success: true,
        message: 'Review created successfully',
        data: { review: newReview }
    });
});


// @desc    Get provider reviews
// @route   GET /api/reviews/provider/:providerId
// @access  Public
exports.getProviderReviews = asyncHandler(async (req, res) => {
    const { page = 1, limit = 10, minRating } = req.query;

    const where = {
        providerId: req.params.providerId,
        isVisible: true
    };

    if (minRating) {
        where.rating = { [Op.gte]: parseInt(minRating) };
    }

    const offset = (parseInt(page) - 1) * parseInt(limit);

    const { count, rows: reviews } = await Review.findAndCountAll({
        where,
        include: [{ model: User, as: 'client', attributes: ['firstName', 'lastName', 'avatar'] }],
        order: [['createdAt', 'DESC']],
        limit: parseInt(limit),
        offset
    });

    // Calculate rating distribution
    const ratingDistribution = await Review.findAll({
        attributes: ['rating', [Review.sequelize.fn('COUNT', Review.sequelize.col('rating')), 'count']],
        where: { providerId: req.params.providerId, isVisible: true },
        group: ['rating'],
        order: [['rating', 'DESC']]
    });

    res.json({
        success: true,
        data: {
            reviews,
            ratingDistribution,
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total: count,
                pages: Math.ceil(count / parseInt(limit))
            }
        }
    });
});

// @desc    Respond to review
// @route   PUT /api/reviews/:id/respond
// @access  Private (Provider)
exports.respondToReview = asyncHandler(async (req, res) => {
    const { responseText } = req.body;

    const review = await Review.findByPk(req.params.id);

    if (!review) {
        return res.status(404).json({
            success: false,
            message: 'Review not found'
        });
    }

    // Verify provider ownership
    const provider = await Provider.findOne({ where: { userId: req.user.id } });
    if (review.providerId !== provider.id) {
        return res.status(403).json({
            success: false,
            message: 'Not authorized'
        });
    }

    await review.addResponse(responseText);

    res.json({
        success: true,
        message: 'Response added successfully',
        data: { review }
    });
});

// @desc    Mark review as helpful
// @route   PUT /api/reviews/:id/helpful
// @access  Private
exports.markHelpful = asyncHandler(async (req, res) => {
    const review = await Review.findByPk(req.params.id);

    if (!review) {
        return res.status(404).json({
            success: false,
            message: 'Review not found'
        });
    }

    review.helpfulCount += 1;
    await review.save();

    res.json({
        success: true,
        message: 'Review marked as helpful',
        data: { helpfulCount: review.helpfulCount }
    });
});

// @desc    Moderate review (Admin only)
// @route   PUT /api/reviews/:id/moderate
// @access  Private (Admin)
exports.moderateReview = asyncHandler(async (req, res) => {
    const { isVisible, moderationNote } = req.body;

    const review = await Review.findByPk(req.params.id);

    if (!review) {
        return res.status(404).json({
            success: false,
            message: 'Review not found'
        });
    }

    review.isVisible = isVisible;
    review.isModerated = true;
    review.moderatedBy = req.user.id;
    review.moderationNote = moderationNote;
    await review.save();

    // Recalculate provider rating if visibility changed
    if (review.changed('isVisible')) {
        await updateProviderRating(review.providerId);
    }

    res.json({
        success: true,
        message: 'Review moderated successfully',
        data: { review }
    });
});

// @desc    Get my reviews (as client)
// @route   GET /api/reviews/my
// @access  Private (Client)
exports.getMyReviews = asyncHandler(async (req, res) => {
    const reviews = await Review.findAll({
        where: { clientId: req.user.id },
        include: [
            { model: Provider, as: 'provider', include: [{ model: User, as: 'user', attributes: ['firstName', 'lastName'] }] },
            { model: Booking, as: 'booking' }
        ],
        order: [['createdAt', 'DESC']]
    });

    res.json({
        success: true,
        data: { reviews }
    });
});
