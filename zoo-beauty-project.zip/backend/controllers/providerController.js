const Provider = require('../models/Provider.mongo');
const User = require('../models/User.mongo');
const Assignment = require('../models/Assignment.mongo');
const { asyncHandler } = require('../middleware/errorHandler');
const crypto = require('crypto'); // Import crypto for UUID generation

// @desc    Get provider profile
// @route   GET /api/providers/:id
// @access  Public
exports.getProvider = asyncHandler(async (req, res) => {
    const provider = await Provider.findById(req.params.id).populate('userId', 'firstName lastName email phone avatar');

    if (!provider) {
        return res.status(404).json({
            success: false,
            message: 'Provider not found'
        });
    }


    res.json({
        success: true,
        data: { provider }
    });
});

// @desc    Get my provider profile
// @route   GET /api/providers/me/profile
// @access  Private (Provider)
exports.getMyProfile = asyncHandler(async (req, res) => {
    const provider = await Provider.findOne({ userId: req.user.id });

    if (!provider) {
        return res.status(404).json({
            success: false,
            message: 'Provider profile not found'
        });
    }

    res.json({
        success: true,
        data: { provider }
    });
});

// @desc    Create/Update provider profile
// @route   PUT /api/providers/profile
// @access  Private (Provider)
exports.updateProfile = asyncHandler(async (req, res) => {
    const {
        firstName,
        lastName,
        businessName,
        bio,
        specializations,
        location, // This will be an object { lat, lng } or { coordinates: [lng, lat] }
        serviceType,
        studioAddress,
        socialMedia,
        bankDetails,
        address, // New fields
        city,
        state,
        country,
        zipCode
    } = req.body;

    let provider = await Provider.findOne({ userId: req.user.id });

    // Handle location data for GEOMETRY('POINT')
    let locationPoint = null;
    if (location && location.coordinates && location.coordinates.length === 2) {
        // Assuming location.coordinates is [lng, lat]
        locationPoint = {
            type: 'Point',
            coordinates: [parseFloat(location.coordinates[0]), parseFloat(location.coordinates[1])]
        };
    } else if (location && location.lat && location.lng) {
        locationPoint = {
            type: 'Point',
            coordinates: [parseFloat(location.lng), parseFloat(location.lat)]
        };
    }

    const profileData = {
        userId: req.user.id,
        businessName,
        bio,
        specializations,
        location: locationPoint, // Assign the processed location
        serviceType,
        studioAddress,
        socialMedia,
        bankDetails,
        address, // New fields
        city,
        state,
        country,
        zipCode
    };

    if (provider) {
        // Update existing profile
        Object.assign(provider, profileData);
        await provider.save();
    } else {
        // Create new profile
        provider = new Provider(profileData);
        await provider.save();
    }

    // Mark user profile as complete
    const user = await User.findById(req.user.id);
    if (user && !user.isProfileComplete) {
        user.isProfileComplete = true;
        user.firstName = firstName || user.firstName;
        user.lastName = lastName || user.lastName;
        await user.save();
    }

    res.json({
        success: true,
        message: 'Provider profile updated successfully',
        data: { provider }
    });
});

// @desc    Add portfolio item
// @route   POST /api/providers/portfolio
// @access  Private (Provider)
exports.addPortfolioItem = asyncHandler(async (req, res) => {
    const { type, url, caption } = req.body;

    const provider = await Provider.findOne({ userId: req.user.id });

    if (!provider) {
        return res.status(404).json({
            success: false,
            message: 'Provider profile not found'
        });
    }

    const portfolio = provider.portfolio || [];
    portfolio.push({
        id: crypto.randomBytes(16).toString('hex'), // Generate unique ID
        type,
        url,
        caption,
        uploadedAt: new Date()
    });
    provider.portfolio = portfolio;

    await provider.save();

    res.json({
        success: true,
        message: 'Portfolio item added successfully',
        data: { portfolio: provider.portfolio }
    });
});

// @desc    Remove portfolio item
// @route   DELETE /api/providers/portfolio/:itemId
// @access  Private (Provider)
exports.removePortfolioItem = asyncHandler(async (req, res) => {
    const provider = await Provider.findOne({ userId: req.user.id });

    if (!provider) {
        return res.status(404).json({
            success: false,
            message: 'Provider profile not found'
        });
    }

    provider.portfolio = provider.portfolio.filter(
        item => item.id !== req.params.itemId
    );

    await provider.save();

    res.json({
        success: true,
        message: 'Portfolio item removed successfully'
    });
});

// @desc    Update services
// @route   PUT /api/providers/services
// @access  Private (Provider)
exports.updateServices = asyncHandler(async (req, res) => {
    const { services } = req.body;

    const provider = await Provider.findOne({ userId: req.user.id });

    if (!provider) {
        return res.status(404).json({
            success: false,
            message: 'Provider profile not found'
        });
    }

    provider.services = services;
    await provider.save();

    res.json({
        success: true,
        message: 'Services updated successfully',
        data: { services: provider.services }
    });
});

// @desc    Update availability
// @route   PUT /api/providers/availability
// @access  Private (Provider)
exports.updateAvailability = asyncHandler(async (req, res) => {
    const { availability } = req.body;

    const provider = await Provider.findOne({ userId: req.user.id });

    if (!provider) {
        return res.status(404).json({
            success: false,
            message: 'Provider profile not found'
        });
    }

    provider.availability = availability;
    await provider.save();

    res.json({
        success: true,
        message: 'Availability updated successfully',
        data: { availability: provider.availability }
    });
});

// @desc    Search providers
// @route   GET /api/providers/search
// @access  Public
exports.searchProviders = asyncHandler(async (req, res) => {
    try {
        const {
            lat,
            lng,
            radius = 10000, // 10km default
            service,
            minRating,
            serviceType,
            page = 1,
            limit = 20
        } = req.query;

        const where = { isVisible: true };

        if (service) {
            where.specializations = { [Op.contains]: [service] };
        }
        if (minRating) {
            where.rating = { [Op.gte]: parseFloat(minRating) };
        }
        if (serviceType) {
            where.serviceType = { [Op.in]: [serviceType, 'both'] };
        }

        const offset = (parseInt(page) - 1) * parseInt(limit);

        const options = {
            where,
            include: [{
                model: User,
                as: 'user',
                attributes: ['firstName', 'lastName', 'avatar']
            }],
            limit: parseInt(limit),
            offset,
            order: [['rating', 'DESC']]
        };

        // Adjusted for GEOMETRY('POINT')
        if (lat && lng) {
            // Ensure lat and lng are numbers
            const numLat = parseFloat(lat);
            const numLng = parseFloat(lng);

            if (isNaN(numLat) || isNaN(numLng)) {
                return res.status(400).json({
                    success: false,
                    message: 'Invalid latitude or longitude provided.'
                });
            }

            // Construct the point in 'POINT(lng lat)' format for ST_GeomFromText
            const searchPoint = literal(`ST_GeomFromText('POINT(${numLng} ${numLat})')`);

            options.attributes = {
                include: [[fn('ST_Distance_Sphere', col('location'), searchPoint), 'distance']]
            };
            // Ensure location is not null and then add distance condition
            options.where.location = { [Op.ne]: null };

            // Add the distance condition to the where clause
            const distanceCondition = literal(`ST_Distance_Sphere(location, ST_GeomFromText('POINT(${numLng} ${numLat})')) <= ${parseInt(radius)}`);

            // Combine with existing 'where' clauses
            if (options.where[Op.and]) {
                options.where[Op.and].push(distanceCondition);
            } else {
                options.where[Op.and] = [distanceCondition];
            }

            options.order = [[literal('distance'), 'ASC']];
        }

        const { count, rows: providers } = await Provider.findAndCountAll(options);

        // Process provider locations for consistent output
        const processedProviders = providers.map(provider => {
            let processedProvider = provider.toJSON();
            if (provider.location && provider.location.coordinates) {
                processedProvider.location = {
                    type: provider.location.type,
                    coordinates: provider.location.coordinates
                };
            } else {
                processedProvider.location = null;
            }
            return processedProvider;
        });

        res.json({
            success: true,
            data: {
                providers: processedProviders,
                pagination: {
                    page: parseInt(page),
                    limit: parseInt(limit),
                    total: count,
                    pages: Math.ceil(count / parseInt(limit))
                }
            }
        });
    } catch (error) {
        console.error('Database error, using mock data:', error.message);

        // Return mock data if database fails
        const mockProviders = [
            {
                id: 1,
                businessName: 'Glam by Sarah',
                userId: { firstName: 'Sarah', lastName: 'Johnson', avatar: 'https://i.pravatar.cc/150?img=1' },
                specializations: ['Makeup', 'Wig Installation'],
                rating: { average: 4.9, count: 127 },
                services: [
                    { name: 'Bridal Makeup', price: 150, duration: 90 },
                    { name: 'Soft Glam Makeup', price: 80, duration: 60 },
                    { name: 'Wig Installation', price: 120, duration: 120 }
                ],
                portfolio: [{ url: 'https://images.unsplash.com/photo-1487412912498-0447578fcca8?w=400' }],
                location: { address: 'Downtown, City Center' },
                isOnline: true,
                isVisible: true
            },
            {
                id: 2,
                businessName: 'Chen\'s Barbershop',
                userId: { firstName: 'Michael', lastName: 'Chen', avatar: 'https://i.pravatar.cc/150?img=12' },
                specializations: ['Barbering', 'Hair Styling'],
                rating: { average: 4.8, count: 89 },
                services: [
                    { name: 'Classic Haircut', price: 50, duration: 45 },
                    { name: 'Beard Trim & Shape', price: 35, duration: 30 },
                    { name: 'Full Grooming Package', price: 100, duration: 90 }
                ],
                portfolio: [{ url: 'https://images.unsplash.com/photo-1503951914875-452162b0f3f1?w=400' }],
                location: { address: 'West Side, Los Angeles' },
                isOnline: true,
                isVisible: true
            },
            {
                id: 3,
                businessName: 'Amara\'s Braiding Studio',
                userId: { firstName: 'Amara', lastName: 'Okonkwo', avatar: 'https://i.pravatar.cc/150?img=9' },
                specializations: ['Braiding', 'Natural Hair Care'],
                rating: { average: 5.0, count: 203 },
                services: [
                    { name: 'Box Braids', price: 180, duration: 240 },
                    { name: 'Cornrows', price: 120, duration: 180 },
                    { name: 'Knotless Braids', price: 220, duration: 300 }
                ],
                portfolio: [{ url: 'https://images.unsplash.com/photo-1580618672591-eb180b1a973f?w=400' }],
                location: { address: 'South Side, Chicago' },
                isOnline: true,
                isVisible: true
            },
            {
                id: 4,
                businessName: 'Martinez Nail Art',
                userId: { firstName: 'David', lastName: 'Martinez', avatar: 'https://i.pravatar.cc/150?img=14' },
                specializations: ['Nail Art', 'Manicure', 'Pedicure'],
                rating: { average: 4.7, count: 145 },
                services: [
                    { name: 'Gel Manicure', price: 55, duration: 60 },
                    { name: 'Custom Nail Art', price: 85, duration: 90 },
                    { name: 'Acrylic Extensions', price: 95, duration: 120 }
                ],
                portfolio: [{ url: 'https://images.unsplash.com/photo-1604654894610-df63bc536371?w=400' }],
                location: { address: 'Midtown, Houston' },
                isOnline: false,
                isVisible: true
            }
        ];

        res.json({
            success: true,
            data: {
                providers: mockProviders,
                pagination: {
                    page: 1,
                    limit: 20,
                    total: 4,
                    pages: 1
                }
            }
        });
    }
});

// @desc    Get provider stats
// @route   GET /api/providers/stats
// @access  Private (Provider)
exports.getStats = asyncHandler(async (req, res) => {
    const provider = await Provider.findOne({ userId: req.user.id });

    if (!provider) {
        return res.status(404).json({
            success: false,
            message: 'Provider profile not found'
        });
    }

    res.json({
        success: true,
        data: {
            stats: provider.stats,
            rating: provider.rating,
            subscription: provider.subscription
        }
    });
});

// @desc    Toggle online status
// @route   PUT /api/providers/online-status
// @access  Private (Provider)
exports.toggleOnlineStatus = asyncHandler(async (req, res) => {
    const provider = await Provider.findOne({ where: { userId: req.user.id } });

    if (!provider) {
        return res.status(404).json({
            success: false,
            message: 'Provider profile not found'
        });
    }

    provider.isOnline = !provider.isOnline;
    await provider.save();

    res.json({
        success: true,
        message: `You are now ${provider.isOnline ? 'online' : 'offline'}`,
        data: { isOnline: provider.isOnline }
    });
});

// @desc    Assign task to beautician
// @route   POST /api/providers/assignments
// @access  Private (Provider)
exports.assignTask = asyncHandler(async (req, res) => {
    const { title, description, assignedToId, priority, dueDate } = req.body;

    // Validate assignedToId is a beautician
    const beautician = await User.findByPk(assignedToId);
    if (!beautician || beautician.role !== 'beautician') {
        return res.status(400).json({
            success: false,
            message: 'Assigned user must be a beautician'
        });
    }

    // Get provider profile of the requesting provider
    const provider = await Provider.findOne({ where: { userId: req.user.id } });
    if (!provider) {
        return res.status(404).json({
            success: false,
            message: 'Provider profile not found'
        });
    }

    // Generate unique taskId
    const taskId = `TASK-${Date.now()}-${Math.floor(Math.random() * 1000)}`;

    // Create assignment
    const assignment = await Assignment.create({
        taskId,
        title,
        description,
        assignedById: req.user.id, // Provider assigning the task
        assignedToId,
        providerId: provider.id, // Link to the provider
        priority,
        dueDate
    });

    res.status(201).json({
        success: true,
        message: 'Task assigned successfully',
        data: { assignment }
    });
});

// @desc    Assign task to beautician
// @route   POST /api/providers/assignments
// @access  Private (Provider)
exports.assignTask = asyncHandler(async (req, res) => {
    const provider = await Provider.findOne({ where: { userId: req.user.id } });
    if (!provider) {
        return res.status(404).json({
            success: false,
            message: 'Provider profile not found'
        });
    }

    const { title, description, assignedToId, priority, dueDate } = req.body;

    // Validate assignedToId is a beautician
    const beautician = await User.findByPk(assignedToId);
    if (!beautician || beautician.role !== 'beautician') {
        return res.status(400).json({
            success: false,
            message: 'Assigned user must be a beautician'
        });
    }

    // Generate unique taskId
    const taskId = `TASK-${Date.now()}-${Math.floor(Math.random() * 1000)}`;

    // Create assignment
    const assignment = await Assignment.create({
        taskId,
        title,
        description,
        assignedById: req.user.id, // Provider assigning the task
        assignedToId,
        providerId: provider.id,
        priority,
        dueDate
    });

    // Send notification to the assigned beautician
    const notificationService = require('../services/notificationService');
    await notificationService.sendAssignmentNotification(assignedToId, assignment);

    res.status(201).json({
        success: true,
        message: 'Task assigned successfully',
        data: { assignment }
    });
});

// @desc    Update assignment status
// @route   PUT /api/providers/assignments/:id/status
// @access  Private (Provider)
exports.updateAssignmentStatus = asyncHandler(async (req, res) => {
    const provider = await Provider.findOne({ where: { userId: req.user.id } });
    if (!provider) {
        return res.status(404).json({
            success: false,
            message: 'Provider profile not found'
        });
    }

    const { status } = req.body;

    const assignment = await Assignment.findOne({
        where: { 
            id: req.params.id,
            providerId: provider.id 
        },
        include: [
            { model: User, as: 'assignedTo', attributes: ['id'] }
        ]
    });
    
    if (!assignment) {
        return res.status(404).json({
            success: false,
            message: 'Assignment not found or not authorized'
        });
    }

    assignment.status = status;
    if (status === 'completed') {
        assignment.completedAt = new Date();
    }
    await assignment.save();

    // Send notification to the assigned beautician about status change
    if (assignment.assignedTo) {
        const notificationService = require('../services/notificationService');
        await notificationService.sendNotification(
            assignment.assignedTo.id,
            'assignment_status',
            'Assignment Status Updated',
            `Your assignment "${assignment.title}" status has been updated to ${status}`,
            { assignmentId: assignment.id, status: status },
            `/dashboard/assignments/${assignment.id}`
        );
    }

    res.json({
        success: true,
        message: 'Assignment status updated successfully',
        data: { assignment }
    });
});

// @desc    Get assignments for provider
// @route   GET /api/providers/assignments
// @access  Private (Provider)
exports.getProviderAssignments = asyncHandler(async (req, res) => {
    const provider = await Provider.findOne({ where: { userId: req.user.id } });
    if (!provider) {
        return res.status(404).json({
            success: false,
            message: 'Provider profile not found'
        });
    }

    const { status, assignedToId, page = 1, limit = 20 } = req.query;

    const where = { providerId: provider.id };
    if (status) where.status = status;
    if (assignedToId) where.assignedToId = assignedToId;

    const offset = (parseInt(page) - 1) * parseInt(limit);

    const { count, rows: assignments } = await Assignment.findAndCountAll({
        where,
        include: [
            { model: User, as: 'assignedBy', attributes: ['firstName', 'lastName', 'email'] },
            { model: User, as: 'assignedTo', attributes: ['firstName', 'lastName', 'email'] },
            { model: Provider, as: 'provider', attributes: ['businessName'] }
        ],
        order: [['createdAt', 'DESC']],
        limit: parseInt(limit),
        offset
    });

    res.json({
        success: true,
        data: {
            assignments,
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total: count,
                pages: Math.ceil(count / parseInt(limit))
            }
        }
    });
});

module.exports = {
    getProvider: exports.getProvider,
    getMyProfile: exports.getMyProfile,
    updateProfile: exports.updateProfile,
    addPortfolioItem: exports.addPortfolioItem,
    removePortfolioItem: exports.removePortfolioItem,
    updateServices: exports.updateServices,
    updateAvailability: exports.updateAvailability,
    searchProviders: exports.searchProviders,
    getStats: exports.getStats,
    toggleOnlineStatus: exports.toggleOnlineStatus,
    assignTask: exports.assignTask,
    getProviderAssignments: exports.getProviderAssignments,
    updateAssignmentStatus: exports.updateAssignmentStatus
};

