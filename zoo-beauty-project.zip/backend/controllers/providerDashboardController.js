const { Op, fn, col, literal, sequelize } = require('sequelize');
const Provider = require('../models/Provider');
const User = require('../models/User');
const Booking = require('../models/Booking');
const Assignment = require('../models/Assignment');
const { asyncHandler } = require('../middleware/errorHandler');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const { getAsync, setAsync } = require('../config/cache');

// ==========================================
// DASHBOARD OVERVIEW & ANALYTICS
// ==========================================

// @desc    Get dashboard overview stats
// @route   GET /api/providers/dashboard/overview
// @access  Private (Provider)
exports.getDashboardOverview = asyncHandler(async (req, res) => {
    const provider = await Provider.findOne({ where: { userId: req.user.id } });

    if (!provider) {
        return res.status(404).json({
            success: false,
            message: 'Provider profile not found'
        });
    }

    // Try to get cached data first
    const cacheKey = `provider_dashboard_${provider.id}`;
    try {
        const cachedData = await getAsync(cacheKey);
        if (cachedData) {
            const parsedData = JSON.parse(cachedData);
            return res.json({
                success: true,
                data: parsedData
            });
        }
    } catch (cacheErr) {
        console.warn('Cache read error:', cacheErr);
    }

    // Get current date ranges
    const now = new Date();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const startOfWeek = new Date(now.setDate(now.getDate() - now.getDay()));
    const startOfToday = new Date(now.setHours(0, 0, 0, 0));

    // Total Revenue (All completed bookings)
    const totalRevenueResult = await Booking.findOne({
        where: {
            providerId: provider.id,
            status: 'completed'
        },
        attributes: [
            [fn('SUM', literal("CAST(payment->>'providerEarnings' AS DECIMAL)")), 'totalRevenue']
        ],
        raw: true
    });

    // This Month Earnings
    const monthEarningsResult = await Booking.findOne({
        where: {
            providerId: provider.id,
            status: 'completed',
            createdAt: { [Op.gte]: startOfMonth }
        },
        attributes: [
            [fn('SUM', literal("CAST(payment->>'providerEarnings' AS DECIMAL)")), 'monthEarnings']
        ],
        raw: true
    });

    // This Week Earnings
    const weekEarningsResult = await Booking.findOne({
        where: {
            providerId: provider.id,
            status: 'completed',
            createdAt: { [Op.gte]: startOfWeek }
        },
        attributes: [
            [fn('SUM', literal("CAST(payment->>'providerEarnings' AS DECIMAL)")), 'weekEarnings']
        ],
        raw: true
    });

    // Today Earnings
    const todayEarningsResult = await Booking.findOne({
        where: {
            providerId: provider.id,
            status: 'completed',
            createdAt: { [Op.gte]: startOfToday }
        },
        attributes: [
            [fn('SUM', literal("CAST(payment->>'providerEarnings' AS DECIMAL)")), 'todayEarnings']
        ],
        raw: true
    });

    // Active Staff Count (Beauticians assigned to this provider)
    const activeStaffCount = await Assignment.count({
        where: {
            providerId: provider.id,
            status: { [Op.in]: ['pending', 'accepted', 'in-progress'] }
        },
        distinct: true,
        col: 'assignedToId'
    });

    // Pending Bookings
    const pendingBookingsCount = await Booking.count({
        where: {
            providerId: provider.id,
            status: 'pending'
        }
    });

    // Upcoming Bookings (Accepted, scheduled for future)
    const upcomingBookingsCount = await Booking.count({
        where: {
            providerId: provider.id,
            status: { [Op.in]: ['accepted', 'confirmed'] },
            scheduledDate: { [Op.gte]: new Date() }
        }
    });

    // Total Bookings
    const totalBookings = await Booking.count({
        where: { providerId: provider.id }
    });

    // Completed Bookings
    const completedBookings = await Booking.count({
        where: {
            providerId: provider.id,
            status: 'completed'
        }
    });

    // Acceptance Rate
    const acceptedBookings = await Booking.count({
        where: {
            providerId: provider.id,
            status: { [Op.in]: ['accepted', 'completed', 'in-progress'] }
        }
    });
    const acceptanceRate = totalBookings > 0 ? ((acceptedBookings / totalBookings) * 100).toFixed(1) : 0;

    const responseData = {
        stats: {
            totalRevenue: parseFloat(totalRevenueResult?.totalRevenue || 0),
            monthEarnings: parseFloat(monthEarningsResult?.monthEarnings || 0),
            weekEarnings: parseFloat(weekEarningsResult?.weekEarnings || 0),
            todayEarnings: parseFloat(todayEarningsResult?.todayEarnings || 0),
            activeStaff: activeStaffCount,
            pendingBookings: pendingBookingsCount,
            upcomingBookings: upcomingBookingsCount,
            totalBookings,
            completedBookings,
            acceptanceRate: parseFloat(acceptanceRate)
        },
        provider: {
            businessName: provider.businessName,
            rating: provider.rating,
            reviewCount: provider.reviewCount,
            isOnline: provider.isOnline
        }
    };

    // Cache the response for 5 minutes
    try {
        await setAsync(cacheKey, JSON.stringify(responseData), 300);
    } catch (cacheErr) {
        console.warn('Cache write error:', cacheErr);
    }

    res.json({
        success: true,
        data: responseData
    });
});

// @desc    Get performance chart data
// @route   GET /api/providers/dashboard/chart
// @access  Private (Provider)
exports.getPerformanceChart = asyncHandler(async (req, res) => {
    const provider = await Provider.findOne({ where: { userId: req.user.id } });

    if (!provider) {
        return res.status(404).json({
            success: false,
            message: 'Provider profile not found'
        });
    }

    const { period = 'week' } = req.query; // week, month, year

    let groupBy, dateFormat, daysBack;

    if (period === 'week') {
        groupBy = 'day';
        dateFormat = '%Y-%m-%d';
        daysBack = 7;
    } else if (period === 'month') {
        groupBy = 'day';
        dateFormat = '%Y-%m-%d';
        daysBack = 30;
    } else {
        groupBy = 'month';
        dateFormat = '%Y-%m';
        daysBack = 365;
    }

    const startDate = new Date();
    startDate.setDate(startDate.getDate() - daysBack);

    const chartData = await Booking.findAll({
        where: {
            providerId: provider.id,
            status: 'completed',
            createdAt: { [Op.gte]: startDate }
        },
        attributes: [
            [fn('DATE', col('createdAt')), 'date'],
            [fn('COUNT', col('id')), 'bookings'],
            [fn('SUM', literal("CAST(payment->>'providerEarnings' AS DECIMAL)")), 'earnings']
        ],
        group: [fn('DATE', col('createdAt'))],
        order: [[fn('DATE', col('createdAt')), 'ASC']],
        raw: true
    });

    res.json({
        success: true,
        data: {
            period,
            chartData: chartData.map(item => ({
                date: item.date,
                bookings: parseInt(item.bookings),
                earnings: parseFloat(item.earnings || 0)
            }))
        }
    });
});

// ==========================================
// STAFF MANAGEMENT
// ==========================================

// @desc    Get all staff (beauticians)
// @route   GET /api/providers/staff
// @access  Private (Provider)
exports.getStaff = asyncHandler(async (req, res) => {
    const provider = await Provider.findOne({ where: { userId: req.user.id } });

    if (!provider) {
        return res.status(404).json({
            success: false,
            message: 'Provider profile not found'
        });
    }

    // Get all assignments for this provider to find beauticians
    const assignments = await Assignment.findAll({
        where: { providerId: provider.id },
        include: [
            {
                model: User,
                as: 'assignedTo',
                attributes: ['id', 'firstName', 'lastName', 'email', 'phone', 'avatar', 'isActive'],
                where: { role: 'beautician' }
            }
        ],
        attributes: ['assignedToId'],
        group: ['assignedToId', 'assignedTo.id']
    });

    // Get unique beauticians
    const beauticianIds = [...new Set(assignments.map(a => a.assignedToId))];

    // Get detailed info for each beautician
    const staff = await Promise.all(beauticianIds.map(async (beauticianId) => {
        const beautician = await User.findByPk(beauticianId, {
            attributes: ['id', 'firstName', 'lastName', 'email', 'phone', 'avatar', 'isActive', 'createdAt']
        });

        if (!beautician) return null;

        // Get beautician's provider profile for specializations
        const beauticianProvider = await Provider.findOne({
            where: { userId: beauticianId },
            attributes: ['specializations', 'rating', 'reviewCount', 'isOnline']
        });

        // Get performance metrics
        const totalBookings = await Booking.count({
            where: {
                providerId: provider.id,
                assignedBeauticianId: beauticianId
            }
        });

        const completedBookings = await Booking.count({
            where: {
                providerId: provider.id,
                assignedBeauticianId: beauticianId,
                status: 'completed'
            }
        });

        const earningsResult = await Booking.findOne({
            where: {
                providerId: provider.id,
                assignedBeauticianId: beauticianId,
                status: 'completed'
            },
            attributes: [
                [fn('SUM', literal("CAST(payment->>'providerEarnings' AS DECIMAL)")), 'totalEarnings']
            ],
            raw: true
        });

        const completionRate = totalBookings > 0 ? ((completedBookings / totalBookings) * 100).toFixed(1) : 0;

        return {
            ...beautician.toJSON(),
            specializations: beauticianProvider?.specializations || [],
            rating: beauticianProvider?.rating || 0,
            reviewCount: beauticianProvider?.reviewCount || 0,
            isOnline: beauticianProvider?.isOnline || false,
            performance: {
                totalBookings,
                completedBookings,
                completionRate: parseFloat(completionRate),
                totalEarnings: parseFloat(earningsResult?.totalEarnings || 0)
            }
        };
    }));

    res.json({
        success: true,
        data: {
            staff: staff.filter(s => s !== null)
        }
    });
});

// @desc    Add new beautician
// @route   POST /api/providers/staff
// @access  Private (Provider)
exports.addStaff = asyncHandler(async (req, res) => {
    const provider = await Provider.findOne({ where: { userId: req.user.id } });

    if (!provider) {
        return res.status(404).json({
            success: false,
            message: 'Provider profile not found'
        });
    }

    const { firstName, lastName, email, phone, specializations = [] } = req.body;

    // Check if user already exists
    const existingUser = await User.findOne({ where: { email } });
    if (existingUser) {
        return res.status(400).json({
            success: false,
            message: 'User with this email already exists'
        });
    }

    // Generate temporary password
    const tempPassword = crypto.randomBytes(8).toString('hex');
    const hashedPassword = await bcrypt.hash(tempPassword, 10);

    // Create user
    const beautician = await User.create({
        firstName,
        lastName,
        email,
        phone,
        password: hashedPassword,
        role: 'beautician',
        isActive: true
    });

    // Create provider profile for beautician
    await Provider.create({
        userId: beautician.id,
        businessName: `${firstName} ${lastName}`,
        specializations,
        serviceType: 'mobile',
        isOnline: false,
        isVisible: false
    });

    // Create initial assignment to link beautician to provider
    await Assignment.create({
        taskId: `STAFF-${Date.now()}`,
        title: 'Staff Member',
        description: `${firstName} ${lastName} added as staff member`,
        assignedById: req.user.id,
        assignedToId: beautician.id,
        providerId: provider.id,
        status: 'accepted',
        priority: 'medium'
    });

    // TODO: Send welcome email with temporary password

    res.status(201).json({
        success: true,
        message: 'Beautician added successfully',
        data: {
            beautician: {
                id: beautician.id,
                firstName: beautician.firstName,
                lastName: beautician.lastName,
                email: beautician.email,
                phone: beautician.phone,
                tempPassword // Return temp password (in production, send via email only)
            }
        }
    });
});

// @desc    Get beautician details
// @route   GET /api/providers/staff/:id
// @access  Private (Provider)
exports.getStaffMember = asyncHandler(async (req, res) => {
    const provider = await Provider.findOne({ where: { userId: req.user.id } });

    if (!provider) {
        return res.status(404).json({
            success: false,
            message: 'Provider profile not found'
        });
    }

    const beauticianId = req.params.id;

    // Verify this beautician is assigned to this provider
    const assignment = await Assignment.findOne({
        where: {
            providerId: provider.id,
            assignedToId: beauticianId
        }
    });

    if (!assignment) {
        return res.status(403).json({
            success: false,
            message: 'Not authorized to view this beautician'
        });
    }

    const beautician = await User.findByPk(beauticianId, {
        attributes: ['id', 'firstName', 'lastName', 'email', 'phone', 'avatar', 'isActive', 'createdAt']
    });

    if (!beautician) {
        return res.status(404).json({
            success: false,
            message: 'Beautician not found'
        });
    }

    const beauticianProvider = await Provider.findOne({
        where: { userId: beauticianId }
    });

    // Get bookings for this beautician
    const bookings = await Booking.findAll({
        where: {
            providerId: provider.id,
            assignedBeauticianId: beauticianId
        },
        include: [
            { model: User, as: 'client', attributes: ['firstName', 'lastName'] }
        ],
        order: [['createdAt', 'DESC']],
        limit: 10
    });

    // Performance metrics
    const totalBookings = await Booking.count({
        where: {
            providerId: provider.id,
            assignedBeauticianId: beauticianId
        }
    });

    const completedBookings = await Booking.count({
        where: {
            providerId: provider.id,
            assignedBeauticianId: beauticianId,
            status: 'completed'
        }
    });

    const earningsResult = await Booking.findOne({
        where: {
            providerId: provider.id,
            assignedBeauticianId: beauticianId,
            status: 'completed'
        },
        attributes: [
            [fn('SUM', literal("CAST(payment->>'providerEarnings' AS DECIMAL)")), 'totalEarnings']
        ],
        raw: true
    });

    res.json({
        success: true,
        data: {
            beautician: {
                ...beautician.toJSON(),
                specializations: beauticianProvider?.specializations || [],
                rating: beauticianProvider?.rating || 0,
                reviewCount: beauticianProvider?.reviewCount || 0,
                isOnline: beauticianProvider?.isOnline || false
            },
            performance: {
                totalBookings,
                completedBookings,
                completionRate: totalBookings > 0 ? ((completedBookings / totalBookings) * 100).toFixed(1) : 0,
                totalEarnings: parseFloat(earningsResult?.totalEarnings || 0)
            },
            recentBookings: bookings
        }
    });
});

// @desc    Update beautician
// @route   PUT /api/providers/staff/:id
// @access  Private (Provider)
exports.updateStaff = asyncHandler(async (req, res) => {
    const provider = await Provider.findOne({ where: { userId: req.user.id } });

    if (!provider) {
        return res.status(404).json({
            success: false,
            message: 'Provider profile not found'
        });
    }

    const beauticianId = req.params.id;
    const { specializations, isActive } = req.body;

    // Verify authorization
    const assignment = await Assignment.findOne({
        where: {
            providerId: provider.id,
            assignedToId: beauticianId
        }
    });

    if (!assignment) {
        return res.status(403).json({
            success: false,
            message: 'Not authorized'
        });
    }

    // Update beautician's provider profile
    const beauticianProvider = await Provider.findOne({
        where: { userId: beauticianId }
    });

    if (beauticianProvider) {
        if (specializations) beauticianProvider.specializations = specializations;
        await beauticianProvider.save();
    }

    // Update user status
    if (typeof isActive !== 'undefined') {
        await User.update({ isActive }, { where: { id: beauticianId } });
    }

    res.json({
        success: true,
        message: 'Beautician updated successfully'
    });
});

// @desc    Remove beautician
// @route   DELETE /api/providers/staff/:id
// @access  Private (Provider)
exports.removeStaff = asyncHandler(async (req, res) => {
    const provider = await Provider.findOne({ where: { userId: req.user.id } });

    if (!provider) {
        return res.status(404).json({
            success: false,
            message: 'Provider profile not found'
        });
    }

    const beauticianId = req.params.id;

    // Verify authorization
    const assignment = await Assignment.findOne({
        where: {
            providerId: provider.id,
            assignedToId: beauticianId
        }
    });

    if (!assignment) {
        return res.status(403).json({
            success: false,
            message: 'Not authorized'
        });
    }

    // Soft delete - deactivate user
    await User.update({ isActive: false }, { where: { id: beauticianId } });

    // Update assignment status
    await Assignment.update(
        { status: 'cancelled' },
        { where: { providerId: provider.id, assignedToId: beauticianId } }
    );

    // Reassign pending bookings
    await Booking.update(
        { assignedBeauticianId: null, status: 'pending' },
        {
            where: {
                providerId: provider.id,
                assignedBeauticianId: beauticianId,
                status: { [Op.in]: ['pending', 'accepted'] }
            }
        }
    );

    res.json({
        success: true,
        message: 'Beautician removed successfully'
    });
});

// ==========================================
// BOOKING DISPATCH
// ==========================================

// @desc    Get online/available beauticians
// @route   GET /api/providers/bookings/available-staff
// @access  Private (Provider)
exports.getAvailableStaff = asyncHandler(async (req, res) => {
    const provider = await Provider.findOne({ where: { userId: req.user.id } });

    if (!provider) {
        return res.status(404).json({
            success: false,
            message: 'Provider profile not found'
        });
    }

    // Get all beauticians assigned to this provider
    const assignments = await Assignment.findAll({
        where: {
            providerId: provider.id,
            status: 'accepted'
        },
        include: [
            {
                model: User,
                as: 'assignedTo',
                attributes: ['id', 'firstName', 'lastName', 'avatar'],
                where: {
                    role: 'beautician',
                    isActive: true
                }
            }
        ]
    });

    const beauticianIds = assignments.map(a => a.assignedToId);

    // Get provider profiles to check online status
    const availableBeauticians = await Provider.findAll({
        where: {
            userId: { [Op.in]: beauticianIds },
            isOnline: true
        },
        include: [
            {
                model: User,
                as: 'user',
                attributes: ['id', 'firstName', 'lastName', 'avatar']
            }
        ]
    });

    res.json({
        success: true,
        data: {
            availableStaff: availableBeauticians.map(p => ({
                id: p.user.id,
                firstName: p.user.firstName,
                lastName: p.user.lastName,
                avatar: p.user.avatar,
                specializations: p.specializations,
                rating: p.rating
            }))
        }
    });
});

// @desc    Assign booking to beautician
// @route   POST /api/providers/bookings/:id/assign
// @access  Private (Provider)
exports.assignBooking = asyncHandler(async (req, res) => {
    const provider = await Provider.findOne({ where: { userId: req.user.id } });

    if (!provider) {
        return res.status(404).json({
            success: false,
            message: 'Provider profile not found'
        });
    }

    const { beauticianId } = req.body;
    const bookingId = req.params.id;

    // Verify booking belongs to this provider
    const booking = await Booking.findOne({
        where: {
            id: bookingId,
            providerId: provider.id
        }
    });

    if (!booking) {
        return res.status(404).json({
            success: false,
            message: 'Booking not found'
        });
    }

    // Verify beautician is assigned to this provider
    const assignment = await Assignment.findOne({
        where: {
            providerId: provider.id,
            assignedToId: beauticianId,
            status: 'accepted'
        }
    });

    if (!assignment) {
        return res.status(400).json({
            success: false,
            message: 'Beautician not assigned to your business'
        });
    }

    // Verify beautician is online
    const beauticianProvider = await Provider.findOne({
        where: { userId: beauticianId }
    });

    if (!beauticianProvider || !beauticianProvider.isOnline) {
        return res.status(400).json({
            success: false,
            message: 'Beautician is currently offline'
        });
    }

    // Update booking
    booking.assignedBeauticianId = beauticianId;
    booking.status = 'assigned';

    const timeline = booking.timeline || [];
    timeline.push({
        status: 'assigned',
        timestamp: new Date(),
        note: `Assigned to beautician`
    });
    booking.timeline = timeline;

    await booking.save();

    // Send notification to beautician
    const Notification = require('../models/Notification');
    await Notification.createNotification(
        beauticianId,
        'booking_assigned',
        'New Booking Assigned',
        `You have been assigned a new booking for ${booking.service.name}`,
        { bookingId: booking.id },
        `/beautician/bookings/${booking.id}`
    );

    res.json({
        success: true,
        message: 'Booking assigned successfully',
        data: { booking }
    });
});

// @desc    Reassign booking
// @route   PUT /api/providers/bookings/:id/reassign
// @access  Private (Provider)
exports.reassignBooking = asyncHandler(async (req, res) => {
    const provider = await Provider.findOne({ where: { userId: req.user.id } });

    if (!provider) {
        return res.status(404).json({
            success: false,
            message: 'Provider profile not found'
        });
    }

    const { newBeauticianId, reason } = req.body;
    const bookingId = req.params.id;

    const booking = await Booking.findOne({
        where: {
            id: bookingId,
            providerId: provider.id
        }
    });

    if (!booking) {
        return res.status(404).json({
            success: false,
            message: 'Booking not found'
        });
    }

    const previousBeauticianId = booking.assignedBeauticianId;

    // Clear assignment
    booking.assignedBeauticianId = newBeauticianId || null;
    booking.status = newBeauticianId ? 'assigned' : 'pending';

    const timeline = booking.timeline || [];
    timeline.push({
        status: 'reassigned',
        timestamp: new Date(),
        note: reason || 'Booking reassigned'
    });
    booking.timeline = timeline;

    await booking.save();

    // Notify previous beautician
    if (previousBeauticianId) {
        const Notification = require('../models/Notification');
        await Notification.createNotification(
            previousBeauticianId,
            'booking_reassigned',
            'Booking Reassigned',
            'A booking has been reassigned to another beautician',
            { bookingId: booking.id },
            `/beautician/bookings`
        );
    }

    // Notify new beautician
    if (newBeauticianId) {
        const Notification = require('../models/Notification');
        await Notification.createNotification(
            newBeauticianId,
            'booking_assigned',
            'New Booking Assigned',
            `You have been assigned a booking for ${booking.service.name}`,
            { bookingId: booking.id },
            `/beautician/bookings/${booking.id}`
        );
    }

    res.json({
        success: true,
        message: 'Booking reassigned successfully',
        data: { booking }
    });
});

// ==========================================
// FINANCIAL RECONCILIATION
// ==========================================

// @desc    Get revenue summary
// @route   GET /api/providers/revenue
// @access  Private (Provider)
exports.getRevenue = asyncHandler(async (req, res) => {
    const provider = await Provider.findOne({ where: { userId: req.user.id } });

    if (!provider) {
        return res.status(404).json({
            success: false,
            message: 'Provider profile not found'
        });
    }

    const { page = 1, limit = 20, status } = req.query;
    const offset = (parseInt(page) - 1) * parseInt(limit);

    // Get all completed bookings
    const where = {
        providerId: provider.id,
        status: 'completed'
    };

    const { count, rows: bookings } = await Booking.findAndCountAll({
        where,
        include: [
            { model: User, as: 'client', attributes: ['firstName', 'lastName'] }
        ],
        order: [['createdAt', 'DESC']],
        limit: parseInt(limit),
        offset
    });

    // Calculate totals
    const totals = await Booking.findOne({
        where,
        attributes: [
            [fn('SUM', literal("CAST(payment->>'amount' AS DECIMAL)")), 'totalRevenue'],
            [fn('SUM', literal("CAST(payment->>'platformFee' AS DECIMAL)")), 'platformCommission'],
            [fn('SUM', literal("CAST(payment->>'providerEarnings' AS DECIMAL)")), 'providerNet']
        ],
        raw: true
    });

    // Format transactions
    const transactions = bookings.map(booking => ({
        bookingId: booking.bookingNumber,
        client: `${booking.client.firstName} ${booking.client.lastName}`,
        service: booking.service.name,
        date: booking.scheduledDate,
        clientPaid: booking.payment.amount,
        platformCommission: booking.payment.platformFee,
        providerNet: booking.payment.providerEarnings,
        status: booking.status,
        payoutStatus: booking.payment.payoutStatus || 'pending'
    }));

    res.json({
        success: true,
        data: {
            summary: {
                totalRevenue: parseFloat(totals?.totalRevenue || 0),
                platformCommission: parseFloat(totals?.platformCommission || 0),
                providerNet: parseFloat(totals?.providerNet || 0),
                pendingPayout: parseFloat(totals?.providerNet || 0), // TODO: Calculate actual pending
                paidOut: 0 // TODO: Calculate from payout records
            },
            transactions,
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total: count,
                pages: Math.ceil(count / parseInt(limit))
            }
        }
    });
});

// @desc    Request payout
// @route   POST /api/providers/payout/request
// @access  Private (Provider)
exports.requestPayout = asyncHandler(async (req, res) => {
    const provider = await Provider.findOne({ where: { userId: req.user.id } });

    if (!provider) {
        return res.status(404).json({
            success: false,
            message: 'Provider profile not found'
        });
    }

    const { amount, notes } = req.body;

    // Verify bank details exist
    if (!provider.bankDetails || Object.keys(provider.bankDetails).length === 0) {
        return res.status(400).json({
            success: false,
            message: 'Please add bank details before requesting payout'
        });
    }

    // Calculate available balance
    const earningsResult = await Booking.findOne({
        where: {
            providerId: provider.id,
            status: 'completed'
        },
        attributes: [
            [fn('SUM', literal("CAST(payment->>'providerEarnings' AS DECIMAL)")), 'totalEarnings']
        ],
        raw: true
    });

    const availableBalance = parseFloat(earningsResult?.totalEarnings || 0);

    if (amount > availableBalance) {
        return res.status(400).json({
            success: false,
            message: `Insufficient balance. Available: KES ${availableBalance}`
        });
    }

    // TODO: Create payout request in database
    // For now, just return success

    res.json({
        success: true,
        message: 'Payout request submitted successfully. Admin will review shortly.',
        data: {
            requestedAmount: amount,
            availableBalance,
            status: 'pending_admin_approval'
        }
    });
});

// @desc    Get advanced analytics data
// @route   GET /api/providers/analytics/advanced
// @access  Private (Provider)
exports.getAdvancedAnalytics = asyncHandler(async (req, res) => {
    const provider = await Provider.findOne({ where: { userId: req.user.id } });

    if (!provider) {
        return res.status(404).json({
            success: false,
            message: 'Provider profile not found'
        });
    }

    // Get current date ranges
    const now = new Date();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const startOfYear = new Date(now.getFullYear(), 0, 1);
    
    // Top performing services
    const topServices = await Booking.findAll({
        where: {
            providerId: provider.id,
            status: 'completed',
            createdAt: { [Op.gte]: startOfMonth }
        },
        attributes: [
            'service.name',
            [fn('COUNT', col('id')), 'bookingCount'],
            [fn('SUM', literal("CAST(payment->>'providerEarnings' AS DECIMAL)")), 'totalEarnings']
        ],
        group: ['service.name'],
        order: [[fn('SUM', literal("CAST(payment->>'providerEarnings' AS DECIMAL)")), 'DESC']],
        limit: 5,
        raw: true
    });

    // Client retention metrics
    const totalClients = await Booking.count({
        where: { providerId: provider.id },
        distinct: true,
        col: 'clientId'
    });

    const repeatClients = await Booking.findAll({
        where: { providerId: provider.id },
        attributes: ['clientId'],
        group: ['clientId'],
        having: sequelize.literal('COUNT(*) > 1')
    });

    const retentionRate = totalClients > 0 ? ((repeatClients.length / totalClients) * 100).toFixed(1) : 0;

    // Peak booking hours
    const peakHours = await Booking.findAll({
        where: {
            providerId: provider.id,
            status: 'completed',
            createdAt: { [Op.gte]: startOfMonth }
        },
        attributes: [
            [fn('HOUR', col('scheduledTime')), 'hour'],
            [fn('COUNT', col('id')), 'bookingCount']
        ],
        group: [fn('HOUR', col('scheduledTime'))],
        order: [[fn('COUNT', col('id')), 'DESC']],
        limit: 5,
        raw: true
    });

    // Monthly growth trend
    const monthlyGrowth = await Booking.findAll({
        where: {
            providerId: provider.id,
            status: 'completed',
            createdAt: { [Op.gte]: startOfYear }
        },
        attributes: [
            [fn('MONTH', col('createdAt')), 'month'],
            [fn('YEAR', col('createdAt')), 'year'],
            [fn('COUNT', col('id')), 'bookingCount'],
            [fn('SUM', literal("CAST(payment->>'providerEarnings' AS DECIMAL)")), 'totalEarnings']
        ],
        group: [fn('MONTH', col('createdAt')), fn('YEAR', col('createdAt'))],
        order: [[fn('YEAR', col('createdAt')), 'ASC'], [fn('MONTH', col('createdAt')), 'ASC']],
        raw: true
    });

    res.json({
        success: true,
        data: {
            topServices: topServices.map(service => ({
                serviceName: service['service.name'],
                bookingCount: parseInt(service.bookingCount),
                totalEarnings: parseFloat(service.totalEarnings || 0)
            })),
            clientMetrics: {
                totalClients,
                repeatClients: repeatClients.length,
                retentionRate: parseFloat(retentionRate)
            },
            peakHours: peakHours.map(hour => ({
                hour: parseInt(hour.hour),
                bookingCount: parseInt(hour.bookingCount)
            })),
            monthlyGrowth: monthlyGrowth.map(month => ({
                month: parseInt(month.month),
                year: parseInt(month.year),
                bookingCount: parseInt(month.bookingCount),
                totalEarnings: parseFloat(month.totalEarnings || 0)
            }))
        }
    });
});

module.exports = {
    getDashboardOverview: exports.getDashboardOverview,
    getPerformanceChart: exports.getPerformanceChart,
    getStaff: exports.getStaff,
    addStaff: exports.addStaff,
    getStaffMember: exports.getStaffMember,
    updateStaff: exports.updateStaff,
    removeStaff: exports.removeStaff,
    getAvailableStaff: exports.getAvailableStaff,
    assignBooking: exports.assignBooking,
    reassignBooking: exports.reassignBooking,
    getRevenue: exports.getRevenue,
    requestPayout: exports.requestPayout,
    getAdvancedAnalytics: exports.getAdvancedAnalytics
};
