const { Op } = require('sequelize');
const ActivityLog = require('../models/ActivityLog');
const User = require('../models/User');
const { asyncHandler } = require('../middleware/errorHandler');
// @desc    Get activity logs
// @route   GET /api/admin/activity-logs
// @access  Private (Admin)
exports.getActivityLogs = asyncHandler(async (req, res) => {
    const { page = 1, limit = 20, userId, action, startDate, endDate } = req.query;

    const where = {};
    
    if (userId) where.userId = userId;
    if (action) where.action = action;
    
    if (startDate || endDate) {
        where.createdAt = {};
        if (startDate) where.createdAt[Op.gte] = new Date(startDate);
        if (endDate) where.createdAt[Op.lte] = new Date(endDate);
    }

    const offset = (parseInt(page) - 1) * parseInt(limit);

    const { count, rows: activityLogs } = await ActivityLog.findAndCountAll({
        where,
        include: [{ model: User, attributes: ['firstName', 'lastName', 'email'] }],
        order: [['createdAt', 'DESC']],
        limit: parseInt(limit),
        offset
    });

    res.json({
        success: true,
        data: {
            activityLogs,
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total: count,
                pages: Math.ceil(count / parseInt(limit))
            }
        }
    });
});

// @desc    Create activity log
// @route   POST /api/admin/activity-logs
// @access  Private (Admin)
exports.createActivityLog = asyncHandler(async (req, res) => {
    const { userId, action, entityType, entityId, description, metadata } = req.body;

    // Get IP address and user agent from request
    const ipAddress = req.ip || req.connection.remoteAddress;
    const userAgent = req.get('User-Agent');

    const activityLog = await ActivityLog.create({
        userId,
        action,
        entityType,
        entityId,
        description,
        metadata,
        ipAddress,
        userAgent
    });

    res.status(201).json({
        success: true,
        message: 'Activity log created successfully',
        data: { activityLog }
    });
});

// @desc    Get activity log by ID
// @route   GET /api/admin/activity-logs/:id
// @access  Private (Admin)
exports.getActivityLogById = asyncHandler(async (req, res) => {
    const activityLog = await ActivityLog.findByPk(req.params.id, {
        include: [{ model: User, attributes: ['firstName', 'lastName', 'email'] }]
    });

    if (!activityLog) {
        return res.status(404).json({
            success: false,
            message: 'Activity log not found'
        });
    }

    res.json({
        success: true,
        data: { activityLog }
    });
});

// @desc    Delete activity log
// @route   DELETE /api/admin/activity-logs/:id
// @access  Private (Admin)
exports.deleteActivityLog = asyncHandler(async (req, res) => {
    const activityLog = await ActivityLog.findByPk(req.params.id);

    if (!activityLog) {
        return res.status(404).json({
            success: false,
            message: 'Activity log not found'
        });
    }

    await activityLog.destroy();

    res.json({
        success: true,
        message: 'Activity log deleted successfully'
    });
});

// Helper function to log admin activities
exports.logActivity = async (userId, action, entityType, entityId, description, metadata = {}) => {
    try {
        // Get IP address and user agent (if available)
        // Note: This would typically be passed from the request context
        const ipAddress = null;
        const userAgent = null;

        await ActivityLog.create({
            userId,
            action,
            entityType,
            entityId,
            description,
            metadata,
            ipAddress,
            userAgent
        });
    } catch (error) {
        console.error('Error logging activity:', error);
    }
};