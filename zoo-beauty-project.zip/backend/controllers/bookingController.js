const Booking = require('../models/Booking');
const Provider = require('../models/Provider');
const User = require('../models/User');
const Notification = require('../models/Notification');
const { asyncHandler } = require('../middleware/errorHandler');

// @desc    Create booking
// @route   POST /api/bookings
// @access  Private (Client)
exports.createBooking = asyncHandler(async (req, res) => {
    const {
        providerId,
        serviceId, // Expecting serviceId now
        scheduledDate,
        scheduledTime,
        location,
        serviceType, // 'on-site' or 'en-route'
        notes
    } = req.body;

    // Verify provider exists and is visible
    const provider = await Provider.findByPk(providerId);

    if (!provider || !provider.isVisible) {
        return res.status(404).json({
            success: false,
            message: 'Provider not found or unavailable'
        });
    }

    // Find the selected service from provider's services
    // Ensure provider.services is an array before trying to find
    const providerServices = provider.services || [];
    const selectedService = providerServices.find(svc => svc.id === serviceId);

    if (!selectedService) {
        return res.status(400).json({
            success: false,
            message: 'Selected service not found for this provider'
        });
    }

    // Handle Assignment Logic
    let assignedBeauticianId = null;
    const isMobileService = serviceType === 'en-route' || serviceType === 'mobile' || serviceType === 'on route';

    if (isMobileService) {
        const { ProviderBeauticianService } = require('../models');

        // Find all active beauticians linked to this provider
        // Note: Ideally we would filter by service capability too, but for now we assign from the pool
        const linkedBeauticians = await ProviderBeauticianService.findAll({
            where: {
                providerId: provider.id,
                isActive: true
            }
        });

        if (linkedBeauticians.length > 0) {
            // Simple assignment strategy: Random selection
            // In a production system, this would check availability slots
            const randomIndex = Math.floor(Math.random() * linkedBeauticians.length);
            assignedBeauticianId = linkedBeauticians[randomIndex].beauticianId;
        }
    }

    // Create booking
    const booking = await Booking.create({
        clientId: req.user.id,
        providerId,
        serviceId: selectedService.id, // Assign service ID
        serviceName: selectedService.name, // Assign service Name
        service: selectedService, // Store full service details
        scheduledDate,
        scheduledTime,
        location,
        serviceType: serviceType || provider.serviceType || 'on-site', // Default based on provider type
        notes,
        amount: selectedService.price, // Set top-level amount
        assignedBeauticianId, // Automatically assigned if applicable
        payment: {
            amount: selectedService.price,
            platformFee: selectedService.price * 0.1, // 10% platform fee
            providerEarnings: selectedService.price * 0.9,
            status: 'pending' // Initial payment status
        },
        timeline: [{
            status: 'pending',
            timestamp: new Date(),
            note: 'Booking created'
        }]
    });

    // Create notification for provider
    await Notification.createNotification(
        provider.userId,
        'booking_created',
        'New Booking Request',
        `You have a new booking request for ${selectedService.name}`,
        { bookingId: booking.id },
        `/bookings/${booking.id}`
    );

    // If assigned to a beautician, notify them too
    if (assignedBeauticianId) {
        await Notification.createNotification(
            assignedBeauticianId,
            'booking_assigned',
            'New Task Assigned',
            `You have been assigned a new mobile service task for ${selectedService.name}`,
            { bookingId: booking.id },
            `/beautician/tasks/${booking.id}`
        );
    }

    // Emit WebSocket event for real-time syncing
    const { getIO } = require('../server');
    const io = getIO();

    // Emit to admin room
    io.emit('booking_created', {
        booking: {
            id: booking.id,
            clientId: booking.clientId,
            providerId: booking.providerId,
            serviceName: booking.serviceName,
            amount: booking.amount,
            status: booking.status,
            createdAt: booking.createdAt
        }
    });

    // Emit to beautician if assigned
    if (assignedBeauticianId) {
        io.to(assignedBeauticianId).emit('booking_assigned', {
            booking: {
                id: booking.id,
                serviceName: booking.serviceName,
                status: booking.status
            }
        });
    }

    res.status(201).json({
        success: true,
        message: 'Booking created successfully',
        data: { booking }
    });
});

// @desc    Get booking by ID
// @route   GET /api/bookings/:id
// @access  Private
exports.getBooking = asyncHandler(async (req, res) => {
    const booking = await Booking.findByPk(req.params.id, {
        include: [
            { model: User, as: 'client', attributes: ['firstName', 'lastName', 'phone', 'avatar'] },
            { model: Provider, as: 'provider', include: [{ model: User, as: 'user', attributes: ['firstName', 'lastName'] }] },
            { model: User, as: 'beautician', attributes: ['firstName', 'lastName', 'phone', 'avatar'] }
        ]
    });

    if (!booking) {
        return res.status(404).json({
            success: false,
            message: 'Booking not found'
        });
    }

    // Check authorization
    // The provider in the booking object is a Sequelize instance. To get its userId,
    // we need to access `booking.provider.user.id` or `booking.provider.userId` if it's directly available.
    // Assuming Provider model has a `userId` field directly.
    const provider = await Provider.findByPk(booking.providerId);


    if (
        booking.clientId !== req.user.id &&
        (provider && provider.userId !== req.user.id) && // Check if provider exists before accessing userId
        req.user.role !== 'admin'
    ) {
        return res.status(403).json({
            success: false,
            message: 'Not authorized to view this booking'
        });
    }

    res.json({
        success: true,
        data: { booking }
    });
});

// @desc    Get my bookings
// @route   GET /api/bookings/my
// @access  Private
exports.getMyBookings = asyncHandler(async (req, res) => {
    const { status, serviceType, page = 1, limit = 10 } = req.query;

    const where = {};

    // Filter by user role
    if (req.user.role === 'client') {
        where.clientId = req.user.id;
    } else if (req.user.role === 'provider') {
        const provider = await Provider.findOne({ where: { userId: req.user.id } });
        if (!provider) {
            return res.status(404).json({
                success: false,
                message: 'Provider profile not found'
            });
        }
        where.providerId = provider.id;
        if (serviceType) {
            where.serviceType = serviceType;
        } else {
            where.serviceType = 'studio'; // Default for provider view
        }

    } else if (req.user.role === 'beautician') {
        const { ProviderBeauticianService } = require('../models');

        // Find the provider this beautician works for
        // We assume a beautician works for one provider for now, or we take the first one
        const link = await ProviderBeauticianService.findOne({
            where: { beauticianId: req.user.id, isActive: true }
        });

        if (!link) {
            return res.status(404).json({
                success: false,
                message: 'You are not linked to any provider'
            });
        }

        where.providerId = link.providerId;

        // Beauticians see bookings assigned to them OR all mobile/en-route bookings for their provider
        // Note: Using Sequelize generic operator for OR condition would require importing Op
        const { Op } = require('sequelize');
        where[Op.and] = [
            { providerId: link.providerId },
            {
                [Op.or]: [
                    { assignedBeauticianId: req.user.id },
                    { serviceType: { [Op.in]: ['mobile', 'en-route', 'on route'] } }
                ]
            }
        ];
    }

    // Filter by status
    if (status) {
        where.status = status;
    }

    const offset = (parseInt(page) - 1) * parseInt(limit);

    const { count, rows: bookings } = await Booking.findAndCountAll({
        where,
        include: [
            { model: User, as: 'client', attributes: ['firstName', 'lastName', 'phone', 'avatar'] },
            { model: Provider, as: 'provider', include: [{ model: User, as: 'user', attributes: ['firstName', 'lastName'] }] },
            { model: User, as: 'beautician', attributes: ['firstName', 'lastName', 'phone', 'avatar'] }
        ],
        order: [['createdAt', 'DESC']],
        limit: parseInt(limit),
        offset
    });

    res.json({
        success: true,
        data: {
            bookings,
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total: count,
                pages: Math.ceil(count / parseInt(limit))
            }
        }
    });
});

// @desc    Accept booking
// @route   PUT /api/bookings/:id/accept
// @access  Private (Provider)
exports.acceptBooking = asyncHandler(async (req, res) => {
    const booking = await Booking.findByPk(req.params.id);

    if (!booking) {
        return res.status(404).json({
            success: false,
            message: 'Booking not found'
        });
    }

    // Verify provider ownership
    const provider = await Provider.findOne({ where: { userId: req.user.id } });
    if (!provider || booking.providerId !== provider.id) {
        return res.status(403).json({
            success: false,
            message: 'Not authorized'
        });
    }

    if (booking.status !== 'pending') {
        return res.status(400).json({
            success: false,
            message: 'Booking cannot be accepted in current status'
        });
    }

    booking.status = 'accepted';
    const timeline = booking.timeline || [];
    timeline.push({
        status: 'accepted',
        timestamp: new Date(),
        note: 'Booking accepted by provider'
    });
    booking.timeline = timeline;
    await booking.save();

    // Update provider stats
    // Ensure provider.stats is an object before accessing properties
    const providerStats = provider.stats || {};
    providerStats.totalBookings = (providerStats.totalBookings || 0) + 1;
    provider.stats = providerStats; // Reassign to trigger update
    await provider.save();

    // Notify client
    await Notification.createNotification(
        booking.clientId,
        'booking_accepted',
        'Booking Accepted',
        'Your booking has been accepted',
        { bookingId: booking.id },
        `/bookings/${booking.id}`
    );

    res.json({
        success: true,
        message: 'Booking accepted successfully',
        data: { booking }
    });
});

// @desc    Reject booking
// @route   PUT /api/bookings/:id/reject
// @access  Private (Provider)
exports.rejectBooking = asyncHandler(async (req, res) => {
    const { reason } = req.body;
    const booking = await Booking.findByPk(req.params.id);

    if (!booking) {
        return res.status(404).json({
            success: false,
            message: 'Booking not found'
        });
    }

    // Verify provider ownership
    const provider = await Provider.findOne({ where: { userId: req.user.id } });
    if (!provider || booking.providerId !== provider.id) {
        return res.status(403).json({
            success: false,
            message: 'Not authorized'
        });
    }

    if (booking.status !== 'pending') {
        return res.status(400).json({
            success: false,
            message: 'Booking cannot be rejected in current status'
        });
    }

    booking.status = 'rejected';
    const timeline = booking.timeline || [];
    timeline.push({
        status: 'rejected',
        timestamp: new Date(),
        note: reason || 'Booking rejected by provider'
    });
    booking.timeline = timeline;
    await booking.save();

    // TODO: Implement actual refund processing here if a payment was already made
    // For now, we assume payment is processed later or handled by admin

    // Notify client
    await Notification.createNotification(
        booking.clientId,
        'booking_rejected',
        'Booking Rejected',
        'Your booking request was declined',
        { bookingId: booking.id },
        `/bookings/${booking.id}`
    );

    res.json({
        success: true,
        message: 'Booking rejected',
        data: { booking }
    });
});

// @desc    Cancel booking
// @route   PUT /api/bookings/:id/cancel
// @access  Private
exports.cancelBooking = asyncHandler(async (req, res) => {
    const { reason } = req.body;
    const booking = await Booking.findByPk(req.params.id);

    if (!booking) {
        return res.status(404).json({
            success: false,
            message: 'Booking not found'
        });
    }

    // Check authorization
    const provider = await Provider.findOne({ where: { userId: req.user.id } });
    const isClient = booking.clientId === req.user.id;
    const isProvider = provider && booking.providerId === provider.id;

    if (!isClient && !isProvider && req.user.role !== 'admin') { // Added admin check
        return res.status(403).json({
            success: false,
            message: 'Not authorized'
        });
    }

    if (!['pending', 'accepted'].includes(booking.status)) {
        return res.status(400).json({
            success: false,
            message: 'Booking cannot be cancelled in current status'
        });
    }

    booking.status = 'cancelled';
    booking.cancellation = {
        cancelledBy: req.user.id,
        reason,
        cancelledAt: new Date()
    };
    const timeline = booking.timeline || [];
    timeline.push({
        status: 'cancelled',
        timestamp: new Date(),
        note: reason || 'Booking cancelled'
    });
    booking.timeline = timeline;
    await booking.save();

    // Update provider stats if applicable
    if (isProvider) { // Check if the canceller is the provider
        const providerStats = provider.stats || {};
        providerStats.cancelledBookings = (providerStats.cancelledBookings || 0) + 1;
        provider.stats = providerStats; // Reassign to trigger update
        await provider.save();
    }


    // TODO: Implement actual refund processing here based on cancellation policy
    // For now, we assume payment is processed later or handled by admin

    // Notify other party
    const targetUserId = isClient ? provider.userId : booking.clientId;
    const notificationType = isClient ? 'booking_cancelled_by_client' : 'booking_cancelled_by_provider';
    const notificationTitle = isClient ? 'Booking Cancelled by Client' : 'Booking Cancelled by Provider';
    const notificationMessage = isClient ?
        `Your booking with ${req.user.firstName} ${req.user.lastName} has been cancelled.` :
        `The booking by ${booking.client.firstName} ${booking.client.lastName} has been cancelled.`;

    await Notification.createNotification(
        targetUserId,
        notificationType,
        notificationTitle,
        notificationMessage,
        { bookingId: booking.id },
        `/bookings/${booking.id}`
    );


    res.json({
        success: true,
        message: 'Booking cancelled successfully',
        data: { booking }
    });
});

// @desc    Assign beautician to booking
// @route   PUT /api/bookings/:id/assign-beautician
// @access  Private (Provider)
exports.assignBeautician = asyncHandler(async (req, res) => {
    const { beauticianId } = req.body;
    const booking = await Booking.findByPk(req.params.id);

    if (!booking) {
        return res.status(404).json({
            success: false,
            message: 'Booking not found'
        });
    }

    // Verify provider ownership
    const provider = await Provider.findOne({ where: { userId: req.user.id } });
    if (!provider || booking.providerId !== provider.id) {
        return res.status(403).json({
            success: false,
            message: 'Not authorized'
        });
    }

    // Verify beautician exists and belongs to this provider
    const beautician = await User.findByPk(beauticianId);
    if (!beautician || beautician.role !== 'beautician') {
        return res.status(400).json({
            success: false,
            message: 'Invalid beautician'
        });
    }

    // Check if beautician is associated with this provider
    const beauticianProvider = await Provider.findOne({ where: { userId: beauticianId } });
    if (!beauticianProvider || beauticianProvider.id !== provider.id) {
        return res.status(400).json({
            success: false,
            message: 'Beautician not associated with this provider'
        });
    }

    // Assign beautician to booking
    booking.assignedBeauticianId = beauticianId;
    await booking.save();

    // Create notification for beautician
    await Notification.createNotification(
        beauticianId,
        'booking_assigned',
        'New Booking Assigned',
        `You have been assigned to a booking for ${booking.serviceName}`,
        { bookingId: booking.id },
        `/bookings/${booking.id}`
    );

    // Emit WebSocket event for real-time syncing
    const { getIO } = require('../server');
    const io = getIO();
    // Emit to beautician's room for real-time notification
    io.to(beauticianId).emit('booking_assigned', {
        booking: {
            id: booking.id,
            clientId: booking.clientId,
            providerId: booking.providerId,
            serviceName: booking.serviceName,
            amount: booking.amount,
            status: booking.status,
            createdAt: booking.createdAt
        }
    });

    res.json({
        success: true,
        message: 'Beautician assigned to booking successfully',
        data: { booking }
    });
});

// @desc    Update booking status
// @route   PUT /api/bookings/:id/status
// @access  Private (Provider)
exports.updateStatus = asyncHandler(async (req, res) => {
    const { status, note } = req.body;
    const booking = await Booking.findByPk(req.params.id);

    if (!booking) {
        return res.status(404).json({
            success: false,
            message: 'Booking not found'
        });
    }

    // Verify provider ownership
    const provider = await Provider.findOne({ where: { userId: req.user.id } });
    if (!provider || booking.providerId !== provider.id) {
        return res.status(403).json({
            success: false,
            message: 'Not authorized'
        });
    }

    // Validate status transition (example: cannot go from cancelled to completed)
    const validTransitions = {
        'pending': ['accepted', 'rejected', 'cancelled'],
        'accepted': ['in-progress', 'cancelled'],
        'in-progress': ['completed', 'cancelled'],
        'completed': [],
        'rejected': [],
        'cancelled': []
    };

    if (!validTransitions[booking.status] || !validTransitions[booking.status].includes(status)) {
        return res.status(400).json({
            success: false,
            message: `Invalid status transition from ${booking.status} to ${status}`
        });
    }


    booking.status = status;
    const timeline = booking.timeline || [];
    timeline.push({
        status,
        timestamp: new Date(),
        note
    });
    booking.timeline = timeline;


    // If completed, update provider stats and create payment record
    if (status === 'completed') {
        const providerStats = provider.stats || {};
        providerStats.completedBookings = (providerStats.completedBookings || 0) + 1;
        providerStats.totalEarnings = (providerStats.totalEarnings || 0) + (booking.payment.providerEarnings || 0);
        provider.stats = providerStats; // Reassign to trigger update
        await provider.save();

        // Create payment record for completed booking
        const Payment = require('../models/Payment');
        const amount = booking.amount || 0;
        const platformFee = amount * 0.1; // 10% platform fee
        const providerAmount = amount - platformFee;

        await Payment.create({
            transactionId: Payment.generateTransactionId(),
            type: 'booking',
            userId: booking.clientId,
            relatedId: booking.id,
            amount: amount,
            platformFee: platformFee,
            netAmount: providerAmount,
            status: 'completed',
            paymentMethod: 'cash', // Default payment method
            metadata: {
                bookingId: booking.id,
                providerId: provider.id
            }
        });

        // Notify client
        await Notification.createNotification(
            booking.clientId,
            'booking_completed',
            'Service Completed',
            'Your service has been completed. Please leave a review!',
            { bookingId: booking.id },
            `/bookings/${booking.id}/review`
        );
    }

    await booking.save();

    // Emit WebSocket event for real-time syncing
    const { getIO } = require('../server');
    const io = getIO();
    // Emit to admin room for real-time dashboard updates
    io.emit('booking_updated', {
        booking: {
            id: booking.id,
            clientId: booking.clientId,
            providerId: booking.providerId,
            serviceName: booking.serviceName,
            amount: booking.amount,
            status: booking.status,
            createdAt: booking.createdAt
        }
    });

    res.json({
        success: true,
        message: 'Booking status updated',
        data: { booking }
    });
});

