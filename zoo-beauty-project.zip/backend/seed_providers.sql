-- Insert Sample Provider Users (Kenyan Providers)
INSERT INTO `users` (`firstName`, `lastName`, `email`, `password`, `phone`, `role`, `isActive`, `isVerified`) VALUES
('Wanjiku', 'Kimani', 'wanjiku@example.com', '$2a$10$rN8qZ5YxH9kQXZ5YxH9kQeO5YxH9kQXZ5YxH9kQXZ5YxH9kQXZ5Yx', '+254712345678', 'provider', 1, 1),
('Otieno', 'Juma', 'otieno@example.com', '$2a$10$rN8qZ5YxH9kQXZ5YxH9kQeO5YxH9kQXZ5YxH9kQXZ5YxH9kQXZ5Yx', '+254723456789', 'provider', 1, 1),
('Amina', 'Hassan', 'amina@example.com', '$2a$10$rN8qZ5YxH9kQXZ5YxH9kQeO5YxH9kQXZ5YxH9kQXZ5YxH9kQXZ5Yx', '+254734567890', 'provider', 1, 1),
('Grace', 'Muthoni', 'grace@example.com', '$2a$10$rN8qZ5YxH9kQXZ5YxH9kQeO5YxH9kQXZ5YxH9kQXZ5YxH9kQXZ5Yx', '+254745678901', 'provider', 1, 1),
('Kevin', 'Mwangi', 'kevin@example.com', '$2a$10$rN8qZ5YxH9kQXZ5YxH9kQeO5YxH9kQXZ5YxH9kQXZ5YxH9kQXZ5Yx', '+254756789012', 'provider', 1, 1),
('Zainab', 'Ali', 'zainab@example.com', '$2a$10$rN8qZ5YxH9kQXZ5YxH9kQeO5YxH9kQXZ5YxH9kQXZ5YxH9kQXZ5Yx', '+254767890123', 'provider', 1, 1),
('Peter', 'Njoroge', 'peter@example.com', '$2a$10$rN8qZ5YxH9kQXZ5YxH9kQeO5YxH9kQXZ5YxH9kQXZ5YxH9kQXZ5Yx', '+254778901234', 'provider', 1, 1),
('Lucy', 'Achieng', 'lucy@example.com', '$2a$10$rN8qZ5YxH9kQXZ5YxH9kQeO5YxH9kQXZ5YxH9kQXZ5YxH9kQXZ5Yx', '+254789012345', 'provider', 1, 1),
('Fatuma', 'Mohamed', 'fatuma@example.com', '$2a$10$rN8qZ5YxH9kQXZ5YxH9kQeO5YxH9kQXZ5YxH9kQXZ5YxH9kQXZ5Yx', '+254790123456', 'provider', 1, 1),
('Esther', 'Wambui', 'esther@example.com', '$2a$10$rN8qZ5YxH9kQXZ5YxH9kQeO5YxH9kQXZ5YxH9kQXZ5YxH9kQXZ5Yx', '+254701234567', 'provider', 1, 1);

-- Insert Provider Profiles
INSERT INTO `providers` (`userId`, `businessName`, `bio`, `specializations`, `location`, `serviceType`, `services`, `portfolio`, `rating`, `stats`, `isVisible`) VALUES
(
    (SELECT id FROM users WHERE email = 'wanjiku@example.com'),
    'Wanjiku\'s Beauty Hub',
    'Top-rated makeup artist in Nairobi specializing in bridal and event makeup. I bring out your inner glow.',
    '["Makeup", "Bridal"]',
    '{"type": "Point", "coordinates": [36.8219, -1.2921], "address": "Westlands, Nairobi"}',
    'both',
    '[{"name": "Bridal Makeup", "description": "Complete bridal package with trial.", "duration": 120, "price": 15000, "category": "Makeup"}, {"name": "Evening Glam", "description": "Perfect for dinners and events.", "duration": 60, "price": 5000, "category": "Makeup"}]',
    '[{"type": "image", "url": "https://images.unsplash.com/photo-1487412912498-0447578fcca8?w=400", "caption": "Bridal Glow"}]',
    '{"average": 4.9, "count": 150}',
    '{"totalBookings": 300, "completedBookings": 295, "totalEarnings": 1500000}',
    1
),
(
    (SELECT id FROM users WHERE email = 'otieno@example.com'),
    'Juma Cuts',
    'Professional barber offering clean cuts, beard trims, and hot towel shaves in Kisumu.',
    '["Barbering", "Grooming"]',
    '{"type": "Point", "coordinates": [34.7617, -0.1022], "address": "CBD, Kisumu"}',
    'studio',
    '[{"name": "Standard Haircut", "description": "Clean cut with clippers and scissors.", "duration": 45, "price": 500, "category": "Barbering"}, {"name": "Beard Trim", "description": "Shaping and lining.", "duration": 30, "price": 300, "category": "Barbering"}]',
    '[{"type": "image", "url": "https://images.unsplash.com/photo-1503951914875-452162b0f3f1?w=400", "caption": "Fade Cut"}]',
    '{"average": 4.8, "count": 95}',
    '{"totalBookings": 200, "completedBookings": 198, "totalEarnings": 100000}',
    1
),
(
    (SELECT id FROM users WHERE email = 'amina@example.com'),
    'Amina Henna & Spa',
    'Traditional Swahili henna art and relaxing spa treatments in the heart of Mombasa.',
    '["Henna", "Spa", "Massage"]',
    '{"type": "Point", "coordinates": [39.6682, -4.0435], "address": "Nyali, Mombasa"}',
    'both',
    '[{"name": "Bridal Henna", "description": "Intricate designs for hands and feet.", "duration": 180, "price": 8000, "category": "Henna"}, {"name": "Full Body Massage", "description": "Relaxing Swedish massage.", "duration": 60, "price": 3000, "category": "Spa"}]',
    '[{"type": "image", "url": "https://images.unsplash.com/photo-1604654894610-df63bc536371?w=400", "caption": "Henna Art"}]',
    '{"average": 5.0, "count": 210}',
    '{"totalBookings": 400, "completedBookings": 390, "totalEarnings": 1200000}',
    1
),
(
    (SELECT id FROM users WHERE email = 'grace@example.com'),
    'Graceful Braids',
    'Neat and painless braiding services. Specializing in knotless braids and cornrows.',
    '["Braiding", "Hair Styling"]',
    '{"type": "Point", "coordinates": [36.8219, -1.2921], "address": "Kilimani, Nairobi"}',
    'studio',
    '[{"name": "Knotless Braids (Waist Length)", "description": "Medium size knotless braids.", "duration": 300, "price": 4500, "category": "Braiding"}, {"name": "Cornrows", "description": "Simple lines.", "duration": 90, "price": 1500, "category": "Braiding"}]',
    '[{"type": "image", "url": "https://images.unsplash.com/photo-1580618672591-eb180b1a973f?w=400", "caption": "Knotless Braids"}]',
    '{"average": 4.7, "count": 180}',
    '{"totalBookings": 350, "completedBookings": 345, "totalEarnings": 1575000}',
    1
),
(
    (SELECT id FROM users WHERE email = 'kevin@example.com'),
    'Kev\'s Mobile Barber',
    'Convenient mobile barber services. I come to your home or office in Nairobi.',
    '["Barbering", "Mobile Service"]',
    '{"type": "Point", "coordinates": [36.8219, -1.2921], "address": "Mobile, Nairobi"}',
    'mobile',
    '[{"name": "House Call Haircut", "description": "Premium haircut at your location.", "duration": 60, "price": 1500, "category": "Barbering"}, {"name": "Beard Grooming", "description": "Detailed beard care.", "duration": 30, "price": 800, "category": "Barbering"}]',
    '[{"type": "image", "url": "https://images.unsplash.com/photo-1622286342621-4bd786c2447c?w=400", "caption": "Mobile Setup"}]',
    '{"average": 4.9, "count": 60}',
    '{"totalBookings": 120, "completedBookings": 118, "totalEarnings": 180000}',
    1
),
(
    (SELECT id FROM users WHERE email = 'zainab@example.com'),
    'Zainab Aesthetics',
    'Advanced skincare treatments including facials, chemical peels, and microdermabrasion.',
    '["Skincare", "Facials"]',
    '{"type": "Point", "coordinates": [39.6682, -4.0435], "address": "Bamburi, Mombasa"}',
    'studio',
    '[{"name": "Deep Cleansing Facial", "description": "Thorough cleanse and extraction.", "duration": 75, "price": 4000, "category": "Skincare"}, {"name": "Chemical Peel", "description": "Skin resurfacing treatment.", "duration": 45, "price": 6000, "category": "Skincare"}]',
    '[{"type": "image", "url": "https://images.unsplash.com/photo-1570172619644-dfd03ed5d881?w=400", "caption": "Facial Treatment"}]',
    '{"average": 4.8, "count": 110}',
    '{"totalBookings": 220, "completedBookings": 215, "totalEarnings": 880000}',
    1
),
(
    (SELECT id FROM users WHERE email = 'peter@example.com'),
    'Njoro\'s Nail Bar',
    'The best acrylics and gel polish in Nakuru. Creative designs and durable finish.',
    '["Nails", "Manicure", "Pedicure"]',
    '{"type": "Point", "coordinates": [36.0800, -0.3031], "address": "Milimani, Nakuru"}',
    'studio',
    '[{"name": "Acrylic Full Set", "description": "Sculpted acrylics with gel polish.", "duration": 120, "price": 2500, "category": "Nails"}, {"name": "Gel Pedicure", "description": "Relaxing pedicure with gel polish.", "duration": 60, "price": 1500, "category": "Nails"}]',
    '[{"type": "image", "url": "https://images.unsplash.com/photo-1632345031435-8727f6897d53?w=400", "caption": "Nail Art"}]',
    '{"average": 4.6, "count": 85}',
    '{"totalBookings": 170, "completedBookings": 165, "totalEarnings": 425000}',
    1
),
(
    (SELECT id FROM users WHERE email = 'lucy@example.com'),
    'Lucy\'s Locs',
    'Specialist in dreadlocks installation, maintenance, and styling in Kisumu.',
    '["Dreadlocks", "Natural Hair"]',
    '{"type": "Point", "coordinates": [34.7617, -0.1022], "address": "Kondele, Kisumu"}',
    'studio',
    '[{"name": "Locs Retwist", "description": "Neat retwist and style.", "duration": 90, "price": 2000, "category": "Hair"}, {"name": "Starter Locs", "description": "Starting new locs.", "duration": 180, "price": 4000, "category": "Hair"}]',
    '[{"type": "image", "url": "https://images.unsplash.com/photo-1519699047748-de8e457a634e?w=400", "caption": "Locs Style"}]',
    '{"average": 4.9, "count": 130}',
    '{"totalBookings": 260, "completedBookings": 255, "totalEarnings": 520000}',
    1
),
(
    (SELECT id FROM users WHERE email = 'fatuma@example.com'),
    'Swahili Bridal Glam',
    'Exquisite bridal makeup and styling for Swahili weddings in Mombasa.',
    '["Makeup", "Bridal"]',
    '{"type": "Point", "coordinates": [39.6682, -4.0435], "address": "Old Town, Mombasa"}',
    'mobile',
    '[{"name": "Nikah Makeup", "description": "Soft and elegant look for Nikah.", "duration": 90, "price": 10000, "category": "Makeup"}, {"name": "Wedding Reception Glam", "description": "Bold and beautiful for the reception.", "duration": 90, "price": 12000, "category": "Makeup"}]',
    '[{"type": "image", "url": "https://images.unsplash.com/photo-1596462502278-27bfdd403348?w=400", "caption": "Bridal Makeup"}]',
    '{"average": 5.0, "count": 100}',
    '{"totalBookings": 150, "completedBookings": 148, "totalEarnings": 1500000}',
    1
),
(
    (SELECT id FROM users WHERE email = 'esther@example.com'),
    'Essie\'s Hair Studio',
    'Premium wigs and weaves installation. Custom wig making services available.',
    '["Wigs", "Weaves", "Hair Styling"]',
    '{"type": "Point", "coordinates": [36.8219, -1.2921], "address": "Karen, Nairobi"}',
    'studio',
    '[{"name": "Wig Installation", "description": "Melting the lace for a natural look.", "duration": 90, "price": 3500, "category": "Hair"}, {"name": "Sew-in Weave", "description": "Traditional sew-in with leave out.", "duration": 150, "price": 4500, "category": "Hair"}]',
    '[{"type": "image", "url": "https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?w=400", "caption": "Wig Install"}]',
    '{"average": 4.8, "count": 175}',
    '{"totalBookings": 320, "completedBookings": 315, "totalEarnings": 1120000}',
    1
);

SELECT 'Kenyan providers added successfully!' AS message;
