const mongoose = require('mongoose');
const User = require('./models/User.mongo');
const { connectDB } = require('./config/mongodb');

// Connect to database
connectDB();

// Test adding a user directly
async function testAddUser() {
  try {
    console.log('Testing user registration directly...');
    
    const userData = {
      email: 'testuser2@example.com',
      password: 'password123',
      role: 'client'
    };
    
    const user = new User(userData);
    await user.save();
    
    console.log('✅ User registered successfully!');
    console.log('User ID:', user._id);
    console.log('Email:', user.email);
    console.log('Role:', user.role);
    console.log('Profile Complete:', user.isProfileComplete);
    console.log('First Name:', user.firstName);
    console.log('Last Name:', user.lastName);
    
    // Close connection
    mongoose.connection.close();
  } catch (error) {
    console.log('❌ Registration failed with error:', error.message);
    mongoose.connection.close();
  }
}

// Run the test
testAddUser();