const mongoose = require('mongoose');
const User = require('./models/User.mongo');
const { connectDB } = require('./config/mongodb');

// Connect to database
connectDB();

async function checkUsers() {
  try {
    console.log('Checking test users...\n');
    
    // Find all test users
    const users = await User.find({
      email: {
        $in: [
          'testclient@example.com',
          'testprovider@example.com',
          'testbeautician@example.com'
        ]
      }
    });
    
    if (users.length === 0) {
      console.log('❌ No test users found');
      mongoose.connection.close();
      return;
    }
    
    console.log(`Found ${users.length} test users:\n`);
    
    for (const user of users) {
      console.log(`📧 Email: ${user.email}`);
      console.log(`👤 Role: ${user.role}`);
      console.log(`🔒 Password (first 20 chars): ${user.password.substring(0, 20)}...`);
      console.log(`📝 First Name: ${user.firstName}`);
      console.log(`📝 Last Name: ${user.lastName}`);
      console.log(`📱 Phone: ${user.phone}`);
      console.log(`✅ Profile Complete: ${user.isProfileComplete}`);
      console.log(`✅ Account Active: ${user.isActive}`);
      console.log(`---\n`);
    }
    
    // Close connection
    mongoose.connection.close();
    
  } catch (error) {
    console.log('❌ Error checking users:', error.message);
    mongoose.connection.close();
  }
}

// Run the check
checkUsers();