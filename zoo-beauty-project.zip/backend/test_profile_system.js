const mongoose = require('mongoose');
const User = require('./models/User.mongo');
const { connectDB } = require('./config/mongodb');

// Connect to database
connectDB();

// Test profile completion system
async function testProfileSystem() {
  try {
    console.log('Testing profile completion system...');
    
    // Create a new provider user with minimal data
    const providerUser = new User({
      email: 'testprovider@example.com',
      password: 'password123',
      role: 'provider'
    });
    
    await providerUser.save();
    console.log('Created provider user with minimal data:', {
      id: providerUser._id,
      email: providerUser.email,
      role: providerUser.role,
      isProfileComplete: providerUser.isProfileComplete,
      firstName: providerUser.firstName,
      lastName: providerUser.lastName
    });
    
    // Simulate provider completing their profile
    providerUser.firstName = 'John';
    providerUser.lastName = 'Doe';
    providerUser.isProfileComplete = true;
    
    await providerUser.save();
    console.log('Updated provider profile:', {
      id: providerUser._id,
      email: providerUser.email,
      firstName: providerUser.firstName,
      lastName: providerUser.lastName,
      isProfileComplete: providerUser.isProfileComplete
    });
    
    // Create a new client user with minimal data
    const clientUser = new User({
      email: 'testclient@example.com',
      password: 'password123',
      role: 'client'
    });
    
    await clientUser.save();
    console.log('Created client user with minimal data:', {
      id: clientUser._id,
      email: clientUser.email,
      role: clientUser.role,
      isProfileComplete: clientUser.isProfileComplete,
      firstName: clientUser.firstName,
      lastName: clientUser.lastName
    });
    
    // Create a new beautician user with minimal data
    const beauticianUser = new User({
      email: 'testbeautician@example.com',
      password: 'password123',
      role: 'beautician'
    });
    
    await beauticianUser.save();
    console.log('Created beautician user with minimal data:', {
      id: beauticianUser._id,
      email: beauticianUser.email,
      role: beauticianUser.role,
      isProfileComplete: beauticianUser.isProfileComplete,
      firstName: beauticianUser.firstName,
      lastName: beauticianUser.lastName
    });
    
    console.log('Profile completion system test completed successfully!');
    
    // Close connection
    mongoose.connection.close();
  } catch (error) {
    console.error('Error testing profile system:', error);
    mongoose.connection.close();
  }
}

// Run the test
testProfileSystem();