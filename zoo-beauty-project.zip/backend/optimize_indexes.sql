-- Additional indexes for provider dashboard optimization

-- Indexes for Booking table to optimize dashboard queries
CREATE INDEX IF NOT EXISTS idx_bookings_provider_status_completed ON bookings(providerId, status) WHERE status = 'completed';
CREATE INDEX IF NOT EXISTS idx_bookings_provider_created_at ON bookings(providerId, createdAt);
CREATE INDEX IF NOT EXISTS idx_bookings_provider_scheduled_date ON bookings(providerId, scheduledDate);
CREATE INDEX IF NOT EXISTS idx_bookings_provider_assigned_beautician ON bookings(providerId, assignedBeauticianId);

-- Indexes for Assignment table to optimize staff queries
CREATE INDEX IF NOT EXISTS idx_assignments_provider_status ON assignments(providerId, status);
CREATE INDEX IF NOT EXISTS idx_assignments_assigned_to ON assignments(assignedToId);
CREATE INDEX IF NOT EXISTS idx_assignments_provider_assigned_to ON assignments(providerId, assignedToId);

-- Composite indexes for performance chart queries
CREATE INDEX IF NOT EXISTS idx_bookings_provider_status_date ON bookings(providerId, status, createdAt);
CREATE INDEX IF NOT EXISTS idx_bookings_payment_provider_earnings ON bookings((CAST(payment->>'providerEarnings' AS DECIMAL)));

-- Indexes for Provider table
CREATE INDEX IF NOT EXISTS idx_providers_rating ON providers(rating);
CREATE INDEX IF NOT EXISTS idx_providers_is_online ON providers(isOnline);
CREATE INDEX IF NOT EXISTS idx_providers_is_visible ON providers(isVisible);