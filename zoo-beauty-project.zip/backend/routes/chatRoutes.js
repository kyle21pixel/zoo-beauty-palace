const express = require('express');
const router = express.Router();
const {
    getConversations,
    getMessages,
    sendMessage,
    markAsRead,
    deleteConversation
} = require('../controllers/chatController');
const { protect } = require('../middleware/auth.mongo');
const { messageLimiter } = require('../middleware/rateLimiter');
const { sendMessageValidation, validate } = require('../middleware/validator');

// All routes are protected
router.get('/conversations', protect, getConversations);
router.get('/messages/:userId', protect, getMessages);
router.post('/send', protect, messageLimiter, sendMessageValidation, validate, sendMessage);
router.put('/mark-read/:conversationId', protect, markAsRead);
router.delete('/conversation/:conversationId', protect, deleteConversation);

module.exports = router;
