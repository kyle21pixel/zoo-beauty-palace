const express = require('express');
const router = express.Router();
const {
    createBooking,
    getBooking,
    getMyBookings,
    acceptBooking,
    rejectBooking,
    cancelBooking,
    updateStatus,
    assignBeautician
} = require('../controllers/bookingController');
const { protect, authorize } = require('../middleware/auth.mongo');
const { bookingLimiter } = require('../middleware/rateLimiter');
const {
    createBookingValidation,
    validateObjectId,
    validate,
    paginationValidation
} = require('../middleware/validator');

// Protected routes
router.post('/', protect, authorize('client'), bookingLimiter, createBookingValidation, validate, createBooking);
router.get('/my', protect, paginationValidation, validate, getMyBookings);
router.get('/:id', protect, validateObjectId('id'), validate, getBooking);

// Provider actions
router.put('/:id/accept', protect, authorize('provider'), acceptBooking);
router.put('/:id/reject', protect, authorize('provider'), rejectBooking);
router.put('/:id/assign-beautician', protect, authorize('provider'), assignBeautician);
router.put('/:id/status', protect, authorize('provider'), updateStatus);

// Client/Provider actions
router.put('/:id/cancel', protect, cancelBooking);

module.exports = router;
