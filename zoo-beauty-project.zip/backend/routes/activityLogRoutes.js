const express = require('express');
const router = express.Router();
const { protect, admin } = require('../middleware/auth');
const {
    getActivityLogs,
    createActivityLog,
    getActivityLogById,
    deleteActivityLog
} = require('../controllers/activityLogController');

router.route('/')
    .get(protect, admin, getActivityLogs)
    .post(protect, admin, createActivityLog);

router.route('/:id')
    .get(protect, admin, getActivityLogById)
    .delete(protect, admin, deleteActivityLog);

module.exports = router;