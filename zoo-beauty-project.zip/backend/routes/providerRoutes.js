const express = require('express');
const router = express.Router();
const {
    getProvider,
    getMyProfile,
    updateProfile,
    addPortfolioItem,
    removePortfolioItem,
    updateServices,
    updateAvailability,
    searchProviders,
    getStats,
    toggleOnlineStatus,
    assignTask,
    getProviderAssignments,
    updateAssignmentStatus
} = require('../controllers/providerController');
const { protect, authorize } = require('../middleware/auth.mongo');
const { updateProviderValidation, validate } = require('../middleware/validator');

// Public routes
router.get('/search', searchProviders);
router.get('/:id', getProvider);

// Protected routes (Provider only)
router.get('/me/profile', protect, authorize('provider'), getMyProfile);
router.post('/setup-profile', protect, authorize('provider'), updateProviderValidation, validate, updateProfile);
router.put('/profile', protect, authorize('provider'), updateProviderValidation, validate, updateProfile);
router.post('/portfolio', protect, authorize('provider'), addPortfolioItem);
router.delete('/portfolio/:itemId', protect, authorize('provider'), removePortfolioItem);
router.put('/services', protect, authorize('provider'), updateServices);
router.put('/availability', protect, authorize('provider'), updateAvailability);
router.get('/me/stats', protect, authorize('provider'), getStats);
router.put('/online-status', protect, authorize('provider'), toggleOnlineStatus);

// Assignment routes
router.post('/assignments', protect, authorize('provider'), assignTask);
router.get('/assignments', protect, authorize('provider'), getProviderAssignments);
router.put('/assignments/:id/status', protect, authorize('provider'), updateAssignmentStatus);

module.exports = router;
