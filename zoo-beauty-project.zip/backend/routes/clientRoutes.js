const express = require('express');
const router = express.Router();
const {
    getMyProfile,
    setupProfile,
    updateProfile
} = require('../controllers/clientController');
const { protect, authorize } = require('../middleware/auth.mongo');

// Protected routes (Client only)
router.get('/me/profile', protect, authorize('client'), getMyProfile);
router.post('/setup-profile', protect, authorize('client'), setupProfile);
router.put('/profile', protect, authorize('client'), updateProfile);

module.exports = router;