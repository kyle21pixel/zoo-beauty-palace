const express = require('express');
const router = express.Router();
const {
    getUsers,
    getUserById,
    createUser,
    updateUser,
    deleteUser,
    getProviders,
    getDashboardStats,
    getBookings,
    getDisputes,
    resolveDispute,
    getAnalytics,
    resetUserPassword
} = require('../controllers/adminController.mongo');
const { protect, authorize } = require('../middleware/auth.mongo');
const { paginationValidation, validate } = require('../middleware/validator');

// All routes are admin only
router.use(protect, authorize('admin'));

// Dashboard route
router.get('/dashboard', getDashboardStats);

// User management routes
router.get('/users', paginationValidation, validate, getUsers);
router.post('/users', validate, createUser);
router.get('/users/:id', getUserById);
router.put('/users/:id', updateUser);
router.delete('/users/:id', deleteUser);

// Provider management routes
router.get('/providers', paginationValidation, validate, getProviders);

// Booking management routes
router.get('/bookings', paginationValidation, validate, getBookings);

// Dispute management routes
router.get('/disputes', paginationValidation, validate, getDisputes);
router.put('/disputes/:id/resolve', resolveDispute);

// Analytics routes
router.get('/analytics', paginationValidation, validate, getAnalytics);

// Password reset route
router.post('/users/:id/reset-password', resetUserPassword);

module.exports = router;