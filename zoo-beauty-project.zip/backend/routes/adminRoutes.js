const express = require('express');
const router = express.Router();
const {
    getUsers,
    getUserById,
    createUser,
    updateUser,
    deleteUser,
    getProviders,
    getProviderById,
    createProvider,
    updateProvider,
    deleteProvider,
    approveProvider,
    rejectProvider,
    getServices,
    getServiceById,
    createService,
    updateService,
    deleteService,
    getBookings,
    getBookingById,
    updateBookingStatus,
    cancelBooking,
    getReviews,
    getReviewById,
    updateReview,
    deleteReview,
    getAnalytics,
    getDateRange,
    exportAnalyticsReport,
    assignTask,
    getAssignments,
    updateAssignmentStatus,
    bulkUpdateAssignmentStatus,
    bulkDeleteAssignments,
    bulkDeleteUsers,
    resetUserPassword,
    getDisputes,
    resolveDispute
} = require('../controllers/adminController');
const {
    getActivityLogs,
    getActivityLogById,
    deleteActivityLog
} = require('../controllers/activityLogController');
const { protect, authorize } = require('../middleware/auth');
const { paginationValidation, validate } = require('../middleware/validator');

// All routes are admin only
router.use(protect, authorize('admin'));

router.get('/users', paginationValidation, validate, getUsers);
router.post('/users', validate, createUser);
router.get('/users/:id', getUserById);
router.put('/users/:id', updateUser);
router.post('/users/:id/reset-password', resetUserPassword);
router.delete('/users/:id', deleteUser);
router.delete('/users/bulk', bulkDeleteUsers);
router.get('/providers', paginationValidation, validate, getProviders);
router.get('/providers/:id', getProviderById);
router.post('/providers', createProvider);
router.put('/providers/:id', updateProvider);
router.delete('/providers/:id', deleteProvider);
router.put('/providers/:id/approve', approveProvider);
router.put('/providers/:id/reject', rejectProvider);
router.get('/services', paginationValidation, validate, getServices);
router.get('/services/:id', getServiceById);
router.post('/services', createService);
router.put('/services/:id', updateService);
router.delete('/services/:id', deleteService);
router.get('/bookings', paginationValidation, validate, getBookings);
router.get('/bookings/:id', getBookingById);
router.put('/bookings/:id/status', updateBookingStatus);
router.put('/bookings/:id/cancel', cancelBooking);
router.get('/reviews', paginationValidation, validate, getReviews);
router.get('/reviews/:id', getReviewById);
router.put('/reviews/:id', updateReview);
router.delete('/reviews/:id', deleteReview);
router.get('/analytics', getAnalytics);
router.get('/analytics/date-range', getDateRange);
router.get('/analytics/export', exportAnalyticsReport);

// Dispute routes
router.get('/disputes', paginationValidation, validate, getDisputes);
router.put('/disputes/:id/resolve', resolveDispute);

// Assignment routes
router.post('/assignments', assignTask);
router.get('/assignments', getAssignments);
router.put('/assignments/:id/status', updateAssignmentStatus);
router.put('/assignments/bulk-status', bulkUpdateAssignmentStatus);
router.delete('/assignments/bulk', bulkDeleteAssignments);

// Activity Log routes
router.get('/activity-logs', getActivityLogs);
router.get('/activity-logs/:id', getActivityLogById);
router.delete('/activity-logs/:id', deleteActivityLog);

module.exports = router;
