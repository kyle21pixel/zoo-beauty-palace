const express = require('express');
const router = express.Router();
const {
    createReview,
    getProviderReviews,
    respondToReview,
    markHelpful,
    moderateReview,
    getMyReviews
} = require('../controllers/reviewController');
const { protect, authorize } = require('../middleware/auth.mongo');
const {
    createReviewValidation,
    validateObjectId,
    validate,
    paginationValidation
} = require('../middleware/validator');

// Public routes
router.get('/provider/:providerId', paginationValidation, validate, getProviderReviews);

// Protected routes
router.post('/', protect, authorize('client'), createReviewValidation, validate, createReview);
router.get('/my', protect, authorize('client'), getMyReviews);
router.put('/:id/respond', protect, authorize('provider'), respondToReview);
router.put('/:id/helpful', protect, markHelpful);

// Admin routes
router.put('/:id/moderate', protect, authorize('admin'), moderateReview);

module.exports = router;
