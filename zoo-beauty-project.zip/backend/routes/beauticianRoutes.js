const express = require('express');
const router = express.Router();
const {
    getMyProfile,
    setupProfile,
    updateProfile,
    getAssignments,
    acceptAssignment,
    completeAssignment
} = require('../controllers/beauticianController');
const { protect, authorize } = require('../middleware/auth.mongo');

// Protected routes (Beautician only)
router.get('/me/profile', protect, authorize('beautician'), getMyProfile);
router.post('/setup-profile', protect, authorize('beautician'), setupProfile);
router.put('/profile', protect, authorize('beautician'), updateProfile);

// Assignment routes
router.get('/assignments', protect, authorize('beautician'), getAssignments);
router.put('/assignments/:id/accept', protect, authorize('beautician'), acceptAssignment);
router.put('/assignments/:id/complete', protect, authorize('beautician'), completeAssignment);

module.exports = router;