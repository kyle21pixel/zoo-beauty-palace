const express = require('express');
const router = express.Router();
const {
    // Dashboard & Analytics
    getDashboardOverview,
    getPerformanceChart,
    getAdvancedAnalytics,

    // Staff Management
    getStaff,
    addStaff,
    getStaffMember,
    updateStaff,
    removeStaff,

    // Booking Dispatch
    getAvailableStaff,
    assignBooking,
    reassignBooking,

    // Financial
    getRevenue,
    requestPayout
} = require('../controllers/providerDashboardController.mongo');

const { protect, authorize } = require('../middleware/auth.mongo');

// ==========================================
// DASHBOARD & ANALYTICS ROUTES
// ==========================================
router.get('/dashboard/overview', protect, authorize('provider'), getDashboardOverview);
router.get('/dashboard/chart', protect, authorize('provider'), getPerformanceChart);
router.get('/analytics/advanced', protect, authorize('provider'), getAdvancedAnalytics);

// ==========================================
// STAFF MANAGEMENT ROUTES
// ==========================================
router.get('/staff', protect, authorize('provider'), getStaff);
router.post('/staff', protect, authorize('provider'), addStaff);
router.get('/staff/:id', protect, authorize('provider'), getStaffMember);
router.put('/staff/:id', protect, authorize('provider'), updateStaff);
router.delete('/staff/:id', protect, authorize('provider'), removeStaff);

// ==========================================
// BOOKING DISPATCH ROUTES
// ==========================================
router.get('/bookings/available-staff', protect, authorize('provider'), getAvailableStaff);
router.post('/bookings/:id/assign', protect, authorize('provider'), assignBooking);
router.put('/bookings/:id/reassign', protect, authorize('provider'), reassignBooking);

// ==========================================
// FINANCIAL ROUTES
// ==========================================
router.get('/revenue', protect, authorize('provider'), getRevenue);
router.post('/payout/request', protect, authorize('provider'), requestPayout);

module.exports = router;
