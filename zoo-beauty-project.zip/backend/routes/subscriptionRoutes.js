const express = require('express');
const router = express.Router();
const {
    getPlans,
    subscribe,
    getCurrentSubscription,
    cancelSubscription,
    renewSubscription,
    toggleAutoRenew
} = require('../controllers/subscriptionController');
const { protect, authorize } = require('../middleware/auth.mongo');

// Public routes
router.get('/plans', getPlans);

// Protected routes (Provider only)
router.post('/subscribe', protect, authorize('provider'), subscribe);
router.get('/current', protect, authorize('provider'), getCurrentSubscription);
router.put('/cancel', protect, authorize('provider'), cancelSubscription);
router.post('/renew', protect, authorize('provider'), renewSubscription);
router.put('/auto-renew', protect, authorize('provider'), toggleAutoRenew);

module.exports = router;
