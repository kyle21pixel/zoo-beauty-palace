const { getIO } = require('../server');
const Notification = require('../models/Notification');

/**
 * Send a real-time notification to a user
 * @param {number} userId - The ID of the user to notify
 * @param {string} type - The type of notification (e.g., 'assignment', 'booking', 'message')
 * @param {string} title - The title of the notification
 * @param {string} message - The message content
 * @param {object} data - Additional data to include with the notification
 * @param {string} actionUrl - URL to navigate to when notification is clicked
 */
exports.sendNotification = async (userId, type, title, message, data = {}, actionUrl = null) => {
    try {
        // Create the notification in the database
        const notification = await Notification.createNotification(
            userId,
            type,
            title,
            message,
            data,
            actionUrl
        );
        
        // Emit the notification via WebSocket
        const io = getIO();
        io.to(userId.toString()).emit('new_notification', {
            id: notification.id,
            userId: notification.userId,
            type: notification.type,
            title: notification.title,
            message: notification.message,
            data: notification.data,
            actionUrl: notification.actionUrl,
            isRead: notification.isRead,
            createdAt: notification.createdAt,
            updatedAt: notification.updatedAt
        });
        
        return notification;
    } catch (error) {
        console.error('Error sending notification:', error);
        throw error;
    }
};

/**
 * Send assignment notification
 * @param {number} userId - The ID of the user to notify
 * @param {object} assignment - The assignment object
 */
exports.sendAssignmentNotification = async (userId, assignment) => {
    return await this.sendNotification(
        userId,
        'assignment',
        'New Assignment Assigned',
        `You have been assigned a new task: ${assignment.title}`,
        { assignmentId: assignment.id, taskId: assignment.taskId },
        `/dashboard/assignments/${assignment.id}`
    );
};

/**
 * Send booking notification
 * @param {number} userId - The ID of the user to notify
 * @param {object} booking - The booking object
 * @param {string} status - The booking status
 */
exports.sendBookingNotification = async (userId, booking, status) => {
    const statusMessages = {
        confirmed: 'Booking Confirmed',
        cancelled: 'Booking Cancelled',
        completed: 'Booking Completed'
    };
    
    const statusDescriptions = {
        confirmed: `Your booking for ${booking.serviceName} has been confirmed.`,
        cancelled: `Your booking for ${booking.serviceName} has been cancelled.`,
        completed: `Your booking for ${booking.serviceName} has been completed.`
    };
    
    return await this.sendNotification(
        userId,
        'booking',
        statusMessages[status] || 'Booking Update',
        statusDescriptions[status] || `Your booking status has been updated to ${status}.`,
        { bookingId: booking.id },
        `/dashboard/bookings/${booking.id}`
    );
};