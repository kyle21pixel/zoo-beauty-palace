const { sequelize } = require('./config/database');
const User = require('./models/User');
require('dotenv').config();

const createAdminUser = async () => {
    try {
        await sequelize.authenticate();
        console.log('Database connected...');

        // Check if admin exists
        const adminExists = await User.findOne({ where: { email: 'admin@zoobeauty.com' } });

        if (adminExists) {
            console.log('Admin user already exists!');
            console.log('Email: admin@zoobeauty.com');
            console.log('Password: admin123');
            process.exit(0);
        }

        // Create admin user
        const admin = await User.create({
            firstName: 'Admin',
            lastName: 'User',
            email: 'admin@zoobeauty.com',
            password: 'admin123', // Will be hashed by the model hook
            phone: '+254700000000',
            role: 'admin',
            isActive: true,
            isVerified: true
        });

        console.log('✅ Admin user created successfully!');
        console.log('Email: admin@zoobeauty.com');
        console.log('Password: admin123');
        console.log('\nYou can now log in at: http://localhost:5173/admin/login');

        process.exit(0);
    } catch (error) {
        console.error('Error creating admin user:', error);
        process.exit(1);
    }
};

createAdminUser();
