const { sequelize } = require('./config/database');
const User = require('./models/User');
const bcrypt = require('bcryptjs');

async function checkUsers() {
    try {
        await sequelize.authenticate();
        console.log('Database connected.');

        const emailsToCheck = ['provider@test.com', 'admin@test.com', 'beautician@test.com', 'client@test.com'];
        const passwordToCheck = 'password123';

        console.log('--- Checking Credentials ---');
        for (const email of emailsToCheck) {
            const user = await User.findOne({ where: { email } });
            if (!user) {
                console.log(`[FAIL] User ${email} NOT FOUND.`);
            } else {
                const isMatch = await bcrypt.compare(passwordToCheck, user.password);
                console.log(`[${isMatch ? 'PASS' : 'FAIL'}] User ${email} (${user.role}): Password match = ${isMatch}`);
            }
        }
        console.log('----------------------------');

    } catch (error) {
        console.error('Error checking users:', error);
    } finally {
        await sequelize.close();
    }
}

checkUsers();
