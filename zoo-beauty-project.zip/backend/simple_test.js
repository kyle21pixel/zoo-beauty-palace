const mongoose = require('mongoose');

// Simple test schema
const testSchema = new mongoose.Schema({
    name: String,
    email: String
});

const TestModel = mongoose.model('Test', testSchema);

async function simpleTest() {
    try {
        // Connect to MongoDB
        console.log('Connecting to MongoDB...');
        await mongoose.connect('mongodb+srv://kylecode21_db_user:21NovembeR2005.@cluster0.zpftrhh.mongodb.net/zoobeauty?retryWrites=true&w=majority');
        console.log('Connected to MongoDB');
        
        // Create a test document
        console.log('Creating test document...');
        const testDoc = new TestModel({
            name: 'Test User',
            email: 'test@example.com'
        });
        
        await testDoc.save();
        console.log('Document saved successfully');
        
        // Find the document
        console.log('Finding document...');
        const foundDoc = await TestModel.findOne({ email: 'test@example.com' });
        console.log('Document found:', foundDoc.name, foundDoc.email);
        
        console.log('✅ Simple test passed!');
        process.exit(0);
    } catch (error) {
        console.error('❌ Simple test failed:', error.message);
        console.error('Full error:', error);
        process.exit(1);
    }
}

simpleTest();