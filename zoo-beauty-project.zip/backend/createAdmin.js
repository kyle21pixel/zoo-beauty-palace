const { Sequelize, DataTypes } = require('sequelize');
require('dotenv').config();

// Use SQLite for development (no separate database server needed)
const sequelize = new Sequelize({
    dialect: 'sqlite',
    storage: 'database.sqlite',
    logging: false
});

const User = sequelize.define('User', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    email: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true,
        validate: {
            isEmail: true
        }
    },
    password: {
        type: DataTypes.STRING,
        allowNull: false
    },
    role: {
        type: DataTypes.ENUM('admin', 'provider', 'client', 'beautician'),
        defaultValue: 'client',
        allowNull: false
    },
    firstName: {
        type: DataTypes.STRING,
        allowNull: false
    },
    lastName: {
        type: DataTypes.STRING,
        allowNull: false
    },
    phone: {
        type: DataTypes.STRING,
        allowNull: true
    },
    avatar: {
        type: DataTypes.STRING,
        defaultValue: 'https://res.cloudinary.com/demo/image/upload/avatar-default.png'
    },
    isActive: {
        type: DataTypes.BOOLEAN,
        defaultValue: true
    },
    isVerified: {
        type: DataTypes.BOOLEAN,
        defaultValue: false
    },
    verificationToken: {
        type: DataTypes.STRING
    },
    resetPasswordToken: {
        type: DataTypes.STRING
    },
    resetPasswordExpires: {
        type: DataTypes.DATE
    },
    preferences: {
        type: DataTypes.JSON,
        defaultValue: {
            language: 'en',
            theme: 'light',
            notifications: {
                email: true,
                push: true,
                sms: false
            }
        }
    },
    lastLogin: {
        type: DataTypes.DATE
    }
}, {
    timestamps: true
});

const bcrypt = require('bcryptjs');

// Add hook to hash password before saving
User.addHook('beforeSave', async (user) => {
    if (user.changed('password')) {
        const salt = await bcrypt.genSalt(10);
        user.password = await bcrypt.hash(user.password, salt);
    }
});

const createAdminUser = async () => {
    try {
        await sequelize.authenticate();
        console.log('✅ Database connected...');
        
        // Sync models with database
        await sequelize.sync({ alter: true });
        console.log('✅ Database models synced');

        // Check if admin exists
        const adminExists = await User.findOne({ where: { email: 'admin@zoobeauty.com' } });

        if (adminExists) {
            console.log('✅ Admin user already exists!');
            console.log('Email: admin@zoobeauty.com');
            console.log('Password: admin123');
            process.exit(0);
        }

        // Create admin user
        const admin = await User.create({
            firstName: 'Admin',
            lastName: 'User',
            email: 'admin@zoobeauty.com',
            password: 'admin123', // Will be hashed by the model hook
            phone: '+254700000000',
            role: 'admin',
            isActive: true,
            isVerified: true
        });

        console.log('✅ Admin user created successfully!');
        console.log('Email: admin@zoobeauty.com');
        console.log('Password: admin123');
        console.log('\nYou can now log in at: http://localhost:5173/admin/login');

        process.exit(0);
    } catch (error) {
        console.error('❌ Error creating admin user:', error.message);
        if (error.errors) {
            error.errors.forEach(err => {
                console.error('Field:', err.path, 'Error:', err.message);
            });
        }
        process.exit(1);
    }
};

createAdminUser();