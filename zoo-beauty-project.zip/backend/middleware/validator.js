const { body, param, query, validationResult } = require('express-validator');

// Validation result checker
exports.validate = (req, res, next) => {
    const errors = validationResult(req);

    if (!errors.isEmpty()) {
        return res.status(400).json({
            success: false,
            message: 'Validation failed',
            errors: errors.array().map(err => ({
                field: err.path,
                message: err.msg
            }))
        });
    }

    next();
};

// User registration validation
exports.registerValidation = [
    body('email')
        .isEmail()
        .withMessage('Please provide a valid email')
        .normalizeEmail(),
    body('password')
        .isLength({ min: 6 })
        .withMessage('Password must be at least 6 characters long'),
    body('role')
        .isIn(['client', 'provider', 'beautician'])
        .withMessage('Role must be either client, provider, or beautician')
];

// Login validation
exports.loginValidation = [
    body('email')
        .isEmail()
        .withMessage('Please provide a valid email')
        .normalizeEmail(),
    body('password')
        .notEmpty()
        .withMessage('Password is required')
];

// Booking creation validation
exports.createBookingValidation = [
    body('providerId')
        .isMongoId()
        .withMessage('Invalid provider ID'),
    body('service.name')
        .trim()
        .notEmpty()
        .withMessage('Service name is required'),
    body('service.price')
        .isFloat({ min: 0 })
        .withMessage('Service price must be a positive number'),
    body('service.duration')
        .isInt({ min: 1 })
        .withMessage('Service duration must be at least 1 minute'),
    body('scheduledDate')
        .isISO8601()
        .withMessage('Invalid date format'),
    body('scheduledTime')
        .matches(/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/)
        .withMessage('Invalid time format (use HH:MM)'),
    body('location.type')
        .isIn(['on-site', 'remote'])
        .withMessage('Location type must be on-site or remote')
];

// Review creation validation
exports.createReviewValidation = [
    body('bookingId')
        .isMongoId()
        .withMessage('Invalid booking ID'),
    body('rating')
        .isInt({ min: 1, max: 5 })
        .withMessage('Rating must be between 1 and 5'),
    body('comment')
        .optional()
        .trim()
        .isLength({ max: 1000 })
        .withMessage('Comment cannot exceed 1000 characters')
];

// Provider profile update validation
exports.updateProviderValidation = [
    body('businessName')
        .optional()
        .trim()
        .notEmpty()
        .withMessage('Business name cannot be empty'),
    body('bio')
        .optional()
        .trim()
        .isLength({ max: 500 })
        .withMessage('Bio cannot exceed 500 characters'),
    body('serviceType')
        .optional()
        .isIn(['on-site', 'remote', 'both'])
        .withMessage('Service type must be on-site, remote, or both')
];

// Message validation
exports.sendMessageValidation = [
    body('receiverId')
        .isMongoId()
        .withMessage('Invalid receiver ID'),
    body('message')
        .trim()
        .notEmpty()
        .withMessage('Message cannot be empty')
        .isLength({ max: 2000 })
        .withMessage('Message cannot exceed 2000 characters')
];

// ObjectId param validation
exports.validateObjectId = (paramName = 'id') => [
    param(paramName)
        .isMongoId()
        .withMessage(`Invalid ${paramName}`)
];

// Pagination validation
exports.paginationValidation = [
    query('page')
        .optional()
        .isInt({ min: 1 })
        .withMessage('Page must be a positive integer'),
    query('limit')
        .optional()
        .isInt({ min: 1, max: 100 })
        .withMessage('Limit must be between 1 and 100')
];
