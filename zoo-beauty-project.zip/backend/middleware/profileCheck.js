const User = require('../models/User.mongo');

// Middleware to check if user profile is complete
const checkProfileCompletion = async (req, res, next) => {
  try {
    // Get the user from the request (assuming it's added by auth middleware)
    const user = req.user;
    
    if (!user) {
      return res.status(401).json({
        success: false,
        message: 'Not authorized, no user found'
      });
    }
    
    // Check if profile is complete
    if (!user.isProfileComplete) {
      return res.status(403).json({
        success: false,
        message: 'Profile not complete',
        redirectTo: `/setup-profile/${user.role}`,
        data: {
          profileComplete: false,
          role: user.role
        }
      });
    }
    
    // Profile is complete, continue to next middleware
    next();
  } catch (error) {
    console.error('Profile completion check error:', error);
    return res.status(500).json({
      success: false,
      message: 'Server error during profile check'
    });
  }
};

module.exports = { checkProfileCompletion };