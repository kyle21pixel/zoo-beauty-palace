-- ==========================================
-- ZOO BEAUTY PRODUCTION DATABASE SETUP
-- ==========================================

-- 1. Create Dedicated User
CREATE USER IF NOT EXISTS 'zooadmin'@'localhost' IDENTIFIED BY 'secure_pass_123';
GRANT ALL PRIVILEGES ON *.* TO 'zooadmin'@'localhost' WITH GRANT OPTION;
FLUSH PRIVILEGES;

-- 2. Create Database
CREATE DATABASE IF NOT EXISTS zoobeauty CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE zoobeauty;

-- 3. Create Tables
-- Users Table
CREATE TABLE IF NOT EXISTS `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `firstName` VARCHAR(100) NOT NULL,
  `lastName` VARCHAR(100) NOT NULL,
  `email` VARCHAR(255) UNIQUE NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `phone` VARCHAR(20),
  `avatar` VARCHAR(500),
  `role` ENUM('client', 'provider', 'admin') DEFAULT 'client',
  `isActive` BOOLEAN DEFAULT TRUE,
  `isVerified` BOOLEAN DEFAULT FALSE,
  `verificationToken` VARCHAR(255),
  `resetPasswordToken` VARCHAR(255),
  `resetPasswordExpire` DATETIME,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Providers Table
CREATE TABLE IF NOT EXISTS `providers` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `userId` INT NOT NULL,
  `businessName` VARCHAR(255),
  `bio` TEXT,
  `specializations` JSON,
  `location` JSON,
  `serviceType` ENUM('mobile', 'studio', 'both') DEFAULT 'both',
  `studioAddress` VARCHAR(500),
  `services` JSON,
  `portfolio` JSON,
  `availability` JSON,
  `rating` JSON,
  `stats` JSON,
  `subscription` JSON,
  `socialMedia` JSON,
  `bankDetails` JSON,
  `isVisible` BOOLEAN DEFAULT TRUE,
  `isOnline` BOOLEAN DEFAULT FALSE,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Bookings Table
CREATE TABLE IF NOT EXISTS `bookings` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `clientId` INT NOT NULL,
  `providerId` INT NOT NULL,
  `serviceId` VARCHAR(100),
  `serviceName` VARCHAR(255) NOT NULL,
  `date` DATE NOT NULL,
  `time` TIME NOT NULL,
  `duration` INT,
  `amount` DECIMAL(10, 2) NOT NULL,
  `status` ENUM('pending', 'confirmed', 'in-progress', 'completed', 'cancelled') DEFAULT 'pending',
  `location` JSON,
  `notes` TEXT,
  `cancellationReason` TEXT,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`clientId`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`providerId`) REFERENCES `providers`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Reviews Table
CREATE TABLE IF NOT EXISTS `reviews` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `bookingId` INT NOT NULL,
  `clientId` INT NOT NULL,
  `providerId` INT NOT NULL,
  `rating` INT NOT NULL CHECK (`rating` >= 1 AND `rating` <= 5),
  `comment` TEXT,
  `response` TEXT,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`bookingId`) REFERENCES `bookings`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`clientId`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`providerId`) REFERENCES `providers`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Payments Table
CREATE TABLE IF NOT EXISTS `payments` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `bookingId` INT,
  `userId` INT NOT NULL,
  `amount` DECIMAL(10, 2) NOT NULL,
  `currency` VARCHAR(3) DEFAULT 'USD',
  `type` ENUM('booking', 'subscription', 'refund') DEFAULT 'booking',
  `method` VARCHAR(50),
  `status` ENUM('pending', 'completed', 'failed', 'refunded') DEFAULT 'pending',
  `transactionId` VARCHAR(255),
  `platformFee` DECIMAL(10, 2),
  `providerAmount` DECIMAL(10, 2),
  `metadata` JSON,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`bookingId`) REFERENCES `bookings`(`id`) ON DELETE SET NULL,
  FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Messages Table
CREATE TABLE IF NOT EXISTS `messages` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `senderId` INT NOT NULL,
  `receiverId` INT NOT NULL,
  `content` TEXT NOT NULL,
  `isRead` BOOLEAN DEFAULT FALSE,
  `readAt` DATETIME,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`senderId`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`receiverId`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Notifications Table
CREATE TABLE IF NOT EXISTS `notifications` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `userId` INT NOT NULL,
  `type` VARCHAR(50) NOT NULL,
  `title` VARCHAR(255) NOT NULL,
  `message` TEXT NOT NULL,
  `data` JSON,
  `isRead` BOOLEAN DEFAULT FALSE,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Disputes Table
CREATE TABLE IF NOT EXISTS `disputes` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `bookingId` INT NOT NULL,
  `reportedBy` INT NOT NULL,
  `reportedAgainst` INT NOT NULL,
  `reason` TEXT NOT NULL,
  `status` ENUM('pending', 'investigating', 'resolved', 'closed') DEFAULT 'pending',
  `resolution` TEXT,
  `assignedTo` INT,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`bookingId`) REFERENCES `bookings`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`reportedBy`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`reportedAgainst`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Favorites Table
CREATE TABLE IF NOT EXISTS `favorites` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `clientId` INT NOT NULL,
  `providerId` INT NOT NULL,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`clientId`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`providerId`) REFERENCES `providers`(`id`) ON DELETE CASCADE,
  UNIQUE KEY `unique_favorite` (`clientId`, `providerId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Subscription Plans Table
CREATE TABLE IF NOT EXISTS `subscription_plans` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL,
  `description` TEXT,
  `price` DECIMAL(10, 2) NOT NULL,
  `duration` INT NOT NULL,
  `features` JSON,
  `isActive` BOOLEAN DEFAULT TRUE,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Analytics Table
CREATE TABLE IF NOT EXISTS `analytics` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `date` DATE NOT NULL,
  `totalBookings` INT DEFAULT 0,
  `completedBookings` INT DEFAULT 0,
  `totalRevenue` DECIMAL(10, 2) DEFAULT 0,
  `newUsers` INT DEFAULT 0,
  `newProviders` INT DEFAULT 0,
  `activeUsers` INT DEFAULT 0,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `unique_date` (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. Seed Data
-- Insert Admin User
INSERT INTO `users` (`firstName`, `lastName`, `email`, `password`, `role`, `isActive`, `isVerified`) 
VALUES ('Admin', 'User', 'admin@zoobeauty.com', '$2a$10$rN8qZ5YxH9kQXZ5YxH9kQeO5YxH9kQXZ5YxH9kQXZ5YxH9kQXZ5Yx', 'admin', TRUE, TRUE);

-- Insert Sample Provider Users
INSERT INTO `users` (`firstName`, `lastName`, `email`, `password`, `phone`, `role`, `isActive`, `isVerified`) VALUES
('Sarah', 'Johnson', 'sarah@example.com', '$2a$10$rN8qZ5YxH9kQXZ5YxH9kQeO5YxH9kQXZ5YxH9kQXZ5YxH9kQXZ5Yx', '+1234567890', 'provider', 1, 1),
('Michael', 'Chen', 'michael@example.com', '$2a$10$rN8qZ5YxH9kQXZ5YxH9kQeO5YxH9kQXZ5YxH9kQXZ5YxH9kQXZ5Yx', '+1234567891', 'provider', 1, 1),
('Amara', 'Okonkwo', 'amara@example.com', '$2a$10$rN8qZ5YxH9kQXZ5YxH9kQeO5YxH9kQXZ5YxH9kQXZ5YxH9kQXZ5Yx', '+1234567892', 'provider', 1, 1),
('David', 'Martinez', 'david@example.com', '$2a$10$rN8qZ5YxH9kQXZ5YxH9kQeO5YxH9kQXZ5YxH9kQXZ5YxH9kQXZ5Yx', '+1234567893', 'provider', 1, 1);

-- Insert Provider Profiles
INSERT INTO `providers` (`userId`, `businessName`, `bio`, `specializations`, `location`, `serviceType`, `services`, `portfolio`, `rating`, `stats`, `isVisible`) VALUES
(
    (SELECT id FROM users WHERE email = 'sarah@example.com'),
    'Glam by Sarah',
    'Professional makeup artist with over 10 years of experience specializing in bridal and editorial looks.',
    '["Makeup", "Wig Installation"]',
    '{"type": "Point", "coordinates": [-74.006, 40.7128], "address": "Downtown, City Center"}',
    'both',
    '[{"name": "Bridal Makeup", "description": "Full bridal glam including lashes and touch-up kit.", "duration": 90, "price": 150, "category": "Makeup"}, {"name": "Soft Glam Makeup", "description": "Natural, glowing look perfect for events.", "duration": 60, "price": 80, "category": "Makeup"}, {"name": "Wig Installation", "description": "Secure installation with customization and styling.", "duration": 120, "price": 120, "category": "Hair"}]',
    '[{"type": "image", "url": "https://images.unsplash.com/photo-1487412912498-0447578fcca8?w=400", "caption": "Bridal Look"}]',
    '{"average": 4.9, "count": 127}',
    '{"totalBookings": 245, "completedBookings": 238, "totalEarnings": 28500}',
    1
),
(
    (SELECT id FROM users WHERE email = 'michael@example.com'),
    'Chen\'s Barbershop',
    'Master barber specializing in modern cuts and traditional grooming. 15 years of experience.',
    '["Barbering", "Hair Styling"]',
    '{"type": "Point", "coordinates": [-118.2437, 34.0522], "address": "West Side, Los Angeles"}',
    'studio',
    '[{"name": "Classic Haircut", "description": "Traditional barbering with hot towel treatment.", "duration": 45, "price": 50, "category": "Barbering"}, {"name": "Beard Trim & Shape", "description": "Professional beard grooming.", "duration": 30, "price": 35, "category": "Barbering"}, {"name": "Full Grooming Package", "description": "Haircut, beard trim, and facial treatment.", "duration": 90, "price": 100, "category": "Barbering"}]',
    '[{"type": "image", "url": "https://images.unsplash.com/photo-1503951914875-452162b0f3f1?w=400", "caption": "Modern Cut"}]',
    '{"average": 4.8, "count": 89}',
    '{"totalBookings": 156, "completedBookings": 152, "totalEarnings": 12400}',
    1
),
(
    (SELECT id FROM users WHERE email = 'amara@example.com'),
    'Amara\'s Braiding Studio',
    'Expert in African braiding styles, protective hairstyles, and natural hair care.',
    '["Braiding", "Natural Hair Care"]',
    '{"type": "Point", "coordinates": [-87.6298, 41.8781], "address": "South Side, Chicago"}',
    'both',
    '[{"name": "Box Braids", "description": "Classic box braids in various sizes.", "duration": 240, "price": 180, "category": "Braiding"}, {"name": "Cornrows", "description": "Intricate cornrow designs.", "duration": 180, "price": 120, "category": "Braiding"}, {"name": "Knotless Braids", "description": "Gentle, natural-looking knotless braids.", "duration": 300, "price": 220, "category": "Braiding"}]',
    '[{"type": "image", "url": "https://images.unsplash.com/photo-1580618672591-eb180b1a973f?w=400", "caption": "Box Braids"}]',
    '{"average": 5.0, "count": 203}',
    '{"totalBookings": 312, "completedBookings": 308, "totalEarnings": 45600}',
    1
),
(
    (SELECT id FROM users WHERE email = 'david@example.com'),
    'Martinez Nail Art',
    'Creative nail artist specializing in custom designs, gel extensions, and luxury manicures.',
    '["Nail Art", "Manicure", "Pedicure"]',
    '{"type": "Point", "coordinates": [-95.3698, 29.7604], "address": "Midtown, Houston"}',
    'studio',
    '[{"name": "Gel Manicure", "description": "Long-lasting gel polish with nail care.", "duration": 60, "price": 55, "category": "Nails"}, {"name": "Custom Nail Art", "description": "Unique hand-painted designs.", "duration": 90, "price": 85, "category": "Nails"}, {"name": "Acrylic Extensions", "description": "Full set of acrylic nail extensions.", "duration": 120, "price": 95, "category": "Nails"}]',
    '[{"type": "image", "url": "https://images.unsplash.com/photo-1604654894610-df63bc536371?w=400", "caption": "Custom Nail Art"}]',
    '{"average": 4.7, "count": 145}',
    '{"totalBookings": 198, "completedBookings": 195, "totalEarnings": 15800}',
    1
);

SELECT 'PRODUCTION SETUP COMPLETED SUCCESSFULLY!' AS message;
