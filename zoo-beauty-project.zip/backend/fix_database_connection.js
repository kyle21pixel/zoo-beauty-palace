const bcrypt = require('bcryptjs');
const mysql = require('mysql2/promise');
require('dotenv').config();

// Generate proper password hash for admin
const generatePasswordHash = async () => {
    const password = 'password123';
    const hash = await bcrypt.hash(password, 10);
    console.log('Password hash for "password123":');
    console.log(hash);
    return hash;
};

// Fix database connection and create admin user
const fixDatabase = async () => {
    try {
        // Connect to MySQL (using root with no password - XAMPP default)
        const connection = await mysql.createConnection({
            host: process.env.DB_HOST || 'localhost',
            user: process.env.DB_USER || 'root',
            password: process.env.DB_PASS || '',
            multipleStatements: true
        });

        console.log('✅ Connected to MySQL');

        // Generate password hash
        const passwordHash = await generatePasswordHash();

        // Use zoobeauty database
        await connection.query('USE zoobeauty');

        // Check if admin user exists
        const [users] = await connection.query(
            "SELECT * FROM users WHERE email = 'admin@zoobeauty.com'"
        );

        if (users.length === 0) {
            // Create admin user with proper password hash
            await connection.query(
                `INSERT INTO users (firstName, lastName, email, password, role, isActive, isVerified) 
                 VALUES (?, ?, ?, ?, ?, ?, ?)`,
                ['Admin', 'User', 'admin@zoobeauty.com', passwordHash, 'admin', true, true]
            );
            console.log('✅ Admin user created successfully!');
        } else {
            // Update existing admin password
            await connection.query(
                `UPDATE users SET password = ? WHERE email = 'admin@zoobeauty.com'`,
                [passwordHash]
            );
            console.log('✅ Admin user password updated!');
        }

        await connection.end();
        console.log('\n✅ Database connection fixed!');
        console.log('\n📝 Admin Login Credentials:');
        console.log('   Email: admin@zoobeauty.com');
        console.log('   Password: password123');
        console.log('\n🚀 You can now restart your backend server!');

    } catch (error) {
        console.error('❌ Error:', error.message);
        console.log('\n💡 Make sure:');
        console.log('   1. MySQL is running in XAMPP');
        console.log('   2. Database "zoobeauty" exists');
        console.log('   3. Check your .env file for correct credentials');
    }
};

fixDatabase();


