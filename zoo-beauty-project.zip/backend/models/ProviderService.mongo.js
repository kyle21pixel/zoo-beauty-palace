const mongoose = require('mongoose');

const providerServiceSchema = new mongoose.Schema({
    provider_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Provider',
        required: true
    },
    service_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Service',
        required: true
    },
    price: {
        type: Number,
        required: true,
        min: 0
    },
    duration_minutes: {
        type: Number,
        required: true,
        min: 1
    },
    is_active: {
        type: Boolean,
        default: true
    },
    created_at: {
        type: Date,
        default: Date.now
    }
}, {
    timestamps: true
});

// Add indexes for better query performance
providerServiceSchema.index({ provider_id: 1 });
providerServiceSchema.index({ service_id: 1 });
providerServiceSchema.index({ is_active: 1 });

module.exports = mongoose.model('ProviderService', providerServiceSchema);