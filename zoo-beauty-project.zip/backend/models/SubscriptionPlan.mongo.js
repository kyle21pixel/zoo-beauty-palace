const mongoose = require('mongoose');

const subscriptionPlanSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true,
        trim: true
    },
    slug: {
        type: String,
        unique: true,
        lowercase: true
    },
    description: {
        type: String,
        trim: true
    },
    price: {
        type: Number,
        required: true,
        min: 0
    },
    currency: {
        type: String,
        default: 'USD'
    },
    duration: {
        type: Number, // in days
        required: true,
        min: 1
    },
    features: {
        type: [String],
        default: []
    },
    benefits: {
        type: {
            maxPortfolioItems: {
                type: Number,
                default: 10
            },
            maxServices: {
                type: Number,
                default: 5
            },
            priorityListing: {
                type: Boolean,
                default: false
            },
            analyticsAccess: {
                type: Boolean,
                default: false
            },
            featuredBadge: {
                type: Boolean,
                default: false
            },
            customBranding: {
                type: Boolean,
                default: false
            }
        },
        default: {
            maxPortfolioItems: 10,
            maxServices: 5,
            priorityListing: false,
            analyticsAccess: false,
            featuredBadge: false,
            customBranding: false
        }
    },
    isActive: {
        type: Boolean,
        default: true
    },
    isPopular: {
        type: Boolean,
        default: false
    },
    sortOrder: {
        type: Number,
        default: 0
    }
}, {
    timestamps: true
});

// Pre-save hook to generate slug from name
subscriptionPlanSchema.pre('save', function(next) {
    if (this.isModified('name')) {
        this.slug = this.name
            .toLowerCase()
            .replace(/[^a-z0-9]+/g, '-')
            .replace(/^-+|-+$/g, '');
    }
    next();
});

// Static method to get active plans
subscriptionPlanSchema.statics.getActivePlans = function() {
    return this.find({ isActive: true }).sort({ sortOrder: 1 });
};

module.exports = mongoose.model('SubscriptionPlan', subscriptionPlanSchema);