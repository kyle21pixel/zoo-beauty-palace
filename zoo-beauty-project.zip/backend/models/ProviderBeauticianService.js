const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/database');

const ProviderBeauticianService = sequelize.define('ProviderBeauticianService', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    providerId: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: 'providers',
            key: 'id'
        }
    },
    beauticianId: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: 'users',
            key: 'id'
        }
    },
    serviceId: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: 'services',
            key: 'id'
        }
    },
    isActive: {
        type: DataTypes.BOOLEAN,
        defaultValue: true
    }
}, {
    timestamps: true,
    tableName: 'provider_beautician_services'
});

module.exports = ProviderBeauticianService;