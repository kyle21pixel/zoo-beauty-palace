const mongoose = require('mongoose');

const disputeSchema = new mongoose.Schema({
    bookingId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Booking',
        required: true
    },
    reportedBy: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    reportedAgainst: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    reason: {
        type: String,
        required: true,
        enum: [
            'no_show',
            'poor_service',
            'payment_issue',
            'unprofessional_behavior',
            'safety_concern',
            'other'
        ]
    },
    description: {
        type: String,
        required: true
    },
    evidence: {
        type: [{
            url: String,
            name: String,
            type: String,
            uploadedAt: {
                type: Date,
                default: Date.now
            }
        }],
        default: []
    },
    status: {
        type: String,
        enum: ['open', 'investigating', 'resolved', 'closed'],
        default: 'open'
    },
    assignedTo: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User' // Admin ID
    },
    resolution: {
        type: {
            action: {
                type: String,
                enum: ['dismissed', 'warning', 'suspension', 'ban', 'refund']
            },
            note: String,
            resolvedBy: {
                type: mongoose.Schema.Types.ObjectId,
                ref: 'User'
            },
            resolvedAt: Date
        },
        default: {}
    }
}, {
    timestamps: true
});

// Instance method to resolve dispute
disputeSchema.methods.resolve = function(action, note, resolvedBy) {
    this.status = 'resolved';
    this.resolution = {
        action,
        note,
        resolvedBy,
        resolvedAt: new Date()
    };
    return this.save();
};

// Instance method to assign dispute to admin
disputeSchema.methods.assignTo = function(adminId) {
    this.assignedTo = adminId;
    this.status = 'investigating';
    return this.save();
};

module.exports = mongoose.model('Dispute', disputeSchema);