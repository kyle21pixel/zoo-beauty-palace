const mongoose = require('mongoose');

const notificationSchema = new mongoose.Schema({
    userId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true,
        index: true
    },
    type: {
        type: String,
        required: true,
        enum: ['booking', 'message', 'review', 'payment', 'system', 'promotion']
    },
    title: {
        type: String,
        required: true
    },
    message: {
        type: String,
        required: true
    },
    data: {
        type: mongoose.Schema.Types.Mixed,
        default: {}
    },
    isRead: {
        type: Boolean,
        default: false
    },
    readAt: {
        type: Date
    },
    actionUrl: {
        type: String
    }
}, {
    timestamps: true
});

// Instance method to mark as read
notificationSchema.methods.markAsRead = function() {
    this.isRead = true;
    this.readAt = new Date();
    return this.save();
};

// Static method to create a notification
notificationSchema.statics.createNotification = async function(userId, type, title, message, data = {}, actionUrl = null) {
    return this.create({
        userId,
        type,
        title,
        message,
        data,
        actionUrl
    });
};

// Static method to mark all as read for a user
notificationSchema.statics.markAllAsRead = function(userId) {
    return this.updateMany(
        { userId, isRead: false },
        { isRead: true, readAt: new Date() }
    );
};

module.exports = mongoose.model('Notification', notificationSchema);