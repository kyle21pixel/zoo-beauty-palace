const mongoose = require('mongoose');

const favoriteSchema = new mongoose.Schema({
    clientId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    providerId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Provider',
        required: true
    }
}, {
    timestamps: true
});

// Ensure unique combination of clientId and providerId
favoriteSchema.index({ clientId: 1, providerId: 1 }, { unique: true });

// Static method to toggle favorite
favoriteSchema.statics.toggleFavorite = async function(clientId, providerId) {
    const existing = await this.findOne({ clientId, providerId });
    
    if (existing) {
        await existing.remove();
        return { isFavorite: false, message: 'Provider removed from favorites' };
    } else {
        const favorite = new this({ clientId, providerId });
        await favorite.save();
        return { isFavorite: true, message: 'Provider added to favorites' };
    }
};

// Static method to check if favorited
favoriteSchema.statics.isFavorited = async function(clientId, providerId) {
    const favorite = await this.findOne({ clientId, providerId });
    return !!favorite;
};

module.exports = mongoose.model('Favorite', favoriteSchema);