const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/database');

const SubscriptionPlan = sequelize.define('SubscriptionPlan', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    name: {
        type: DataTypes.STRING,
        allowNull: false
    },
    slug: {
        type: DataTypes.STRING,
        unique: true
    },
    description: {
        type: DataTypes.TEXT
    },
    price: {
        type: DataTypes.FLOAT,
        allowNull: false,
        validate: { min: 0 }
    },
    currency: {
        type: DataTypes.STRING,
        defaultValue: 'USD'
    },
    duration: {
        type: DataTypes.INTEGER, // in days
        allowNull: false,
        validate: { min: 1 }
    },
    features: {
        type: DataTypes.JSON,
        defaultValue: []
    },
    benefits: {
        type: DataTypes.JSON,
        defaultValue: {
            maxPortfolioItems: 10,
            maxServices: 5,
            priorityListing: false,
            analyticsAccess: false,
            featuredBadge: false,
            customBranding: false
        }
    },
    isActive: {
        type: DataTypes.BOOLEAN,
        defaultValue: true
    },
    isPopular: {
        type: DataTypes.BOOLEAN,
        defaultValue: false
    },
    sortOrder: {
        type: DataTypes.INTEGER,
        defaultValue: 0
    }
}, {
    timestamps: true,
    hooks: {
        beforeSave: (plan) => {
            if (plan.changed('name')) {
                plan.slug = plan.name
                    .toLowerCase()
                    .replace(/[^a-z0-9]+/g, '-')
                    .replace(/^-+|-+$/g, '');
            }
        }
    }
});

// Static method
SubscriptionPlan.getActivePlans = function () {
    return this.findAll({
        where: { isActive: true },
        order: [['sortOrder', 'ASC']]
    });
};

module.exports = SubscriptionPlan;
