const mongoose = require('mongoose');

const serviceSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true,
        unique: true,
        trim: true
    },
    slug: {
        type: String,
        unique: true,
        lowercase: true
    },
    description: {
        type: String,
        trim: true
    },
    category: {
        type: String,
        enum: ['hair', 'makeup', 'nails', 'skin', 'body', 'other'],
        required: true
    },
    icon: {
        type: String
    },
    isActive: {
        type: Boolean,
        default: true
    },
    suggestedPrice: {
        type: {
            min: {
                type: Number,
                default: 0
            },
            max: {
                type: Number,
                default: 0
            }
        },
        default: { min: 0, max: 0 }
    },
    suggestedDuration: {
        type: Number // in minutes
    }
}, {
    timestamps: true
});

// Pre-save hook to generate slug from name
serviceSchema.pre('save', function(next) {
    if (this.isModified('name')) {
        this.slug = this.name
            .toLowerCase()
            .replace(/[^a-z0-9]+/g, '-')
            .replace(/^-+|-+$/g, '');
    }
    next();
});

module.exports = mongoose.model('Service', serviceSchema);