const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/database');

const Provider = sequelize.define('Provider', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    userId: {
        type: DataTypes.INTEGER,
        allowNull: false,
        unique: true
    },
    businessName: {
        type: DataTypes.STRING,
        allowNull: false
    },
    bio: {
        type: DataTypes.TEXT
    },
    specializations: {
        type: DataTypes.JSON, // Array of strings
        defaultValue: []
    },
    location: {
        type: DataTypes.JSON, // Changed from GEOMETRY for SQLite compatibility
        allowNull: true
    },
    address: {
        type: DataTypes.STRING
    },
    city: {
        type: DataTypes.STRING
    },
    state: {
        type: DataTypes.STRING
    },
    country: {
        type: DataTypes.STRING
    },
    zipCode: {
        type: DataTypes.STRING
    },
    serviceType: {
        type: DataTypes.ENUM('mobile', 'studio', 'both'),
        defaultValue: 'both'
    },
    studioAddress: {
        type: DataTypes.STRING
    },
    portfolio: {
        type: DataTypes.JSON, // Array of objects
        defaultValue: []
    },
    services: {
        type: DataTypes.JSON, // Array of objects with service details
        defaultValue: []
    },
    availability: {
        type: DataTypes.JSON,
        defaultValue: {
            monday: { isAvailable: false, slots: [] },
            tuesday: { isAvailable: false, slots: [] },
            wednesday: { isAvailable: false, slots: [] },
            thursday: { isAvailable: false, slots: [] },
            friday: { isAvailable: false, slots: [] },
            saturday: { isAvailable: false, slots: [] },
            sunday: { isAvailable: false, slots: [] }
        }
    },
    rating: {
        type: DataTypes.FLOAT,
        defaultValue: 0
    },
    reviewCount: {
        type: DataTypes.INTEGER,
        defaultValue: 0
    },
    subscription: {
        type: DataTypes.JSON,
        defaultValue: {
            status: 'expired',
            autoRenew: true
        }
    },
    isOnline: {
        type: DataTypes.BOOLEAN,
        defaultValue: false
    },
    isVisible: {
        type: DataTypes.BOOLEAN,
        defaultValue: false
    },
    stats: {
        type: DataTypes.JSON,
        defaultValue: {
            totalBookings: 0,
            completedBookings: 0,
            cancelledBookings: 0,
            totalEarnings: 0
        }
    },
    bankDetails: {
        type: DataTypes.JSON,
        defaultValue: {}
    },
    documents: {
        type: DataTypes.JSON,
        defaultValue: []
    },
    socialMedia: {
        type: DataTypes.JSON,
        defaultValue: {}
    }
}, {
    timestamps: true,
    indexes: [
        {
            fields: ['userId']
        },
        {
            fields: ['rating']
        },
        {
            fields: ['isOnline']
        },
        {
            fields: ['isVisible']
        }
    ],
    hooks: {
        beforeSave: (provider) => {
            // Update isVisible based on subscription status
            const sub = provider.subscription || {};
            if (sub.status === 'active' && new Date(sub.endDate) > new Date()) {
                provider.isVisible = true;
            } else {
                provider.isVisible = false;
            }
        }
    }
});

// Instance methods
Provider.prototype.isAvailableAt = function (date, time) {
    const days = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
    const dayName = days[date.getDay()];
    const dayAvailability = this.availability[dayName];

    if (!dayAvailability || !dayAvailability.isAvailable) {
        return false;
    }

    // Check if time falls within any slot
    return dayAvailability.slots.some(slot => {
        return time >= slot.start && time <= slot.end;
    });
};

module.exports = Provider;
