const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const userSchema = new mongoose.Schema({
    full_name: {
        type: String,
        required: true,
        trim: true
    },
    phone_number: {
        type: String,
        required: true,
        trim: true,
        unique: true
    },
    email: {
        type: String,
        required: true,
        unique: true,
        lowercase: true,
        trim: true
    },
    password_hash: {
        type: String,
        required: true,
        minlength: 6
    },
    role: {
        type: String,
        enum: ['CLIENT', 'PROVIDER', 'ADMIN'],
        default: 'CLIENT'
    },
    is_active: {
        type: Boolean,
        default: true
    },
    created_at: {
        type: Date,
        default: Date.now
    },
    updated_at: {
        type: Date,
        default: Date.now
    }
}, {
    timestamps: true
});

// Hash password before saving
// Temporarily disabled due to issues with pre-save hook
// userSchema.pre('save', function(next) {
//     const user = this;
//     
//     // If password is not modified, skip hashing
//     if (!user.isModified('password') || !user.password) {
//         return next();
//     }
//     
//     // Hash the password
//     bcrypt.genSalt(10, (err, salt) => {
//         if (err) return next(err);
//         
//         bcrypt.hash(user.password, salt, (err, hash) => {
//             if (err) return next(err);
//             
//             user.password = hash;
//             next();
//         });
//     });
// });

// Compare password method
userSchema.methods.comparePassword = async function(candidatePassword) {
    return await bcrypt.compare(candidatePassword, this.password_hash);
};

// Generate auth token method
userSchema.methods.generateAuthToken = function() {
    return jwt.sign(
        {
            id: this._id,
            role: this.role,
            email: this.email
        },
        process.env.JWT_SECRET || 'your-secret-key',
        { expiresIn: process.env.JWT_EXPIRE || '7d' }
    );
};

// Add indexes for better query performance
userSchema.index({ email: 1 });
userSchema.index({ role: 1 });
userSchema.index({ is_active: 1 });
userSchema.index({ created_at: -1 });

// Hide sensitive fields when converting to JSON
userSchema.methods.toJSON = function() {
    const userObject = this.toObject();
    delete userObject.password_hash;
    return userObject;
};

module.exports = mongoose.model('User', userSchema);