const mongoose = require('mongoose');

const providerBeauticianServiceSchema = new mongoose.Schema({
    providerId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Provider',
        required: true
    },
    beauticianId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    serviceId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Service',
        required: true
    },
    isActive: {
        type: Boolean,
        default: true
    }
}, {
    timestamps: true
});

// Ensure unique combination
providerBeauticianServiceSchema.index({ providerId: 1, beauticianId: 1, serviceId: 1 }, { unique: true });

module.exports = mongoose.model('ProviderBeauticianService', providerBeauticianServiceSchema);