const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/database');

const Dispute = sequelize.define('Dispute', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    bookingId: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    reportedBy: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    reportedAgainst: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    reason: {
        type: DataTypes.ENUM(
            'no_show',
            'poor_service',
            'payment_issue',
            'unprofessional_behavior',
            'safety_concern',
            'other'
        ),
        allowNull: false
    },
    description: {
        type: DataTypes.TEXT,
        allowNull: false
    },
    evidence: {
        type: DataTypes.JSON, // Array of URLs
        defaultValue: []
    },
    status: {
        type: DataTypes.ENUM('open', 'investigating', 'resolved', 'closed'),
        defaultValue: 'open'
    },
    assignedTo: {
        type: DataTypes.INTEGER // Admin ID
    },
    resolution: {
        type: DataTypes.JSON,
        defaultValue: {}
    }
}, {
    timestamps: true
});

// Instance methods
Dispute.prototype.resolve = function (action, note, resolvedBy) {
    this.status = 'resolved';
    this.resolution = {
        action,
        note,
        resolvedBy,
        resolvedAt: new Date()
    };
    return this.save();
};

Dispute.prototype.assignTo = function (adminId) {
    this.assignedTo = adminId;
    this.status = 'investigating';
    return this.save();
};

module.exports = Dispute;
