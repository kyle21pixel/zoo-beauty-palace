const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/database');

const Notification = sequelize.define('Notification', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    userId: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    type: {
        type: DataTypes.STRING,
        allowNull: false
    },
    title: {
        type: DataTypes.STRING,
        allowNull: false
    },
    message: {
        type: DataTypes.STRING,
        allowNull: false
    },
    data: {
        type: DataTypes.JSON,
        defaultValue: {}
    },
    isRead: {
        type: DataTypes.BOOLEAN,
        defaultValue: false
    },
    readAt: {
        type: DataTypes.DATE
    },
    actionUrl: {
        type: DataTypes.STRING
    }
}, {
    timestamps: true
});

// Instance method
Notification.prototype.markAsRead = function () {
    this.isRead = true;
    this.readAt = new Date();
    return this.save();
};

// Static methods
Notification.createNotification = async function (userId, type, title, message, data = {}, actionUrl = null) {
    return this.create({
        userId,
        type,
        title,
        message,
        data,
        actionUrl
    });
};

Notification.markAllAsRead = function (userId) {
    return this.update(
        { isRead: true, readAt: new Date() },
        { where: { userId, isRead: false } }
    );
};

module.exports = Notification;
