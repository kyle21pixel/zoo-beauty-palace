const mongoose = require('mongoose');

const assignmentSchema = new mongoose.Schema({
    taskId: {
        type: String,
        required: true,
        unique: true
    },
    title: {
        type: String,
        required: true,
        trim: true
    },
    description: {
        type: String,
        trim: true
    },
    assignedById: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    assignedToId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    providerId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Provider'
    },
    status: {
        type: String,
        enum: ['pending', 'accepted', 'in-progress', 'completed', 'cancelled'],
        default: 'pending'
    },
    priority: {
        type: String,
        enum: ['low', 'medium', 'high', 'urgent'],
        default: 'medium'
    },
    dueDate: {
        type: Date
    },
    completedAt: {
        type: Date
    },
    notes: {
        type: String,
        trim: true
    }
}, {
    timestamps: true
});

// Indexes
assignmentSchema.index({ assignedById: 1 });
assignmentSchema.index({ assignedToId: 1 });
assignmentSchema.index({ providerId: 1 });
assignmentSchema.index({ status: 1 });
assignmentSchema.index({ providerId: 1, status: 1 });
assignmentSchema.index({ providerId: 1, assignedToId: 1 });

module.exports = mongoose.model('Assignment', assignmentSchema);