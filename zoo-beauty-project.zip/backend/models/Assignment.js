const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/database');

const Assignment = sequelize.define('Assignment', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    taskId: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true
    },
    title: {
        type: DataTypes.STRING,
        allowNull: false
    },
    description: {
        type: DataTypes.TEXT
    },
    assignedById: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: 'users',
            key: 'id'
        }
    },
    assignedToId: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: 'users',
            key: 'id'
        }
    },
    providerId: {
        type: DataTypes.INTEGER,
        allowNull: true,
        references: {
            model: 'providers',
            key: 'id'
        }
    },
    status: {
        type: DataTypes.ENUM('pending', 'accepted', 'in-progress', 'completed', 'cancelled'),
        defaultValue: 'pending'
    },
    priority: {
        type: DataTypes.ENUM('low', 'medium', 'high', 'urgent'),
        defaultValue: 'medium'
    },
    dueDate: {
        type: DataTypes.DATE
    },
    completedAt: {
        type: DataTypes.DATE
    },
    notes: {
        type: DataTypes.TEXT
    }
}, {
    timestamps: true,
    indexes: [
        {
            fields: ['assignedById']
        },
        {
            fields: ['assignedToId']
        },
        {
            fields: ['providerId']
        },
        {
            fields: ['status']
        },
        {
            fields: ['providerId', 'status']
        },
        {
            fields: ['providerId', 'assignedToId']
        }
    ]
});

module.exports = Assignment;