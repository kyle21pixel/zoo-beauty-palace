const mongoose = require('mongoose');

const availabilitySchema = new mongoose.Schema({
    provider_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Provider',
        required: true
    },
    day_of_week: {
        type: String,
        required: true,
        enum: ['MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY', 'SUNDAY']
    },
    start_time: {
        type: String,
        required: true
    },
    end_time: {
        type: String,
        required: true
    },
    created_at: {
        type: Date,
        default: Date.now
    }
}, {
    timestamps: true
});

// Add indexes for better query performance
availabilitySchema.index({ provider_id: 1 });
availabilitySchema.index({ day_of_week: 1 });

module.exports = mongoose.model('Availability', availabilitySchema);