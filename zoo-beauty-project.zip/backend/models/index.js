const User = require('./User.mongo');
const Provider = require('./Provider.mongo');
const Service = require('./Service.mongo');
const Booking = require('./Booking.mongo');
const Review = require('./Review.mongo');
const Message = require('./Message.mongo');
const Notification = require('./Notification.mongo');
const Payment = require('./Payment.mongo');
const Dispute = require('./Dispute.mongo');
const Analytics = require('./Analytics.mongo');
const Favorite = require('./Favorite.mongo');
const SubscriptionPlan = require('./SubscriptionPlan.mongo');
const Assignment = require('./Assignment.mongo');
const ProviderBeauticianService = require('./ProviderBeauticianService.mongo');
const ActivityLog = require('./ActivityLog.mongo');

// Mongoose models don't require explicit associations like Sequelize
// Relationships are defined in the schemas themselves using refs

module.exports = {
    User,
    Provider,
    Service,
    Booking,
    Review,
    Message,
    Notification,
    Payment,
    Dispute,
    Analytics,
    Favorite,
    SubscriptionPlan,
    Assignment,
    ProviderBeauticianService,
    ActivityLog
};