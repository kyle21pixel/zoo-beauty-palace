const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/database');

const Booking = sequelize.define('Booking', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    bookingNumber: {
        type: DataTypes.STRING,
        unique: true
    },
    clientId: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    providerId: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    assignedBeauticianId: {
        type: DataTypes.INTEGER,
        allowNull: true,
        references: {
            model: 'users',
            key: 'id'
        },
        comment: 'Beautician assigned to this booking by the provider'
    },
    service: {
        type: DataTypes.JSON,
        allowNull: false
    },
    scheduledDate: {
        type: DataTypes.DATEONLY,
        allowNull: false
    },
    scheduledTime: {
        type: DataTypes.STRING,
        allowNull: false
    },
    location: {
        type: DataTypes.JSON,
        allowNull: false
    },
    serviceType: {
        type: DataTypes.ENUM('mobile', 'studio', 'both'),
        allowNull: false,
        defaultValue: 'studio',
        comment: 'mobile for beautician services, studio for provider services, both for hybrid'
    },
    status: {
        type: DataTypes.ENUM('pending', 'accepted', 'in-progress', 'completed', 'cancelled', 'rejected'),
        defaultValue: 'pending'
    },
    payment: {
        type: DataTypes.JSON,
        defaultValue: {
            status: 'pending',
            platformFee: 0,
            providerEarnings: 0
        }
    },
    timeline: {
        type: DataTypes.JSON,
        defaultValue: []
    },
    cancellation: {
        type: DataTypes.JSON,
        defaultValue: {}
    },
    notes: {
        type: DataTypes.TEXT
    }
}, {
    timestamps: true,
    indexes: [
        {
            fields: ['providerId']
        },
        {
            fields: ['clientId']
        },
        {
            fields: ['status']
        },
        {
            fields: ['scheduledDate']
        },
        {
            fields: ['providerId', 'status']
        },
        {
            fields: ['providerId', 'createdAt']
        },
        {
            fields: ['providerId', 'scheduledDate']
        },
        {
            fields: ['providerId', 'assignedBeauticianId']
        },
        {
            fields: ['providerId', 'status', 'createdAt']
        }
    ],
    hooks: {
        beforeCreate: async (booking) => {
            // Generate booking number
            const date = new Date();
            const dateStr = date.toISOString().split('T')[0].replace(/-/g, '');

            // Count bookings for today
            const count = await Booking.count({
                where: sequelize.where(
                    sequelize.fn('DATE', sequelize.col('createdAt')),
                    date.toISOString().split('T')[0]
                )
            });

            booking.bookingNumber = `ZB-${dateStr}-${String(count + 1).padStart(3, '0')}`;
        },
        beforeSave: (booking) => {
            // Calculate platform fee and provider earnings
            if (booking.payment && booking.payment.amount) {
                const payment = { ...booking.payment };
                payment.platformFee = payment.amount * 0.10; // 10% platform fee
                payment.providerEarnings = payment.amount - payment.platformFee;
                booking.payment = payment;
            }

            // Add status to timeline if status changed
            if (booking.changed('status')) {
                const timeline = booking.timeline ? [...booking.timeline] : [];
                timeline.push({
                    status: booking.status,
                    timestamp: new Date()
                });
                booking.timeline = timeline;
            }
        }
    }
});

module.exports = Booking;
