const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/database');

const Review = sequelize.define('Review', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    bookingId: {
        type: DataTypes.INTEGER,
        allowNull: false,
        unique: true
    },
    clientId: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    providerId: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    rating: {
        type: DataTypes.INTEGER,
        allowNull: false,
        validate: { min: 1, max: 5 }
    },
    review: {
        type: DataTypes.JSON, // Breakdown ratings
        defaultValue: {}
    },
    comment: {
        type: DataTypes.TEXT
    },
    images: {
        type: DataTypes.JSON, // Array of strings
        defaultValue: []
    },
    response: {
        type: DataTypes.JSON,
        defaultValue: {}
    },
    isModerated: {
        type: DataTypes.BOOLEAN,
        defaultValue: false
    },
    moderatedBy: {
        type: DataTypes.INTEGER
    },
    moderationNote: {
        type: DataTypes.STRING
    },
    isVisible: {
        type: DataTypes.BOOLEAN,
        defaultValue: true
    },
    helpfulCount: {
        type: DataTypes.INTEGER,
        defaultValue: 0
    }
}, {
    timestamps: true
});

// Instance method
Review.prototype.addResponse = function (responseText) {
    this.response = {
        text: responseText,
        respondedAt: new Date()
    };
    return this.save();
};

module.exports = Review;
