const mongoose = require('mongoose');

const paymentSchema = new mongoose.Schema({
    booking_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Booking',
        required: true
    },
    amount: {
        type: Number,
        required: true,
        min: 0
    },
    payment_method: {
        type: String,
        enum: ['MPESA', 'CARD'],
        required: true
    },
    payment_status: {
        type: String,
        enum: ['INITIATED', 'SUCCESS', 'FAILED'],
        default: 'INITIATED'
    },
    transaction_reference: {
        type: String,
        required: true,
        unique: true
    },
    created_at: {
        type: Date,
        default: Date.now
    }
}, {
    timestamps: true
});

// Pre-save hook to calculate net amount
paymentSchema.pre('save', function(next) {
    if (this.isModified('amount') || this.isModified('platformFee')) {
        this.netAmount = this.amount - (this.platformFee || 0);
    }
    next();
});

// Static method to generate transaction ID
paymentSchema.statics.generateTransactionId = function() {
    const timestamp = Date.now().toString(36);
    const random = Math.random().toString(36).substring(2, 8);
    return `TXN-${timestamp}-${random}`.toUpperCase();
};

module.exports = mongoose.model('Payment', paymentSchema);