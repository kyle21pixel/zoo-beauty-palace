const mongoose = require('mongoose');

const providerSchema = new mongoose.Schema({
    user_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true,
        unique: true
    },
    business_name: {
        type: String,
        required: true,
        trim: true
    },
    bio: {
        type: String,
        trim: true
    },
    verification_status: {
        type: String,
        enum: ['PENDING', 'VERIFIED', 'REJECTED'],
        default: 'PENDING'
    },
    average_rating: {
        type: Number,
        default: 0,
        min: 0,
        max: 5
    },
    total_reviews: {
        type: Number,
        default: 0
    },
    city: {
        type: String,
        trim: true
    },
    created_at: {
        type: Date,
        default: Date.now
    }
}, {
    timestamps: true
});

// Indexes
providerSchema.index({ userId: 1 });
providerSchema.index({ rating: -1 });
providerSchema.index({ isOnline: 1 });
providerSchema.index({ isVisible: 1 });
providerSchema.index({ location: '2dsphere' });

// Pre-save hook to update isVisible based on subscription status
// Temporarily disabled due to issues with pre-save hook
// providerSchema.pre('save', function(next) {
//     const subscription = this.subscription || {};
//     if (subscription.status === 'active' && subscription.endDate && new Date(subscription.endDate) > new Date()) {
//         this.isVisible = true;
//     } else {
//         this.isVisible = false;
//     }
//     next();
// });

// Instance method to check availability
providerSchema.methods.isAvailableAt = function(date, time) {
    const days = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
    const dayName = days[date.getDay()];
    const dayAvailability = this.availability[dayName];

    if (!dayAvailability || !dayAvailability.isAvailable) {
        return false;
    }

    // Check if time falls within any slot
    return dayAvailability.slots.some(slot => {
        return time >= slot.start && time <= slot.end;
    });
};

module.exports = mongoose.model('Provider', providerSchema);