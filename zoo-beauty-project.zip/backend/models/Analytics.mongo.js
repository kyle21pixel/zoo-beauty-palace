const mongoose = require('mongoose');

const analyticsSchema = new mongoose.Schema({
    date: {
        type: Date,
        required: true,
        unique: true
    },
    metrics: {
        type: {
            newUsers: {
                type: Number,
                default: 0
            },
            newProviders: {
                type: Number,
                default: 0
            },
            newClients: {
                type: Number,
                default: 0
            },
            totalBookings: {
                type: Number,
                default: 0
            },
            completedBookings: {
                type: Number,
                default: 0
            },
            cancelledBookings: {
                type: Number,
                default: 0
            },
            revenue: {
                type: Number,
                default: 0
            },
            platformFees: {
                type: Number,
                default: 0
            },
            activeSubscriptions: {
                type: Number,
                default: 0
            }
        },
        default: {
            newUsers: 0,
            newProviders: 0,
            newClients: 0,
            totalBookings: 0,
            completedBookings: 0,
            cancelledBookings: 0,
            revenue: 0,
            platformFees: 0,
            activeSubscriptions: 0
        }
    },
    topProviders: {
        type: [{
            providerId: mongoose.Schema.Types.ObjectId,
            providerName: String,
            bookingCount: Number,
            revenue: Number
        }],
        default: []
    },
    topServices: {
        type: [{
            serviceId: mongoose.Schema.Types.ObjectId,
            serviceName: String,
            bookingCount: Number
        }],
        default: []
    },
    geographicData: {
        type: [{
            city: String,
            state: String,
            country: String,
            bookingCount: Number,
            revenue: Number
        }],
        default: []
    }
}, {
    timestamps: true
});

// Static method to get or create analytics for a date
analyticsSchema.statics.getOrCreateForDate = async function(date) {
    const dateOnly = new Date(date);
    dateOnly.setHours(0, 0, 0, 0);
    
    let analytics = await this.findOne({ date: dateOnly });
    
    if (!analytics) {
        analytics = new this({ date: dateOnly });
        await analytics.save();
    }
    
    return analytics;
};

// Static method to get analytics for a date range
analyticsSchema.statics.getDateRange = function(startDate, endDate) {
    return this.find({
        date: {
            $gte: new Date(startDate),
            $lte: new Date(endDate)
        }
    }).sort({ date: 1 });
};

module.exports = mongoose.model('Analytics', analyticsSchema);