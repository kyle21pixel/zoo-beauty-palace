const mongoose = require('mongoose');

const bookingSchema = new mongoose.Schema({
    client_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    provider_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Provider',
        required: true
    },
    service_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Service',
        required: true
    },
    booking_date: {
        type: Date,
        required: true
    },
    start_time: {
        type: String,
        required: true
    },
    location_type: {
        type: String,
        enum: ['ON_SITE', 'ON_ROUTE'],
        required: true
    },
    client_address: {
        type: String
    },
    status: {
        type: String,
        enum: ['PENDING', 'CONFIRMED', 'COMPLETED', 'CANCELLED'],
        default: 'PENDING'
    },
    created_at: {
        type: Date,
        default: Date.now
    }
}, {
    timestamps: true
});

// Indexes
bookingSchema.index({ provider_id: 1 });
bookingSchema.index({ client_id: 1 });
bookingSchema.index({ status: 1 });
bookingSchema.index({ booking_date: 1 });
bookingSchema.index({ provider_id: 1, status: 1 });
bookingSchema.index({ provider_id: 1, created_at: -1 });
bookingSchema.index({ provider_id: 1, booking_date: 1 });
bookingSchema.index({ service_id: 1 });

// Pre-save hook to generate booking number and calculate fees
// Temporarily disabled due to issues with pre-save hook
// bookingSchema.pre('save', async function(next) {
//     // Generate booking number if it's a new booking
//     if (this.isNew) {
//         const date = new Date();
//         const dateStr = date.toISOString().split('T')[0].replace(/-/g, '');
//         
//         // Count bookings for today
//         const todayStart = new Date(date.setHours(0, 0, 0, 0));
//         const todayEnd = new Date(date.setHours(23, 59, 59, 999));
//         
//         const count = await mongoose.model('Booking').countDocuments({
//             createdAt: {
//                 $gte: todayStart,
//                 $lte: todayEnd
//             }
//         });
//         
//         this.bookingNumber = `ZB-${dateStr}-${String(count + 1).padStart(3, '0')}`;
//     }
//     
//     // Calculate platform fee and provider earnings
//     if (this.payment && this.payment.amount) {
//         const payment = { ...this.payment };
//         payment.platformFee = payment.amount * 0.10; // 10% platform fee
//         payment.providerEarnings = payment.amount - payment.platformFee;
//         this.payment = payment;
//     }
//     
//     // Add status to timeline if status changed
//     if (this.isModified('status')) {
//         const timeline = this.timeline ? [...this.timeline] : [];
//         timeline.push({
//             status: this.status,
//             timestamp: new Date()
//         });
//         this.timeline = timeline;
//     }
//     
//     next();
// });

module.exports = mongoose.model('Booking', bookingSchema);