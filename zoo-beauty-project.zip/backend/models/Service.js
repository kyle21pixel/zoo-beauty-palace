const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/database');

const Service = sequelize.define('Service', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    name: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true
    },
    slug: {
        type: DataTypes.STRING,
        unique: true
    },
    description: {
        type: DataTypes.TEXT
    },
    category: {
        type: DataTypes.ENUM('hair', 'makeup', 'nails', 'skin', 'body', 'other'),
        allowNull: false
    },
    icon: {
        type: DataTypes.STRING
    },
    isActive: {
        type: DataTypes.BOOLEAN,
        defaultValue: true
    },
    suggestedPrice: {
        type: DataTypes.JSON,
        defaultValue: { min: 0, max: 0 }
    },
    suggestedDuration: {
        type: DataTypes.INTEGER
    }
}, {
    timestamps: true,
    hooks: {
        beforeSave: (service) => {
            if (service.changed('name')) {
                service.slug = service.name
                    .toLowerCase()
                    .replace(/[^a-z0-9]+/g, '-')
                    .replace(/^-+|-+$/g, '');
            }
        }
    }
});

module.exports = Service;
