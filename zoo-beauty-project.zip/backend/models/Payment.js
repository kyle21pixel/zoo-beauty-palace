const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/database');

const Payment = sequelize.define('Payment', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    transactionId: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true
    },
    type: {
        type: DataTypes.ENUM('booking', 'subscription', 'refund', 'payout'),
        allowNull: false
    },
    userId: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    relatedId: {
        type: DataTypes.INTEGER // Booking or Subscription ID
    },
    amount: {
        type: DataTypes.FLOAT,
        allowNull: false,
        validate: { min: 0 }
    },
    currency: {
        type: DataTypes.STRING,
        defaultValue: 'USD'
    },
    platformFee: {
        type: DataTypes.FLOAT,
        defaultValue: 0,
        validate: { min: 0 }
    },
    netAmount: {
        type: DataTypes.FLOAT,
        validate: { min: 0 }
    },
    status: {
        type: DataTypes.ENUM('pending', 'processing', 'completed', 'failed', 'refunded'),
        defaultValue: 'pending'
    },
    paymentMethod: {
        type: DataTypes.ENUM('card', 'wallet', 'bank_transfer', 'cash')
    },
    gateway: {
        type: DataTypes.ENUM('stripe', 'paystack', 'paypal')
    },
    gatewayTransactionId: {
        type: DataTypes.STRING
    },
    metadata: {
        type: DataTypes.JSON,
        defaultValue: {}
    },
    refund: {
        type: DataTypes.JSON,
        defaultValue: {}
    }
}, {
    timestamps: true,
    hooks: {
        beforeSave: (payment) => {
            if (payment.changed('amount') || payment.changed('platformFee')) {
                payment.netAmount = payment.amount - (payment.platformFee || 0);
            }
        }
    }
});

// Static method
Payment.generateTransactionId = function () {
    const timestamp = Date.now().toString(36);
    const random = Math.random().toString(36).substring(2, 8);
    return `TXN-${timestamp}-${random}`.toUpperCase();
};

module.exports = Payment;
