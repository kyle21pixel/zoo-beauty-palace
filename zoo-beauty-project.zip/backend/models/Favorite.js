const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/database');

const Favorite = sequelize.define('Favorite', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    clientId: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    providerId: {
        type: DataTypes.INTEGER,
        allowNull: false
    }
}, {
    timestamps: true,
    indexes: [
        {
            unique: true,
            fields: ['clientId', 'providerId']
        }
    ]
});

// Static methods
Favorite.toggleFavorite = async function (clientId, providerId) {
    const existing = await this.findOne({ where: { clientId, providerId } });

    if (existing) {
        await existing.destroy();
        return { isFavorite: false, message: 'Provider removed from favorites' };
    } else {
        await this.create({ clientId, providerId });
        return { isFavorite: true, message: 'Provider added to favorites' };
    }
};

Favorite.isFavorited = async function (clientId, providerId) {
    const favorite = await this.findOne({ where: { clientId, providerId } });
    return !!favorite;
};

module.exports = Favorite;
