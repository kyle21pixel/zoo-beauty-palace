const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/database');

const Analytics = sequelize.define('Analytics', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    date: {
        type: DataTypes.DATEONLY,
        allowNull: false,
        unique: true
    },
    metrics: {
        type: DataTypes.JSON,
        defaultValue: {
            newUsers: 0,
            newProviders: 0,
            newClients: 0,
            totalBookings: 0,
            completedBookings: 0,
            cancelledBookings: 0,
            revenue: 0,
            platformFees: 0,
            activeSubscriptions: 0
        }
    },
    topProviders: {
        type: DataTypes.JSON,
        defaultValue: []
    },
    topServices: {
        type: DataTypes.JSON,
        defaultValue: []
    },
    geographicData: {
        type: DataTypes.JSON,
        defaultValue: []
    }
}, {
    timestamps: true
});

// Static methods
Analytics.getOrCreateForDate = async function (date) {
    const dateOnly = new Date(date).toISOString().split('T')[0];

    const [analytics, created] = await this.findOrCreate({
        where: { date: dateOnly },
        defaults: { date: dateOnly }
    });

    return analytics;
};

Analytics.getDateRange = function (startDate, endDate) {
    const { Op } = require('sequelize');
    return this.findAll({
        where: {
            date: {
                [Op.between]: [startDate, endDate]
            }
        },
        order: [['date', 'ASC']]
    });
};

module.exports = Analytics;
