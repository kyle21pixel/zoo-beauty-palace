const mongoose = require('mongoose');

const reviewSchema = new mongoose.Schema({
    booking_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Booking',
        required: true,
        unique: true
    },
    client_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    provider_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Provider',
        required: true
    },
    rating: {
        type: Number,
        required: true,
        min: 1,
        max: 5
    },
    comment: {
        type: String,
        trim: true
    },
    created_at: {
        type: Date,
        default: Date.now
    }
}, {
    timestamps: true
});

// Instance method to add response
reviewSchema.methods.addResponse = function(responseText, userId) {
    this.response = {
        text: responseText,
        respondedAt: new Date(),
        respondedBy: userId
    };
    return this.save();
};

module.exports = mongoose.model('Review', reviewSchema);