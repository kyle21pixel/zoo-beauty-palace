-- Create Database
CREATE DATABASE IF NOT EXISTS zoobeauty CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE zoobeauty;

-- Users Table
CREATE TABLE IF NOT EXISTS `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `firstName` VARCHAR(100) NOT NULL,
  `lastName` VARCHAR(100) NOT NULL,
  `email` VARCHAR(255) UNIQUE NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `phone` VARCHAR(20),
  `avatar` VARCHAR(500),
  `role` ENUM('client', 'provider', 'admin') DEFAULT 'client',
  `isActive` BOOLEAN DEFAULT TRUE,
  `isVerified` BOOLEAN DEFAULT FALSE,
  `verificationToken` VARCHAR(255),
  `resetPasswordToken` VARCHAR(255),
  `resetPasswordExpire` DATETIME,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Providers Table
CREATE TABLE IF NOT EXISTS `providers` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `userId` INT NOT NULL,
  `businessName` VARCHAR(255),
  `bio` TEXT,
  `specializations` JSON,
  `location` JSON,
  `serviceType` ENUM('mobile', 'studio', 'both') DEFAULT 'both',
  `studioAddress` VARCHAR(500),
  `services` JSON,
  `portfolio` JSON,
  `availability` JSON,
  `rating` JSON,
  `stats` JSON,
  `subscription` JSON,
  `socialMedia` JSON,
  `bankDetails` JSON,
  `isVisible` BOOLEAN DEFAULT TRUE,
  `isOnline` BOOLEAN DEFAULT FALSE,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Assignments Table
CREATE TABLE IF NOT EXISTS `assignments` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `taskId` VARCHAR(100) NOT NULL UNIQUE,
  `title` VARCHAR(255) NOT NULL,
  `description` TEXT,
  `assignedById` INT NOT NULL,
  `assignedToId` INT NOT NULL,
  `providerId` INT,
  `status` ENUM('pending', 'accepted', 'in-progress', 'completed', 'cancelled') DEFAULT 'pending',
  `priority` ENUM('low', 'medium', 'high', 'urgent') DEFAULT 'medium',
  `dueDate` DATETIME,
  `completedAt` DATETIME,
  `notes` TEXT,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`assignedById`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`assignedToId`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`providerId`) REFERENCES `providers`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Bookings Table
CREATE TABLE IF NOT EXISTS `bookings` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `clientId` INT NOT NULL,
  `providerId` INT NOT NULL,
  `serviceId` VARCHAR(100),
  `serviceName` VARCHAR(255) NOT NULL,
  `date` DATE NOT NULL,
  `time` TIME NOT NULL,
  `duration` INT,
  `amount` DECIMAL(10, 2) NOT NULL,
  `status` ENUM('pending', 'confirmed', 'in-progress', 'completed', 'cancelled') DEFAULT 'pending',
  `location` JSON,
  `notes` TEXT,
  `cancellationReason` TEXT,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`clientId`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`providerId`) REFERENCES `providers`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Reviews Table
CREATE TABLE IF NOT EXISTS `reviews` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `bookingId` INT NOT NULL,
  `clientId` INT NOT NULL,
  `providerId` INT NOT NULL,
  `rating` INT NOT NULL CHECK (`rating` >= 1 AND `rating` <= 5),
  `comment` TEXT,
  `response` TEXT,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`bookingId`) REFERENCES `bookings`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`clientId`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`providerId`) REFERENCES `providers`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Payments Table
CREATE TABLE IF NOT EXISTS `payments` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `bookingId` INT,
  `userId` INT NOT NULL,
  `amount` DECIMAL(10, 2) NOT NULL,
  `currency` VARCHAR(3) DEFAULT 'USD',
  `type` ENUM('booking', 'subscription', 'refund') DEFAULT 'booking',
  `method` VARCHAR(50),
  `status` ENUM('pending', 'completed', 'failed', 'refunded') DEFAULT 'pending',
  `transactionId` VARCHAR(255),
  `platformFee` DECIMAL(10, 2),
  `providerAmount` DECIMAL(10, 2),
  `metadata` JSON,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`bookingId`) REFERENCES `bookings`(`id`) ON DELETE SET NULL,
  FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Messages Table
CREATE TABLE IF NOT EXISTS `messages` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `senderId` INT NOT NULL,
  `receiverId` INT NOT NULL,
  `content` TEXT NOT NULL,
  `isRead` BOOLEAN DEFAULT FALSE,
  `readAt` DATETIME,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`senderId`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`receiverId`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Notifications Table
CREATE TABLE IF NOT EXISTS `notifications` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `userId` INT NOT NULL,
  `type` VARCHAR(50) NOT NULL,
  `title` VARCHAR(255) NOT NULL,
  `message` TEXT NOT NULL,
  `data` JSON,
  `isRead` BOOLEAN DEFAULT FALSE,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Disputes Table
CREATE TABLE IF NOT EXISTS `disputes` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `bookingId` INT NOT NULL,
  `reportedBy` INT NOT NULL,
  `reportedAgainst` INT NOT NULL,
  `reason` TEXT NOT NULL,
  `status` ENUM('pending', 'investigating', 'resolved', 'closed') DEFAULT 'pending',
  `resolution` TEXT,
  `assignedTo` INT,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`bookingId`) REFERENCES `bookings`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`reportedBy`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`reportedAgainst`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Favorites Table
CREATE TABLE IF NOT EXISTS `favorites` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `clientId` INT NOT NULL,
  `providerId` INT NOT NULL,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`clientId`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`providerId`) REFERENCES `providers`(`id`) ON DELETE CASCADE,
  UNIQUE KEY `unique_favorite` (`clientId`, `providerId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Subscription Plans Table
CREATE TABLE IF NOT EXISTS `subscription_plans` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL,
  `description` TEXT,
  `price` DECIMAL(10, 2) NOT NULL,
  `duration` INT NOT NULL,
  `features` JSON,
  `isActive` BOOLEAN DEFAULT TRUE,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Provider-Beautician Services Table
CREATE TABLE IF NOT EXISTS `provider_beautician_services` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `providerId` INT NOT NULL,
  `beauticianId` INT NOT NULL,
  `serviceId` INT NOT NULL,
  `isActive` BOOLEAN DEFAULT TRUE,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`providerId`) REFERENCES `providers`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`beauticianId`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`serviceId`) REFERENCES `services`(`id`) ON DELETE CASCADE,
  UNIQUE KEY `unique_provider_beautician_service` (`providerId`, `beauticianId`, `serviceId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Analytics Table
CREATE TABLE IF NOT EXISTS `analytics` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `date` DATE NOT NULL,
  `totalBookings` INT DEFAULT 0,
  `completedBookings` INT DEFAULT 0,
  `totalRevenue` DECIMAL(10, 2) DEFAULT 0,
  `newUsers` INT DEFAULT 0,
  `newProviders` INT DEFAULT 0,
  `activeUsers` INT DEFAULT 0,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `unique_date` (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Activity Logs Table
CREATE TABLE IF NOT EXISTS `activity_logs` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `userId` INT NOT NULL,
  `action` VARCHAR(100) NOT NULL,
  `entityType` VARCHAR(50),
  `entityId` INT,
  `description` TEXT,
  `metadata` JSON,
  `ipAddress` VARCHAR(45),
  `userAgent` TEXT,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create Indexes for better performance
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_role ON users(role);
CREATE INDEX idx_providers_userId ON providers(userId);
CREATE INDEX idx_bookings_clientId ON bookings(clientId);
CREATE INDEX idx_bookings_providerId ON bookings(providerId);
CREATE INDEX idx_bookings_date ON bookings(date);
CREATE INDEX idx_bookings_status ON bookings(status);
CREATE INDEX idx_reviews_providerId ON reviews(providerId);
CREATE INDEX idx_messages_senderId ON messages(senderId);
CREATE INDEX idx_messages_receiverId ON messages(receiverId);
CREATE INDEX idx_notifications_userId ON notifications(userId);

-- Insert Admin User
INSERT INTO `users` (`firstName`, `lastName`, `email`, `password`, `role`, `isActive`, `isVerified`) 
VALUES ('Admin', 'User', 'admin@zoobeauty.com', '$2a$10$rN8qZ5YxH9kQXZ5YxH9kQeO5YxH9kQXZ5YxH9kQXZ5YxH9kQXZ5Yx', 'admin', TRUE, TRUE);

SELECT 'Database setup completed successfully!' AS message;