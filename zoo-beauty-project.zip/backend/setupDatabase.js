const mysql = require('mysql2');
const fs = require('fs');
require('dotenv').config();

console.log('🔧 Setting up Zoo Beauty Database...\n');

// Create connection without database first
const connection = mysql.createConnection({
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASS || '',
    multipleStatements: true
});

connection.connect((err) => {
    if (err) {
        console.error('❌ Error connecting to MySQL:', err.message);
        console.log('\n💡 Troubleshooting tips:');
        console.log('   1. Make sure MySQL is running in XAMPP');
        console.log('   2. Check if DB_PASS in .env file is correct');
        console.log('   3. Current settings:');
        console.log('      - Host:', process.env.DB_HOST || 'localhost');
        console.log('      - User:', process.env.DB_USER || 'root');
        console.log('      - Pass:', process.env.DB_PASS ? '(set)' : '(empty)');
        process.exit(1);
    }

    console.log('✅ Connected to MySQL\n');

    // Read and execute SQL file
    const sql = fs.readFileSync('./database_setup.sql', 'utf8');

    connection.query(sql, (err, results) => {
        if (err) {
            console.error('❌ Error executing SQL:', err.message);
            connection.end();
            process.exit(1);
        }

        console.log('✅ Database created successfully!\n');

        // Verify tables
        connection.query('USE zoobeauty; SHOW TABLES;', (err, tables) => {
            if (err) {
                console.error('Error checking tables:', err.message);
            } else {
                console.log('📋 Tables created:');
                tables.forEach(table => {
                    console.log('   ✓', Object.values(table)[0]);
                });
            }

            connection.end();
            console.log('\n🎉 Database setup complete!');
            console.log('📝 Next step: Run "node seedProviders.js" to add sample data\n');
        });
    });
});
