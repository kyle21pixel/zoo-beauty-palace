const mongoose = require('mongoose');
const User = require('./models/User.mongo');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { connectDB } = require('./config/mongodb');

// Connect to database
connectDB();

async function testLogin() {
  try {
    console.log('Testing login...\n');
    
    const email = 'testclient@example.com';
    const password = 'password123';
    
    // Find user
    const user = await User.findOne({ email });
    
    if (!user) {
      console.log('❌ User not found');
      mongoose.connection.close();
      return;
    }
    
    console.log(`Found user: ${user.email}`);
    console.log(`Stored password hash: ${user.password.substring(0, 20)}...`);
    
    // Test password comparison
    console.log('\nTesting password comparison...');
    const isMatch = await bcrypt.compare(password, user.password);
    console.log(`Password match: ${isMatch}`);
    
    // Test with user method
    console.log('\nTesting with user method...');
    const isMatch2 = await user.comparePassword(password);
    console.log(`Password match (user method): ${isMatch2}`);
    
    // Test login flow
    if (isMatch2) {
      console.log('\n✅ Login successful!');
      console.log(`User ID: ${user._id}`);
      console.log(`Role: ${user.role}`);
      console.log(`Profile Complete: ${user.isProfileComplete}`);
      
      // Generate token
      const token = jwt.sign(
        {
          id: user._id,
          role: user.role,
          email: user.email
        },
        process.env.JWT_SECRET || 'your-secret-key',
        { expiresIn: process.env.JWT_EXPIRE || '7d' }
      );
      
      console.log(`\nJWT Token: ${token.substring(0, 30)}...`);
      
      // Update last login
      user.lastLogin = new Date();
      await user.save();
      
      console.log('\n✅ Last login updated');
    } else {
      console.log('❌ Invalid credentials');
    }
    
    // Close connection
    mongoose.connection.close();
    
  } catch (error) {
    console.log('❌ Login failed with error:', error.message);
    mongoose.connection.close();
  }
}

// Run the test
testLogin();