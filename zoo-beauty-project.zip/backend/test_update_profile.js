const mongoose = require('mongoose');
const User = require('./models/User.mongo');
const { connectDB } = require('./config/mongodb');

// Connect to database
connectDB();

// Test updating a user's profile
async function testUpdateProfile() {
  try {
    console.log('Testing profile update...');
    
    // Find the user we just created
    const user = await User.findOne({ email: 'testuser2@example.com' });
    
    if (!user) {
      console.log('❌ User not found');
      mongoose.connection.close();
      return;
    }
    
    console.log('Found user:', user.email);
    
    // Update user profile
    user.firstName = 'John';
    user.lastName = 'Doe';
    user.phone = '123-456-7890';
    user.isProfileComplete = true;
    
    await user.save();
    
    console.log('✅ Profile updated successfully!');
    console.log('User ID:', user._id);
    console.log('Email:', user.email);
    console.log('First Name:', user.firstName);
    console.log('Last Name:', user.lastName);
    console.log('Phone:', user.phone);
    console.log('Profile Complete:', user.isProfileComplete);
    
    // Close connection
    mongoose.connection.close();
  } catch (error) {
    console.log('❌ Profile update failed with error:', error.message);
    mongoose.connection.close();
  }
}

// Run the test
testUpdateProfile();