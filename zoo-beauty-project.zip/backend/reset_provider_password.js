const { sequelize } = require('./config/database');
const User = require('./models/User');

async function resetPassword() {
    try {
        await sequelize.authenticate();
        console.log('Database connected.');

        const email = 'provider@test.com';
        const newPassword = 'password123';

        const user = await User.findOne({ where: { email } });

        if (!user) {
            console.log(`User with email ${email} NOT FOUND.`);
        } else {
            console.log(`User found. Resetting password...`);
            user.password = newPassword;
            await user.save(); // This triggers the beforeSave hook which hashes the password
            console.log(`Password reset for ${email} to '${newPassword}' successfully.`);
        }

    } catch (error) {
        console.error('Error resetting password:', error);
    } finally {
        await sequelize.close();
    }
}

resetPassword();
