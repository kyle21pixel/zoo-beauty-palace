const { sequelize } = require('./config/database');
const User = require('./models/User');
const Provider = require('./models/Provider');
const bcrypt = require('bcryptjs');

async function seedTestData() {
    try {
        console.log('🌱 Seeding test data...\n');

        // Create Provider User (On-Site Services)
        console.log('Creating Provider account...');
        const providerUser = await User.create({
            email: 'provider@test.com',
            password: 'password123',
            role: 'provider',
            firstName: 'Grace',
            lastName: 'Wanjiru',
            phone: '+254712345678',
            avatar: 'https://i.pravatar.cc/150?img=9',
            isActive: true,
            isVerified: true
        });

        // Create Provider Profile
        const provider = await Provider.create({
            userId: providerUser.id,
            businessName: 'Grace Nails & Spa',
            bio: 'Certified nail technician offering premium nail care services and creative nail art designs.',
            specializations: ['Nail Art', 'Manicure', 'Pedicure'],
            location: {
                type: 'Point',
                coordinates: [36.7000, -1.3167] // Karen, Nairobi [lng, lat]
            },
            address: 'Karen Shopping Center',
            city: 'Nairobi',
            state: 'Nairobi County',
            country: 'Kenya',
            zipCode: '00100',
            serviceType: 'on-site',
            studioAddress: 'Karen Shopping Center, Ground Floor',
            portfolio: [
                'https://images.unsplash.com/photo-1604654894610-df63bc536371?w=400',
                'https://images.unsplash.com/photo-1610992015732-2449b76344bc?w=400',
                'https://images.unsplash.com/photo-1519014816548-bf5fe059798b?w=400'
            ],
            services: [
                {
                    id: 'srv1',
                    name: 'Gel Manicure',
                    price: 1500,
                    duration: 60,
                    description: 'Long-lasting gel manicure with premium products'
                },
                {
                    id: 'srv2',
                    name: 'Acrylic Nails',
                    price: 2500,
                    duration: 90,
                    description: 'Full set of acrylic nails with custom design'
                },
                {
                    id: 'srv3',
                    name: 'Pedicure',
                    price: 1200,
                    duration: 45,
                    description: 'Relaxing pedicure with foot massage'
                }
            ],
            availability: {
                monday: { isAvailable: true, slots: [{ start: '09:00', end: '18:00' }] },
                tuesday: { isAvailable: true, slots: [{ start: '09:00', end: '18:00' }] },
                wednesday: { isAvailable: true, slots: [{ start: '09:00', end: '18:00' }] },
                thursday: { isAvailable: true, slots: [{ start: '09:00', end: '18:00' }] },
                friday: { isAvailable: true, slots: [{ start: '09:00', end: '19:00' }] },
                saturday: { isAvailable: true, slots: [{ start: '10:00', end: '17:00' }] },
                sunday: { isAvailable: false, slots: [] }
            },
            rating: 4.7,
            reviewCount: 178,
            subscription: {
                status: 'active',
                plan: 'premium',
                startDate: new Date(),
                endDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days from now
                autoRenew: true
            },
            isOnline: true,
            isVisible: true,
            stats: {
                totalBookings: 289,
                completedBookings: 276,
                cancelledBookings: 13,
                totalEarnings: 552000
            }
        });

        console.log('✓ Provider created:', providerUser.email);
        console.log('  Business:', provider.businessName);
        console.log('  Service Type: on-site\n');

        // Create Beautician User (En-Route Services)
        console.log('Creating Beautician account...');
        const beauticianUser = await User.create({
            email: 'beautician@test.com',
            password: 'password123',
            role: 'beautician',
            firstName: 'Sarah',
            lastName: 'Njeri',
            phone: '+254723456789',
            avatar: 'https://i.pravatar.cc/150?img=1',
            isActive: true,
            isVerified: true
        });

        // Create Beautician Profile (stored as Provider with serviceType='on-route')
        const beautician = await Provider.create({
            userId: beauticianUser.id,
            businessName: 'Glam by Sarah',
            bio: 'Professional mobile makeup artist with 10+ years of experience. I come to you! Specializing in bridal and editorial makeup.',
            specializations: ['Makeup', 'Bridal Makeup', 'Hair Styling'],
            location: {
                type: 'Point',
                coordinates: [36.8167, -1.2667] // Westlands, Nairobi [lng, lat]
            },
            address: 'Westlands Area',
            city: 'Nairobi',
            state: 'Nairobi County',
            country: 'Kenya',
            zipCode: '00100',
            serviceType: 'on-route',
            portfolio: [
                'https://images.unsplash.com/photo-1487412912498-0447578fcca8?w=400',
                'https://images.unsplash.com/photo-1596462502278-27bfdd403348?w=400',
                'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?w=400'
            ],
            services: [
                {
                    id: 'srv1',
                    name: 'Bridal Makeup',
                    price: 8000,
                    duration: 120,
                    description: 'Complete bridal makeup package with trial session'
                },
                {
                    id: 'srv2',
                    name: 'Event Makeup',
                    price: 5000,
                    duration: 90,
                    description: 'Glamorous makeup for special events'
                },
                {
                    id: 'srv3',
                    name: 'Photoshoot Makeup',
                    price: 6000,
                    duration: 90,
                    description: 'Professional makeup for photo and video shoots'
                }
            ],
            availability: {
                monday: { isAvailable: true, slots: [{ start: '09:00', end: '17:00' }] },
                tuesday: { isAvailable: true, slots: [{ start: '09:00', end: '17:00' }] },
                wednesday: { isAvailable: true, slots: [{ start: '09:00', end: '17:00' }] },
                thursday: { isAvailable: true, slots: [{ start: '09:00', end: '17:00' }] },
                friday: { isAvailable: true, slots: [{ start: '09:00', end: '19:00' }] },
                saturday: { isAvailable: true, slots: [{ start: '10:00', end: '18:00' }] },
                sunday: { isAvailable: false, slots: [] }
            },
            rating: 4.9,
            reviewCount: 234,
            subscription: {
                status: 'active',
                plan: 'premium',
                startDate: new Date(),
                endDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
                autoRenew: true
            },
            isOnline: true,
            isVisible: true,
            stats: {
                totalBookings: 450,
                completedBookings: 432,
                cancelledBookings: 18,
                totalEarnings: 2640000
            }
        });

        console.log('✓ Beautician created:', beauticianUser.email);
        console.log('  Business:', beautician.businessName);
        console.log('  Service Type: en-route\n');

        // Create Client User
        console.log('Creating Client account...');
        const clientUser = await User.create({
            email: 'client@test.com',
            password: 'password123',
            role: 'client',
            firstName: 'Jane',
            lastName: 'Wambui',
            phone: '+254734567890',
            avatar: 'https://i.pravatar.cc/150?img=5',
            isActive: true,
            isVerified: true
        });

        console.log('✓ Client created:', clientUser.email);

        // Create Admin User
        console.log('Creating Admin account...');
        const adminUser = await User.create({
            email: 'admin@test.com',
            password: 'password123',
            role: 'admin',
            firstName: 'Super',
            lastName: 'Admin',
            phone: '+254700000000',
            avatar: 'https://i.pravatar.cc/150?img=15',
            isActive: true,
            isVerified: true
        });
        console.log('✓ Admin created:', adminUser.email);

        console.log('\n✅ Test data seeded successfully!\n');
        console.log('═══════════════════════════════════════');
        console.log('Test Accounts:');
        console.log('═══════════════════════════════════════');
        console.log('Admin:');
        console.log('  Email: admin@test.com');
        console.log('  Password: password123');
        console.log('  Dashboard: /admin/dashboard');
        console.log('');
        console.log('Provider (On-Site):');
        console.log('  Email: provider@test.com');
        console.log('  Password: password123');
        console.log('  Dashboard: /provider/dashboard');
        console.log('');
        console.log('Beautician (En-Route):');
        console.log('  Email: beautician@test.com');
        console.log('  Password: password123');
        console.log('  Dashboard: /beautician/dashboard');
        console.log('');
        console.log('Client (Account Optional):');
        console.log('  Email: client@test.com');
        console.log('  Password: password123');
        console.log('  Dashboard: /client/dashboard');
        console.log('═══════════════════════════════════════\n');

    } catch (error) {
        console.error('❌ Error seeding test data:', error);
        throw error;
    } finally {
        await sequelize.close();
    }
}

// Run the seed function
seedTestData();
