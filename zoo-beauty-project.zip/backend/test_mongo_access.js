const { connectDB } = require('./config/mongodb');
const { User } = require('./models');

async function testMongoAccess() {
    try {
        // Connect to MongoDB
        console.log('Connecting to MongoDB...');
        const connected = await connectDB();
        
        if (!connected) {
            console.error('Failed to connect to MongoDB');
            process.exit(1);
        }
        
        console.log('Successfully connected to MongoDB');
        
        // Test creating a user
        console.log('Creating a test user...');
        const user = new User({
            email: 'test@example.com',
            password: 'password123',
            role: 'client',
            firstName: 'Test',
            lastName: 'User',
            phone: '1234567890'
        });
        
        await user.save();
        console.log('User created successfully:', user._id);
        
        // Test finding the user
        console.log('Finding the test user...');
        const foundUser = await User.findOne({ email: 'test@example.com' });
        console.log('User found:', foundUser.email, foundUser.firstName, foundUser.lastName);
        
        console.log('✅ User test passed! MongoDB data access is working correctly.');
        process.exit(0);
    } catch (error) {
        console.error('❌ Test failed:', error.message);
        console.error('Full error:', error);
        process.exit(1);
    }
}

testMongoAccess();