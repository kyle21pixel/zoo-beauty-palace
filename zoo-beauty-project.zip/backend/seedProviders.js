const { sequelize } = require('./config/database');
const { User, Provider } = require('./models');
const bcrypt = require('bcryptjs');
require('dotenv').config();
const crypto = require('crypto');

const seedProviders = async () => {
    try {
        await sequelize.authenticate();
        console.log('Database Connected...');

        // Sync models
        await sequelize.sync({ alter: true });
        console.log('Models synced...');

        // Create provider users (Kenyan Providers)
        const providerUsersData = [
            { firstName: 'Wanjiku', lastName: 'Kimani', email: 'wanjiku@example.com', phone: '+254712345678' },
            { firstName: 'Otieno', lastName: 'Juma', email: 'otieno@example.com', phone: '+254723456789' },
            { firstName: 'Amina', lastName: 'Hassan', email: 'amina@example.com', phone: '+254734567890' },
            { firstName: 'Grace', lastName: 'Muthoni', email: 'grace@example.com', phone: '+254745678901' },
            { firstName: 'Kevin', lastName: 'Mwangi', email: 'kevin@example.com', phone: '+254756789012' },
            { firstName: 'Zainab', lastName: 'Ali', email: 'zainab@example.com', phone: '+254767890123' },
            { firstName: 'Peter', lastName: 'Njoroge', email: 'peter@example.com', phone: '+254778901234' },
            { firstName: 'Lucy', lastName: 'Achieng', email: 'lucy@example.com', phone: '+254789012345' },
            { firstName: 'Fatuma', lastName: 'Mohamed', email: 'fatuma@example.com', phone: '+254790123456' },
            { firstName: 'Esther', lastName: 'Wambui', email: 'esther@example.com', phone: '+254701234567' }
        ];

        const createdUsers = [];
        const passwordHash = await bcrypt.hash('password123', 10);

        for (const userData of providerUsersData) {
            const existingUser = await User.findOne({ where: { email: userData.email } });
            if (!existingUser) {
                const user = await User.create({
                    ...userData,
                    password: passwordHash,
                    role: 'provider',
                    isActive: true,
                    isVerified: true
                });
                createdUsers.push(user);
                console.log(`Created user: ${user.email}`);
            } else {
                createdUsers.push(existingUser);
                console.log(`User already exists: ${existingUser.email}`);
            }
        }

        // Create provider profiles
        const providersData = [
            {
                userId: createdUsers[0].id,
                businessName: 'Wanjiku\'s Beauty Hub',
                bio: 'Top-rated makeup artist in Nairobi specializing in bridal and event makeup. I bring out your inner glow.',
                specializations: ['Makeup', 'Bridal'],
                location: { type: 'Point', coordinates: [36.8219, -1.2921] },
                serviceType: 'both',
                services: [
                    { name: 'Bridal Makeup', description: 'Complete bridal package with trial.', duration: 120, price: 15000, category: 'Makeup' },
                    { name: 'Evening Glam', description: 'Perfect for dinners and events.', duration: 60, price: 5000, category: 'Makeup' }
                ],
                portfolio: [{ id: crypto.randomBytes(16).toString('hex'), type: 'image', url: 'https://images.unsplash.com/photo-1487412912498-0447578fcca8?w=400', caption: 'Bridal Glow' }],
                rating: { average: 4.9, count: 150 },
                stats: { totalBookings: 300, completedBookings: 295, totalEarnings: 1500000 },
                isVisible: true
            },
            {
                userId: createdUsers[1].id,
                businessName: 'Juma Cuts',
                bio: 'Professional barber offering clean cuts, beard trims, and hot towel shaves in Kisumu.',
                specializations: ['Barbering', 'Grooming'],
                location: { type: 'Point', coordinates: [34.7617, -0.1022] },
                serviceType: 'studio',
                services: [
                    { name: 'Standard Haircut', description: 'Clean cut with clippers and scissors.', duration: 45, price: 500, category: 'Barbering' },
                    { name: 'Beard Trim', description: 'Shaping and lining.', duration: 30, price: 300, category: 'Barbering' }
                ],
                portfolio: [{ id: crypto.randomBytes(16).toString('hex'), type: 'image', url: 'https://images.unsplash.com/photo-1503951914875-452162b0f3f1?w=400', caption: 'Fade Cut' }],
                rating: { average: 4.8, count: 95 },
                stats: { totalBookings: 200, completedBookings: 198, totalEarnings: 100000 },
                isVisible: true
            },
            {
                userId: createdUsers[2].id,
                businessName: 'Amina Henna & Spa',
                bio: 'Traditional Swahili henna art and relaxing spa treatments in the heart of Mombasa.',
                specializations: ['Henna', 'Spa', 'Massage'],
                location: { type: 'Point', coordinates: [39.6682, -4.0435] },
                serviceType: 'both',
                services: [
                    { name: 'Bridal Henna', description: 'Intricate designs for hands and feet.', duration: 180, price: 8000, category: 'Henna' },
                    { name: 'Full Body Massage', description: 'Relaxing Swedish massage.', duration: 60, price: 3000, category: 'Spa' }
                ],
                portfolio: [{ id: crypto.randomBytes(16).toString('hex'), type: 'image', url: 'https://images.unsplash.com/photo-1604654894610-df63bc536371?w=400', caption: 'Henna Art' }],
                rating: { average: 5.0, count: 210 },
                stats: { totalBookings: 400, completedBookings: 390, totalEarnings: 1200000 },
                isVisible: true
            },
            {
                userId: createdUsers[3].id,
                businessName: 'Graceful Braids',
                bio: 'Neat and painless braiding services. Specializing in knotless braids and cornrows.',
                specializations: ['Braiding', 'Hair Styling'],
                location: { type: 'Point', coordinates: [36.8219, -1.2921] },
                serviceType: 'studio',
                services: [
                    { name: 'Knotless Braids', description: 'Medium size knotless braids.', duration: 300, price: 4500, category: 'Braiding' },
                    { name: 'Cornrows', description: 'Simple lines.', duration: 90, price: 1500, category: 'Braiding' }
                ],
                portfolio: [{ id: crypto.randomBytes(16).toString('hex'), type: 'image', url: 'https://images.unsplash.com/photo-1580618672591-eb180b1a973f?w=400', caption: 'Knotless Braids' }],
                rating: { average: 4.7, count: 180 },
                stats: { totalBookings: 350, completedBookings: 345, totalEarnings: 1575000 },
                isVisible: true
            },
            {
                userId: createdUsers[4].id,
                businessName: 'Kev\'s Mobile Barber',
                bio: 'Convenient mobile barber services. I come to your home or office in Nairobi.',
                specializations: ['Barbering', 'Mobile Service'],
                location: { type: 'Point', coordinates: [36.8219, -1.2921] },
                serviceType: 'mobile',
                services: [
                    { name: 'House Call Haircut', description: 'Premium haircut at your location.', duration: 60, price: 1500, category: 'Barbering' },
                    { name: 'Beard Grooming', description: 'Detailed beard care.', duration: 30, price: 800, category: 'Barbering' }
                ],
                portfolio: [{ id: crypto.randomBytes(16).toString('hex'), type: 'image', url: 'https://images.unsplash.com/photo-1622286342621-4bd786c2447c?w=400', caption: 'Mobile Setup' }],
                rating: { average: 4.9, count: 60 },
                stats: { totalBookings: 120, completedBookings: 118, totalEarnings: 180000 },
                isVisible: true
            },
            {
                userId: createdUsers[5].id,
                businessName: 'Zainab Aesthetics',
                bio: 'Advanced skincare treatments including facials, chemical peels, and microdermabrasion.',
                specializations: ['Skincare', 'Facials'],
                location: { type: 'Point', coordinates: [39.6682, -4.0435] },
                serviceType: 'studio',
                services: [
                    { name: 'Deep Cleansing Facial', description: 'Thorough cleanse and extraction.', duration: 75, price: 4000, category: 'Skincare' },
                    { name: 'Chemical Peel', description: 'Skin resurfacing treatment.', duration: 45, price: 6000, category: 'Skincare' }
                ],
                portfolio: [{ id: crypto.randomBytes(16).toString('hex'), type: 'image', url: 'https://images.unsplash.com/photo-1570172619644-dfd03ed5d881?w=400', caption: 'Facial Treatment' }],
                rating: { average: 4.8, count: 110 },
                stats: { totalBookings: 220, completedBookings: 215, totalEarnings: 880000 },
                isVisible: true
            },
            {
                userId: createdUsers[6].id,
                businessName: 'Njoro\'s Nail Bar',
                bio: 'The best acrylics and gel polish in Nakuru. Creative designs and durable finish.',
                specializations: ['Nails', 'Manicure', 'Pedicure'],
                location: { type: 'Point', coordinates: [36.0800, -0.3031] },
                serviceType: 'studio',
                services: [
                    { name: 'Acrylic Full Set', description: 'Sculpted acrylics with gel polish.', duration: 120, price: 2500, category: 'Nails' },
                    { name: 'Gel Pedicure', description: 'Relaxing pedicure with gel polish.', duration: 60, price: 1500, category: 'Nails' }
                ],
                portfolio: [{ id: crypto.randomBytes(16).toString('hex'), type: 'image', url: 'https://images.unsplash.com/photo-1632345031435-8727f6897d53?w=400', caption: 'Nail Art' }],
                rating: { average: 4.6, count: 85 },
                stats: { totalBookings: 170, completedBookings: 165, totalEarnings: 425000 },
                isVisible: true
            },
            {
                userId: createdUsers[7].id,
                businessName: 'Lucy\'s Locs',
                bio: 'Specialist in dreadlocks installation, maintenance, and styling in Kisumu.',
                specializations: ['Dreadlocks', 'Natural Hair'],
                location: { type: 'Point', coordinates: [34.7617, -0.1022] },
                serviceType: 'studio',
                services: [
                    { name: 'Locs Retwist', description: 'Neat retwist and style.', duration: 90, price: 2000, category: 'Hair' },
                    { name: 'Starter Locs', description: 'Starting new locs.', duration: 180, price: 4000, category: 'Hair' }
                ],
                portfolio: [{ id: crypto.randomBytes(16).toString('hex'), type: 'image', url: 'https://images.unsplash.com/photo-1519699047748-de8e457a634e?w=400', caption: 'Locs Style' }],
                rating: { average: 4.9, count: 130 },
                stats: { totalBookings: 260, completedBookings: 255, totalEarnings: 520000 },
                isVisible: true
            },
            {
                userId: createdUsers[8].id,
                businessName: 'Swahili Bridal Glam',
                bio: 'Exquisite bridal makeup and styling for Swahili weddings in Mombasa.',
                specializations: ['Makeup', 'Bridal'],
                location: { type: 'Point', coordinates: [39.6682, -4.0435] },
                serviceType: 'mobile',
                services: [
                    { name: 'Nikah Makeup', description: 'Soft and elegant look for Nikah.', duration: 90, price: 10000, category: 'Makeup' },
                    { name: 'Wedding Reception Glam', description: 'Bold and beautiful for the reception.', duration: 90, price: 12000, category: 'Makeup' }
                ],
                portfolio: [{ id: crypto.randomBytes(16).toString('hex'), type: 'image', url: 'https://images.unsplash.com/photo-1596462502278-27bfdd403348?w=400', caption: 'Bridal Makeup' }],
                rating: { average: 5.0, count: 100 },
                stats: { totalBookings: 150, completedBookings: 148, totalEarnings: 1500000 },
                isVisible: true
            },
            {
                userId: createdUsers[9].id,
                businessName: 'Essie\'s Hair Studio',
                bio: 'Premium wigs and weaves installation. Custom wig making services available.',
                specializations: ['Wigs', 'Weaves', 'Hair Styling'],
                location: { type: 'Point', coordinates: [36.8219, -1.2921] },
                serviceType: 'studio',
                services: [
                    { name: 'Wig Installation', description: 'Melting the lace for a natural look.', duration: 90, price: 3500, category: 'Hair' },
                    { name: 'Sew-in Weave', description: 'Traditional sew-in with leave out.', duration: 150, price: 4500, category: 'Hair' }
                ],
                portfolio: [{ id: crypto.randomBytes(16).toString('hex'), type: 'image', url: 'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?w=400', caption: 'Wig Install' }],
                rating: { average: 4.8, count: 175 },
                stats: { totalBookings: 320, completedBookings: 315, totalEarnings: 1120000 },
                isVisible: true
            }
        ];

        for (const providerData of providersData) {
            const existingProvider = await Provider.findOne({ where: { userId: providerData.userId } });
            if (!existingProvider) {
                const provider = await Provider.create(providerData);
                console.log(`Created provider: ${providerData.businessName}`);
            } else {
                console.log(`Provider already exists: ${providerData.businessName}`);
            }
        }

        console.log('\n✅ Seed completed successfully!');
        process.exit(0);
    } catch (error) {
        console.error('Error seeding providers:', error);
        process.exit(1);
    }
};

seedProviders();
