const mongoose = require('mongoose');
const User = require('./models/User.mongo');
const Provider = require('./models/Provider.mongo');
const Booking = require('./models/Booking.mongo');
const { connectDB } = require('./config/mongodb');

// Connect to database
connectDB();

async function testBooking() {
  try {
    console.log('Testing booking creation...\n');
    
    // Find our test users
    const client = await User.findOne({ email: 'testclient@example.com' });
    const provider = await User.findOne({ email: 'testprovider@example.com' });
    const providerProfile = await Provider.findOne({ userId: provider._id });
    
    if (!client || !provider || !providerProfile) {
      console.log('❌ Required users not found');
      mongoose.connection.close();
      return;
    }
    
    console.log(`Found client: ${client.firstName} ${client.lastName}`);
    console.log(`Found provider: ${provider.firstName} ${provider.lastName}`);
    console.log(`Provider business: ${providerProfile.businessName}\n`);
    
    // Create a test booking
    const bookingData = {
      bookingNumber: 'ZB-20251221-001', // Manual booking number
      clientId: client._id,
      providerId: providerProfile._id,
      service: {
        name: 'Makeup Application',
        description: 'Professional makeup application for special occasions',
        price: 75.00,
        duration: 60 // minutes
      },
      scheduledDate: new Date(Date.now() + 24 * 60 * 60 * 1000), // Tomorrow
      scheduledTime: '14:30',
      location: {
        type: 'Point',
        coordinates: [-118.2437, 34.0522], // Los Angeles coordinates
        address: 'Client Address, City, State'
      },
      serviceType: 'studio',
      status: 'pending',
      payment: {
        amount: 75.00,
        currency: 'USD',
        status: 'pending',
        platformFee: 7.50, // 10% of 75.00
        providerEarnings: 67.50 // 75.00 - 7.50
      },
      timeline: [{
        status: 'pending',
        timestamp: new Date(),
        note: 'Booking created'
      }],
      notes: 'Please arrive 10 minutes early'
    };
    
    const booking = new Booking(bookingData);
    await booking.save();
    
    console.log('✅ Booking created successfully!');
    console.log(`Booking ID: ${booking._id}`);
    console.log(`Booking Number: ${booking.bookingNumber}`);
    console.log(`Service: ${booking.service.name}`);
    console.log(`Price: $${booking.service.price}`);
    console.log(`Date: ${booking.scheduledDate.toDateString()}`);
    console.log(`Time: ${booking.scheduledTime}`);
    console.log(`Status: ${booking.status}\n`);
    
    // Close connection
    mongoose.connection.close();
    
  } catch (error) {
    console.log('❌ Booking failed with error:', error.message);
    mongoose.connection.close();
  }
}

// Run the test
testBooking();