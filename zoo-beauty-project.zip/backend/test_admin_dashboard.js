const mongoose = require('mongoose');
const User = require('./models/User.mongo');
const { connectDB } = require('./config/mongodb');

// Connect to database
connectDB();

async function testAdminDashboard() {
  try {
    console.log('Testing admin dashboard access to users...\n');
    
    // Get all users (similar to what admin dashboard would do)
    const users = await User.find({}, { password: 0 }) // Exclude password field
      .sort({ createdAt: -1 })
      .limit(20);
    
    console.log(`Found ${users.length} users:`);
    
    users.forEach((user, index) => {
      console.log(`${index + 1}. ${user.firstName} ${user.lastName} (${user.email}) - ${user.role}`);
      console.log(`   Profile Complete: ${user.isProfileComplete} | Active: ${user.isActive}`);
      console.log(`   Created: ${user.createdAt.toLocaleString()}\n`);
    });
    
    // Get counts by role
    const userCounts = await User.aggregate([
      {
        $group: {
          _id: '$role',
          count: { $sum: 1 }
        }
      }
    ]);
    
    console.log('User Counts by Role:');
    userCounts.forEach(roleCount => {
      console.log(`  ${roleCount._id}: ${roleCount.count}`);
    });
    
    // Close connection
    mongoose.connection.close();
    
  } catch (error) {
    console.log('❌ Error accessing users:', error.message);
    mongoose.connection.close();
  }
}

// Run the test
testAdminDashboard();