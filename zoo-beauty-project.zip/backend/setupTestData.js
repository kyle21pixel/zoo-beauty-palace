const { sequelize } = require('./config/database');
const User = require('./models/User');
const Provider = require('./models/Provider');
require('dotenv').config();

const setupTestData = async () => {
    try {
        await sequelize.authenticate();
        console.log('Database connected...');

        // Clear existing data
        console.log('Clearing existing data...');
        await sequelize.sync({ force: true });
        console.log('All tables cleared.');

        // Create Admin user
        console.log('Creating Admin user...');
        const admin = await User.create({
            firstName: 'Admin',
            lastName: 'User',
            email: 'admin@zoobeauty.com',
            password: 'admin123',
            phone: '+254700000000',
            role: 'admin',
            isActive: true,
            isVerified: true
        });
        console.log('✅ Admin user created');

        // Create Provider user
        console.log('Creating Provider user...');
        const providerUser = await User.create({
            firstName: 'Provider',
            lastName: 'Salon',
            email: 'provider@zoobeauty.com',
            password: 'provider123',
            phone: '+254700000001',
            role: 'provider',
            isActive: true,
            isVerified: true
        });

        // Create Provider profile
        const provider = await Provider.create({
            userId: providerUser.id,
            businessName: 'Test Salon',
            serviceType: 'studio',
            bio: 'A test salon for development purposes',
            address: '123 Test Street',
            city: 'Nairobi',
            isVisible: true,
            isOnline: true
        });
        console.log('✅ Provider user and profile created');

        // Create Beautician user
        console.log('Creating Beautician user...');
        const beauticianUser = await User.create({
            firstName: 'Beautician',
            lastName: 'Stylist',
            email: 'beautician@zoobeauty.com',
            password: 'beautician123',
            phone: '+254700000002',
            role: 'beautician',
            isActive: true,
            isVerified: true
        });

        // Create Beautician profile (linked to the provider)
        const beautician = await Provider.create({
            userId: beauticianUser.id,
            businessName: 'Test Beautician',
            serviceType: 'mobile',
            bio: 'A test beautician for development purposes',
            address: '456 Test Avenue',
            city: 'Nairobi',
            isVisible: true,
            isOnline: true
        });
        console.log('✅ Beautician user and profile created');

        console.log('\n=== TEST DATA SETUP COMPLETE ===');
        console.log('\nLogin Credentials:');
        console.log('Admin: admin@zoobeauty.com / admin123');
        console.log('Provider: provider@zoobeauty.com / provider123');
        console.log('Beautician: beautician@zoobeauty.com / beautician123');
        console.log('\nYou can now perform end-to-end testing!');

        process.exit(0);
    } catch (error) {
        console.error('Error setting up test data:', error);
        process.exit(1);
    }
};

setupTestData();