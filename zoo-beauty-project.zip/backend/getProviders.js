const { Sequelize } = require('sequelize');
const path = require('path');

const sequelize = new Sequelize({
    dialect: 'sqlite',
    storage: path.join(__dirname, 'database.sqlite'),
    logging: false
});

async function getProviders() {
    try {
        const users = await sequelize.query(
            'SELECT id, email, firstName, lastName, role, isActive FROM users WHERE role = "provider" LIMIT 10',
            { type: sequelize.QueryTypes.SELECT }
        );

        console.log('\n=== PROVIDER ACCOUNTS ===\n');
        if (users.length === 0) {
            console.log('❌ No provider accounts found.');
            console.log('\n💡 To create a provider account:');
            console.log('   1. Go to http://localhost:5175/register');
            console.log('   2. Select "Provider" as account type');
            console.log('   3. Fill in the registration form\n');
        } else {
            users.forEach((user, index) => {
                console.log(`${index + 1}. 📧 Email: ${user.email}`);
                console.log(`   👤 Name: ${user.firstName} ${user.lastName}`);
                console.log(`   ✅ Status: ${user.isActive ? 'Active' : 'Inactive'}`);
                console.log(`   🔑 Password: Use the password you set during registration\n`);
            });

            console.log('💡 Login at: http://localhost:5175/login\n');
        }

        process.exit(0);
    } catch (error) {
        console.error('❌ Error:', error.message);
        process.exit(1);
    }
}

getProviders();
