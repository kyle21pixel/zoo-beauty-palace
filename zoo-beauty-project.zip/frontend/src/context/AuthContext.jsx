import { createContext, useState, useContext, useEffect } from 'react';
import api from '../lib/axios';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
    const [user, setUser] = useState(null);
    const [loading, setLoading] = useState(true);

    // DEV MODE: Disabled - Using real authentication
    // useEffect(() => {
    //     // Default to Provider role for UI testing. Change 'role' to 'admin' or 'beautician' to test other dashboards.
    //     const mockUser = {
    //         id: 1,
    //         role: 'provider',
    //         firstName: 'Demo',
    //         lastName: 'Provider',
    //         email: 'provider@test.com',
    //         phone: '+254712345678',
    //         avatar: 'https://i.pravatar.cc/150?img=12',
    //         isActive: true,
    //         isVerified: true
    //     };

    //     console.log('DEV MODE: Authentication bypassed. Logged in as:', mockUser.role);
    //     setUser(mockUser);
    //     setLoading(false);
    // }, []);

    // Original Auth Check - Enabled
    useEffect(() => {
        const checkAuth = async () => {
            const token = localStorage.getItem('token');
            if (token) {
                try {
                    const response = await api.get('/auth/me');
                    if (response.data.success) {
                        setUser(response.data.data.user);
                    } else {
                        localStorage.removeItem('token');
                        localStorage.removeItem('user');
                    }
                } catch (error) {
                    console.error('Auth check failed', error);
                    localStorage.removeItem('token');
                    localStorage.removeItem('user');
                }
            }
            setLoading(false);
        };

        checkAuth();
    }, []);

    const login = async (email, password) => {
        try {
            const response = await api.post('/auth/login', { email, password });

            if (response.data.success) {
                const { token, user } = response.data.data;

                localStorage.setItem('token', token);
                localStorage.setItem('user', JSON.stringify(user));
                setUser(user);
                return { success: true };
            } else {
                return { success: false, message: response.data.message };
            }
        } catch (error) {
            return {
                success: false,
                message: error.response?.data?.message || 'Login failed'
            };
        }
    };

    const logout = () => {
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        setUser(null);
    };

    return (
        <AuthContext.Provider value={{ user, setUser, login, logout, loading }}>
            {children}
        </AuthContext.Provider>
    );
};

export const useAuth = () => useContext(AuthContext);
