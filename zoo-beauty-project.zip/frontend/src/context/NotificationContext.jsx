import { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { io } from 'socket.io-client';
import { getNotifications } from '../services/notificationService';

const NotificationContext = createContext(null);

export const useNotification = () => {
    const context = useContext(NotificationContext);
    // Return default values if context is not available instead of throwing
    if (!context) {
        console.warn('useNotification used outside of NotificationProvider, returning defaults');
        return {
            notifications: [],
            unreadCount: 0,
            loading: false,
            fetchNotifications: () => {},
            markAsRead: () => {},
            markAllAsRead: () => {},
            addNotification: () => {}
        };
    }
    return context;
};

export const NotificationProvider = ({ children }) => {
    const [notifications, setNotifications] = useState([]);
    const [unreadCount, setUnreadCount] = useState(0);
    const [loading, setLoading] = useState(true);
    const [socket, setSocket] = useState(null);

    // Fetch notifications from API
    const fetchNotifications = useCallback(async () => {
        try {
            setLoading(true);
            const response = await getNotifications({ unreadOnly: true });
            if (response.success) {
                setNotifications(response.data.notifications);
                setUnreadCount(response.data.notifications.length);
            }
        } catch (error) {
            console.error('Error fetching notifications:', error);
        } finally {
            setLoading(false);
        }
    }, []);

    // Mark a notification as read
    const markAsRead = useCallback(async (id) => {
        try {
            setNotifications(prev => prev.map(notification => 
                notification.id === id ? { ...notification, isRead: true } : notification
            ));
            setUnreadCount(prev => prev > 0 ? prev - 1 : 0);
        } catch (error) {
            console.error('Error marking notification as read:', error);
        }
    }, []);

    // Mark all notifications as read
    const markAllAsRead = useCallback(async () => {
        try {
            setNotifications(prev => prev.map(notification => ({ ...notification, isRead: true })));
            setUnreadCount(0);
        } catch (error) {
            console.error('Error marking all notifications as read:', error);
        }
    }, []);

    // Add a new notification
    const addNotification = useCallback((notification) => {
        setNotifications(prev => [notification, ...prev]);
        setUnreadCount(prev => prev + 1);
    }, []);

    // Initialize WebSocket connection
    useEffect(() => {
        // Get the user from localStorage or auth context
        let user = null;
        try {
            user = JSON.parse(localStorage.getItem('user') || 'null');
        } catch (e) {
            console.warn('Could not parse user from localStorage:', e);
        }
        
        let newSocket = null;
        
        if (user && user.id) {
            try {
                // Initialize socket connection
                newSocket = io(import.meta.env.VITE_API_URL || 'http://localhost:5000', {
                    reconnection: true,
                    reconnectionAttempts: 3,
                    reconnectionDelay: 1000,
                    timeout: 5000
                });
                setSocket(newSocket);
                
                // Join user's room
                newSocket.emit('join', user.id);
                
                // Listen for new notifications
                newSocket.on('new_notification', (notification) => {
                    addNotification(notification);
                });
                
                // Listen for notification updates
                newSocket.on('notification_updated', (data) => {
                    markAsRead(data.notificationId);
                });
                
                // Listen for all notifications read
                newSocket.on('all_notifications_read', () => {
                    markAllAsRead();
                });
                
                // Handle socket errors gracefully
                newSocket.on('connect_error', (error) => {
                    console.warn('Socket connection error:', error.message);
                });
            } catch (error) {
                console.warn('Socket initialization failed:', error);
            }
        }
        
        // Fetch initial notifications (works even without socket)
        fetchNotifications();
        
        return () => {
            if (newSocket) {
                newSocket.disconnect();
            }
        };
    }, []);  // Empty dependency array - run only once on mount

    return (
        <NotificationContext.Provider value={{
            notifications,
            unreadCount,
            loading,
            fetchNotifications,
            markAsRead,
            markAllAsRead,
            addNotification
        }}>
            {children}
        </NotificationContext.Provider>
    );
};