import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from './context/AuthContext';
import { ToastProvider } from './context/ToastContext';
import { NotificationProvider } from './context/NotificationContext';
import ErrorBoundary from './components/ErrorBoundary';
import LandingPage from './pages/LandingPage';
// LoginPage removed as per requirements
import AdminLoginPage from './pages/admin/AdminLoginPage';
import RegisterPage from './pages/RegisterPage';
// Client Dashboard removed as per requirements
import ProviderDashboard from './pages/provider/ProviderDashboard';
import AddProductPage from './pages/provider/AddProductPage';
import AddServicePage from './pages/provider/AddServicePage';
import AddPortfolioPage from './pages/provider/AddPortfolioPage';
import AddStaffPage from './pages/provider/AddStaffPage';
import BeauticianDashboard from './pages/beautician/BeauticianDashboard';
import AdminDashboard from './pages/admin/AdminDashboard';
import SearchProviders from './pages/client/SearchProviders';
import ProviderProfile from './pages/ProviderProfile';
import ServiceProvidersPage from './pages/ServiceProvidersPage';
import ServicesPage from './pages/ServicesPage';
import OnRouteServices from './pages/OnRouteServices';
import AboutPage from './pages/AboutPage';
import JournalPage from './pages/JournalPage';
import ProtectedRoute from './components/ProtectedRoute';
import DevRoleSwitcher from './components/DevRoleSwitcher';
import './App.css';

// Redirect component for authenticated users
const RedirectIfAuthenticated = ({ children }) => {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div style={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        height: '100vh',
        fontSize: '1.5rem'
      }}>
        Loading...
      </div>
    );
  }

  if (user) {
    // Redirect to appropriate dashboard based on role
    if (user.role === 'admin') {
      return <Navigate to="/admin/dashboard" replace />;
    } else if (user.role === 'provider') {
      return <Navigate to="/provider/dashboard" replace />;
    } else if (user.role === 'beautician') {
      return <Navigate to="/beautician/dashboard" replace />;
    } else {
      // Redirect clients to services page instead of client dashboard
      return <Navigate to="/services" replace />;
    }
  }

  return children;
};

function App() {
  return (
    <ErrorBoundary>
      <ToastProvider>
        <NotificationProvider>
          <Router>
            <DevRoleSwitcher />
            <Routes>
              {/* Public Routes */}
              <Route path="/" element={<LandingPage />} />
              {/* Login route removed as per requirements */}
              <Route
                path="/admin/login"
                element={
                  <RedirectIfAuthenticated>
                    <AdminLoginPage />
                  </RedirectIfAuthenticated>
                }
              />
              <Route
                path="/register"
                element={
                  <RedirectIfAuthenticated>
                    <RegisterPage />
                  </RedirectIfAuthenticated>
                }
              />
              <Route path="/services" element={<SearchProviders />} />
              <Route path="/choose-service" element={<ServicesPage />} />
              <Route path="/services/:serviceType" element={<ServiceProvidersPage />} />
              <Route path="/on-route-services" element={<OnRouteServices />} />
              <Route path="/providers/:id" element={<ProviderProfile />} />
              <Route path="/beautician/:id" element={<ProviderProfile />} />
              <Route path="/about" element={<AboutPage />} />
              <Route path="/journal" element={<JournalPage />} />
              <Route path="/journal/:id" element={<JournalPage />} />

              {/* Client Dashboard removed as per requirements */}
              <Route
                path="/client/dashboard"
                element={<Navigate to="/" replace />}
              />

              {/* Provider Routes - Protected */}
              <Route
                path="/provider/dashboard"
                element={
                  <ProtectedRoute allowedRoles={['provider']}>
                    <ProviderDashboard />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/provider/add-product"
                element={
                  <ProtectedRoute allowedRoles={['provider']}>
                    <AddProductPage />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/provider/add-service"
                element={
                  <ProtectedRoute allowedRoles={['provider']}>
                    <AddServicePage />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/provider/add-portfolio"
                element={
                  <ProtectedRoute allowedRoles={['provider']}>
                    <AddPortfolioPage />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/provider/add-staff"
                element={
                  <ProtectedRoute allowedRoles={['provider']}>
                    <AddStaffPage />
                  </ProtectedRoute>
                }
              />

              {/* Beautician Routes - Protected */}
              <Route
                path="/beautician/dashboard"
                element={
                  <ProtectedRoute allowedRoles={['beautician']}>
                    <BeauticianDashboard />
                  </ProtectedRoute>
                }
              />

              {/* Admin Routes - Protected */}
              <Route
                path="/admin/dashboard"
                element={
                  <ProtectedRoute allowedRoles={['admin']}>
                    <AdminDashboard />
                  </ProtectedRoute>
                }
              />

              {/* Catch all - redirect to home */}
              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
          </Router>
        </NotificationProvider>
      </ToastProvider>
    </ErrorBoundary>
  );
}

export default App;
