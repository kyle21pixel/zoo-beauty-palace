// Mock Data for ZOO beauty Palace Application
// This file contains all mock data used across dashboards

// ==================== USERS DATA ====================
export const mockUsers = [
    {
        _id: '1',
        firstName: 'Sarah',
        lastName: 'Kamau',
        email: 'sarah.kamau@example.com',
        phone: '+254712345678',
        role: 'client',
        avatar: 'https://i.pravatar.cc/150?img=1',
        isActive: true,
        createdAt: '2024-01-15T10:30:00Z',
        lastLogin: '2025-11-29T14:20:00Z'
    },
    {
        _id: '2',
        firstName: 'David',
        lastName: 'Ochieng',
        email: 'david.ochieng@example.com',
        phone: '+254723456789',
        role: 'provider',
        avatar: 'https://i.pravatar.cc/150?img=2',
        isActive: true,
        createdAt: '2024-02-10T09:15:00Z',
        lastLogin: '2025-11-30T08:45:00Z'
    },
    {
        _id: '3',
        firstName: 'Amina',
        lastName: 'Abdi',
        email: 'amina.abdi@example.com',
        phone: '+254734567890',
        role: 'provider',
        avatar: 'https://i.pravatar.cc/150?img=5',
        isActive: true,
        createdAt: '2024-03-05T11:20:00Z',
        lastLogin: '2025-11-30T10:30:00Z'
    },
    {
        _id: '4',
        firstName: 'James',
        lastName: 'Mwangi',
        email: 'james.mwangi@example.com',
        phone: '+254745678901',
        role: 'client',
        avatar: 'https://i.pravatar.cc/150?img=12',
        isActive: true,
        createdAt: '2024-04-20T15:45:00Z',
        lastLogin: '2025-11-28T16:10:00Z'
    },
    {
        _id: '5',
        firstName: 'Grace',
        lastName: 'Wanjiru',
        email: 'grace.wanjiru@example.com',
        phone: '+254756789012',
        role: 'provider',
        avatar: 'https://i.pravatar.cc/150?img=9',
        isActive: true,
        createdAt: '2024-05-12T13:30:00Z',
        lastLogin: '2025-11-30T09:15:00Z'
    },
    {
        _id: '6',
        firstName: 'Peter',
        lastName: 'Kimani',
        email: 'peter.kimani@example.com',
        phone: '+254767890123',
        role: 'client',
        avatar: 'https://i.pravatar.cc/150?img=13',
        isActive: false,
        createdAt: '2024-06-08T10:00:00Z',
        lastLogin: '2025-11-20T12:30:00Z'
    },
    {
        _id: '7',
        firstName: 'Lucy',
        lastName: 'Akinyi',
        email: 'lucy.akinyi@example.com',
        phone: '+254778901234',
        role: 'provider',
        avatar: 'https://i.pravatar.cc/150?img=10',
        isActive: true,
        createdAt: '2024-07-15T14:20:00Z',
        lastLogin: '2025-11-29T17:45:00Z'
    },
    {
        _id: '8',
        firstName: 'Michael',
        lastName: 'Otieno',
        email: 'michael.otieno@example.com',
        phone: '+254789012345',
        role: 'client',
        avatar: 'https://i.pravatar.cc/150?img=14',
        isActive: true,
        createdAt: '2024-08-22T09:30:00Z',
        lastLogin: '2025-11-30T11:20:00Z'
    }
];

// ==================== PROVIDERS DATA ====================
export const mockProviders = [
    {
        _id: 'p1',
        id: 'p1',
        userId: {
            _id: '2',
            firstName: 'David',
            lastName: 'Ochieng',
            email: 'david.ochieng@example.com',
            avatar: 'https://i.pravatar.cc/150?img=2',
            isActive: true
        },
        businessName: 'Glam by David',
        specializations: JSON.stringify(['Makeup', 'Bridal Makeup', 'Special Effects']),
        bio: 'Award-winning makeup artist with 10+ years of experience. Specializing in bridal and editorial makeup.',
        services: JSON.stringify([
            { name: 'Bridal Makeup', price: 8000, duration: 120 },
            { name: 'Event Makeup', price: 5000, duration: 90 },
            { name: 'Photoshoot Makeup', price: 6000, duration: 90 }
        ]),
        portfolio: JSON.stringify([
            'https://images.unsplash.com/photo-1487412912498-0447578fcca8?w=400',
            'https://images.unsplash.com/photo-1596462502278-27bfdd403348?w=400',
            'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?w=400',
            'https://images.unsplash.com/photo-1560066984-138dadb4c035?w=400'
        ]),
        location: JSON.stringify({ address: 'Westlands, Nairobi', lat: -1.2667, lng: 36.8167 }),
        rating: JSON.stringify({ average: 4.8, count: 156 }),
        availability: JSON.stringify({
            monday: ['09:00-17:00'],
            tuesday: ['09:00-17:00'],
            wednesday: ['09:00-17:00'],
            thursday: ['09:00-17:00'],
            friday: ['09:00-19:00'],
            saturday: ['10:00-18:00'],
            sunday: []
        }),
        isOnline: true,
        stats: {
            totalBookings: 342,
            completedBookings: 328,
            totalEarnings: 2640000,
            averageRating: 4.8
        },
        createdAt: '2024-02-10T09:15:00Z'
    },
    {
        _id: 'p2',
        id: 'p2',
        userId: {
            _id: '3',
            firstName: 'Amina',
            lastName: 'Abdi',
            email: 'amina.abdi@example.com',
            avatar: 'https://i.pravatar.cc/150?img=5',
            isActive: true
        },
        businessName: 'Amina\'s Hair Studio',
        specializations: JSON.stringify(['Hair Styling', 'Braiding', 'Wig Installation']),
        bio: 'Professional hair stylist specializing in natural hair care, braiding, and wig installations.',
        services: JSON.stringify([
            { name: 'Box Braids', price: 3500, duration: 180 },
            { name: 'Wig Installation', price: 4000, duration: 120 },
            { name: 'Hair Treatment', price: 2500, duration: 60 }
        ]),
        portfolio: JSON.stringify([
            'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?w=400',
            'https://images.unsplash.com/photo-1583900985737-6d0495555783?w=400',
            'https://images.unsplash.com/photo-1560066984-138dadb4c035?w=400',
            'https://images.unsplash.com/photo-1516975080664-ed2fc6a32937?w=400'
        ]),
        location: JSON.stringify({ address: 'Kilimani, Nairobi', lat: -1.2833, lng: 36.7833 }),
        rating: JSON.stringify({ average: 4.9, count: 203 }),
        availability: JSON.stringify({
            monday: ['08:00-18:00'],
            tuesday: ['08:00-18:00'],
            wednesday: ['08:00-18:00'],
            thursday: ['08:00-18:00'],
            friday: ['08:00-20:00'],
            saturday: ['09:00-19:00'],
            sunday: ['10:00-16:00']
        }),
        isOnline: true,
        stats: {
            totalBookings: 456,
            completedBookings: 445,
            totalEarnings: 1780000,
            averageRating: 4.9
        },
        createdAt: '2024-03-05T11:20:00Z'
    },
    {
        _id: 'p3',
        id: 'p3',
        userId: {
            _id: '5',
            firstName: 'Grace',
            lastName: 'Wanjiru',
            email: 'grace.wanjiru@example.com',
            avatar: 'https://i.pravatar.cc/150?img=9',
            isActive: true
        },
        businessName: 'Grace Nails & Spa',
        specializations: JSON.stringify(['Nail Art', 'Manicure', 'Pedicure']),
        bio: 'Certified nail technician offering premium nail care services and creative nail art designs.',
        services: JSON.stringify([
            { name: 'Gel Manicure', price: 1500, duration: 60 },
            { name: 'Acrylic Nails', price: 2500, duration: 90 },
            { name: 'Pedicure', price: 1200, duration: 45 }
        ]),
        portfolio: JSON.stringify([
            'https://images.unsplash.com/photo-1560066984-138dadb4c035?w=400',
            'https://images.unsplash.com/photo-1604654894610-df63bc536371?w=400',
            'https://images.unsplash.com/photo-1610992015732-2449b76344bc?w=400',
            'https://images.unsplash.com/photo-1519014816548-bf5fe059798b?w=400'
        ]),
        location: JSON.stringify({ address: 'Karen, Nairobi', lat: -1.3167, lng: 36.7000 }),
        rating: JSON.stringify({ average: 4.7, count: 178 }),
        availability: JSON.stringify({
            monday: ['09:00-18:00'],
            tuesday: ['09:00-18:00'],
            wednesday: ['09:00-18:00'],
            thursday: ['09:00-18:00'],
            friday: ['09:00-19:00'],
            saturday: ['10:00-17:00'],
            sunday: []
        }),
        isOnline: false,
        stats: {
            totalBookings: 289,
            completedBookings: 276,
            totalEarnings: 552000,
            averageRating: 4.7
        },
        createdAt: '2024-05-12T13:30:00Z'
    },
    {
        _id: 'p4',
        id: 'p4',
        userId: {
            _id: '7',
            firstName: 'Lucy',
            lastName: 'Akinyi',
            email: 'lucy.akinyi@example.com',
            avatar: 'https://i.pravatar.cc/150?img=10',
            isActive: true
        },
        businessName: 'Lucy\'s Skincare Clinic',
        specializations: JSON.stringify(['Facial Treatment', 'Skincare', 'Anti-Aging']),
        bio: 'Licensed esthetician providing professional skincare treatments and consultations.',
        services: JSON.stringify([
            { name: 'Deep Cleansing Facial', price: 3500, duration: 75 },
            { name: 'Anti-Aging Treatment', price: 5000, duration: 90 },
            { name: 'Acne Treatment', price: 4000, duration: 60 }
        ]),
        portfolio: JSON.stringify([
            'https://images.unsplash.com/photo-1570172619644-dfd03ed5d881?w=400',
            'https://images.unsplash.com/photo-1512496015851-a90fb38ba796?w=400',
            'https://images.unsplash.com/photo-1616394584738-fc6e612e71b9?w=400',
            'https://images.unsplash.com/photo-1559599101-f09722fb4948?w=400'
        ]),
        location: JSON.stringify({ address: 'Lavington, Nairobi', lat: -1.2833, lng: 36.7667 }),
        rating: JSON.stringify({ average: 4.9, count: 134 }),
        availability: JSON.stringify({
            monday: ['10:00-18:00'],
            tuesday: ['10:00-18:00'],
            wednesday: ['10:00-18:00'],
            thursday: ['10:00-18:00'],
            friday: ['10:00-18:00'],
            saturday: ['11:00-16:00'],
            sunday: []
        }),
        isOnline: true,
        stats: {
            totalBookings: 198,
            completedBookings: 192,
            totalEarnings: 864000,
            averageRating: 4.9
        },
        createdAt: '2024-07-15T14:20:00Z'
    }
];

// ==================== BOOKINGS DATA ====================
export const mockBookings = [
    {
        _id: 'b1',
        clientId: {
            _id: '1',
            firstName: 'Sarah',
            lastName: 'Kamau',
            email: 'sarah.kamau@example.com',
            avatar: 'https://i.pravatar.cc/150?img=1'
        },
        providerId: {
            _id: '2',
            firstName: 'David',
            lastName: 'Ochieng',
            businessName: 'Glam by David'
        },
        service: 'Bridal Makeup',
        date: '2025-12-05T10:00:00Z',
        time: '10:00 AM',
        duration: 120,
        amount: 8000,
        status: 'confirmed',
        location: 'Westlands, Nairobi',
        notes: 'Wedding makeup for outdoor ceremony',
        createdAt: '2025-11-25T14:30:00Z'
    },
    {
        _id: 'b2',
        clientId: {
            _id: '4',
            firstName: 'James',
            lastName: 'Mwangi',
            email: 'james.mwangi@example.com',
            avatar: 'https://i.pravatar.cc/150?img=12'
        },
        providerId: {
            _id: '3',
            firstName: 'Amina',
            lastName: 'Abdi',
            businessName: 'Amina\'s Hair Studio'
        },
        service: 'Box Braids',
        date: '2025-12-02T14:00:00Z',
        time: '2:00 PM',
        duration: 180,
        amount: 3500,
        status: 'pending',
        location: 'Kilimani, Nairobi',
        notes: 'Medium length box braids',
        createdAt: '2025-11-28T09:15:00Z'
    },
    {
        _id: 'b3',
        clientId: {
            _id: '8',
            firstName: 'Michael',
            lastName: 'Otieno',
            email: 'michael.otieno@example.com',
            avatar: 'https://i.pravatar.cc/150?img=14'
        },
        providerId: {
            _id: '5',
            firstName: 'Grace',
            lastName: 'Wanjiru',
            businessName: 'Grace Nails & Spa'
        },
        service: 'Gel Manicure',
        date: '2025-11-28T11:00:00Z',
        time: '11:00 AM',
        duration: 60,
        amount: 1500,
        status: 'completed',
        location: 'Karen, Nairobi',
        notes: 'French tips design',
        createdAt: '2025-11-20T16:45:00Z',
        completedAt: '2025-11-28T12:00:00Z'
    },
    {
        _id: 'b4',
        clientId: {
            _id: '1',
            firstName: 'Sarah',
            lastName: 'Kamau',
            email: 'sarah.kamau@example.com',
            avatar: 'https://i.pravatar.cc/150?img=1'
        },
        providerId: {
            _id: '7',
            firstName: 'Lucy',
            lastName: 'Akinyi',
            businessName: 'Lucy\'s Skincare Clinic'
        },
        service: 'Deep Cleansing Facial',
        date: '2025-12-01T15:00:00Z',
        time: '3:00 PM',
        duration: 75,
        amount: 3500,
        status: 'confirmed',
        location: 'Lavington, Nairobi',
        notes: 'First time client',
        createdAt: '2025-11-26T10:20:00Z'
    },
    {
        _id: 'b5',
        clientId: {
            _id: '4',
            firstName: 'James',
            lastName: 'Mwangi',
            email: 'james.mwangi@example.com',
            avatar: 'https://i.pravatar.cc/150?img=12'
        },
        providerId: {
            _id: '2',
            firstName: 'David',
            lastName: 'Ochieng',
            businessName: 'Glam by David'
        },
        service: 'Event Makeup',
        date: '2025-11-25T16:00:00Z',
        time: '4:00 PM',
        duration: 90,
        amount: 5000,
        status: 'completed',
        location: 'Westlands, Nairobi',
        notes: 'Corporate event',
        createdAt: '2025-11-18T13:30:00Z',
        completedAt: '2025-11-25T17:30:00Z'
    },
    {
        _id: 'b6',
        clientId: {
            _id: '8',
            firstName: 'Michael',
            lastName: 'Otieno',
            email: 'michael.otieno@example.com',
            avatar: 'https://i.pravatar.cc/150?img=14'
        },
        providerId: {
            _id: '3',
            firstName: 'Amina',
            lastName: 'Abdi',
            businessName: 'Amina\'s Hair Studio'
        },
        service: 'Wig Installation',
        date: '2025-11-22T10:00:00Z',
        time: '10:00 AM',
        duration: 120,
        amount: 4000,
        status: 'completed',
        location: 'Kilimani, Nairobi',
        notes: 'Lace front wig',
        createdAt: '2025-11-15T11:00:00Z',
        completedAt: '2025-11-22T12:00:00Z'
    },
    {
        _id: 'b7',
        clientId: {
            _id: '1',
            firstName: 'Sarah',
            lastName: 'Kamau',
            email: 'sarah.kamau@example.com',
            avatar: 'https://i.pravatar.cc/150?img=1'
        },
        providerId: {
            _id: '5',
            firstName: 'Grace',
            lastName: 'Wanjiru',
            businessName: 'Grace Nails & Spa'
        },
        service: 'Acrylic Nails',
        date: '2025-12-10T13:00:00Z',
        time: '1:00 PM',
        duration: 90,
        amount: 2500,
        status: 'pending',
        location: 'Karen, Nairobi',
        notes: 'Stiletto shape with rhinestones',
        createdAt: '2025-11-29T15:45:00Z'
    },
    {
        _id: 'b8',
        clientId: {
            _id: '4',
            firstName: 'James',
            lastName: 'Mwangi',
            email: 'james.mwangi@example.com',
            avatar: 'https://i.pravatar.cc/150?img=12'
        },
        providerId: {
            _id: '7',
            firstName: 'Lucy',
            lastName: 'Akinyi',
            businessName: 'Lucy\'s Skincare Clinic'
        },
        service: 'Anti-Aging Treatment',
        date: '2025-11-20T14:00:00Z',
        time: '2:00 PM',
        duration: 90,
        amount: 5000,
        status: 'completed',
        location: 'Lavington, Nairobi',
        notes: 'Follow-up session',
        createdAt: '2025-11-12T09:30:00Z',
        completedAt: '2025-11-20T15:30:00Z'
    }
];

// ==================== REVIEWS DATA ====================
export const mockReviews = [
    {
        _id: 'r1',
        bookingId: 'b3',
        clientId: {
            _id: '8',
            firstName: 'Michael',
            lastName: 'Otieno',
            avatar: 'https://i.pravatar.cc/150?img=14'
        },
        providerId: 'p3',
        rating: 5,
        comment: 'Excellent service! Grace is very professional and my nails look amazing. Highly recommend!',
        createdAt: '2025-11-28T13:00:00Z'
    },
    {
        _id: 'r2',
        bookingId: 'b5',
        clientId: {
            _id: '4',
            firstName: 'James',
            lastName: 'Mwangi',
            avatar: 'https://i.pravatar.cc/150?img=12'
        },
        providerId: 'p1',
        rating: 5,
        comment: 'David did an amazing job with my makeup for the corporate event. Very talented!',
        createdAt: '2025-11-25T18:00:00Z'
    },
    {
        _id: 'r3',
        bookingId: 'b6',
        clientId: {
            _id: '8',
            firstName: 'Michael',
            lastName: 'Otieno',
            avatar: 'https://i.pravatar.cc/150?img=14'
        },
        providerId: 'p2',
        rating: 5,
        comment: 'Amina is the best! My wig installation looks so natural. Will definitely book again.',
        createdAt: '2025-11-22T13:30:00Z'
    },
    {
        _id: 'r4',
        bookingId: 'b8',
        clientId: {
            _id: '4',
            firstName: 'James',
            lastName: 'Mwangi',
            avatar: 'https://i.pravatar.cc/150?img=12'
        },
        providerId: 'p4',
        rating: 5,
        comment: 'Lucy is very knowledgeable about skincare. My skin has improved so much!',
        createdAt: '2025-11-20T16:00:00Z'
    }
];

// ==================== DASHBOARD STATS ====================
export const mockDashboardStats = {
    admin: {
        totalUsers: 1247,
        totalProviders: 342,
        totalClients: 905,
        totalBookings: 5834,
        completedBookings: 5234,
        activeBookings: 456,
        totalRevenue: 46720000,
        platformFee: 4672000,
        pendingDisputes: 3,
        monthlyGrowth: {
            users: 12,
            bookings: 15,
            revenue: 18
        }
    },
    provider: {
        totalBookings: 342,
        completedBookings: 328,
        upcomingBookings: 8,
        cancelledBookings: 6,
        totalEarnings: 2640000,
        thisMonthEarnings: 384000,
        averageRating: 4.8,
        totalReviews: 156,
        responseRate: 98,
        completionRate: 96
    },
    client: {
        totalBookings: 12,
        upcomingBookings: 2,
        completedBookings: 9,
        cancelledBookings: 1,
        totalSpent: 58500,
        favoriteProviders: 3,
        reviewsGiven: 8
    }
};

// ==================== REVENUE DATA ====================
export const mockRevenueData = [
    { month: 'June', bookings: 3456, revenue: 2764800, platformFee: 276480 },
    { month: 'July', bookings: 3678, revenue: 2942400, platformFee: 294240 },
    { month: 'August', bookings: 3789, revenue: 3031200, platformFee: 303120 },
    { month: 'September', bookings: 3956, revenue: 3164800, platformFee: 316480 },
    { month: 'October', bookings: 4123, revenue: 3298400, platformFee: 329840 },
    { month: 'November', bookings: 4842, revenue: 3873600, platformFee: 387360 }
];

// ==================== DISPUTES DATA ====================
export const mockDisputes = [
    {
        _id: 'd1',
        bookingId: 'b2',
        reportedBy: {
            _id: '4',
            firstName: 'James',
            lastName: 'Mwangi'
        },
        reportedAgainst: {
            _id: '3',
            firstName: 'Amina',
            lastName: 'Abdi'
        },
        reason: 'Service not as described',
        description: 'The braiding style was different from what was agreed upon.',
        status: 'pending',
        createdAt: '2025-11-29T10:00:00Z'
    },
    {
        _id: 'd2',
        bookingId: 'b7',
        reportedBy: {
            _id: '1',
            firstName: 'Sarah',
            lastName: 'Kamau'
        },
        reportedAgainst: {
            _id: '5',
            firstName: 'Grace',
            lastName: 'Wanjiru'
        },
        reason: 'Late arrival',
        description: 'Provider arrived 45 minutes late without prior notice.',
        status: 'pending',
        createdAt: '2025-11-30T08:30:00Z'
    }
];

// ==================== NOTIFICATIONS DATA ====================
export const mockNotifications = [
    {
        _id: 'n1',
        userId: '2',
        type: 'booking',
        title: 'New Booking Request',
        message: 'Sarah Kamau has requested a Bridal Makeup service for Dec 5, 2025',
        read: false,
        createdAt: '2025-11-25T14:30:00Z'
    },
    {
        _id: 'n2',
        userId: '1',
        type: 'confirmation',
        title: 'Booking Confirmed',
        message: 'Your booking with David Ochieng has been confirmed for Dec 5, 2025',
        read: false,
        createdAt: '2025-11-25T15:00:00Z'
    },
    {
        _id: 'n3',
        userId: '3',
        type: 'review',
        title: 'New Review',
        message: 'Michael Otieno left you a 5-star review!',
        read: true,
        createdAt: '2025-11-22T13:30:00Z'
    }
];

// Helper function to get mock data based on user role
export const getMockDataForRole = (role) => {
    switch (role) {
        case 'admin':
            return {
                stats: mockDashboardStats.admin,
                users: mockUsers,
                providers: mockProviders,
                bookings: mockBookings,
                revenue: mockRevenueData,
                disputes: mockDisputes
            };
        case 'provider':
            return {
                stats: mockDashboardStats.provider,
                bookings: mockBookings.filter(b => b.providerId._id === '2'), // Example for provider ID 2
                reviews: mockReviews.filter(r => r.providerId === 'p1'),
                notifications: mockNotifications.filter(n => n.userId === '2')
            };
        case 'client':
            return {
                stats: mockDashboardStats.client,
                bookings: mockBookings.filter(b => b.clientId._id === '1'), // Example for client ID 1
                favoriteProviders: mockProviders.slice(0, 3),
                notifications: mockNotifications.filter(n => n.userId === '1')
            };
        default:
            return {};
    }
};

export default {
    mockUsers,
    mockProviders,
    mockBookings,
    mockReviews,
    mockDashboardStats,
    mockRevenueData,
    mockDisputes,
    mockNotifications,
    getMockDataForRole
};
