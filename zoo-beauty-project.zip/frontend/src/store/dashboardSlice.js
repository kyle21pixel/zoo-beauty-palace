import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  stats: {
    totalUsers: 0,
    totalProviders: 0,
    totalBookings: 0,
    platformFee: 0,
    totalRevenue: 0,
    pendingDisputes: 0
  },
  recentUsers: [],
  recentBookings: [],
  providers: [],
  bookings: [],
  users: [],
  loading: false,
  error: null
};

export const dashboardSlice = createSlice({
  name: 'dashboard',
  initialState,
  reducers: {
    setStats: (state, action) => {
      state.stats = action.payload;
    },
    setRecentUsers: (state, action) => {
      state.recentUsers = action.payload;
    },
    setRecentBookings: (state, action) => {
      state.recentBookings = action.payload;
    },
    setProviders: (state, action) => {
      state.providers = action.payload;
    },
    setBookings: (state, action) => {
      state.bookings = action.payload;
    },
    setUsers: (state, action) => {
      state.users = action.payload;
    },
    setLoading: (state, action) => {
      state.loading = action.payload;
    },
    setError: (state, action) => {
      state.error = action.payload;
    },
    // Real-time updates
    incrementTotalBookings: (state) => {
      state.stats.totalBookings += 1;
    },
    updatePlatformRevenue: (state, action) => {
      const { platformFee, totalRevenue } = action.payload;
      state.stats.platformFee += platformFee;
      state.stats.totalRevenue += totalRevenue;
    },
    addRecentBooking: (state, action) => {
      // Add to the beginning of the array and keep only 5 most recent
      state.recentBookings = [action.payload, ...state.recentBookings].slice(0, 5);
    },
    updateRecentBooking: (state, action) => {
      state.recentBookings = state.recentBookings.map(booking => 
        booking.id === action.payload.id ? action.payload : booking
      );
    }
  },
});

export const {
  setStats,
  setRecentUsers,
  setRecentBookings,
  setProviders,
  setBookings,
  setUsers,
  setLoading,
  setError,
  incrementTotalBookings,
  updatePlatformRevenue,
  addRecentBooking,
  updateRecentBooking
} = dashboardSlice.actions;

export default dashboardSlice.reducer;