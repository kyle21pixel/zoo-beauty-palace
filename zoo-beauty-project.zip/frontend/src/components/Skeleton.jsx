import './Skeleton.css';

// Single skeleton line
export const SkeletonLine = ({ width = '100%', height = '1rem' }) => (
    <div 
        className="skeleton skeleton-line" 
        style={{ width, height }}
    />
);

// Skeleton for text content
export const SkeletonText = ({ lines = 3, width = '100%' }) => (
    <div className="skeleton-text">
        {Array.from({ length: lines }).map((_, i) => (
            <SkeletonLine 
                key={i} 
                width={i === lines - 1 ? '70%' : width} 
            />
        ))}
    </div>
);

// Skeleton for avatar/circle
export const SkeletonAvatar = ({ size = '3rem' }) => (
    <div 
        className="skeleton skeleton-avatar" 
        style={{ width: size, height: size }}
    />
);

// Skeleton for stat card
export const SkeletonStatCard = () => (
    <div className="skeleton-stat-card card">
        <div className="skeleton-stat-icon skeleton" />
        <div className="skeleton-stat-content">
            <SkeletonLine width="60%" height="0.8rem" />
            <SkeletonLine width="80%" height="1.5rem" />
            <SkeletonLine width="40%" height="0.7rem" />
        </div>
    </div>
);

// Skeleton for table row
export const SkeletonTableRow = ({ columns = 4 }) => (
    <tr className="skeleton-row">
        {Array.from({ length: columns }).map((_, i) => (
            <td key={i}>
                <SkeletonLine width={`${60 + Math.random() * 30}%`} />
            </td>
        ))}
    </tr>
);

// Skeleton for table
export const SkeletonTable = ({ rows = 5, columns = 4 }) => (
    <div className="table-container">
        <table className="data-table skeleton-table">
            <thead>
                <tr>
                    {Array.from({ length: columns }).map((_, i) => (
                        <th key={i}>
                            <SkeletonLine width="70%" height="0.75rem" />
                        </th>
                    ))}
                </tr>
            </thead>
            <tbody>
                {Array.from({ length: rows }).map((_, i) => (
                    <SkeletonTableRow key={i} columns={columns} />
                ))}
            </tbody>
        </table>
    </div>
);

// Skeleton for card content
export const SkeletonCard = ({ hasHeader = true }) => (
    <div className="skeleton-card card">
        {hasHeader && (
            <div className="skeleton-card-header">
                <SkeletonLine width="30%" height="1.2rem" />
                <SkeletonLine width="15%" height="0.9rem" />
            </div>
        )}
        <div className="skeleton-card-body">
            <SkeletonText lines={3} />
        </div>
    </div>
);

// Loading state for stats grid
export const SkeletonStatsGrid = () => (
    <div className="stats-grid">
        <SkeletonStatCard />
        <SkeletonStatCard />
        <SkeletonStatCard />
        <SkeletonStatCard />
    </div>
);

// Loading state for dashboard overview
export const SkeletonDashboardOverview = () => (
    <div className="dashboard-content">
        <SkeletonStatsGrid />
        <div className="activity-grid">
            <div className="section card">
                <div className="section-header">
                    <SkeletonLine width="25%" height="1.2rem" />
                    <SkeletonLine width="10%" height="0.9rem" />
                </div>
                <SkeletonTable rows={5} columns={4} />
            </div>
            <div className="section card">
                <div className="section-header">
                    <SkeletonLine width="25%" height="1.2rem" />
                    <SkeletonLine width="10%" height="0.9rem" />
                </div>
                <SkeletonTable rows={5} columns={4} />
            </div>
        </div>
    </div>
);

export default {
    SkeletonLine,
    SkeletonText,
    SkeletonAvatar,
    SkeletonStatCard,
    SkeletonTableRow,
    SkeletonTable,
    SkeletonCard,
    SkeletonStatsGrid,
    SkeletonDashboardOverview
};
