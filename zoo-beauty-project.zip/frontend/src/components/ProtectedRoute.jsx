import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const ProtectedRoute = ({ children, allowedRoles = [] }) => {
    const { user, loading } = useAuth();

    if (loading) {
        return (
            <div style={{
                display: 'flex',
                justifyContent: 'center',
                alignItems: 'center',
                height: '100vh',
                fontSize: '1.5rem'
            }}>
                Loading...
            </div>
        );
    }

    if (!user) {
        return <Navigate to="/login" replace />;
    }

    // Check if user has required role
    if (allowedRoles.length > 0 && !allowedRoles.includes(user.role)) {
        // Redirect based on user's actual role
        if (user.role === 'admin') {
            return <Navigate to="/admin/dashboard" replace />;
        } else if (user.role === 'provider') {
            return <Navigate to="/provider/dashboard" replace />;
        } else if (user.role === 'beautician') {
            return <Navigate to="/beautician/dashboard" replace />;
        } else {
            // For clients or other roles, redirect to services page instead of client dashboard
            return <Navigate to="/services" replace />;
        }
    }

    return children;
};

export default ProtectedRoute;

