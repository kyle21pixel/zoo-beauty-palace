import React, { useState, useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';

// Fix for default marker icons in Leaflet
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

const DispatchMap = ({ pendingBookings, availableStaff, onAssignBooking }) => {
  // Default center for the map (Nairobi, Kenya)
  const defaultCenter = [-1.286389, 36.817223];
  const defaultZoom = 13;

  // Extract locations from bookings and staff
  const getLocations = () => {
    const locations = [];
    
    // Add booking locations
    pendingBookings.forEach(booking => {
      if (booking.location?.coordinates) {
        locations.push({
          id: booking.id,
          type: 'booking',
          lat: booking.location.coordinates.lat,
          lng: booking.location.coordinates.lng,
          data: booking
        });
      }
    });
    
    // Add staff locations
    availableStaff.forEach(staff => {
      if (staff.location?.coordinates) {
        locations.push({
          id: staff.id,
          type: 'staff',
          lat: staff.location.coordinates.lat,
          lng: staff.location.coordinates.lng,
          data: staff
        });
      }
    });
    
    return locations;
  };

  const locations = getLocations();

  return (
    <div style={{ height: '400px', width: '100%', borderRadius: '16px', overflow: 'hidden' }}>
      <MapContainer 
        center={defaultCenter} 
        zoom={defaultZoom} 
        style={{ height: '100%', width: '100%' }}
      >
        <TileLayer
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        />
        
        {locations.map(location => (
          <Marker 
            key={`${location.type}-${location.id}`}
            position={[location.lat, location.lng]}
          >
            <Popup>
              {location.type === 'booking' ? (
                <div>
                  <h4>Booking: {location.data.service?.name || 'Service'}</h4>
                  <p>Client: {location.data.client?.firstName} {location.data.client?.lastName}</p>
                  <p>Time: {location.data.scheduledTime}</p>
                  <button 
                    className="btn btn-primary btn-sm"
                    onClick={() => onAssignBooking(location.data.id)}
                    style={{ marginTop: '0.5rem' }}
                  >
                    Assign Staff
                  </button>
                </div>
              ) : (
                <div>
                  <h4>Staff: {location.data.firstName} {location.data.lastName}</h4>
                  <p>Rating: {location.data.rating?.toFixed(1) || 'N/A'}</p>
                  <p>Specializations: {location.data.specializations?.join(', ') || 'None'}</p>
                </div>
              )}
            </Popup>
          </Marker>
        ))}
      </MapContainer>
    </div>
  );
};

export default DispatchMap;