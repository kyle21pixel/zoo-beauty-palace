import React from 'react';
import { useAuth } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';

const DevRoleSwitcher = () => {
    const { setUser } = useAuth();
    const navigate = useNavigate();

    const switchRole = (role) => {
        const mockUsers = {
            admin: {
                id: 1,
                role: 'admin',
                firstName: 'Admin',
                lastName: 'User',
                email: 'admin@test.com',
                isActive: true,
                avatar: 'https://i.pravatar.cc/150?img=15'
            },
            provider: {
                id: 2,
                role: 'provider',
                firstName: 'Demo',
                lastName: 'Provider',
                email: 'provider@test.com',
                isActive: true,
                avatar: 'https://i.pravatar.cc/150?img=12',
                businessName: 'Glamour Spa'
            },
            beautician: {
                id: 3,
                role: 'beautician',
                firstName: 'Sarah',
                lastName: 'Styles',
                email: 'beautician@test.com',
                isActive: true,
                avatar: 'https://i.pravatar.cc/150?img=5',
                bio: 'Expert Mobile Beautician'
            },
            client: {
                id: 4,
                role: 'client',
                firstName: 'Jane',
                lastName: 'Doe',
                email: 'client@test.com',
                isActive: true,
                avatar: 'https://i.pravatar.cc/150?img=9'
            }
        };

        const user = mockUsers[role];
        setUser(user);

        // Navigate based on role
        if (role === 'admin') navigate('/admin/dashboard');
        else if (role === 'provider') navigate('/provider/dashboard');
        else if (role === 'beautician') navigate('/beautician/dashboard');
        else navigate('/');

        console.log(`Switched to ${role}`);
    };

    const btnStyle = {
        padding: '5px 10px',
        fontSize: '12px',
        border: '1px solid #444',
        borderRadius: '4px',
        background: '#333',
        color: 'white',
        cursor: 'pointer',
        transition: 'all 0.2s',
        flex: 1
    };

    return (
        <div style={{
            position: 'fixed',
            bottom: 20,
            right: 20,
            zIndex: 10000,
            background: 'rgba(0,0,0,0.85)',
            padding: '12px',
            borderRadius: '8px',
            color: 'white',
            boxShadow: '0 4px 12px rgba(0,0,0,0.3)',
            display: 'flex',
            flexDirection: 'column',
            gap: '8px',
            minWidth: '200px',
            backdropFilter: 'blur(4px)'
        }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ fontSize: '11px', textTransform: 'uppercase', letterSpacing: '1px', fontWeight: 'bold', color: '#aaa' }}>Dev Switcher</span>
                <span style={{ width: '6px', height: '6px', borderRadius: '50%', background: '#0f0' }}></span>
            </div>
            <div style={{ display: 'flex', gap: '5px', flexWrap: 'wrap' }}>
                <button style={btnStyle} onClick={() => switchRole('admin')}>Admin</button>
                <button style={btnStyle} onClick={() => switchRole('provider')}>Provider</button>
            </div>
            <div style={{ display: 'flex', gap: '5px', flexWrap: 'wrap' }}>
                <button style={btnStyle} onClick={() => switchRole('beautician')}>Beautician</button>
                <button style={btnStyle} onClick={() => switchRole('client')}>Client</button>
            </div>
        </div>
    );
};

export default DevRoleSwitcher;
