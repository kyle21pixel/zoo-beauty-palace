import { Component } from 'react';

class ErrorBoundary extends Component {
    constructor(props) {
        super(props);
        this.state = { hasError: false, error: null, errorInfo: null };
    }

    static getDerivedStateFromError(error) {
        return { hasError: true };
    }

    componentDidCatch(error, errorInfo) {
        this.setState({
            error: error,
            errorInfo: errorInfo
        });
        console.error('ErrorBoundary caught an error:', error, errorInfo);
    }

    render() {
        if (this.state.hasError) {
            return (
                <div style={{
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    justifyContent: 'center',
                    minHeight: '100vh',
                    padding: '2rem',
                    background: 'linear-gradient(135deg, #fdf2f8 0%, #fce7f3 100%)',
                    fontFamily: 'system-ui, sans-serif'
                }}>
                    <div style={{
                        background: 'white',
                        padding: '2rem',
                        borderRadius: '1rem',
                        boxShadow: '0 10px 25px rgba(0,0,0,0.1)',
                        maxWidth: '600px',
                        width: '100%',
                        textAlign: 'center'
                    }}>
                        <h1 style={{ color: '#be123c', marginBottom: '1rem' }}>
                            Something went wrong
                        </h1>
                        <p style={{ color: '#6b7280', marginBottom: '1.5rem' }}>
                            An unexpected error occurred. Please try refreshing the page.
                        </p>
                        <button
                            onClick={() => window.location.reload()}
                            style={{
                                background: 'linear-gradient(135deg, #e91e63 0%, #d97706 100%)',
                                color: 'white',
                                border: 'none',
                                padding: '0.75rem 1.5rem',
                                borderRadius: '0.5rem',
                                fontSize: '1rem',
                                fontWeight: '600',
                                cursor: 'pointer',
                                marginRight: '0.5rem'
                            }}
                        >
                            Refresh Page
                        </button>
                        <button
                            onClick={() => {
                                localStorage.clear();
                                window.location.href = '/';
                            }}
                            style={{
                                background: 'transparent',
                                color: '#be123c',
                                border: '2px solid #be123c',
                                padding: '0.75rem 1.5rem',
                                borderRadius: '0.5rem',
                                fontSize: '1rem',
                                fontWeight: '600',
                                cursor: 'pointer'
                            }}
                        >
                            Clear & Go Home
                        </button>
                        {this.state.error && (
                            <details style={{ marginTop: '1.5rem', textAlign: 'left' }}>
                                <summary style={{ cursor: 'pointer', color: '#9ca3af' }}>
                                    Technical Details
                                </summary>
                                <pre style={{
                                    background: '#f3f4f6',
                                    padding: '1rem',
                                    borderRadius: '0.5rem',
                                    marginTop: '0.5rem',
                                    overflow: 'auto',
                                    fontSize: '0.75rem',
                                    color: '#374151'
                                }}>
                                    {this.state.error.toString()}
                                    {this.state.errorInfo?.componentStack}
                                </pre>
                            </details>
                        )}
                    </div>
                </div>
            );
        }

        return this.props.children;
    }
}

export default ErrorBoundary;
