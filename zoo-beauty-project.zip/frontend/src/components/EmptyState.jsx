import { 
    Users, Calendar, Briefcase, Bell, AlertTriangle, 
    FileText, Search, Inbox, CheckCircle, Star
} from 'lucide-react';
import './EmptyState.css';

const iconMap = {
    users: Users,
    calendar: Calendar,
    briefcase: Briefcase,
    bell: Bell,
    alert: AlertTriangle,
    file: FileText,
    search: Search,
    inbox: Inbox,
    check: CheckCircle,
    star: Star
};

export const EmptyState = ({ 
    icon = 'inbox', 
    title = 'No data found', 
    description = 'There is no data to display at the moment.',
    action = null,
    actionLabel = 'Add New',
    onAction = null,
    size = 'medium' // small, medium, large
}) => {
    const IconComponent = iconMap[icon] || Inbox;
    
    const sizeClasses = {
        small: 'empty-state-sm',
        medium: 'empty-state-md',
        large: 'empty-state-lg'
    };

    return (
        <div className={`empty-state ${sizeClasses[size]}`}>
            <div className="empty-state-icon">
                <IconComponent />
            </div>
            <h3 className="empty-state-title">{title}</h3>
            <p className="empty-state-description">{description}</p>
            {action || (onAction && (
                <button className="btn btn-primary empty-state-action" onClick={onAction}>
                    {actionLabel}
                </button>
            ))}
        </div>
    );
};

// Pre-configured empty states for common use cases
export const EmptyUsers = ({ onAction }) => (
    <EmptyState
        icon="users"
        title="No users yet"
        description="Start by adding providers or beauticians to your platform."
        actionLabel="+ Add User"
        onAction={onAction}
    />
);

export const EmptyBookings = () => (
    <EmptyState
        icon="calendar"
        title="No bookings"
        description="Bookings will appear here once clients start making reservations."
    />
);

export const EmptyProviders = ({ onAction }) => (
    <EmptyState
        icon="briefcase"
        title="No providers registered"
        description="Providers are service owners who manage beauticians and services."
        actionLabel="+ Add Provider"
        onAction={onAction}
    />
);

export const EmptyNotifications = () => (
    <EmptyState
        icon="bell"
        title="All caught up!"
        description="You have no notifications at the moment."
        size="small"
    />
);

export const EmptyDisputes = () => (
    <EmptyState
        icon="check"
        title="No disputes"
        description="Great! There are no pending disputes to resolve."
    />
);

export const EmptyAssignments = ({ onAction }) => (
    <EmptyState
        icon="file"
        title="No assignments"
        description="Create assignments to delegate tasks to beauticians."
        actionLabel="+ Create Assignment"
        onAction={onAction}
    />
);

export const EmptySearchResults = ({ searchTerm }) => (
    <EmptyState
        icon="search"
        title="No results found"
        description={`We couldn't find anything matching "${searchTerm}". Try a different search term.`}
    />
);

export const EmptyReviews = () => (
    <EmptyState
        icon="star"
        title="No reviews yet"
        description="Reviews will appear here once clients start leaving feedback."
    />
);

export const EmptyAnalytics = () => (
    <EmptyState
        icon="alert"
        title="Not enough data"
        description="Analytics will become available as your platform gathers more activity data."
    />
);

export const EmptyTable = ({ 
    colSpan = 4, 
    icon = 'inbox',
    title = 'No data',
    description = 'No records found.'
}) => (
    <tr>
        <td colSpan={colSpan} className="empty-table-cell">
            <EmptyState
                icon={icon}
                title={title}
                description={description}
                size="small"
            />
        </td>
    </tr>
);

export default EmptyState;
