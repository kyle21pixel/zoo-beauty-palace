import api from '../lib/axios';

export const getProviderStats = async () => {
    try {
        const response = await api.get('/providers/me/stats');
        return response.data;
    } catch (error) {
        console.error('Error fetching provider stats:', error);
        throw error;
    }
};

export const getProviderProfile = async () => {
    try {
        const response = await api.get('/providers/me/profile');
        return response.data;
    } catch (error) {
        console.error('Error fetching provider profile:', error);
        throw error;
    }
};

export const updateProviderProfile = async (data) => {
    try {
        const response = await api.put('/providers/profile', data);
        return response.data;
    } catch (error) {
        console.error('Error updating provider profile:', error);
        throw error;
    }
};

export const getProviderBookings = async (params) => {
    try {
        // Assuming there's a route for provider bookings, likely reusing getMyBookings or specific provider route
        // Looking at bookingRoutes.js: router.get('/my', protect, paginationValidation, validate, getMyBookings);
        // This likely returns bookings for the current user (provider or client)
        const response = await api.get('/bookings/my', { params });
        return response.data;
    } catch (error) {
        console.error('Error fetching provider bookings:', error);
        throw error;
    }
};

export const acceptBooking = async (id) => {
    try {
        const response = await api.put(`/bookings/${id}/accept`);
        return response.data;
    } catch (error) {
        console.error(`Error accepting booking ${id}:`, error);
        throw error;
    }
};

export const rejectBooking = async (id) => {
    try {
        const response = await api.put(`/bookings/${id}/reject`);
        return response.data;
    } catch (error) {
        console.error(`Error rejecting booking ${id}:`, error);
        throw error;
    }
};

export const addPortfolioItem = async (data) => {
    try {
        const response = await api.post('/providers/portfolio', data);
        return response.data;
    } catch (error) {
        console.error('Error adding portfolio item:', error);
        throw error;
    }
};

export const removePortfolioItem = async (itemId) => {
    try {
        const response = await api.delete(`/providers/portfolio/${itemId}`);
        return response.data;
    } catch (error) {
        console.error(`Error removing portfolio item ${itemId}:`, error);
        throw error;
    }
};
