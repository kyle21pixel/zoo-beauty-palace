import axios from '../lib/axios';

/**
 * Get user notifications
 * @param {Object} params - Query parameters
 * @returns {Promise}
 */
export const getNotifications = async (params = {}) => {
    try {
        const response = await axios.get('/notifications', { params });
        return response.data;
    } catch (error) {
        console.error('Error fetching notifications:', error);
        throw error;
    }
};

/**
 * Mark a notification as read
 * @param {number} id - Notification ID
 * @returns {Promise}
 */
export const markAsRead = async (id) => {
    try {
        const response = await axios.put(`/notifications/${id}/read`);
        return response.data;
    } catch (error) {
        console.error(`Error marking notification ${id} as read:`, error);
        throw error;
    }
};

/**
 * Mark all notifications as read
 * @returns {Promise}
 */
export const markAllAsRead = async () => {
    try {
        const response = await axios.put('/notifications/read-all');
        return response.data;
    } catch (error) {
        console.error('Error marking all notifications as read:', error);
        throw error;
    }
};

/**
 * Delete a notification
 * @param {number} id - Notification ID
 * @returns {Promise}
 */
export const deleteNotification = async (id) => {
    try {
        const response = await axios.delete(`/notifications/${id}`);
        return response.data;
    } catch (error) {
        console.error(`Error deleting notification ${id}:`, error);
        throw error;
    }
};