import api from '../lib/axios';

// ==========================================
// DASHBOARD & ANALYTICS
// ==========================================

export const getProviderDashboardOverview = async () => {
    try {
        const response = await api.get('/providers/dashboard/overview');
        return response.data;
    } catch (error) {
        console.error('Error fetching dashboard overview:', error);
        throw error;
    }
};

export const getProviderPerformanceChart = async (period = 'week') => {
    try {
        const response = await api.get(`/providers/dashboard/chart?period=${period}`);
        return response.data;
    } catch (error) {
        console.error('Error fetching performance chart:', error);
        throw error;
    }
};

export const getAdvancedAnalytics = async () => {
    try {
        const response = await api.get('/providers/analytics/advanced');
        return response.data;
    } catch (error) {
        console.error('Error fetching advanced analytics:', error);
        throw error;
    }
};

// ==========================================
// STAFF MANAGEMENT
// ==========================================

export const getProviderStaff = async () => {
    try {
        const response = await api.get('/providers/staff');
        return response.data;
    } catch (error) {
        console.error('Error fetching staff:', error);
        throw error;
    }
};

export const addProviderStaff = async (staffData) => {
    try {
        const response = await api.post('/providers/staff', staffData);
        return response.data;
    } catch (error) {
        console.error('Error adding staff:', error);
        throw error;
    }
};

export const getProviderStaffMember = async (staffId) => {
    try {
        const response = await api.get(`/providers/staff/${staffId}`);
        return response.data;
    } catch (error) {
        console.error('Error fetching staff member:', error);
        throw error;
    }
};

export const updateProviderStaff = async (staffId, updates) => {
    try {
        const response = await api.put(`/providers/staff/${staffId}`, updates);
        return response.data;
    } catch (error) {
        console.error('Error updating staff:', error);
        throw error;
    }
};

export const removeProviderStaff = async (staffId) => {
    try {
        const response = await api.delete(`/providers/staff/${staffId}`);
        return response.data;
    } catch (error) {
        console.error('Error removing staff:', error);
        throw error;
    }
};

// ==========================================
// BOOKING DISPATCH
// ==========================================

export const getAvailableStaff = async () => {
    try {
        const response = await api.get('/providers/bookings/available-staff');
        return response.data;
    } catch (error) {
        console.error('Error fetching available staff:', error);
        throw error;
    }
};

export const assignBookingToStaff = async (bookingId, beauticianId) => {
    try {
        const response = await api.post(`/providers/bookings/${bookingId}/assign`, {
            beauticianId
        });
        return response.data;
    } catch (error) {
        console.error('Error assigning booking:', error);
        throw error;
    }
};

export const reassignBooking = async (bookingId, newBeauticianId, reason) => {
    try {
        const response = await api.put(`/providers/bookings/${bookingId}/reassign`, {
            newBeauticianId,
            reason
        });
        return response.data;
    } catch (error) {
        console.error('Error reassigning booking:', error);
        throw error;
    }
};

// ==========================================
// FINANCIAL
// ==========================================

export const getProviderRevenue = async (page = 1, limit = 20) => {
    try {
        const response = await api.get(`/providers/revenue?page=${page}&limit=${limit}`);
        return response.data;
    } catch (error) {
        console.error('Error fetching revenue:', error);
        throw error;
    }
};

export const requestPayout = async (amount, notes) => {
    try {
        const response = await api.post('/providers/payout/request', {
            amount,
            notes
        });
        return response.data;
    } catch (error) {
        console.error('Error requesting payout:', error);
        throw error;
    }
};

// ==========================================
// EXISTING PROVIDER SERVICES (from providerService.js)
// ==========================================

export const getProviderProfile = async () => {
    try {
        const response = await api.get('/providers/me/profile');
        return response.data;
    } catch (error) {
        console.error('Error fetching provider profile:', error);
        throw error;
    }
};

export const getProviderStats = async () => {
    try {
        const response = await api.get('/providers/me/stats');
        return response.data;
    } catch (error) {
        console.error('Error fetching provider stats:', error);
        throw error;
    }
};

export const getProviderBookings = async (params = {}) => {
    try {
        const queryParams = new URLSearchParams(params).toString();
        const response = await api.get(`/bookings/my?${queryParams}`);
        return response.data;
    } catch (error) {
        console.error('Error fetching provider bookings:', error);
        throw error;
    }
};

export const acceptBooking = async (bookingId) => {
    try {
        const response = await api.put(`/bookings/${bookingId}/accept`);
        return response.data;
    } catch (error) {
        console.error('Error accepting booking:', error);
        throw error;
    }
};

export const rejectBooking = async (bookingId, reason) => {
    try {
        const response = await api.put(`/bookings/${bookingId}/reject`, { reason });
        return response.data;
    } catch (error) {
        console.error('Error rejecting booking:', error);
        throw error;
    }
};

export const updateProviderProfile = async (profileData) => {
    try {
        const response = await api.put('/providers/profile', profileData);
        return response.data;
    } catch (error) {
        console.error('Error updating provider profile:', error);
        throw error;
    }
};

export const addPortfolioItem = async (portfolioItem) => {
    try {
        const response = await api.post('/providers/portfolio', portfolioItem);
        return response.data;
    } catch (error) {
        console.error('Error adding portfolio item:', error);
        throw error;
    }
};

export const removePortfolioItem = async (itemId) => {
    try {
        const response = await api.delete(`/providers/portfolio/${itemId}`);
        return response.data;
    } catch (error) {
        console.error('Error removing portfolio item:', error);
        throw error;
    }
};

export const toggleOnlineStatus = async () => {
    try {
        const response = await api.put('/providers/online-status');
        return response.data;
    } catch (error) {
        console.error('Error toggling online status:', error);
        throw error;
    }
};
