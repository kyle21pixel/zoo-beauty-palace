import api from '../lib/axios';

// Admin assignment services
export const assignTask = async (assignmentData) => {
  try {
    const response = await api.post('/admin/assignments', assignmentData);
    return response.data;
  } catch (error) {
    console.error('Error assigning task:', error);
    throw error;
  }
};

export const getAssignments = async (params = {}) => {
  try {
    // Set default pagination values
    const queryParams = {
      page: 1,
      limit: 20,
      ...params
    };
    
    const response = await api.get('/admin/assignments', { params: queryParams });
    return response.data;
  } catch (error) {
    console.error('Error fetching assignments:', error);
    throw error;
  }
};

export const updateAssignmentStatus = async (id, status) => {
  try {
    const response = await api.put(`/admin/assignments/${id}/status`, { status });
    return response.data;
  } catch (error) {
    console.error(`Error updating assignment ${id} status:`, error);
    throw error;
  }
};

export const bulkUpdateAssignmentStatus = async (assignmentIds, status) => {
  try {
    const response = await api.put('/admin/assignments/bulk-status', { assignmentIds, status });
    return response.data;
  } catch (error) {
    console.error('Error bulk updating assignment statuses:', error);
    throw error;
  }
};

export const bulkDeleteAssignments = async (assignmentIds) => {
  try {
    const response = await api.delete('/admin/assignments/bulk', { data: { assignmentIds } });
    return response.data;
  } catch (error) {
    console.error('Error bulk deleting assignments:', error);
    throw error;
  }
};

// Provider assignment services
export const providerAssignTask = async (assignmentData) => {
  try {
    const response = await api.post('/providers/assignments', assignmentData);
    return response.data;
  } catch (error) {
    console.error('Error assigning task (provider):', error);
    throw error;
  }
};

export const getProviderAssignments = async (params = {}) => {
  try {
    // Set default pagination values
    const queryParams = {
      page: 1,
      limit: 20,
      ...params
    };
    
    const response = await api.get('/providers/assignments', { params: queryParams });
    return response.data;
  } catch (error) {
    console.error('Error fetching provider assignments:', error);
    throw error;
  }
};

// Beautician assignment services
export const getMyAssignments = async (params = {}) => {
  try {
    // Set default pagination values
    const queryParams = {
      page: 1,
      limit: 20,
      ...params
    };
    
    const response = await api.get('/beauticians/assignments', { params: queryParams });
    return response.data;
  } catch (error) {
    console.error('Error fetching my assignments:', error);
    throw error;
  }
};

export const acceptAssignment = async (id) => {
  try {
    const response = await api.put(`/beauticians/assignments/${id}/accept`);
    return response.data;
  } catch (error) {
    console.error(`Error accepting assignment ${id}:`, error);
    throw error;
  }
};

export const completeAssignment = async (id) => {
  try {
    const response = await api.put(`/beauticians/assignments/${id}/complete`);
    return response.data;
  } catch (error) {
    console.error(`Error completing assignment ${id}:`, error);
    throw error;
  }
};