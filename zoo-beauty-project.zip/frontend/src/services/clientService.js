import api from '../lib/axios';

export const getClientBookings = async () => {
    try {
        const response = await api.get('/bookings/my');
        return response.data;
    } catch (error) {
        console.error('Error fetching client bookings:', error);
        throw error;
    }
};

export const searchProviders = async (params) => {
    try {
        const response = await api.get('/providers/search', { params });
        return response.data;
    } catch (error) {
        console.error('Error searching providers:', error);
        throw error;
    }
};
