import api from '../lib/axios';

export const getDashboardStats = async () => {
    try {
        const response = await api.get('/admin/dashboard');
        return response.data;
    } catch (error) {
        console.error('Error fetching dashboard stats:', error);
        throw error;
    }
};

export const getUsers = async (params = {}) => {
    try {
        // Set default pagination values
        const queryParams = {
            page: 1,
            limit: 20,
            ...params
        };
        
        const response = await api.get('/admin/users', { params: queryParams });
        return response.data;
    } catch (error) {
        console.error('Error fetching users:', error);
        throw error;
    }
};

export const createUser = async (data) => {
    try {
        const response = await api.post('/admin/users', data);
        return response.data;
    } catch (error) {
        console.error('Error creating user:', error);
        throw error;
    }
};

export const getProviders = async (params = {}) => {
    try {
        // Set default pagination values
        const queryParams = {
            page: 1,
            limit: 20,
            ...params
        };
        
        const response = await api.get('/admin/providers', { params: queryParams });
        return response.data;
    } catch (error) {
        console.error('Error fetching providers:', error);
        throw error;
    }
};

export const getBeauticians = async (params = {}) => {
    try {
        // Set default pagination values
        const queryParams = {
            page: 1,
            limit: 20,
            role: 'beautician',
            ...params
        };
        
        const response = await api.get('/admin/users', { params: queryParams });
        return response.data;
    } catch (error) {
        console.error('Error fetching beauticians:', error);
        throw error;
    }
};

export const updateUser = async (id, data) => {
    try {
        const response = await api.put(`/admin/users/${id}`, data);
        return response.data;
    } catch (error) {
        console.error(`Error updating user ${id}:`, error);
        throw error;
    }
};

export const deleteUser = async (id) => {
    try {
        const response = await api.delete(`/admin/users/${id}`);
        return response.data;
    } catch (error) {
        console.error(`Error deleting user ${id}:`, error);
        throw error;
    }
};

export const getBookings = async (params = {}) => {
    try {
        // Set default pagination values
        const queryParams = {
            page: 1,
            limit: 20,
            ...params
        };
        
        const response = await api.get('/admin/bookings', { params: queryParams });
        return response.data;
    } catch (error) {
        console.error('Error fetching bookings:', error);
        throw error;
    }
};

export const getDisputes = async (params = {}) => {
    try {
        // Set default pagination values
        const queryParams = {
            page: 1,
            limit: 20,
            ...params
        };
        
        const response = await api.get('/admin/disputes', { params: queryParams });
        return response.data;
    } catch (error) {
        console.error('Error fetching disputes:', error);
        throw error;
    }
};

export const resolveDispute = async (id, data) => {
    try {
        const response = await api.put(`/admin/disputes/${id}/resolve`, data);
        return response.data;
    } catch (error) {
        console.error(`Error resolving dispute ${id}:`, error);
        throw error;
    }
};

export const getAnalytics = async (params = {}) => {
    try {
        // Set default pagination values
        const queryParams = {
            page: 1,
            limit: 20,
            ...params
        };
        
        const response = await api.get('/admin/analytics', { params: queryParams });
        return response.data;
    } catch (error) {
        console.error('Error fetching analytics:', error);
        throw error;
    }
};

export const resetUserPassword = async (id) => {
    try {
        const response = await api.post(`/admin/users/${id}/reset-password`);
        return response.data;
    } catch (error) {
        console.error(`Error resetting password for user ${id}:`, error);
        throw error;
    }
};
