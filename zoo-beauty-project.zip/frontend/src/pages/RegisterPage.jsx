import { useState, useEffect } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Mail, Lock, User, Phone, Briefcase, Sparkles, Home, Moon, Sun } from 'lucide-react';
import './AuthPages.css';
import api from '../lib/axios'; // Import the axios instance

const RegisterPage = () => {
    const navigate = useNavigate();
    const [searchParams] = useSearchParams();
    const defaultType = searchParams.get('type') || 'client';

    const [userType, setUserType] = useState(defaultType);
    const [darkMode, setDarkMode] = useState(false);
    const [formData, setFormData] = useState({
        firstName: '',
        lastName: '',
        email: '',
        phone: '',
        password: '',
        confirmPassword: '',
        businessName: ''
    });
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');

    useEffect(() => {
        if (darkMode) {
            document.body.classList.add('dark-mode');
        } else {
            document.body.classList.remove('dark-mode');
        }
    }, [darkMode]);

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.id]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError(''); // Clear previous errors

        if (formData.password !== formData.confirmPassword) {
            setError('Passwords do not match');
            return;
        }

        setLoading(true);

        try {
            // 1. Register the user
            const userData = {
                firstName: formData.firstName,
                lastName: formData.lastName,
                email: formData.email,
                phone: formData.phone,
                password: formData.password,
                role: userType,
            };

            const registerResponse = await api.post('/auth/register', userData);

            if (registerResponse.data.success) {
                // If user is a provider, create their profile
                if (userType === 'provider') {
                    const providerProfileData = {
                        businessName: formData.businessName,
                        userId: registerResponse.data.data.user.id // Use the ID from the newly registered user
                    };
                    // Note: The /providers/profile endpoint is PUT, but if no profile exists, it creates one.
                    // However, it requires authentication. We would need to login the user first or
                    // have a dedicated endpoint for initial provider profile creation without auth.
                    // For now, let's assume the user logs in after registration and completes their profile.
                    // Or, if backend allows, we can pass a token for initial creation.
                    // Given the current backend structure, the provider is created when the user is created.
                    // The `updateProfile` in providerController handles creation if not found.
                    // So we will modify this to use the `updateProfile` API after login.
                    // For now, we will just navigate to login.
                    alert('Registration successful! Please check your email to verify your account and then log in.');
                    navigate('/login');

                } else {
                    alert('Registration successful! Please check your email to verify your account and then log in.');
                    navigate('/login');
                }
            } else {
                setError(registerResponse.data.message || 'Registration failed.');
            }
        } catch (err) {
            setError(err.response?.data?.message || 'Registration failed. Please try again.');
            console.error('Registration error:', err);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="auth-page">
            <div className="auth-container">
                <motion.div
                    className="auth-card card card-glass"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                >
                    <div className="auth-header">
                        <Link to="/" className="logo">
                            <img src="/assets/logo.png" alt="ZOO beauty Palace" className="logo-image" />
                            <span className="logo-text">
                                <span className="logo-top">ZOO</span>
                                <span className="logo-bottom">beauty Palace</span>
                            </span>
                        </Link>
                        <div className="auth-controls">
                            <button
                                className="icon-btn"
                                onClick={() => setDarkMode(!darkMode)}
                                title={darkMode ? "Switch to Light Mode" : "Switch to Dark Mode"}
                            >
                                {darkMode ? <Sun size={20} /> : <Moon size={20} />}
                            </button>
                        </div>
                        <h1>Create Account</h1>
                        <p>Join ZOO beauty Palace today</p>
                    </div>

                    {/* User Type Selector */}
                    <div className="user-type-selector">
                        <button
                            type="button"
                            className={`type-btn ${userType === 'client' ? 'active' : ''}`}
                            onClick={() => setUserType('client')}
                        >
                            <User size={20} />
                            I'm a Client
                        </button>
                        <button
                            type="button"
                            className={`type-btn ${userType === 'provider' ? 'active' : ''}`}
                            onClick={() => setUserType('provider')}
                        >
                            <Briefcase size={20} />
                            I'm a Provider
                        </button>
                        <button
                            type="button"
                            className={`type-btn ${userType === 'beautician' ? 'active' : ''}`}
                            onClick={() => setUserType('beautician')}
                        >
                            <Sparkles size={20} />
                            I'm a Beautician
                        </button>
                    </div>

                    <form onSubmit={handleSubmit} className="auth-form">
                        <div className="form-row">
                            <div className="form-group">
                                <label htmlFor="firstName">
                                    <User size={18} />
                                    First Name
                                </label>
                                <input
                                    type="text"
                                    id="firstName"
                                    className="input"
                                    placeholder="John"
                                    value={formData.firstName}
                                    onChange={handleChange}
                                    required
                                />
                            </div>

                            <div className="form-group">
                                <label htmlFor="lastName">
                                    <User size={18} />
                                    Last Name
                                </label>
                                <input
                                    type="text"
                                    id="lastName"
                                    className="input"
                                    placeholder="Doe"
                                    value={formData.lastName}
                                    onChange={handleChange}
                                    required
                                />
                            </div>
                        </div>

                        {userType === 'provider' && (
                            <div className="form-group">
                                <label htmlFor="businessName">
                                    <Briefcase size={18} />
                                    Business Name
                                </label>
                                <input
                                    type="text"
                                    id="businessName"
                                    className="input"
                                    placeholder="Your Business Name"
                                    value={formData.businessName}
                                    onChange={handleChange}
                                    required={userType === 'provider'}
                                />
                            </div>
                        )}

                        <div className="form-group">
                            <label htmlFor="email">
                                <Mail size={18} />
                                Email Address
                            </label>
                            <input
                                type="email"
                                id="email"
                                className="input"
                                placeholder="you@example.com"
                                value={formData.email}
                                onChange={handleChange}
                                required
                            />
                        </div>

                        <div className="form-group">
                            <label htmlFor="phone">
                                <Phone size={18} />
                                Phone Number
                            </label>
                            <input
                                type="tel"
                                id="phone"
                                className="input"
                                placeholder="+1 (555) 000-0000"
                                value={formData.phone}
                                onChange={handleChange}
                                required
                            />
                        </div>

                        <div className="form-row">
                            <div className="form-group">
                                <label htmlFor="password">
                                    <Lock size={18} />
                                    Password
                                </label>
                                <input
                                    type="password"
                                    id="password"
                                    className="input"
                                    placeholder="••••••••"
                                    value={formData.password}
                                    onChange={handleChange}
                                    required
                                    minLength={6}
                                />
                            </div>

                            <div className="form-group">
                                <label htmlFor="confirmPassword">
                                    <Lock size={18} />
                                    Confirm Password
                                </label>
                                <input
                                    type="password"
                                    id="confirmPassword"
                                    className="input"
                                    placeholder="••••••••"
                                    value={formData.confirmPassword}
                                    onChange={handleChange}
                                    required
                                />
                            </div>
                        </div>

                        {error && <p className="text-error text-center mt-4">{error}</p>}

                        <button type="submit" className="btn btn-primary" disabled={loading}>
                            {loading ? 'Creating Account...' : 'Create Account'}
                        </button>
                    </form>

                    <div className="auth-footer">
                        <p>Already have an account? <Link to="/login" className="link">Sign in</Link></p>
                    </div>
                </motion.div>
            </div>
        </div>
    );
};

export default RegisterPage;
