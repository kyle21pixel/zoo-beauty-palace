import { motion } from 'framer-motion';
import { useState, useEffect } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { Search, MapPin, Star, Calendar, DollarSign, Filter, Moon, Sun, ArrowLeft } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import axios from 'axios';
import { mockProviders } from '../data/mockData';
import './client/SearchProviders.css';

const ServiceProvidersPage = () => {
    const navigate = useNavigate();
    const { user, logout } = useAuth();
    const { serviceType } = useParams();
    const [searchQuery, setSearchQuery] = useState('');
    const [providers, setProviders] = useState([]);
    const [loading, setLoading] = useState(true);
    const [darkMode, setDarkMode] = useState(false);

    // Service type mapping
    const serviceMapping = {
        'makeup': 'Makeup Artists',
        'hair': 'Hair Stylists',
        'nails': 'Nail Technicians',
        'skincare': 'Skincare Experts',
        'barbering': 'Barbers',
        'braiding': 'Braiding Specialists',
        'wigs': 'Wig Installation'
    };

    const currentServiceTitle = serviceMapping[serviceType] || 'All Services';

    useEffect(() => {
        fetchProviders();
    }, [serviceType]);

    useEffect(() => {
        if (darkMode) {
            document.body.classList.add('dark-mode');
        } else {
            document.body.classList.remove('dark-mode');
        }
    }, [darkMode]);

    const fetchProviders = async () => {
        try {
            const response = await axios.get('http://localhost:5000/api/providers/search');
            if (response.data.success && response.data.data.providers.length > 0) {
                const providersData = response.data.data.providers.map(p => ({
                    id: p.id,
                    name: `${p.userId?.firstName || ''} ${p.userId?.lastName || ''}`.trim(),
                    businessName: p.businessName,
                    avatar: p.userId?.avatar || 'https://i.pravatar.cc/150?img=1',
                    specializations: JSON.parse(p.specializations || '[]'),
                    rating: JSON.parse(p.rating || '{"average": 0, "count": 0}').average,
                    reviewCount: JSON.parse(p.rating || '{"average": 0, "count": 0}').count,
                    price: p.services ? Math.min(...JSON.parse(p.services).map(s => s.price)) : 0,
                    location: JSON.parse(p.location || '{"address": "Location not specified"}').address,
                    distance: '2.3 km',
                    isOnline: p.isOnline || false,
                    portfolio: JSON.parse(p.portfolio || '[]').map(item => item.url || item).slice(0, 4)
                }));
                setProviders(providersData);
            } else {
                // Use mock data if API returns no data
                const mockData = mockProviders.map(p => ({
                    id: p.id,
                    name: `${p.userId.firstName} ${p.userId.lastName}`,
                    businessName: p.businessName,
                    avatar: p.userId.avatar,
                    specializations: JSON.parse(p.specializations),
                    rating: JSON.parse(p.rating).average,
                    reviewCount: JSON.parse(p.rating).count,
                    price: Math.min(...JSON.parse(p.services).map(s => s.price)),
                    location: JSON.parse(p.location).address,
                    distance: '2.3 km',
                    isOnline: p.isOnline,
                    portfolio: JSON.parse(p.portfolio)
                }));
                setProviders(mockData);
            }
        } catch (error) {
            console.error('Error fetching providers:', error);
            // Use mock data on error
            const mockData = mockProviders.map(p => ({
                id: p.id,
                name: `${p.userId.firstName} ${p.userId.lastName}`,
                businessName: p.businessName,
                avatar: p.userId.avatar,
                specializations: JSON.parse(p.specializations),
                rating: JSON.parse(p.rating).average,
                reviewCount: JSON.parse(p.rating).count,
                price: Math.min(...JSON.parse(p.services).map(s => s.price)),
                location: JSON.parse(p.location).address,
                distance: '2.3 km',
                isOnline: p.isOnline,
                portfolio: JSON.parse(p.portfolio)
            }));
            setProviders(mockData);
        } finally {
            setLoading(false);
        }
    };

    const filteredProviders = providers.filter(provider => {
        const matchesSearch = provider.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
            provider.businessName.toLowerCase().includes(searchQuery.toLowerCase());

        // Filter by service type if specified
        const matchesService = !serviceType || serviceType === 'all' ||
            provider.specializations.some(s => {
                const spec = s.toLowerCase();
                switch (serviceType) {
                    case 'makeup': return spec.includes('makeup');
                    case 'hair': return spec.includes('hair') || spec.includes('styling');
                    case 'nails': return spec.includes('nail');
                    case 'skincare': return spec.includes('skin') || spec.includes('facial');
                    case 'barbering': return spec.includes('barber');
                    case 'braiding': return spec.includes('braid');
                    case 'wigs': return spec.includes('wig');
                    default: return true;
                }
            });

        return matchesSearch && matchesService;
    });

    if (loading) {
        return <div className="loading">Loading providers...</div>;
    }

    return (
        <div className="search-page">
            <header className="search-header">
                <div className="container">
                    <div className="header-content">
                        <Link to="/" className="logo">
                            <img src="/assets/logo.png" alt="ZOO beauty Palace" className="logo-image" />
                            <span className="logo-text">
                                <span className="logo-top">ZOO</span>
                                <span className="logo-bottom">beauty Palace</span>
                            </span>
                        </Link>
                        <div className="header-actions">
                            <button className="btn btn-ghost btn-icon" onClick={() => setDarkMode(!darkMode)}>
                                {darkMode ? <Sun size={20} /> : <Moon size={20} />}
                            </button>
                            <Link to="/" className="btn btn-ghost btn-sm">Home</Link>
                            {user ? (
                                <>
                                    <Link
                                        to={
                                            user.role === 'admin' ? '/admin/dashboard' :
                                                user.role === 'provider' ? '/provider/dashboard' :
                                                    '/client/dashboard'
                                        }
                                        className="btn btn-ghost btn-sm"
                                    >
                                        Dashboard
                                    </Link>
                                    <button
                                        onClick={() => {
                                            logout();
                                            navigate('/');
                                        }}
                                        className="btn btn-outline btn-sm"
                                    >
                                        Logout
                                    </button>
                                </>
                            ) : (
                                <>
                                    <Link to="/register?type=provider" className="btn btn-ghost btn-sm">Become a Provider</Link>
                                    <Link to="/login" className="btn btn-primary btn-sm">Sign In</Link>
                                </>
                            )}
                        </div>
                    </div>
                </div>
            </header>

            <section className="search-section">
                <div className="container">
                    <motion.div
                        className="search-content"
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                    >
                        <button
                            onClick={() => navigate(-1)}
                            className="btn btn-ghost btn-sm"
                            style={{ marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}
                        >
                            <ArrowLeft size={18} />
                            Back
                        </button>
                        <h1>{currentServiceTitle}</h1>
                        <p>Browse {filteredProviders.length} verified {currentServiceTitle.toLowerCase()} in your area</p>

                        <div className="search-bar">
                            <Search className="search-icon" />
                            <input
                                type="text"
                                placeholder="Search by name or location..."
                                value={searchQuery}
                                onChange={(e) => setSearchQuery(e.target.value)}
                                className="search-input"
                            />
                            <button className="btn btn-primary">Search</button>
                        </div>
                    </motion.div>
                </div>
            </section>

            <section className="results-section">
                <div className="container">
                    <div className="results-header">
                        <h2>{filteredProviders.length} Providers Found</h2>
                    </div>

                    {filteredProviders.length === 0 ? (
                        <div className="no-results">
                            <p>No {currentServiceTitle.toLowerCase()} found. Try adjusting your search criteria or <Link to="/services">browse all services</Link>.</p>
                        </div>
                    ) : (
                        <div className="providers-grid">
                            {filteredProviders.map((provider, index) => (
                                <motion.div
                                    key={provider.id}
                                    className="provider-card card"
                                    initial={{ opacity: 0, y: 20 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    transition={{ delay: index * 0.05 }}
                                    whileHover={{ y: -8 }}
                                >
                                    <div className="provider-header">
                                        <div className="provider-avatar">
                                            <img src={provider.avatar} alt={provider.name} />
                                            {provider.isOnline && <span className="online-badge"></span>}
                                        </div>
                                        <div className="provider-info">
                                            <h3>{provider.name}</h3>
                                            <p className="business-name">{provider.businessName}</p>
                                            <div className="rating">
                                                <Star size={16} fill="currentColor" />
                                                <span>{provider.rating}</span>
                                                <span className="review-count">({provider.reviewCount} reviews)</span>
                                            </div>
                                        </div>
                                    </div>

                                    <div className="provider-portfolio">
                                        {provider.portfolio.slice(0, 3).map((img, i) => (
                                            <img key={i} src={img} alt={`Work ${i + 1}`} />
                                        ))}
                                    </div>

                                    <div className="provider-specializations">
                                        {provider.specializations.map((spec, i) => (
                                            <span key={i} className="spec-tag">{spec}</span>
                                        ))}
                                    </div>

                                    <div className="provider-details">
                                        <div className="detail-item">
                                            <MapPin size={16} />
                                            <span>{provider.location}</span>
                                        </div>
                                        <div className="detail-item">
                                            <DollarSign size={16} />
                                            <span>From KES {provider.price}</span>
                                        </div>
                                    </div>

                                    <div className="provider-actions">
                                        <Link to={`/providers/${provider.id}`} className="btn btn-outline">
                                            View Profile
                                        </Link>
                                        <Link
                                            to={`/providers/${provider.id}`}
                                            state={{ openBooking: true }}
                                            className="btn btn-primary"
                                        >
                                            <Calendar size={18} />
                                            Book Now
                                        </Link>
                                    </div>
                                </motion.div>
                            ))}
                        </div>
                    )}
                </div>
            </section>
        </div>
    );
};

export default ServiceProvidersPage;
