import { motion } from 'framer-motion';
import { Sparkles, Search, Calendar, Star, ArrowRight, Check, ChevronLeft, ChevronRight, User, Clock, Heart, Moon, Sun, Instagram, Facebook, Twitter, Youtube } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import './LandingPage.css';

const LandingPage = () => {
    const navigate = useNavigate();
    const { user, logout } = useAuth();
    const [currentSlide, setCurrentSlide] = useState(0);
    const [darkMode, setDarkMode] = useState(false);

    useEffect(() => {
        if (darkMode) {
            document.body.classList.add('dark-mode');
        } else {
            document.body.classList.remove('dark-mode');
        }
    }, [darkMode]);

    const features = [
        {
            icon: <Search size={32} />,
            title: 'Find Artists',
            description: 'Discover talented beauty professionals in your area with verified portfolios.'
        },
        {
            icon: <Calendar size={32} />,
            title: 'Book Instantly',
            description: 'Secure your appointment in seconds with real-time availability.'
        },
        {
            icon: <Star size={32} />,
            title: 'Premium Experience',
            description: 'Enjoy top-tier service from vetted experts committed to excellence.'
        }
    ];

    const serviceSlides = [
        {
            image: 'https://images.unsplash.com/photo-1487412912498-0447578fcca8?w=800',
            title: 'Bridal & Event Makeup',
            desc: 'Radiate elegance on your special day.'
        },
        {
            image: 'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?w=800',
            title: 'Luxury Hair Styling',
            desc: 'From custom wigs to precision cuts.'
        },
        {
            image: 'https://images.unsplash.com/photo-1560066984-138dadb4c035?w=800',
            title: 'Nail Artistry',
            desc: 'Exquisite designs for every occasion.'
        },
        {
            image: 'https://images.unsplash.com/photo-1570172619644-dfd03ed5d881?w=800',
            title: 'Rejuvenating Facials',
            desc: 'Restore your glow with expert care.'
        }
    ];

    const blogs = [
        {
            id: 1,
            image: 'https://images.unsplash.com/photo-1596462502278-27bfdd403348?w=400',
            title: 'Summer Beauty Trends 2025',
            excerpt: 'The hottest looks taking over the season.',
            author: 'Sarah J.',
            date: 'Nov 25, 2025'
        },
        {
            id: 2,
            image: 'https://images.unsplash.com/photo-1516975080664-ed2fc6a32937?w=400',
            title: 'Wig Care 101',
            excerpt: 'Keep your installation looking flawless.',
            author: 'Amara O.',
            date: 'Nov 20, 2025'
        },
        {
            id: 3,
            image: 'https://images.unsplash.com/photo-1512496015851-a90fb38ba796?w=400',
            title: 'The Glass Skin Routine',
            excerpt: 'Expert steps to achieving that radiant glow.',
            author: 'Dr. Smith',
            date: 'Nov 15, 2025'
        }
    ];

    const nextSlide = () => {
        setCurrentSlide((prev) => (prev + 1) % serviceSlides.length);
    };

    const prevSlide = () => {
        setCurrentSlide((prev) => (prev - 1 + serviceSlides.length) % serviceSlides.length);
    };

    return (
        <div className="landing-page">
            {/* Navigation */}
            <nav className="navbar">
                <div className="container nav-content">
                    <div className="logo-container">
                        <img src="/assets/logo.png" alt="ZOO beauty Palace" className="logo-image" />
                        <span className="logo-text">
                            <span className="logo-top">ZOO</span>
                            <span className="logo-bottom">beauty Palace</span>
                        </span>
                    </div>

                    <div className="nav-center">
                        <Link to="/services" className="nav-link">Services</Link>
                        <Link to="/about" className="nav-link">About</Link>
                        <Link to="/journal" className="nav-link">Journal</Link>
                    </div>

                    <div className="nav-actions">
                        {user ? (
                            <>
                                <Link
                                    to={
                                        user.role === 'admin' ? '/admin/dashboard' :
                                            user.role === 'provider' ? '/provider/dashboard' :
                                                '/client/dashboard'
                                    }
                                    className="nav-link"
                                    style={{ marginRight: '1rem' }}
                                >
                                    Dashboard
                                </Link>
                                <button
                                    onClick={() => {
                                        logout();
                                        navigate('/');
                                    }}
                                    className="btn btn-outline"
                                    style={{ padding: '0.5rem 1rem', fontSize: '0.9rem' }}
                                >
                                    Logout
                                </button>
                            </>
                        ) : (
                            <>
                                {/* Admin login removed as per requirements */}
                            </>
                        )}
                        <Link to="/services" className="btn btn-primary" style={{ padding: '0.5rem 1.5rem', fontSize: '0.9rem' }}>Book Now</Link>
                        <button
                            className="theme-toggle"
                            onClick={() => setDarkMode(!darkMode)}
                            title={darkMode ? "Switch to Light Mode" : "Switch to Dark Mode"}
                            style={{ background: 'transparent', border: 'none', color: 'var(--text-secondary)', cursor: 'pointer', marginLeft: '1rem' }}
                        >
                            {darkMode ? <Sun size={20} /> : <Moon size={20} />}
                        </button>
                    </div>
                </div>
            </nav>

            {/* Hero Section */}
            <section className="hero">
                <div className="container">
                    <motion.div
                        className="hero-content"
                        initial={{ opacity: 0, y: 30 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.8 }}
                    >
                        <div className="inline-block px-4 py-2 mb-6 rounded-full bg-white/30 backdrop-blur-md border border-white/40 text-sm font-medium text-primary shadow-sm">
                            ✨ Elevate Your Beauty Routine
                        </div>
                        <h1 className="hero-title">
                            Beauty Services,
                            <br />
                            <span className="gradient-text">Perfected.</span>
                        </h1>
                        <p className="hero-subtitle">
                            Connect with the city's finest makeup artists, hair stylists, and beauty experts.
                            Luxury service, delivered to you.
                        </p>

                        <div className="hero-actions">
                            <Link to="/choose-service" className="btn btn-primary btn-lg">
                                Find an Artist
                                <ArrowRight size={20} />
                            </Link>
                            <Link to="/register?type=provider" className="btn btn-outline btn-lg">
                                I'm a Professional
                            </Link>
                        </div>

                        <div className="hero-stats">
                            <div className="stat">
                                <div className="stat-value">1k+</div>
                                <div className="stat-label">Elite Artists</div>
                            </div>
                            <div className="stat">
                                <div className="stat-value">50k+</div>
                                <div className="stat-label">Glowing Reviews</div>
                            </div>
                            <div className="stat">
                                <div className="stat-value">4.9</div>
                                <div className="stat-label">Star Rating</div>
                            </div>
                        </div>
                    </motion.div>
                </div>
            </section>

            {/* Service Carousel Section */}
            <section className="services-carousel-section">
                <div className="container">
                    <div className="section-header text-center mb-12">
                        <h2>Curated Services</h2>
                        <p style={{ color: 'var(--text-secondary)', fontSize: '1.2rem' }}>Experience the art of beauty</p>
                    </div>

                    <div className="carousel-container">
                        <button className="carousel-btn prev" onClick={prevSlide}><ChevronLeft /></button>
                        <div className="carousel-track">
                            <motion.div
                                className="carousel-slide"
                                key={currentSlide}
                                initial={{ opacity: 0, scale: 0.95 }}
                                animate={{ opacity: 1, scale: 1 }}
                                exit={{ opacity: 0, scale: 0.95 }}
                                transition={{ duration: 0.5 }}
                            >
                                <img src={serviceSlides[currentSlide].image} alt={serviceSlides[currentSlide].title} />
                                <div className="slide-content">
                                    <h3>{serviceSlides[currentSlide].title}</h3>
                                    <p>{serviceSlides[currentSlide].desc}</p>
                                    <Link to="/services" className="btn btn-primary btn-sm mt-4">Reserve Now</Link>
                                </div>
                            </motion.div>
                        </div>
                        <button className="carousel-btn next" onClick={nextSlide}><ChevronRight /></button>
                    </div>
                </div>
            </section>

            {/* Features Section */}
            <section className="features">
                <div className="container">
                    <motion.div
                        className="section-header text-center mb-12"
                        initial={{ opacity: 0 }}
                        whileInView={{ opacity: 1 }}
                        viewport={{ once: true }}
                    >
                        <h2>The ZOO beauty Palace Standard</h2>
                        <p style={{ color: 'var(--text-secondary)', fontSize: '1.2rem' }}>Why we are the preferred choice for beauty</p>
                    </motion.div>

                    <div className="features-grid">
                        {features.map((feature, index) => (
                            <motion.div
                                key={index}
                                className="feature-card"
                                initial={{ opacity: 0, y: 30 }}
                                whileInView={{ opacity: 1, y: 0 }}
                                viewport={{ once: true }}
                                transition={{ delay: index * 0.1 }}
                            >
                                <div className="feature-icon">{feature.icon}</div>
                                <h3>{feature.title}</h3>
                                <p>{feature.description}</p>
                            </motion.div>
                        ))}
                    </div>
                </div>
            </section>

            {/* Blogs Section */}
            <section id="blogs" className="blogs-section">
                <div className="container">
                    <div className="section-header text-center mb-12">
                        <h2>Beauty Journal</h2>
                        <p style={{ color: 'var(--text-secondary)', fontSize: '1.2rem' }}>Trends, tips, and expert advice</p>
                    </div>
                    <div className="blogs-grid">
                        {blogs.map((blog, index) => (
                            <motion.div
                                key={blog.id}
                                className="blog-card"
                                initial={{ opacity: 0, y: 20 }}
                                whileInView={{ opacity: 1, y: 0 }}
                                viewport={{ once: true }}
                                transition={{ delay: index * 0.1 }}
                            >
                                <img src={blog.image} alt={blog.title} className="blog-image" />
                                <div className="blog-content">
                                    <div className="blog-meta">
                                        <span className="flex items-center gap-1"><User size={14} /> {blog.author}</span>
                                        <span className="flex items-center gap-1"><Clock size={14} /> {blog.date}</span>
                                    </div>
                                    <h3>{blog.title}</h3>
                                    <p>{blog.excerpt}</p>
                                    <Link to={`/journal/${blog.id}`} className="read-more">Read Article <ArrowRight size={16} /></Link>
                                </div>
                            </motion.div>
                        ))}
                    </div>
                </div>
            </section>

            {/* CTA Section */}
            <section className="cta">
                <div className="container">
                    <motion.div
                        className="cta-content"
                        initial={{ opacity: 0, scale: 0.95 }}
                        whileInView={{ opacity: 1, scale: 1 }}
                        viewport={{ once: true }}
                    >
                        <h2>Ready to Glow?</h2>
                        <p>Join the community of beauty enthusiasts and professionals.</p>
                        <div className="cta-actions">
                            <Link to="/services" className="btn btn-white btn-lg" style={{ background: 'white', color: '#be123c' }}>
                                Explore Services
                            </Link>
                            <Link to="/register?type=provider" className="btn btn-outline btn-lg" style={{ borderColor: 'white', color: 'white' }}>
                                Join as Artist
                            </Link>
                        </div>
                    </motion.div>
                </div>
            </section>

            {/* Footer */}
            <footer className="footer">
                <div className="container">
                    <div className="footer-content">
                        <div className="footer-section">
                            <div className="logo-container mb-4">
                                <img src="/assets/logo.png" alt="ZOO beauty Palace" className="logo-image" style={{ width: '40px', height: '40px' }} />
                                <span className="logo-text" style={{ color: 'white' }}>
                                    <span className="logo-top">ZOO</span>
                                    <span className="logo-bottom">beauty Palace</span>
                                </span>
                            </div>
                            <p className="text-rose-200 mb-6">Redefining luxury beauty services on demand. Connect with the best.</p>
                            <div className="flex gap-4">
                                <a href="#" className="hover:text-white transition-colors"><Instagram size={20} /></a>
                                <a href="#" className="hover:text-white transition-colors"><Facebook size={20} /></a>
                                <a href="#" className="hover:text-white transition-colors"><Twitter size={20} /></a>
                                <a href="#" className="hover:text-white transition-colors"><Youtube size={20} /></a>
                            </div>
                        </div>

                        <div className="footer-section">
                            <h4>Discover</h4>
                            <Link to="/services/makeup">Makeup Artists</Link>
                            <Link to="/services/hair">Hair Stylists</Link>
                            <Link to="/services/nails">Nail Technicians</Link>
                            <Link to="/services/skincare">Skincare Experts</Link>
                        </div>

                        <div className="footer-section">
                            <h4>Company</h4>
                            <Link to="/about">Our Story</Link>
                            <Link to="/about">Careers</Link>
                            <Link to="/about">Press</Link>
                            <Link to="/about">Contact Us</Link>
                        </div>

                        <div className="footer-section">
                            <h4>Legal</h4>
                            <Link to="/about">Terms of Service</Link>
                            <Link to="/about">Privacy Policy</Link>
                            <Link to="/about">Cookie Policy</Link>
                        </div>
                    </div>

                    <div className="footer-bottom mt-12 pt-8 border-t border-rose-900 text-center text-rose-300">
                        <p>&copy; 2025 ZOO beauty Palace. All rights reserved.</p>
                    </div>
                </div>
            </footer>
        </div>
    );
};

export default LandingPage;
