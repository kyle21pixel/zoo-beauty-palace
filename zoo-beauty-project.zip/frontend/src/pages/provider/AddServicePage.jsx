import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useToast } from '../../context/ToastContext';
import { ArrowLeft, Save } from 'lucide-react';
import '../../pages/provider/ProviderDashboard.css';

const AddServicePage = () => {
    const navigate = useNavigate();
    const { showSuccess, showError } = useToast();
    const [loading, setLoading] = useState(false);

    const [formData, setFormData] = useState({
        serviceName: '',
        category: '',
        price: '',
        duration: '',
        description: '',
        preparationTime: '',
        cleanupTime: ''
    });

    const handleBack = () => {
        navigate('/provider/dashboard');
    };

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        try {
            await new Promise(resolve => setTimeout(resolve, 1500));
            showSuccess('Service added successfully!');
            navigate('/provider/dashboard');
        } catch (error) {
            showError('Failed to add service');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="provider-dashboard">
            <div className="add-page-container" style={{ padding: '2rem', maxWidth: '800px', margin: '0 auto' }}>
                <header className="page-header" style={{ marginBottom: '2rem', display: 'flex', alignItems: 'center', gap: '1rem' }}>
                    <button className="btn btn-ghost" onClick={handleBack}>
                        <ArrowLeft size={24} />
                    </button>
                    <div>
                        <h1>Add New Service</h1>
                        <p className="section-subtitle">Define a new service for your clients</p>
                    </div>
                </header>

                <form onSubmit={handleSubmit} className="add-service-form card" style={{ padding: '2rem' }}>
                    <div className="form-group">
                        <label>Service Name</label>
                        <input
                            type="text"
                            name="serviceName"
                            className="input"
                            placeholder="e.g. Bridal Makeup Package"
                            value={formData.serviceName}
                            onChange={handleInputChange}
                            required
                        />
                    </div>

                    <div className="form-row" style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                        <div className="form-group">
                            <label>Category</label>
                            <select
                                name="category"
                                className="input"
                                value={formData.category}
                                onChange={handleInputChange}
                                required
                            >
                                <option value="">Select Category</option>
                                <option value="hair">Hair</option>
                                <option value="makeup">Makeup</option>
                                <option value="nails">Nails</option>
                                <option value="spa">Spa & Massage</option>
                            </select>
                        </div>
                        <div className="form-group">
                            <label>Price (KES)</label>
                            <input
                                type="number"
                                name="price"
                                className="input"
                                placeholder="0.00"
                                value={formData.price}
                                onChange={handleInputChange}
                                required
                            />
                        </div>
                    </div>

                    <div className="form-row" style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '1rem' }}>
                        <div className="form-group">
                            <label>Duration</label>
                            <input
                                type="text"
                                name="duration"
                                className="input"
                                placeholder="e.g. 1 hour"
                                value={formData.duration}
                                onChange={handleInputChange}
                                required
                            />
                        </div>
                        <div className="form-group">
                            <label>Prep Time (mins)</label>
                            <input
                                type="number"
                                name="preparationTime"
                                className="input"
                                placeholder="15"
                                value={formData.preparationTime}
                                onChange={handleInputChange}
                            />
                        </div>
                        <div className="form-group">
                            <label>Cleanup Time (mins)</label>
                            <input
                                type="number"
                                name="cleanupTime"
                                className="input"
                                placeholder="15"
                                value={formData.cleanupTime}
                                onChange={handleInputChange}
                            />
                        </div>
                    </div>

                    <div className="form-group">
                        <label>Description</label>
                        <textarea
                            name="description"
                            className="input"
                            rows="4"
                            placeholder="Describe what the service entails..."
                            value={formData.description}
                            onChange={handleInputChange}
                        />
                    </div>

                    <div className="form-actions" style={{ marginTop: '2rem', display: 'flex', justifyContent: 'flex-end', gap: '1rem' }}>
                        <button type="button" className="btn btn-ghost" onClick={handleBack}>Cancel</button>
                        <button type="submit" className="btn btn-primary" disabled={loading}>
                            {loading ? <div className="spinner-small"></div> : <Save size={20} />}
                            {loading ? 'Saving...' : 'Save Service'}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default AddServicePage;
