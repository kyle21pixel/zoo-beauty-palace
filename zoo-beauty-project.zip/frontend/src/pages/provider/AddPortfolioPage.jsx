import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useToast } from '../../context/ToastContext';
import { ArrowLeft, Upload, Save, X } from 'lucide-react';
import '../../pages/provider/ProviderDashboard.css';

const AddPortfolioPage = () => {
    const navigate = useNavigate();
    const { showSuccess, showError } = useToast();
    const [loading, setLoading] = useState(false);
    const [image, setImage] = useState(null);

    const [formData, setFormData] = useState({
        title: '',
        category: '',
        description: ''
    });

    const handleBack = () => {
        navigate('/provider/dashboard');
    };

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleImageUpload = (e) => {
        const file = e.target.files[0];
        if (file) {
            setImage(URL.createObjectURL(file));
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        try {
            await new Promise(resolve => setTimeout(resolve, 1500));
            showSuccess('Portfolio item added successfully!');
            navigate('/provider/dashboard');
        } catch (error) {
            showError('Failed to add portfolio item');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="provider-dashboard">
            <div className="add-page-container" style={{ padding: '2rem', maxWidth: '800px', margin: '0 auto' }}>
                <header className="page-header" style={{ marginBottom: '2rem', display: 'flex', alignItems: 'center', gap: '1rem' }}>
                    <button className="btn btn-ghost" onClick={handleBack}>
                        <ArrowLeft size={24} />
                    </button>
                    <div>
                        <h1>Add Portfolio Item</h1>
                        <p className="section-subtitle">Showcase your best work to potential clients</p>
                    </div>
                </header>

                <form onSubmit={handleSubmit} className="add-portfolio-form card" style={{ padding: '2rem' }}>
                    <div className="form-group">
                        <label>Title</label>
                        <input
                            type="text"
                            name="title"
                            className="input"
                            placeholder="e.g. Summer Bridal Look"
                            value={formData.title}
                            onChange={handleInputChange}
                            required
                        />
                    </div>

                    <div className="form-group">
                        <label>Category</label>
                        <select
                            name="category"
                            className="input"
                            value={formData.category}
                            onChange={handleInputChange}
                            required
                        >
                            <option value="">Select Category</option>
                            <option value="hair">Hair</option>
                            <option value="makeup">Makeup</option>
                            <option value="nails">Nails</option>
                            <option value="spa">Spa</option>
                        </select>
                    </div>

                    <div className="form-group">
                        <label>Image</label>
                        <div className="image-upload-area" style={{
                            border: '2px dashed var(--pd-border)',
                            borderRadius: '8px',
                            padding: '2rem',
                            textAlign: 'center',
                            marginTop: '0.5rem',
                            cursor: 'pointer',
                            position: 'relative',
                            minHeight: '200px',
                            display: 'flex',
                            flexDirection: 'column',
                            justifyContent: 'center',
                            alignItems: 'center'
                        }}>
                            {!image ? (
                                <>
                                    <input
                                        type="file"
                                        accept="image/*"
                                        onChange={handleImageUpload}
                                        style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%', opacity: 0, cursor: 'pointer' }}
                                        required
                                    />
                                    <Upload size={48} color="var(--pd-text-secondary)" />
                                    <p style={{ marginTop: '1rem', color: 'var(--pd-text-secondary)' }}>Click or drag to upload photo</p>
                                </>
                            ) : (
                                <div style={{ position: 'relative', width: '100%', height: '100%' }}>
                                    <img src={image} alt="Preview" style={{ maxWidth: '100%', maxHeight: '400px', borderRadius: '4px' }} />
                                    <button
                                        type="button"
                                        onClick={() => setImage(null)}
                                        style={{
                                            position: 'absolute', top: '10px', right: '10px',
                                            background: 'rgba(0,0,0,0.7)', color: 'white',
                                            border: 'none', borderRadius: '50%',
                                            width: '32px', height: '32px',
                                            display: 'flex', alignItems: 'center', justifyContent: 'center',
                                            cursor: 'pointer'
                                        }}
                                    >
                                        <X size={20} />
                                    </button>
                                </div>
                            )}
                        </div>
                    </div>

                    <div className="form-group">
                        <label>Description</label>
                        <textarea
                            name="description"
                            className="input"
                            rows="3"
                            placeholder="Add details about this work..."
                            value={formData.description}
                            onChange={handleInputChange}
                        />
                    </div>

                    <div className="form-actions" style={{ marginTop: '2rem', display: 'flex', justifyContent: 'flex-end', gap: '1rem' }}>
                        <button type="button" className="btn btn-ghost" onClick={handleBack}>Cancel</button>
                        <button type="submit" className="btn btn-primary" disabled={loading}>
                            {loading ? <div className="spinner-small"></div> : <Save size={20} />}
                            {loading ? 'Saving...' : 'Publish to Portfolio'}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default AddPortfolioPage;
