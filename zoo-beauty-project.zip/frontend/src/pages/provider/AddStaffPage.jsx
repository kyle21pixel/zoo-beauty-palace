import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useToast } from '../../context/ToastContext';
import { ArrowLeft, Save, User, Mail, Phone, MapPin, Calendar, Clock, Briefcase } from 'lucide-react';
import '../../pages/provider/ProviderDashboard.css';

const AddStaffPage = () => {
    const navigate = useNavigate();
    const { showSuccess, showError } = useToast();
    const [loading, setLoading] = useState(false);

    const [formData, setFormData] = useState({
        firstName: '',
        lastName: '',
        email: '',
        phone: '',
        role: 'beautician',
        specializations: '',
        bio: '',
        scheduleType: 'full-time',
        startDate: ''
    });

    const handleBack = () => {
        navigate('/provider/dashboard');
    };

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);

        try {
            // Simulate API call
            await new Promise(resolve => setTimeout(resolve, 1500));
            showSuccess('Staff invitation sent successfully!');
            navigate('/provider/dashboard');
        } catch (error) {
            console.error('Error adding staff:', error);
            showError('Failed to add staff member');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="provider-dashboard">
            <div className="add-page-container" style={{ padding: '2rem', maxWidth: '1000px', margin: '0 auto' }}>
                <header className="page-header" style={{ marginBottom: '2rem', display: 'flex', alignItems: 'center', gap: '1rem' }}>
                    <button className="btn btn-ghost" onClick={handleBack}>
                        <ArrowLeft size={24} />
                    </button>
                    <div>
                        <h1>Add Staff Member</h1>
                        <p className="section-subtitle">Onboard new team members and assign roles</p>
                    </div>
                </header>

                <form onSubmit={handleSubmit} className="add-staff-form">
                    <div className="grid-layout" style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '2rem' }}>

                        {/* Personal Information */}
                        <div className="card" style={{ padding: '2rem' }}>
                            <h3 style={{ marginBottom: '1.5rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                                <User size={20} /> Personal Information
                            </h3>

                            <div className="form-row" style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                                <div className="form-group">
                                    <label>First Name</label>
                                    <input
                                        type="text"
                                        name="firstName"
                                        className="input"
                                        placeholder="Jane"
                                        value={formData.firstName}
                                        onChange={handleInputChange}
                                        required
                                    />
                                </div>
                                <div className="form-group">
                                    <label>Last Name</label>
                                    <input
                                        type="text"
                                        name="lastName"
                                        className="input"
                                        placeholder="Doe"
                                        value={formData.lastName}
                                        onChange={handleInputChange}
                                        required
                                    />
                                </div>
                            </div>

                            <div className="form-group">
                                <label>Email Address</label>
                                <div className="input-with-icon" style={{ position: 'relative' }}>
                                    <Mail size={18} style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: 'var(--pd-text-secondary)' }} />
                                    <input
                                        type="email"
                                        name="email"
                                        className="input"
                                        style={{ paddingLeft: '2.5rem' }}
                                        placeholder="jane.doe@example.com"
                                        value={formData.email}
                                        onChange={handleInputChange}
                                        required
                                    />
                                </div>
                            </div>

                            <div className="form-group">
                                <label>Phone Number</label>
                                <div className="input-with-icon" style={{ position: 'relative' }}>
                                    <Phone size={18} style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: 'var(--pd-text-secondary)' }} />
                                    <input
                                        type="tel"
                                        name="phone"
                                        className="input"
                                        style={{ paddingLeft: '2.5rem' }}
                                        placeholder="+254 700 000000"
                                        value={formData.phone}
                                        onChange={handleInputChange}
                                    />
                                </div>
                            </div>
                        </div>

                        {/* Professional Details */}
                        <div className="card" style={{ padding: '2rem' }}>
                            <h3 style={{ marginBottom: '1.5rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                                <Briefcase size={20} /> Role & Details
                            </h3>

                            <div className="form-group">
                                <label>Role</label>
                                <select
                                    name="role"
                                    className="input"
                                    value={formData.role}
                                    onChange={handleInputChange}
                                >
                                    <option value="beautician">Beautician/Stylist</option>
                                    <option value="receptionist">Receptionist</option>
                                    <option value="assistant">Assistant</option>
                                    <option value="manager">Manager</option>
                                </select>
                            </div>

                            <div className="form-group">
                                <label>Specializations</label>
                                <input
                                    type="text"
                                    name="specializations"
                                    className="input"
                                    placeholder="e.g. Hair Coloring, Nail Art (comma separated)"
                                    value={formData.specializations}
                                    onChange={handleInputChange}
                                />
                            </div>

                            <div className="form-row" style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                                <div className="form-group">
                                    <label>Schedule Type</label>
                                    <select
                                        name="scheduleType"
                                        className="input"
                                        value={formData.scheduleType}
                                        onChange={handleInputChange}
                                    >
                                        <option value="full-time">Full Time</option>
                                        <option value="part-time">Part Time</option>
                                        <option value="on-call">On Call</option>
                                    </select>
                                </div>
                                <div className="form-group">
                                    <label>Start Date</label>
                                    <input
                                        type="date"
                                        name="startDate"
                                        className="input"
                                        value={formData.startDate}
                                        onChange={handleInputChange}
                                    />
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="card" style={{ padding: '2rem', marginTop: '2rem' }}>
                        <div className="form-group">
                            <label>Short Bio / Notes</label>
                            <textarea
                                name="bio"
                                className="input"
                                rows="3"
                                placeholder="Any additional notes about this staff member..."
                                value={formData.bio}
                                onChange={handleInputChange}
                            />
                        </div>
                    </div>

                    <div className="form-actions" style={{ marginTop: '2rem', display: 'flex', justifyContent: 'flex-end', gap: '1rem' }}>
                        <button type="button" className="btn btn-ghost" onClick={handleBack}>Cancel</button>
                        <button type="submit" className="btn btn-primary" disabled={loading}>
                            {loading ? <div className="spinner-small"></div> : <Save size={20} />}
                            {loading ? 'Sending Invite...' : 'Create Staff Profile'}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default AddStaffPage;
