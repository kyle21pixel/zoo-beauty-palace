import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { useNotification } from '../../context/NotificationContext';
import {
    Calendar, DollarSign, Star, TrendingUp, Users,
    MessageSquare, Settings, LogOut, Image, Clock, MapPin, Bell,
    Moon, Sun, Check, X, Eye, Edit, Zap, Briefcase, BarChart3,
    Megaphone, Package, UserPlus, Navigation, Phone, Search,
    Filter, RefreshCw, ArrowUp, ArrowDown, Target, FileText, Menu, Scissors, ShoppingBag, Plus, Trash2, Tag
} from 'lucide-react';
import { BarChart, LineChart, PieChart } from '../../components/ChartComponents';
import {
    getProviderStats, getProviderProfile, getProviderBookings,
    acceptBooking, rejectBooking, addPortfolioItem, removePortfolioItem,
    updateProviderProfile
} from '../../services/providerService';
import { providerAssignTask, getProviderAssignments } from '../../services/assignmentService';
import {
    getProviderDashboardOverview,
    getProviderPerformanceChart,
    getProviderStaff,
    getAvailableStaff,
    assignBookingToStaff,
    getProviderRevenue
} from '../../services/providerDashboardService';
import { mockProviders, mockBookings, mockDashboardStats, mockReviews, mockNotifications } from '../../data/mockData';

import './ProviderDashboard.css';

// Generic Modal Component
const GenericModal = ({ isOpen, onClose, title, children }) => {
    if (!isOpen) return null;
    return (
        <div className="modal-overlay">
            <div className="modal-content">
                <div className="modal-header">
                    <h3>{title}</h3>
                    <button onClick={onClose} className="btn-ghost" style={{ padding: '4px' }}>
                        <X size={20} />
                    </button>
                </div>
                <div className="modal-body">
                    {children}
                </div>
            </div>
        </div>
    );
};

const ProviderDashboard = () => {
    const navigate = useNavigate();
    const { user, logout } = useAuth();
    const { showSuccess, showError } = useToast();
    const { notifications, unreadCount, markAsRead } = useNotification();
    const [activeTab, setActiveTab] = useState('overview');
    const [darkMode, setDarkMode] = useState(false);
    const [loading, setLoading] = useState(true);
    const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

    // Modal State
    const [modalOpen, setModalOpen] = useState(false);
    const [modalType, setModalType] = useState(null); // 'addService', 'addProduct', 'addStaff', 'assignStaff', 'payout'
    const [modalData, setModalData] = useState(null);

    const [providerData, setProviderData] = useState({
        name: '',
        businessName: '',
        avatar: '',
        rating: 0,
        reviewCount: 0,
        isOnline: false,
        phone: '',
        bio: '',
        stats: {
            totalBookings: 0,
            completedBookings: 0,
            totalEarnings: 0,
            thisMonthEarnings: 0,
            pendingBookings: 0,
            upcomingBookings: 0
        }
    });

    const [bookings, setBookings] = useState([]);
    const [filteredBookings, setFilteredBookings] = useState([]); // Added for filtering
    const [bookingsFilter, setBookingsFilter] = useState('all'); // Added filter state

    const [upcomingBookings, setUpcomingBookings] = useState([]);
    const [portfolio, setPortfolio] = useState([]);
    const [reviews, setReviews] = useState([]);
    const [messages, setMessages] = useState([]);
    const [earnings, setEarnings] = useState([]);
    const [assignments, setAssignments] = useState([]);

    // New dashboard data
    const [dashboardStats, setDashboardStats] = useState({});
    const [chartData, setChartData] = useState([]);
    const [revenueChartData, setRevenueChartData] = useState([]);
    const [bookingTrendsData, setBookingTrendsData] = useState([]);
    const [serviceDistributionData, setServiceDistributionData] = useState([]);
    const [advancedAnalytics, setAdvancedAnalytics] = useState({
        topServices: [],
        clientMetrics: {},
        peakHours: [],
        monthlyGrowth: []
    });
    const [staff, setStaff] = useState([]);
    const [availableStaff, setAvailableStaff] = useState([]);
    const [pendingBookings, setPendingBookings] = useState([]);
    const [revenueData, setRevenueData] = useState(null);
    const [chartTimeRange, setChartTimeRange] = useState('week'); // For chart filtering

    useEffect(() => {
        fetchData();
    }, []);

    // Effect to handle booking filtering
    useEffect(() => {
        if (bookingsFilter === 'all') {
            setFilteredBookings(bookings);
        } else {
            setFilteredBookings(bookings.filter(b => b.status === bookingsFilter));
        }
    }, [bookings, bookingsFilter]);

    // Close mobile menu when clicking outside
    useEffect(() => {
        const handleClickOutside = (event) => {
            if (mobileMenuOpen && !event.target.closest('.dashboard-sidebar') && !event.target.closest('.menu-toggle')) {
                setMobileMenuOpen(false);
            }
        };

        document.addEventListener('click', handleClickOutside);
        return () => {
            document.removeEventListener('click', handleClickOutside);
        };
    }, [mobileMenuOpen]);

    const fetchData = async () => {
        try {
            // Use new dashboard overview API for better performance
            const [overviewRes, profileRes, bookingsRes, assignmentsRes, staffRes] = await Promise.all([
                getProviderDashboardOverview().catch(() => ({ success: false })),
                getProviderProfile().catch(() => ({ success: false })),
                getProviderBookings({ limit: 50 }).catch(() => ({ success: false })),
                getProviderAssignments({ limit: 50 }).catch(() => ({ success: false })),
                getProviderStaff().catch(() => ({ success: false }))
            ]);

            // Set dashboard stats from new API
            if (overviewRes.success) {
                setDashboardStats(overviewRes.data.stats);
                setProviderData(prev => ({
                    ...prev,
                    businessName: overviewRes.data.provider.businessName,
                    rating: overviewRes.data.provider.rating,
                    reviewCount: overviewRes.data.provider.reviewCount,
                    isOnline: overviewRes.data.provider.isOnline,
                    stats: overviewRes.data.stats
                }));
            }

            if (profileRes.success) {
                setProviderData(prev => ({
                    ...prev,
                    name: `${profileRes.data.user.firstName} ${profileRes.data.user.lastName}`,
                    avatar: profileRes.data.user.avatar,
                    phone: profileRes.data.user.phone,
                    bio: profileRes.data.providerProfile.bio
                }));
                setPortfolio(profileRes.data.providerProfile.portfolio || []);
            }

            if (bookingsRes.success) {
                setBookings(bookingsRes.data.bookings);
                setUpcomingBookings(bookingsRes.data.bookings.filter(b =>
                    new Date(b.scheduledDate) > new Date() && b.status === 'confirmed'
                ));
                setPendingBookings(bookingsRes.data.bookings.filter(b => b.status === 'pending'));
            }

            if (assignmentsRes.success) {
                setAssignments(assignmentsRes.data.assignments);
            }

            if (staffRes.success) {
                setStaff(staffRes.data.staff);
            }

            // Fetch chart data
            const chartRes = await getProviderPerformanceChart('week').catch(() => ({ success: false }));
            if (chartRes.success) {
                setChartData(chartRes.data.chartData);

                // Process data for different chart types
                const revenueData = chartRes.data.chartData.map(item => ({
                    date: item.date,
                    earnings: item.earnings
                }));
                setRevenueChartData(revenueData);

                const bookingData = chartRes.data.chartData.map(item => ({
                    date: item.date,
                    bookings: item.bookings
                }));
                setBookingTrendsData(bookingData);

                // Mock service distribution data
                const serviceData = [
                    { name: 'Hair Styling', value: 35 },
                    { name: 'Makeup', value: 25 },
                    { name: 'Nails', value: 20 },
                    { name: 'Facial', value: 15 },
                    { name: 'Waxing', value: 5 }
                ];
                setServiceDistributionData(serviceData);
            }



            // Fetch available staff
            const availableRes = await getAvailableStaff().catch(() => ({ success: false }));
            if (availableRes.success) {
                setAvailableStaff(availableRes.data.availableStaff);
            }

            // Use mock data for Reviews, Messages, Earnings if API endpoints not ready
            setReviews(mockReviews.map(r => ({
                id: r._id,
                client: `${r.clientId.firstName} ${r.clientId.lastName}`,
                rating: r.rating,
                comment: r.comment,
                date: new Date(r.createdAt).toLocaleDateString()
            })));

            setMessages(mockNotifications.map((n, i) => ({
                id: n._id || i,
                client: "System Notification",
                message: n.message,
                time: new Date(n.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                unread: !n.read
            })));

            const today = new Date();
            const last6Months = Array.from({ length: 6 }, (_, i) => {
                const d = new Date(today.getFullYear(), today.getMonth() - i, 1);
                return d.toLocaleString('default', { month: 'long' });
            }).reverse();

            setEarnings(last6Months.map((month, i) => ({
                month,
                bookings: Math.floor(Math.random() * 50) + 10,
                amount: (Math.floor(Math.random() * 50) + 10) * 1500
            })));

        } catch (error) {
            console.error('Error fetching provider data:', error);
        } finally {
            setLoading(false);
        }
    };

    const handleAcceptBooking = async (id) => {
        try {
            await acceptBooking(id);
            showSuccess('Booking accepted successfully');
            fetchData(); // Refresh
        } catch (error) {
            console.error('Error accepting booking:', error);
            showError('Failed to accept booking');
        }
    };

    const handleRejectBooking = async (id) => {
        try {
            await rejectBooking(id);
            showSuccess('Booking rejected successfully');
            fetchData(); // Refresh
        } catch (error) {
            console.error('Error rejecting booking:', error);
            showError('Failed to reject booking');
        }
    };

    const handleAssignBooking = async (bookingId, staffId) => {
        try {
            await assignBookingToStaff(bookingId, staffId);
            showSuccess('Booking assigned successfully');
            fetchData(); // Refresh
        } catch (error) {
            console.error('Error assigning booking:', error);
            showError('Failed to assign booking');
        }
    };

    const handleOpenModal = (type, data = null) => {
        setModalType(type);
        setModalData(data);
        setModalOpen(true);
    };

    const handleCloseModal = () => {
        setModalOpen(false);
        setModalType(null);
        setModalData(null);
    };

    const handleFormSubmit = (e) => {
        e.preventDefault();
        // In a real app, you would gather form data here and call the API
        showSuccess('Operation completed successfully');
        handleCloseModal();
        fetchData(); // Refresh data
    };

    const handleManualAssign = (bookingId) => {
        handleOpenModal('assignStaff', { bookingId });
    };

    const renderModalContent = () => {
        switch (modalType) {
            case 'addService':
                return (
                    <form onSubmit={handleFormSubmit}>
                        <div className="form-group">
                            <label>Service Name</label>
                            <input type="text" className="input" placeholder="e.g. Bridal Makeup" required />
                        </div>
                        <div className="form-group">
                            <label>Category</label>
                            <select className="input">
                                <option>Hair</option>
                                <option>Makeup</option>
                                <option>Nails</option>
                                <option>Massage</option>
                            </select>
                        </div>
                        <div className="form-group">
                            <label>Price (KES)</label>
                            <input type="number" className="input" placeholder="0.00" required />
                        </div>
                        <div className="form-group">
                            <label>Duration</label>
                            <input type="text" className="input" placeholder="e.g. 1 hour" required />
                        </div>
                        <button type="submit" className="btn btn-primary w-full" style={{ width: '100%' }}>Add Service</button>
                    </form>
                );
            case 'addProduct':
                return (
                    <form onSubmit={handleFormSubmit}>
                        <div className="form-group">
                            <label>Product Name</label>
                            <input type="text" className="input" placeholder="e.g. Luxury Wig" required />
                        </div>
                        <div className="form-group">
                            <label>Category</label>
                            <select className="input">
                                <option>Wigs</option>
                                <option>Skin Care</option>
                                <option>Makeup</option>
                                <option>Hair Care</option>
                            </select>
                        </div>
                        <div className="form-group">
                            <label>Price (KES)</label>
                            <input type="number" className="input" placeholder="0.00" required />
                        </div>
                        <div className="form-group">
                            <label>Stock Quantity</label>
                            <input type="number" className="input" placeholder="0" required />
                        </div>
                        <div className="form-group">
                            <label>Image URL</label>
                            <input type="text" className="input" placeholder="https://..." />
                        </div>
                        <button type="submit" className="btn btn-primary w-full" style={{ width: '100%' }}>Add Product</button>
                    </form>
                );
            case 'addStaff':
                return (
                    <form onSubmit={handleFormSubmit}>
                        <div className="form-group">
                            <label>Full Name</label>
                            <input type="text" className="input" placeholder="First Last" required />
                        </div>
                        <div className="form-group">
                            <label>Email</label>
                            <input type="email" className="input" placeholder="email@example.com" required />
                        </div>
                        <div className="form-group">
                            <label>Role/Specialty</label>
                            <input type="text" className="input" placeholder="e.g. Nail Technician" required />
                        </div>
                        <div className="form-group">
                            <label>Phone</label>
                            <input type="tel" className="input" placeholder="+254..." />
                        </div>
                        <button type="submit" className="btn btn-primary w-full" style={{ width: '100%' }}>Send Invitation</button>
                    </form>
                );
            case 'assignStaff':
                return (
                    <form onSubmit={handleFormSubmit}>
                        <div className="form-group">
                            <label>Select Staff Member</label>
                            <select className="input" required>
                                <option value="">-- Choose Staff --</option>
                                {availableStaff.map(s => (
                                    <option key={s.id} value={s.id}>{s.firstName} {s.lastName}</option>
                                ))}
                                {staff.map(s => (
                                    <option key={s.id} value={s.id}>{s.firstName} {s.lastName} (Offline)</option>
                                ))}
                            </select>
                        </div>
                        <div className="form-group">
                            <label>Notes</label>
                            <textarea className="input" rows="3" placeholder="Instructions for staff..."></textarea>
                        </div>
                        <button type="submit" className="btn btn-primary w-full" style={{ width: '100%' }}>Assign Booking</button>
                    </form>
                );
            case 'payout':
                return (
                    <form onSubmit={handleFormSubmit}>
                        <div className="form-group">
                            <label>Amount to Withdraw (KES)</label>
                            <input type="number" className="input" max={dashboardStats.totalEarnings} required />
                            <small style={{ display: 'block', marginTop: '0.5rem', color: 'var(--pd-text-secondary)' }}>Available Balance: KES {dashboardStats.totalEarnings?.toLocaleString()}</small>
                        </div>
                        <div className="form-group">
                            <label>Payment Method</label>
                            <select className="input">
                                <option>M-Pesa</option>
                                <option>Bank Transfer</option>
                            </select>
                        </div>
                        <button type="submit" className="btn btn-primary w-full" style={{ width: '100%' }}>Request Payout</button>
                    </form>
                );
            case 'viewBooking':
                return (
                    <div style={{ padding: '0.5rem' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '1.5rem' }}>
                            <div className="client-avatar" style={{ width: '60px', height: '60px', fontSize: '1.5rem' }}>{modalData?.client?.firstName?.charAt(0) || modalData?.clientId?.firstName?.charAt(0)}</div>
                            <div>
                                <h3 style={{ margin: 0 }}>{modalData?.client?.firstName || modalData?.clientId?.firstName} {modalData?.client?.lastName || modalData?.clientId?.lastName}</h3>
                                <p style={{ color: 'var(--pd-text-secondary)' }}>{modalData?.client?.phone || 'No phone number'}</p>
                            </div>
                        </div>
                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                            <div><small style={{ color: 'var(--pd-text-secondary)' }}>Service</small><p style={{ fontWeight: 500 }}>{modalData?.service?.name || modalData?.service}</p></div>
                            <div><small style={{ color: 'var(--pd-text-secondary)' }}>Status</small><p><span className={`status-badge ${modalData?.status}`}>{modalData?.status}</span></p></div>
                            <div><small style={{ color: 'var(--pd-text-secondary)' }}>Date</small><p style={{ fontWeight: 500 }}>{modalData?.scheduledDate ? new Date(modalData?.scheduledDate).toLocaleDateString() : new Date(modalData?.date).toLocaleDateString()}</p></div>
                            <div><small style={{ color: 'var(--pd-text-secondary)' }}>Time</small><p style={{ fontWeight: 500 }}>{modalData?.scheduledTime || modalData?.time}</p></div>
                            <div><small style={{ color: 'var(--pd-text-secondary)' }}>Location</small><p style={{ fontWeight: 500 }}>{modalData?.location?.address || 'N/A'}</p></div>
                            <div><small style={{ color: 'var(--pd-text-secondary)' }}>Amount</small><p style={{ color: 'var(--pd-success)', fontWeight: 600 }}>KES {modalData?.payment?.amount?.toLocaleString() || modalData?.amount}</p></div>
                        </div>
                        <button className="btn btn-outline w-full mt-4" onClick={handleCloseModal}>Close</button>
                    </div>
                );
            case 'viewStaff':
                return (
                    <div style={{ textAlign: 'center' }}>
                        <img src={modalData?.avatar || 'https://i.pravatar.cc/150'} alt={modalData?.firstName} style={{ width: '100px', height: '100px', borderRadius: '50%', marginBottom: '1rem' }} />
                        <h3>{modalData?.firstName} {modalData?.lastName}</h3>
                        <p style={{ color: 'var(--pd-text-secondary)' }}>{modalData?.specializations?.join(', ')}</p>
                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem', marginTop: '1.5rem', textAlign: 'left', background: 'var(--pd-bg)', padding: '1rem', borderRadius: '12px' }}>
                            <div><small style={{ color: 'var(--pd-text-secondary)' }}>Email</small><p style={{ fontWeight: 500 }}>{modalData?.email || 'N/A'}</p></div>
                            <div><small style={{ color: 'var(--pd-text-secondary)' }}>Phone</small><p style={{ fontWeight: 500 }}>{modalData?.phone || 'N/A'}</p></div>
                            <div><small style={{ color: 'var(--pd-text-secondary)' }}>Rating</small><p style={{ fontWeight: 500, color: 'var(--pd-warning)' }}>★ {modalData?.rating?.toFixed(1)}</p></div>
                            <div><small style={{ color: 'var(--pd-text-secondary)' }}>Status</small><p style={{ fontWeight: 500, color: modalData?.isOnline ? 'var(--pd-success)' : 'var(--pd-text-secondary)' }}>{modalData?.isOnline ? 'Online' : 'Offline'}</p></div>
                        </div>
                        <button className="btn btn-outline w-full mt-4" onClick={handleCloseModal}>Close</button>
                    </div>
                );
            case 'editStaff':
                return (
                    <form onSubmit={handleFormSubmit}>
                        <div className="form-group">
                            <label>First Name</label>
                            <input type="text" className="input" defaultValue={modalData?.firstName} required />
                        </div>
                        <div className="form-group">
                            <label>Last Name</label>
                            <input type="text" className="input" defaultValue={modalData?.lastName} required />
                        </div>
                        <div className="form-group">
                            <label>Specializations (comma separated)</label>
                            <input type="text" className="input" defaultValue={modalData?.specializations?.join(', ')} required />
                        </div>
                        <button type="submit" className="btn btn-primary w-full" style={{ width: '100%' }}>Save Changes</button>
                    </form>
                );
            case 'editService':
                return (
                    <form onSubmit={handleFormSubmit}>
                        <div className="form-group">
                            <label>Service Name</label>
                            <input type="text" className="input" defaultValue={modalData?.name} required />
                        </div>
                        <div className="form-group">
                            <label>Price (KES)</label>
                            <input type="number" className="input" defaultValue={modalData?.price} required />
                        </div>
                        <div className="form-group">
                            <label>Duration</label>
                            <input type="text" className="input" defaultValue={modalData?.duration} required />
                        </div>
                        <div className="form-group">
                            <label>Category</label>
                            <input type="text" className="input" defaultValue={modalData?.category} required />
                        </div>
                        <div className="form-group">
                            <label style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', cursor: 'pointer' }}>
                                <input type="checkbox" defaultChecked={modalData?.active} />
                                Active Service
                            </label>
                        </div>
                        <button type="submit" className="btn btn-primary w-full" style={{ width: '100%' }}>Save Changes</button>
                    </form>
                );
            case 'editProduct':
                return (
                    <form onSubmit={handleFormSubmit}>
                        <div className="form-group">
                            <label>Product Name</label>
                            <input type="text" className="input" defaultValue={modalData?.name} required />
                        </div>
                        <div className="form-group">
                            <label>Price (KES)</label>
                            <input type="number" className="input" defaultValue={modalData?.price} required />
                        </div>
                        <div className="form-group">
                            <label>Stock</label>
                            <input type="number" className="input" defaultValue={modalData?.stock} required />
                        </div>
                        <div className="form-group">
                            <label>Category</label>
                            <input type="text" className="input" defaultValue={modalData?.category} required />
                        </div>
                        <button type="submit" className="btn btn-primary w-full" style={{ width: '100%' }}>Update Product</button>
                    </form>
                );
            default:
                return null;
        }
    };

    // Override the placeholder handleDecline with this one
    // But since the original one was const, I must delete the original one in this edit as well?
    // I am editing BEFORE line 386. The original functions were at 303-348.
    // I should simply REPLACE the old functions with the new logic, or ensure I don't doubly declare.
    // The previous view shows 'handleManualAssign' at 319. I am redefining it. This is a syntax error if I don't delete the old one.
    // I will replace the block from 303 to 386 with this new block.

    return (

        <div className={`provider-dashboard ${darkMode ? 'dark-mode' : ''}`}>
            {/* Sidebar */}
            <button
                className="menu-toggle"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                style={{ display: 'none' }}
            >
                <Menu size={20} />
            </button>

            <aside className={`dashboard-sidebar ${mobileMenuOpen ? 'active' : ''}`}>
                <div className="sidebar-header">
                    <Link to="/" className="logo">
                        <img src="/assets/logo.png" alt="ZOO beauty Palace" className="logo-image" />
                        <span className="logo-text">
                            <span className="logo-top">ZOO</span>
                            <span className="logo-bottom">beauty Palace</span>
                        </span>
                    </Link>
                </div>

                <nav className="sidebar-nav">
                    <button className={`nav-item ${activeTab === 'overview' ? 'active' : ''}`} onClick={() => {
                        setActiveTab('overview');
                        setMobileMenuOpen(false);
                    }}>
                        <TrendingUp size={20} />
                        Overview
                    </button>

                    <button className={`nav-item ${activeTab === 'staff' ? 'active' : ''}`} onClick={() => {
                        setActiveTab('staff');
                        setMobileMenuOpen(false);
                    }}>
                        <Users size={20} />
                        Staff Management
                        {staff.length > 0 && (
                            <span className="badge-info">{staff.length}</span>
                        )}
                    </button>
                    <button className={`nav-item ${activeTab === 'services' ? 'active' : ''}`} onClick={() => {
                        setActiveTab('services');
                        setMobileMenuOpen(false);
                    }}>
                        <Scissors size={20} />
                        My Services
                    </button>
                    <button className={`nav-item ${activeTab === 'bookings' ? 'active' : ''}`} onClick={() => {
                        setActiveTab('bookings');
                        setMobileMenuOpen(false);
                    }}>
                        <Calendar size={20} />
                        Bookings
                    </button>
                    <button className={`nav-item ${activeTab === 'financial' ? 'active' : ''}`} onClick={() => {
                        setActiveTab('financial');
                        setMobileMenuOpen(false);
                    }}>
                        <DollarSign size={20} />
                        Financial
                    </button>
                    <button className={`nav-item ${activeTab === 'crm' ? 'active' : ''}`} onClick={() => {
                        setActiveTab('crm');
                        setMobileMenuOpen(false);
                    }}>
                        <Briefcase size={20} />
                        Clients (CRM)
                    </button>
                    <button className={`nav-item ${activeTab === 'analytics' ? 'active' : ''}`} onClick={() => {
                        setActiveTab('analytics');
                        setMobileMenuOpen(false);
                    }}>
                        <BarChart3 size={20} />
                        Analytics
                    </button>
                    <button className={`nav-item ${activeTab === 'products' ? 'active' : ''}`} onClick={() => {
                        setActiveTab('products');
                        setMobileMenuOpen(false);
                    }}>
                        <ShoppingBag size={20} />
                        Store Products
                    </button>
                    <button className={`nav-item ${activeTab === 'portfolio' ? 'active' : ''}`} onClick={() => {
                        setActiveTab('portfolio');
                        setMobileMenuOpen(false);
                    }}>
                        <Image size={20} />
                        Portfolio
                    </button>
                    <button className={`nav-item ${activeTab === 'reviews' ? 'active' : ''}`} onClick={() => {
                        setActiveTab('reviews');
                        setMobileMenuOpen(false);
                    }}>
                        <Star size={20} />
                        Reviews
                    </button>
                    <button className={`nav-item ${activeTab === 'messages' ? 'active' : ''}`} onClick={() => {
                        setActiveTab('messages');
                        setMobileMenuOpen(false);
                    }}>
                        <MessageSquare size={20} />
                        Messages
                        {messages.filter(m => m.unread).length > 0 && (
                            <span className="badge">{messages.filter(m => m.unread).length}</span>
                        )}
                    </button>
                    <button className={`nav-item ${activeTab === 'assignments' ? 'active' : ''}`} onClick={() => {
                        setActiveTab('assignments');
                        setMobileMenuOpen(false);
                    }}>
                        <Check size={20} />
                        Assignments
                        {assignments.length > 0 && (
                            <span className="badge">{assignments.length}</span>
                        )}
                    </button>
                    <button className={`nav-item ${activeTab === 'settings' ? 'active' : ''}`} onClick={() => {
                        setActiveTab('settings');
                        setMobileMenuOpen(false);
                    }}>
                        <Settings size={20} />
                        Settings
                    </button>
                </nav>

                <div className="sidebar-footer">
                    <button
                        className="nav-item"
                        onClick={() => {
                            logout();
                            navigate('/');
                            setMobileMenuOpen(false);
                        }}
                        style={{ background: 'none', border: 'none', width: '100%', textAlign: 'left', cursor: 'pointer' }}
                    >
                        <LogOut size={20} />
                        Logout
                    </button>
                </div>
            </aside>

            {/* Main Content */}
            <main className="dashboard-main">
                {/* Header */}
                <header className="dashboard-header">
                    <div className="header-left">
                        <h1>Welcome back, {providerData.name || user?.firstName || 'Provider'}!</h1>
                        <p>{providerData.businessName || 'Your Business'}</p>
                    </div>
                    <div className="header-right">
                        <button className="btn btn-ghost" onClick={() => setDarkMode(!darkMode)}>
                            {darkMode ? <Sun size={20} /> : <Moon size={20} />}
                        </button>
                        <div className="notification-dropdown">
                            <button className="btn btn-ghost">
                                <Bell size={20} />
                                {unreadCount > 0 && (
                                    <span className="notification-badge">{unreadCount}</span>
                                )}
                            </button>
                            {notifications.length > 0 && (
                                <div className="notification-list">
                                    {notifications.slice(0, 5).map(notification => (
                                        <div
                                            key={notification.id}
                                            className="notification-item"
                                            onClick={() => markAsRead(notification.id)}
                                        >
                                            <div className="notification-content">
                                                <h4>{notification.title}</h4>
                                                <p>{notification.message}</p>
                                                <small>{new Date(notification.createdAt).toLocaleTimeString()}</small>
                                            </div>
                                        </div>
                                    ))}
                                    <div className="notification-footer">
                                        <button>View All Notifications</button>
                                    </div>
                                </div>
                            )}
                        </div>
                        <div className="profile-menu">
                            <img src={providerData.avatar} alt={providerData.name} />
                            <div className="online-indicator"></div>
                        </div>
                    </div>
                </header>

                {/* Overview Tab */}
                {activeTab === 'overview' && (
                    <div className="dashboard-content">
                        <div className="section-header">
                            <div>
                                <h2>Dashboard Overview</h2>
                                <p className="section-subtitle">Your business at a glance</p>
                            </div>
                            <button className="btn btn-primary btn-sm" onClick={fetchData}>
                                <RefreshCw size={16} />
                                Refresh
                            </button>
                        </div>

                        <div className="stats-grid">
                            <div className="stat-card card">
                                <div className="stat-icon" style={{ background: 'linear-gradient(135deg, #d946ef 0%, #9333ea 100%)' }}>
                                    <DollarSign size={24} />
                                </div>
                                <div className="stat-info">
                                    <p className="stat-label">Total Revenue</p>
                                    <h3 className="stat-value">KES {(dashboardStats.totalRevenue || providerData.stats.totalEarnings || 0).toLocaleString()}</h3>
                                    <span className="stat-change up">
                                        <ArrowUp size={14} />
                                        +15% from last month
                                    </span>
                                </div>
                            </div>
                            <div className="stat-card card">
                                <div className="stat-icon" style={{ background: 'linear-gradient(135deg, #14b8a6 0%, #0d9488 100%)' }}>
                                    <TrendingUp size={24} />
                                </div>
                                <div className="stat-info">
                                    <p className="stat-label">This Month</p>
                                    <h3 className="stat-value">KES {(dashboardStats.monthEarnings || providerData.stats.thisMonthEarnings || 0).toLocaleString()}</h3>
                                    <span className="stat-change up">
                                        <ArrowUp size={14} />
                                        +12% growth
                                    </span>
                                </div>
                            </div>
                            <div className="stat-card card">
                                <div className="stat-icon" style={{ background: 'linear-gradient(135deg, #3b82f6 0%, #2563eb 100%)' }}>
                                    <Users size={24} />
                                </div>
                                <div className="stat-info">
                                    <p className="stat-label">Active Staff</p>
                                    <h3 className="stat-value">{dashboardStats.activeStaff || staff.length || 0}</h3>
                                    <span className="stat-subtitle">Online beauticians</span>
                                </div>
                            </div>
                            <div className="stat-card card">
                                <div className="stat-icon" style={{ background: 'linear-gradient(135deg, #f59e0b 0%, #d97706 100%)' }}>
                                    <Clock size={24} />
                                </div>
                                <div className="stat-info">
                                    <p className="stat-label">Pending Bookings</p>
                                    <h3 className="stat-value">{dashboardStats.pendingBookings || pendingBookings.length || 0}</h3>
                                    <span className="stat-subtitle">Awaiting assignment</span>
                                </div>
                            </div>
                            <div className="stat-card card">
                                <div className="stat-icon" style={{ background: 'linear-gradient(135deg, #10b981 0%, #059669 100%)' }}>
                                    <Check size={24} />
                                </div>
                                <div className="stat-info">
                                    <p className="stat-label">Completed</p>
                                    <h3 className="stat-value">{dashboardStats.completedBookings || providerData.stats.completedBookings || 0}</h3>
                                    <span className="stat-subtitle">Jobs finished</span>
                                </div>
                            </div>
                            <div className="stat-card card">
                                <div className="stat-icon" style={{ background: 'linear-gradient(135deg, #f59e0b 0%, #d97706 100%)' }}>
                                    <Target size={24} />
                                </div>
                                <div className="stat-info">
                                    <p className="stat-label">Acceptance Rate</p>
                                    <h3 className="stat-value">{dashboardStats.acceptanceRate || 0}%</h3>
                                    <span className="stat-change up">
                                        {dashboardStats.acceptanceRate >= 80 ? 'Excellent' : 'Good'}
                                    </span>
                                </div>
                            </div>
                        </div>

                        <div className="section">
                            <div className="section-header">
                                <h2>Upcoming Bookings</h2>
                                <button className="btn btn-ghost btn-sm" onClick={() => setActiveTab('bookings')}>View All</button>
                            </div>
                            {loading ? (
                                <div className="empty-state">
                                    <div className="spinner"></div>
                                    <p>Loading bookings...</p>
                                </div>
                            ) : upcomingBookings.length === 0 ? (
                                <div className="empty-state">
                                    <Calendar size={48} color="var(--pd-text-secondary)" />
                                    <h3>No Upcoming Bookings</h3>
                                    <p>You don't have any upcoming bookings. New requests will appear here.</p>
                                </div>
                            ) : (
                                <div className="bookings-list">
                                    {upcomingBookings.slice(0, 3).map(booking => (
                                        <div key={booking._id} className="booking-card card">
                                            <div className="booking-info">
                                                <div className="booking-client">
                                                    <div className="client-avatar">{booking.clientId?.firstName?.charAt(0)}</div>
                                                    <div>
                                                        <h4>{booking.clientId?.firstName} {booking.clientId?.lastName}</h4>
                                                        <p>{booking.service}</p>
                                                    </div>
                                                </div>
                                                <div className="booking-details">
                                                    <div className="detail-item"><Calendar size={16} /><span>{new Date(booking.date).toLocaleDateString()}</span></div>
                                                    <div className="detail-item"><Clock size={16} /><span>{booking.time}</span></div>
                                                    <div className="detail-item"><span>KES {booking.amount}</span></div>
                                                </div>
                                            </div>
                                            <div className="booking-actions">
                                                <span className={`status-badge ${booking.status}`}>{booking.status}</span>
                                                <button className="btn btn-primary btn-sm" onClick={() => handleOpenModal('viewBooking', booking)}>View Details</button>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            )}
                        </div>
                    </div>
                )}

                {/* Bookings Tab */}
                {activeTab === 'bookings' && (
                    <div className="dashboard-content">
                        <div className="section-header">
                            <h2>All Bookings</h2>
                            <div className="filter-buttons">
                                <button className="btn btn-ghost btn-sm">All</button>
                                <button className="btn btn-ghost btn-sm">Pending</button>
                                <button className="btn btn-ghost btn-sm">Confirmed</button>
                                <button className="btn btn-ghost btn-sm">Completed</button>
                            </div>
                        </div>
                        {loading ? (
                            <div className="empty-state">
                                <div className="spinner"></div>
                                <p>Loading bookings...</p>
                            </div>
                        ) : bookings.length === 0 ? (
                            <div className="empty-state">
                                <Calendar size={48} color="var(--pd-text-secondary)" />
                                <h3>No Bookings</h3>
                                <p>You don't have any bookings yet. New booking requests will appear here.</p>
                            </div>
                        ) : (
                            <div className="bookings-list">
                                {bookings.map(booking => (
                                    <div key={booking._id} className="booking-card card">
                                        <div className="booking-info">
                                            <div className="booking-client">
                                                <div className="client-avatar">{booking.clientId?.firstName?.charAt(0)}</div>
                                                <div>
                                                    <h4>{booking.clientId?.firstName} {booking.clientId?.lastName}</h4>
                                                    <p>{booking.service}</p>
                                                </div>
                                            </div>
                                            <div className="booking-details">
                                                <div className="detail-item"><Calendar size={16} /><span>{new Date(booking.date).toLocaleDateString()}</span></div>
                                                <div className="detail-item"><Clock size={16} /><span>{booking.time}</span></div>
                                                <div className="detail-item"><span>KES {booking.amount}</span></div>
                                            </div>
                                        </div>
                                        <div className="booking-actions">
                                            <span className={`status-badge ${booking.status}`}>{booking.status}</span>
                                            {booking.status === 'pending' && (
                                                <>
                                                    <button className="btn btn-sm" style={{ background: 'var(--success)', color: 'white' }} onClick={() => handleAcceptBooking(booking._id)}><Check size={16} />Accept</button>
                                                    <button className="btn btn-sm" style={{ background: 'var(--error)', color: 'white' }} onClick={() => handleRejectBooking(booking._id)}><X size={16} />Decline</button>
                                                </>
                                            )}
                                            {booking.status !== 'pending' && (
                                                <button className="btn btn-primary btn-sm" onClick={() => handleOpenModal('viewBooking', booking)}><Eye size={16} />View</button>
                                            )}
                                        </div>
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>
                )}



                {/* Staff Management Tab */}
                {activeTab === 'staff' && (
                    <div className="dashboard-content">
                        <div className="section-header">
                            <div>
                                <h2>Staff Management</h2>
                                <p className="section-subtitle">{staff.length} total staff members</p>
                            </div>
                            <button className="btn btn-primary btn-sm" onClick={() => navigate('/provider/add-staff')}>
                                <UserPlus size={16} />
                                Add Staff
                            </button>
                        </div>

                        {staff.length === 0 ? (
                            <div className="empty-state card">
                                <Users size={48} color="var(--primary)" />
                                <h3>No Staff Members</h3>
                                <p>Add beauticians to your team to start managing bookings.</p>
                                <button className="btn btn-primary" onClick={() => navigate('/provider/add-staff')}>
                                    <UserPlus size={16} />
                                    Add Your First Staff Member
                                </button>
                            </div>
                        ) : (
                            <div className="staff-grid" style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: '1.5rem' }}>
                                {staff.map(member => (
                                    <div key={member.id} className="card" style={{ padding: '1.5rem' }}>
                                        <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '1rem' }}>
                                            <img
                                                src={member.avatar || 'https://i.pravatar.cc/150'}
                                                alt={member.firstName}
                                                style={{ width: '64px', height: '64px', borderRadius: '50%' }}
                                            />
                                            <div style={{ flex: 1 }}>
                                                <h4>{member.firstName} {member.lastName}</h4>
                                                <p style={{ fontSize: '0.875rem', color: 'var(--text-secondary)' }}>
                                                    {member.specializations?.slice(0, 2).join(', ')}
                                                </p>
                                                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginTop: '0.25rem' }}>
                                                    <Star size={14} fill="var(--warning)" color="var(--warning)" />
                                                    <span>{member.rating.toFixed(1)}</span>
                                                    <span style={{ color: 'var(--text-secondary)' }}>({member.reviewCount} reviews)</span>
                                                </div>
                                            </div>
                                            <div style={{
                                                width: '12px',
                                                height: '12px',
                                                borderRadius: '50%',
                                                background: member.isOnline ? 'var(--success)' : 'var(--text-secondary)'
                                            }}></div>
                                        </div>
                                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem', marginBottom: '1rem' }}>
                                            <div>
                                                <p style={{ fontSize: '0.75rem', color: 'var(--text-secondary)' }}>Total Bookings</p>
                                                <p style={{ fontSize: '1.25rem', fontWeight: '600' }}>{member.performance?.totalBookings || 0}</p>
                                            </div>
                                            <div>
                                                <p style={{ fontSize: '0.75rem', color: 'var(--text-secondary)' }}>Completion Rate</p>
                                                <p style={{ fontSize: '1.25rem', fontWeight: '600', color: 'var(--success)' }}>
                                                    {member.performance?.completionRate || 0}%
                                                </p>
                                            </div>
                                        </div>
                                        <div style={{ display: 'flex', gap: '0.5rem' }}>
                                            <button className="btn btn-outline btn-sm" style={{ flex: 1 }} onClick={() => handleOpenModal('viewStaff', member)}>
                                                <Eye size={16} />
                                                View Details
                                            </button>
                                            <button className="btn btn-ghost btn-sm" onClick={() => handleOpenModal('editStaff', member)}>
                                                <Edit size={16} />
                                            </button>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>
                )}

                {/* Financial Dashboard Tab */}
                {activeTab === 'financial' && (
                    <div className="dashboard-content">
                        <div className="section-header">
                            <div>
                                <h2>Financial Dashboard</h2>
                                <p className="section-subtitle">Revenue tracking and payouts</p>
                            </div>
                            <button className="btn btn-primary btn-sm" onClick={() => handleOpenModal('payout')}>
                                <DollarSign size={16} />
                                Request Payout
                            </button>
                        </div>

                        <div className="stats-grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))' }}>
                            <div className="stat-card card">
                                <div className="stat-info">
                                    <p className="stat-label">Total Revenue</p>
                                    <h3 className="stat-value">KES {(dashboardStats.totalRevenue || 0).toLocaleString()}</h3>
                                </div>
                            </div>
                            <div className="stat-card card">
                                <div className="stat-info">
                                    <p className="stat-label">This Month</p>
                                    <h3 className="stat-value">KES {(dashboardStats.monthEarnings || 0).toLocaleString()}</h3>
                                </div>
                            </div>
                            <div className="stat-card card">
                                <div className="stat-info">
                                    <p className="stat-label">This Week</p>
                                    <h3 className="stat-value">KES {(dashboardStats.weekEarnings || 0).toLocaleString()}</h3>
                                </div>
                            </div>
                            <div className="stat-card card">
                                <div className="stat-info">
                                    <p className="stat-label">Today</p>
                                    <h3 className="stat-value">KES {(dashboardStats.todayEarnings || 0).toLocaleString()}</h3>
                                </div>
                            </div>
                        </div>

                        <div className="card" style={{ marginTop: '1.5rem', padding: '1.5rem' }}>
                            <h3 style={{ marginBottom: '1rem' }}>Recent Transactions</h3>
                            <p style={{ color: 'var(--text-secondary)' }}>Transaction history will appear here</p>
                        </div>
                    </div>
                )}

                {/* CRM Tab */}
                {activeTab === 'crm' && (
                    <div className="dashboard-content">
                        <div className="section-header">
                            <div>
                                <h2>Client Relationship Management</h2>
                                <p className="section-subtitle">Manage your client relationships</p>
                            </div>
                            <div style={{ display: 'flex', gap: '0.5rem' }}>
                                <div className="search-box" style={{ position: 'relative' }}>
                                    <Search size={20} style={{ position: 'absolute', left: '0.75rem', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-secondary)' }} />
                                    <input
                                        type="text"
                                        placeholder="Search clients..."
                                        style={{ paddingLeft: '2.5rem', width: '250px' }}
                                    />
                                </div>
                            </div>
                        </div>

                        <div className="empty-state card">
                            <Briefcase size={48} color="var(--primary)" />
                            <h3>Client CRM</h3>
                            <p>Track client history, preferences, and lifetime value</p>
                        </div>
                    </div>
                )}

                {/* Analytics Tab */}
                {activeTab === 'analytics' && (
                    <div className="dashboard-content">
                        <div className="section-header">
                            <div>
                                <h2>Analytics & Reports</h2>
                                <p className="section-subtitle">Business insights and performance metrics</p>
                            </div>
                            <button className="btn btn-primary btn-sm">
                                <FileText size={16} />
                                Export Report
                            </button>
                        </div>

                        <div className="analytics-grid" style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(500px, 1fr))', gap: '1.5rem', marginBottom: '1.5rem' }}>
                            <div className="card">
                                <LineChart
                                    data={revenueChartData}
                                    dataKeys={['earnings']}
                                    xAxisKey="date"
                                    title="Revenue Trends"
                                    height={300}
                                />
                            </div>
                            <div className="card">
                                <BarChart
                                    data={bookingTrendsData}
                                    dataKey="bookings"
                                    xAxisKey="date"
                                    title="Booking Trends"
                                    height={300}
                                />
                            </div>
                        </div>

                        <div className="card" style={{ padding: '1.5rem' }}>
                            <PieChart
                                data={serviceDistributionData}
                                dataKey="value"
                                nameKey="name"
                                title="Service Distribution"
                                height={400}
                            />
                        </div>

                        {/* Advanced Analytics Section */}
                        <div className="section" style={{ marginTop: '2rem' }}>
                            <h2>Advanced Insights</h2>

                            {/* Top Performing Services */}
                            <div className="card" style={{ marginBottom: '1.5rem' }}>
                                <h3>Top Performing Services</h3>
                                {advancedAnalytics.topServices.length > 0 ? (
                                    <div className="table-container">
                                        <table className="data-table">
                                            <thead>
                                                <tr>
                                                    <th>Service</th>
                                                    <th>Bookings</th>
                                                    <th>Earnings</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {advancedAnalytics.topServices.map((service, index) => (
                                                    <tr key={index}>
                                                        <td>{service.serviceName}</td>
                                                        <td>{service.bookingCount}</td>
                                                        <td>KES {service.totalEarnings.toLocaleString()}</td>
                                                    </tr>
                                                ))}
                                            </tbody>
                                        </table>
                                    </div>
                                ) : (
                                    <p>No data available</p>
                                )}
                            </div>

                            {/* Client Metrics */}
                            <div className="stats-grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', marginBottom: '1.5rem' }}>
                                <div className="stat-card card">
                                    <div className="stat-info">
                                        <p className="stat-label">Total Clients</p>
                                        <h3 className="stat-value">{advancedAnalytics.clientMetrics.totalClients || 0}</h3>
                                    </div>
                                </div>
                                <div className="stat-card card">
                                    <div className="stat-info">
                                        <p className="stat-label">Repeat Clients</p>
                                        <h3 className="stat-value">{advancedAnalytics.clientMetrics.repeatClients || 0}</h3>
                                    </div>
                                </div>
                                <div className="stat-card card">
                                    <div className="stat-info">
                                        <p className="stat-label">Retention Rate</p>
                                        <h3 className="stat-value">{advancedAnalytics.clientMetrics.retentionRate || 0}%</h3>
                                    </div>
                                </div>
                            </div>

                            {/* Peak Hours */}
                            <div className="card" style={{ marginBottom: '1.5rem' }}>
                                <h3>Peak Booking Hours</h3>
                                {advancedAnalytics.peakHours.length > 0 ? (
                                    <div className="table-container">
                                        <table className="data-table">
                                            <thead>
                                                <tr>
                                                    <th>Hour</th>
                                                    <th>Bookings</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {advancedAnalytics.peakHours.map((hour, index) => (
                                                    <tr key={index}>
                                                        <td>{hour.hour}:00</td>
                                                        <td>{hour.bookingCount}</td>
                                                    </tr>
                                                ))}
                                            </tbody>
                                        </table>
                                    </div>
                                ) : (
                                    <p>No data available</p>
                                )}
                            </div>
                        </div>
                    </div>
                )}


                {/* Earnings Tab */}
                {activeTab === 'earnings' && (
                    <div className="dashboard-content">
                        <div className="stats-grid" style={{ gridTemplateColumns: 'repeat(2, 1fr)' }}>
                            <div className="stat-card card">
                                <div className="stat-info">
                                    <p className="stat-label">This Month</p>
                                    <h3 className="stat-value">KES {providerData.stats.thisMonthEarnings.toLocaleString()}</h3>
                                    <p className="stat-change positive">+15% from last month</p>
                                </div>
                            </div>
                            <div className="stat-card card">
                                <div className="stat-info">
                                    <p className="stat-label">Total Earnings</p>
                                    <h3 className="stat-value">KES {providerData.stats.totalEarnings.toLocaleString()}</h3>
                                    <p className="stat-change positive">All time</p>
                                </div>
                            </div>
                        </div>
                        <div className="section card">
                            <h2>Monthly Breakdown</h2>
                            <div className="table-container">
                                <table className="data-table">
                                    <thead>
                                        <tr>
                                            <th>Month</th>
                                            <th>Bookings</th>
                                            <th>Amount</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {earnings.map((item, index) => (
                                            <tr key={index}>
                                                <td>{item.month}</td>
                                                <td>{item.bookings}</td>
                                                <td>KES {item.amount.toLocaleString()}</td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                )}

                {/* Portfolio Tab */}
                {activeTab === 'portfolio' && (
                    <div className="dashboard-content">
                        <div className="section-header">
                            <h2>My Portfolio</h2>
                            <button className="btn btn-primary" onClick={() => navigate('/provider/add-portfolio')}>Add New Photo</button>
                        </div>
                        {loading ? (
                            <div className="empty-state">
                                <div className="spinner"></div>
                                <p>Loading portfolio...</p>
                            </div>
                        ) : portfolio.length === 0 ? (
                            <div className="empty-state">
                                <Image size={48} color="var(--pd-text-secondary)" />
                                <h3>No Portfolio Items</h3>
                                <p>Add photos to showcase your work and attract more clients!</p>
                                <button className="btn btn-primary mt-4" onClick={() => navigate('/provider/add-portfolio')}>Add Photo</button>
                            </div>
                        ) : (
                            <div className="portfolio-grid">
                                {portfolio.map(item => (
                                    <div key={item._id} className="portfolio-item card">
                                        <img src={item.image} alt={item.title} />
                                        <div className="portfolio-info">
                                            <h4>{item.title}</h4>
                                            <span className="category-badge">{item.category}</span>
                                        </div>
                                        <div className="portfolio-actions">
                                            <button className="btn btn-ghost btn-sm" onClick={() => alert('Edit portfolio ' + item._id)}><Edit size={16} /></button>
                                            <button className="btn btn-ghost btn-sm" onClick={() => handleDeletePortfolio(item._id)}><X size={16} /></button>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>
                )}

                {/* Reviews Tab */}
                {activeTab === 'reviews' && (
                    <div className="dashboard-content">
                        <div className="section-header">
                            <h2>Client Reviews</h2>
                            <div className="rating-summary">
                                <Star size={24} fill="currentColor" style={{ color: '#f59e0b' }} />
                                <span className="rating-value">{providerData.rating}</span>
                                <span className="rating-count">({providerData.reviewCount} reviews)</span>
                            </div>
                        </div>
                        {loading ? (
                            <div className="empty-state">
                                <div className="spinner"></div>
                                <p>Loading reviews...</p>
                            </div>
                        ) : reviews.length === 0 ? (
                            <div className="empty-state">
                                <Star size={48} color="var(--pd-text-secondary)" />
                                <h3>No Reviews Yet</h3>
                                <p>You haven't received any reviews yet. Complete bookings to get reviews from clients!</p>
                            </div>
                        ) : (
                            <div className="reviews-list">
                                {reviews.map(review => (
                                    <div key={review.id} className="review-card card">
                                        <div className="review-header">
                                            <div className="client-avatar">{review.client.charAt(0)}</div>
                                            <div>
                                                <h4>{review.client}</h4>
                                                <div className="review-rating">
                                                    {[...Array(review.rating)].map((_, i) => (
                                                        <Star key={i} size={14} fill="currentColor" style={{ color: '#f59e0b' }} />
                                                    ))}
                                                </div>
                                            </div>
                                            <span className="review-date">{review.date}</span>
                                        </div>
                                        <p className="review-comment">{review.comment}</p>
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>
                )}

                {/* Messages Tab */}
                {activeTab === 'messages' && (
                    <div className="dashboard-content">
                        <div className="section-header">
                            <h2>Messages</h2>
                        </div>
                        {loading ? (
                            <div className="empty-state">
                                <div className="spinner"></div>
                                <p>Loading messages...</p>
                            </div>
                        ) : messages.length === 0 ? (
                            <div className="empty-state">
                                <MessageSquare size={48} color="var(--pd-text-secondary)" />
                                <h3>No Messages</h3>
                                <p>You don't have any messages yet. Messages from clients will appear here.</p>
                            </div>
                        ) : (
                            <div className="messages-list">
                                {messages.map(message => (
                                    <div key={message.id} className={`message-card card ${message.unread ? 'unread' : ''}`}>
                                        <div className="message-header">
                                            <div className="client-avatar">{message.client.charAt(0)}</div>
                                            <div className="message-info">
                                                <h4>{message.client}</h4>
                                                <p>{message.message}</p>
                                            </div>
                                            <span className="message-time">{message.time}</span>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>
                )}

                {/* Settings Tab */}
                {activeTab === 'settings' && (
                    <div className="dashboard-content">
                        <div className="section-header">
                            <div>
                                <h2>Profile Settings</h2>
                                <p className="section-subtitle">Manage your account information and preferences</p>
                            </div>
                        </div>

                        <div className="card" style={{ maxWidth: '800px' }}>
                            <div className="settings-form">
                                <form onSubmit={handleUpdateProfile}>
                                    <div className="grid-layout" style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: '1.5rem', marginBottom: '1.5rem' }}>
                                        <div className="form-group">
                                            <label>Business Name</label>
                                            <input name="businessName" type="text" className="input" defaultValue={providerData.businessName} />
                                        </div>
                                        <div className="form-group">
                                            <label>Email Address</label>
                                            <input name="email" type="email" className="input" defaultValue={providerData.email || user?.email} disabled style={{ opacity: 0.7, cursor: 'not-allowed' }} />
                                        </div>
                                        <div className="form-group">
                                            <label>Phone Number</label>
                                            <input name="phone" type="tel" className="input" defaultValue={providerData.phone || ''} placeholder="+254..." />
                                        </div>
                                        <div className="form-group">
                                            <label>Location / Address</label>
                                            <input name="address" type="text" className="input" defaultValue={providerData.address || ''} placeholder="e.g. Westlands, Nairobi" />
                                        </div>
                                    </div>

                                    <div className="form-group">
                                        <label>Bio / Description</label>
                                        <textarea name="bio" className="input" rows="4" defaultValue={providerData.bio || ''} placeholder="Tell clients about your business..." />
                                    </div>

                                    <div className="form-actions" style={{ display: 'flex', justifyContent: 'flex-end', marginTop: '2rem' }}>
                                        <button type="submit" className="btn btn-primary">
                                            <Save size={18} />
                                            Save Changes
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                )}

                {/* Assignments Tab */}
                {activeTab === 'assignments' && (
                    <div className="dashboard-content">
                        <div className="section-header">
                            <h2>Task Assignments</h2>
                        </div>

                        <div className="section card">
                            <div className="table-container">
                                <table className="data-table">
                                    <thead>
                                        <tr>
                                            <th>Task ID</th>
                                            <th>Title</th>
                                            <th>Assigned By</th>
                                            <th>Status</th>
                                            <th>Priority</th>
                                            <th>Due Date</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {assignments.map(assignment => (
                                            <tr key={assignment.id}>
                                                <td>{assignment.taskId}</td>
                                                <td>{assignment.title}</td>
                                                <td>{assignment.assignedBy?.firstName} {assignment.assignedBy?.lastName}</td>
                                                <td><span className={`status-badge ${assignment.status}`}>{assignment.status}</span></td>
                                                <td><span className={`priority-badge ${assignment.priority}`}>{assignment.priority}</span></td>
                                                <td>{assignment.dueDate ? new Date(assignment.dueDate).toLocaleDateString() : 'N/A'}</td>
                                            </tr>
                                        ))}
                                        {assignments.length === 0 && (
                                            <tr>
                                                <td colSpan="6" className="text-center">No assignments found</td>
                                            </tr>
                                        )}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                )}

                {/* Services Management Tab */}
                {activeTab === 'services' && (
                    <div className="dashboard-content">
                        <div className="section-header">
                            <div>
                                <h2>My Services</h2>
                                <p className="section-subtitle">Manage the services you offer to clients</p>
                            </div>
                            <button className="btn btn-primary btn-sm" onClick={() => navigate('/provider/add-service')}>
                                <Plus size={16} />
                                Add New Service
                            </button>
                        </div>

                        <div className="stats-grid" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))' }}>
                            {/* Mock Services Data - In real app, fetch from API */}
                            {[
                                { id: 1, name: 'Bridal Makeup', price: 5000, duration: '2 Hours', category: 'Makeup', active: true },
                                { id: 2, name: 'Gel Manicure', price: 1500, duration: '45 Mins', category: 'Nails', active: true },
                                { id: 3, name: 'Full Body Massage', price: 3500, duration: '1 Hour', category: 'Spa & Wellness', active: false },
                                { id: 4, name: 'Hair Cut & Style', price: 2000, duration: '1 Hour', category: 'Hair', active: true }
                            ].map(service => (
                                <div key={service.id} className="card service-card">
                                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '1rem' }}>
                                        <div style={{
                                            width: '40px', height: '40px', borderRadius: '10px',
                                            background: 'var(--pd-primary-light)', color: 'var(--pd-primary)',
                                            display: 'flex', alignItems: 'center', justifyContent: 'center'
                                        }}>
                                            <Scissors size={20} />
                                        </div>
                                        <div className={`status-badge ${service.active ? 'confirmed' : 'cancelled'}`} style={{ fontSize: '0.75rem', padding: '0.25rem 0.5rem' }}>
                                            {service.active ? 'Active' : 'Inactive'}
                                        </div>
                                    </div>
                                    <h3 style={{ marginBottom: '0.5rem' }}>{service.name}</h3>
                                    <p style={{ color: 'var(--pd-text-secondary)', fontSize: '0.9rem', marginBottom: '1rem' }}>
                                        {service.category} • {service.duration}
                                    </p>
                                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: 'auto' }}>
                                        <span style={{ fontSize: '1.25rem', fontWeight: '700', color: 'var(--pd-text-primary)' }}>
                                            KES {service.price.toLocaleString()}
                                        </span>
                                        <div style={{ display: 'flex', gap: '0.5rem' }}>
                                            <button className="btn btn-ghost btn-sm" style={{ padding: '0.5rem' }} onClick={() => handleOpenModal('editService', service)}>
                                                <Edit size={16} />
                                            </button>
                                            <button className="btn btn-ghost btn-sm" style={{ padding: '0.5rem', color: 'var(--pd-danger)' }} onClick={() => { if (window.confirm('Are you sure you want to delete this service?')) showSuccess('Service deleted successfully'); }}>
                                                <Trash2 size={16} />
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                )}

                {/* Products Marketplace Tab */}
                {activeTab === 'products' && (
                    <div className="dashboard-content">
                        <div className="section-header">
                            <div>
                                <h2>Store Products</h2>
                                <p className="section-subtitle">Sell beauty products directly to your clients</p>
                            </div>
                            <button className="btn btn-primary btn-sm" onClick={() => navigate('/provider/add-product')}>
                                <Plus size={16} />
                                Add Product
                            </button>
                        </div>

                        <div className="stats-grid" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(250px, 1fr))' }}>
                            {/* Mock Products Data */}
                            {[
                                { id: 1, name: 'Luxury Human Hair Wig', price: 15000, stock: 5, category: 'Wigs', image: 'https://images.unsplash.com/photo-1595476103518-3c8ad043fbc8?w=400' },
                                { id: 2, name: 'Organic Face Serum', price: 2500, stock: 12, category: 'Skin Care', image: 'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?w=400' },
                                { id: 3, name: 'Matte Lipstick Set', price: 3000, stock: 20, category: 'Makeup', image: 'https://images.unsplash.com/photo-1586495777744-4413f21062fa?w=400' },
                                { id: 4, name: 'Argan Oil Shampoo', price: 1800, stock: 0, category: 'Hair Care', image: 'https://images.unsplash.com/photo-1535585209827-a15fcdbc4c2d?w=400' }
                            ].map(product => (
                                <div key={product.id} className="card product-card" style={{ padding: '0', overflow: 'hidden' }}>
                                    <div style={{ height: '200px', overflow: 'hidden', position: 'relative' }}>
                                        <img src={product.image} alt={product.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                                        {product.stock === 0 && (
                                            <div style={{ position: 'absolute', top: '10px', right: '10px', background: 'rgba(0,0,0,0.7)', color: 'white', padding: '4px 8px', borderRadius: '4px', fontSize: '0.75rem', fontWeight: '600' }}>
                                                OUT OF STOCK
                                            </div>
                                        )}
                                    </div>
                                    <div style={{ padding: '1rem' }}>
                                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start', marginBottom: '0.5rem' }}>
                                            <div>
                                                <span style={{ fontSize: '0.7rem', textTransform: 'uppercase', color: 'var(--pd-text-secondary)', fontWeight: '600' }}>{product.category}</span>
                                                <h3 style={{ fontSize: '1rem', lineHeight: '1.4' }}>{product.name}</h3>
                                            </div>
                                        </div>
                                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '1rem' }}>
                                            <span style={{ fontSize: '1.1rem', fontWeight: '700' }}>KES {product.price.toLocaleString()}</span>
                                            <span style={{ fontSize: '0.8rem', color: product.stock > 0 ? 'var(--pd-success)' : 'var(--pd-danger)' }}>
                                                {product.stock} in stock
                                            </span>
                                        </div>
                                        <div style={{ display: 'flex', gap: '0.5rem', marginTop: '1rem' }}>
                                            <button className="btn btn-outline btn-sm" style={{ flex: 1 }} onClick={() => handleOpenModal('editProduct', product)}>Edit</button>
                                            <button className="btn btn-ghost btn-sm" style={{ color: 'var(--pd-danger)' }} onClick={() => { if (window.confirm('Are you sure you want to delete this product?')) showSuccess('Product deleted successfully'); }}><Trash2 size={16} /></button>
                                        </div>
                                    </div>
                                </div>
                            ))}

                            {/* Empty Add Card */}
                            <div className="card" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', borderStyle: 'dashed', border: '2px dashed var(--pd-border)', background: 'transparent', cursor: 'pointer', minHeight: '350px' }} onClick={() => navigate('/provider/add-product')}>
                                <div style={{
                                    width: '60px', height: '60px', borderRadius: '50%', background: 'var(--pd-bg)',
                                    display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: '1rem',
                                    color: 'var(--pd-text-secondary)'
                                }}>
                                    <Plus size={24} />
                                </div>
                                <h3 style={{ color: 'var(--pd-text-secondary)' }}>Add Product</h3>
                            </div>
                        </div>
                    </div>
                )}
            </main>
        </div>

    );
};

export default ProviderDashboard;
