import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useToast } from '../../context/ToastContext'; // Adjust path as needed
import { ArrowLeft, Upload, Save, X } from 'lucide-react';
import '../../pages/provider/ProviderDashboard.css'; // Re-use dashboard styles

const AddProductPage = () => {
    const navigate = useNavigate();
    const { showSuccess, showError } = useToast();
    const [loading, setLoading] = useState(false);
    const [images, setImages] = useState([]);

    const [formData, setFormData] = useState({
        productName: '',
        category: '',
        price: '',
        stock: '',
        description: '',
        sku: '',
        brand: '',
        tags: ''
    });

    const handleBack = () => {
        navigate('/provider/dashboard');
    };

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleImageUpload = (e) => {
        // Placeholder for image upload logic
        // In a real app, this would handle file reading/uploading
        const files = Array.from(e.target.files);
        // Simulating URLs for now
        const newImages = files.map(file => URL.createObjectURL(file));
        setImages(prev => [...prev, ...newImages]);
    };

    const removeImage = (index) => {
        setImages(prev => prev.filter((_, i) => i !== index));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);

        try {
            // Simulate API call
            await new Promise(resolve => setTimeout(resolve, 1500));
            showSuccess('Product added successfully!');
            navigate('/provider/dashboard');
        } catch (error) {
            console.error('Error adding product:', error);
            showError('Failed to add product');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="provider-dashboard">
            <div className="add-page-container" style={{ padding: '2rem', maxWidth: '1200px', margin: '0 auto' }}>
                <header className="page-header" style={{ marginBottom: '2rem', display: 'flex', alignItems: 'center', gap: '1rem' }}>
                    <button className="btn btn-ghost" onClick={handleBack}>
                        <ArrowLeft size={24} />
                    </button>
                    <div>
                        <h1>Add New Product</h1>
                        <p className="section-subtitle">Create a new product listing for your store</p>
                    </div>
                </header>

                <form onSubmit={handleSubmit} className="add-product-form">
                    <div className="grid-layout" style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '2rem' }}>

                        {/* Left Column: Main Details */}
                        <div className="main-details card" style={{ padding: '2rem' }}>
                            <div className="form-group">
                                <label>Product Name</label>
                                <input
                                    type="text"
                                    name="productName"
                                    className="input"
                                    placeholder="e.g. Luxury Argan Oil Hair Mask"
                                    value={formData.productName}
                                    onChange={handleInputChange}
                                    required
                                />
                            </div>

                            <div className="form-group">
                                <label>Description</label>
                                <textarea
                                    name="description"
                                    className="input"
                                    rows="6"
                                    placeholder="Describe your product... (ingredients, benefits, usage)"
                                    value={formData.description}
                                    onChange={handleInputChange}
                                    required
                                />
                            </div>

                            <div className="form-row" style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                                <div className="form-group">
                                    <label>Category</label>
                                    <select
                                        name="category"
                                        className="input"
                                        value={formData.category}
                                        onChange={handleInputChange}
                                    >
                                        <option value="">Select Category</option>
                                        <option value="hair">Hair Care</option>
                                        <option value="skin">Skin Care</option>
                                        <option value="makeup">Makeup</option>
                                        <option value="tools">Tools & Accessories</option>
                                    </select>
                                </div>
                                <div className="form-group">
                                    <label>Brand</label>
                                    <input
                                        type="text"
                                        name="brand"
                                        className="input"
                                        placeholder="e.g. L'Oreal"
                                        value={formData.brand}
                                        onChange={handleInputChange}
                                    />
                                </div>
                            </div>
                        </div>

                        {/* Right Column: Pricing & Media */}
                        <div className="side-details" style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
                            <div className="card" style={{ padding: '1.5rem' }}>
                                <h3>Pricing & Inventory</h3>
                                <div className="form-group" style={{ marginTop: '1rem' }}>
                                    <label>Price (KES)</label>
                                    <input
                                        type="number"
                                        name="price"
                                        className="input"
                                        placeholder="0.00"
                                        value={formData.price}
                                        onChange={handleInputChange}
                                        required
                                    />
                                </div>
                                <div className="form-group">
                                    <label>Stock Quantity</label>
                                    <input
                                        type="number"
                                        name="stock"
                                        className="input"
                                        placeholder="0"
                                        value={formData.stock}
                                        onChange={handleInputChange}
                                        required
                                    />
                                </div>
                                <div className="form-group">
                                    <label>SKU (Optional)</label>
                                    <input
                                        type="text"
                                        name="sku"
                                        className="input"
                                        placeholder="PROD-001"
                                        value={formData.sku}
                                        onChange={handleInputChange}
                                    />
                                </div>
                            </div>

                            <div className="card" style={{ padding: '1.5rem' }}>
                                <h3>Product Images</h3>
                                <div className="image-upload-area" style={{
                                    border: '2px dashed var(--pd-border)',
                                    borderRadius: '8px',
                                    padding: '2rem',
                                    textAlign: 'center',
                                    marginTop: '1rem',
                                    cursor: 'pointer',
                                    position: 'relative'
                                }}>
                                    <input
                                        type="file"
                                        multiple
                                        accept="image/*"
                                        onChange={handleImageUpload}
                                        style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%', opacity: 0, cursor: 'pointer' }}
                                    />
                                    <Upload size={32} color="var(--pd-text-secondary)" />
                                    <p style={{ marginTop: '0.5rem', color: 'var(--pd-text-secondary)' }}>Click to upload images</p>
                                </div>

                                {images.length > 0 && (
                                    <div className="image-preview" style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '0.5rem', marginTop: '1rem' }}>
                                        {images.map((img, index) => (
                                            <div key={index} style={{ position: 'relative', aspectRatio: '1' }}>
                                                <img src={img} alt="Preview" style={{ width: '100%', height: '100%', objectFit: 'cover', borderRadius: '4px' }} />
                                                <button
                                                    type="button"
                                                    onClick={() => removeImage(index)}
                                                    style={{
                                                        position: 'absolute', top: '-5px', right: '-5px',
                                                        background: 'red', color: 'white',
                                                        border: 'none', borderRadius: '50%',
                                                        width: '20px', height: '20px',
                                                        display: 'flex', alignItems: 'center', justifyContent: 'center',
                                                        cursor: 'pointer'
                                                    }}
                                                >
                                                    <X size={12} />
                                                </button>
                                            </div>
                                        ))}
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>

                    <div className="form-actions" style={{ marginTop: '2rem', display: 'flex', justifyContent: 'flex-end', gap: '1rem' }}>
                        <button type="button" className="btn btn-ghost" onClick={handleBack}>Cancel</button>
                        <button type="submit" className="btn btn-primary" disabled={loading}>
                            {loading ? <div className="spinner-small"></div> : <Save size={20} />}
                            {loading ? 'Saving...' : 'Save Product'}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default AddProductPage;
