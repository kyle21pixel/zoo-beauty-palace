import { motion } from 'framer-motion';
import { useState, useEffect } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { Sparkles, Search, MapPin, Star, Calendar, DollarSign, Filter, X, Moon } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import axios from 'axios';
import { mockProviders } from '../../data/mockData';
import './SearchProviders.css';

const SearchProviders = () => {
    const navigate = useNavigate();
    const { user, logout } = useAuth();
    const [searchQuery, setSearchQuery] = useState('');
    const [selectedService, setSelectedService] = useState('all');
    const [showFilters, setShowFilters] = useState(false);
    const [providers, setProviders] = useState([]);
    const [loading, setLoading] = useState(true);

    const [searchParams] = useSearchParams();
    const serviceType = searchParams.get('serviceType') || 'on-site'; // Default to on-site

    useEffect(() => {
        fetchProviders();
    }, [searchQuery, selectedService, serviceType]);

    const fetchProviders = async () => {
        setLoading(true);
        try {
            const params = {
                search: searchQuery,
                service: selectedService !== 'all' ? selectedService : undefined,
                serviceType: serviceType // This will be 'on-site' or 'on-route'
            };

            // Using the clientService function we created earlier would be cleaner, but axios here is fine too.
            // Let's stick to axios as per existing code but fix the URL and params.
            const response = await axios.get('http://localhost:5000/api/providers/search', { params });

            if (response.data.success) {
                const providersData = response.data.data.providers.map(p => ({
                    id: p.id,
                    name: `${p.userId?.firstName || ''} ${p.userId?.lastName || ''}`.trim(),
                    businessName: p.businessName,
                    avatar: p.userId?.avatar || 'https://i.pravatar.cc/150?img=1',
                    specializations: p.specializations || [],
                    rating: p.rating?.average || 0,
                    reviewCount: p.rating?.count || 0,
                    price: p.services ? Math.min(...(p.services || []).map(s => s.price)) : 0,
                    location: p.location?.address || 'Location not specified',
                    distance: '2.3 km', // This would come from backend if geo-search was enabled
                    isOnline: p.isOnline || false,
                    portfolio: (p.portfolio || []).map(item => item.url || item).slice(0, 4)
                }));
                setProviders(providersData);
            } else {
                setProviders([]);
            }
        } catch (error) {
            console.error('Error fetching providers:', error);
            setProviders([]);
        } finally {
            setLoading(false);
        }
    };

    const services = ['All Services', 'Makeup', 'Hair Styling', 'Barbering', 'Braiding', 'Wig Installation', 'Nail Art', 'Facial Treatment'];

    const filteredProviders = providers.filter(provider => {
        const matchesSearch = provider.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
            provider.businessName.toLowerCase().includes(searchQuery.toLowerCase());
        const matchesService = selectedService === 'all' ||
            provider.specializations.some(s => s.toLowerCase().includes(selectedService.toLowerCase().replace(' services', '')));
        return matchesSearch && matchesService;
    });

    if (loading) {
        return <div className="loading">Loading providers...</div>;
    }

    return (
        <div className="search-page">
            <header className="search-header">
                <div className="container">
                    <div className="header-content">
                        <Link to="/" className="logo">
                            <img src="/assets/logo.png" alt="ZOO beauty Palace" className="logo-image" />
                        </Link>
                        <div className="header-actions">
                            <button className="btn btn-ghost btn-icon" onClick={() => document.body.classList.toggle('dark-mode')}>
                                <Moon size={20} />
                            </button>
                            <Link to="/" className="btn btn-ghost btn-sm">Home</Link>
                            {user ? (
                                <>
                                    <Link
                                        to={
                                            user.role === 'admin' ? '/admin/dashboard' :
                                                user.role === 'provider' ? '/provider/dashboard' :
                                                    '/client/dashboard'
                                        }
                                        className="btn btn-ghost btn-sm"
                                    >
                                        Dashboard
                                    </Link>
                                    <button
                                        onClick={() => {
                                            logout();
                                            navigate('/');
                                        }}
                                        className="btn btn-outline btn-sm"
                                    >
                                        Logout
                                    </button>
                                </>
                            ) : (
                                <>
                                    <Link to="/register?type=provider" className="btn btn-ghost btn-sm">Become a Provider</Link>
                                    <Link to="/login" className="btn btn-primary btn-sm">Sign In</Link>
                                </>
                            )}
                        </div>
                    </div>
                </div>
            </header>

            <section className="search-section">
                <div className="container">
                    <motion.div
                        className="search-content"
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                    >
                        <h1>Find Your Perfect {serviceType === 'on-route' ? 'Beautician' : 'Beauty Professional'}</h1>
                        <p>Browse {providers.length} verified {serviceType === 'on-route' ? 'beauticians' : 'providers'} in your area</p>

                        <div className="search-bar">
                            <Search className="search-icon" />
                            <input
                                type="text"
                                placeholder="Search by name, service, or location..."
                                value={searchQuery}
                                onChange={(e) => setSearchQuery(e.target.value)}
                                className="search-input"
                            />
                            <button className="btn btn-primary">Search</button>
                        </div>

                        <div className="service-filters">
                            {services.map((service, index) => (
                                <button
                                    key={index}
                                    className={`filter-chip ${selectedService === (service === 'All Services' ? 'all' : service.toLowerCase()) ? 'active' : ''}`}
                                    onClick={() => setSelectedService(service === 'All Services' ? 'all' : service.toLowerCase())}
                                >
                                    {service}
                                </button>
                            ))}
                        </div>
                    </motion.div>
                </div>
            </section>

            <section className="results-section">
                <div className="container">
                    <div className="results-header">
                        <h2>{filteredProviders.length} {serviceType === 'on-route' ? 'Beauticians' : 'Providers'} Found</h2>
                        <button className="btn btn-ghost btn-sm" onClick={() => setShowFilters(!showFilters)}>
                            <Filter size={18} />
                            Filters
                        </button>
                    </div>

                    {filteredProviders.length === 0 ? (
                        <div className="no-results">
                            <p>No providers found. Try adjusting your search criteria.</p>
                        </div>
                    ) : (
                        <div className="providers-grid">
                            {filteredProviders.map((provider, index) => (
                                <motion.div
                                    key={provider.id}
                                    className="provider-card card"
                                    initial={{ opacity: 0, y: 20 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    transition={{ delay: index * 0.05 }}
                                    whileHover={{ y: -8 }}
                                >
                                    <div className="provider-header">
                                        <div className="provider-avatar">
                                            <img src={provider.avatar} alt={provider.name} />
                                            {provider.isOnline && <span className="online-badge"></span>}
                                        </div>
                                        <div className="provider-info">
                                            <h3>{provider.name}</h3>
                                            <p className="business-name">{provider.businessName}</p>
                                            <div className="rating">
                                                <Star size={16} fill="currentColor" />
                                                <span>{provider.rating}</span>
                                                <span className="review-count">({provider.reviewCount} reviews)</span>
                                            </div>
                                        </div>
                                    </div>

                                    <div className="provider-portfolio">
                                        {provider.portfolio.slice(0, 3).map((img, i) => (
                                            <img key={i} src={img} alt={`Work ${i + 1}`} />
                                        ))}
                                    </div>

                                    <div className="provider-specializations">
                                        {provider.specializations.map((spec, i) => (
                                            <span key={i} className="spec-tag">{spec}</span>
                                        ))}
                                    </div>

                                    <div className="provider-details">
                                        <div className="detail-item">
                                            <MapPin size={16} />
                                            <span>{provider.location}</span>
                                        </div>
                                        <div className="detail-item">
                                            <DollarSign size={16} />
                                            <span>From ${provider.price}</span>
                                        </div>
                                    </div>

                                    <div className="provider-actions">
                                        <Link to={`/providers/${provider.id}`} className="btn btn-outline">
                                            View Profile
                                        </Link>
                                        <Link
                                            to={`/providers/${provider.id}`}
                                            state={{ openBooking: true }}
                                            className="btn btn-primary"
                                        >
                                            <Calendar size={18} />
                                            Book Now
                                        </Link>
                                    </div>
                                </motion.div>
                            ))}
                        </div>
                    )}
                </div>
            </section>
        </div>
    );
};

export default SearchProviders;
