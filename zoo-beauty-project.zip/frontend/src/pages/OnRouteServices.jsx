import { motion } from 'framer-motion';
import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Search, MapPin, Star, Filter, Moon, Sun, ArrowLeft, Navigation, Clock, DollarSign } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import axios from 'axios';
import './OnRouteServices.css';

const OnRouteServicesPage = () => {
    const navigate = useNavigate();
    const { user } = useAuth();
    const [searchQuery, setSearchQuery] = useState('');
    const [darkMode, setDarkMode] = useState(false);
    const [selectedService, setSelectedService] = useState('all');
    const [beauticians, setBeauticians] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        fetchBeauticians();
    }, []);

    useEffect(() => {
        if (darkMode) {
            document.body.classList.add('dark-mode');
        } else {
            document.body.classList.remove('dark-mode');
        }
    }, [darkMode]);

    const fetchBeauticians = async () => {
        setLoading(true);
        try {
            const response = await axios.get('http://localhost:5000/api/providers/search', {
                params: {
                    serviceType: 'on-route' // Only fetch beauticians
                }
            });

            if (response.data.success) {
                const beauticiansData = response.data.data.providers.map(p => ({
                    id: p.id,
                    name: `${p.user?.firstName || ''} ${p.user?.lastName || ''}`.trim() || p.businessName,
                    avatar: p.user?.avatar || 'https://i.pravatar.cc/150?img=1',
                    specializations: Array.isArray(p.specializations) ? p.specializations : [],
                    rating: p.rating || 0,
                    reviewCount: p.reviewCount || 0,
                    completedBookings: p.stats?.completedBookings || 0,
                    priceRange: p.services && p.services.length > 0
                        ? `${Math.min(...p.services.map(s => s.price))}-${Math.max(...p.services.map(s => s.price))}`
                        : '0-0',
                    distance: '2.3 km', // Would come from geolocation
                    eta: '15 min',
                    isAvailable: p.isOnline || false,
                    serviceArea: p.address || 'Service area not specified',
                    bio: p.bio || 'Professional beautician',
                    portfolio: Array.isArray(p.portfolio) ? p.portfolio.slice(0, 3) : []
                }));
                setBeauticians(beauticiansData);
            }
        } catch (error) {
            console.error('Error fetching beauticians:', error);
            setBeauticians([]);
        } finally {
            setLoading(false);
        }
    };

    const filteredBeauticians = beauticians.filter(beautician => {
        const matchesSearch = beautician.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
            beautician.specializations.some(spec => spec.toLowerCase().includes(searchQuery.toLowerCase()));

        const matchesService = selectedService === 'all' ||
            beautician.specializations.some(spec => spec.toLowerCase().includes(selectedService.toLowerCase()));

        return matchesSearch && matchesService;
    });

    const serviceCategories = ['all', 'makeup', 'hair', 'nails', 'braiding', 'henna', 'skincare'];

    if (loading) {
        return <div className="loading">Loading beauticians...</div>;
    }

    return (
        <div className={`on-route-services ${darkMode ? 'dark-mode' : ''}`}>
            <header className="page-header">
                <div className="container">
                    <div className="header-content">
                        <Link to="/" className="logo">
                            <img src="/assets/logo.png" alt="ZOO Beauty Palace" />
                            <span className="logo-text">
                                <span className="logo-top">ZOO</span>
                                <span className="logo-bottom">beauty Palace</span>
                            </span>
                        </Link>
                        <div className="header-actions">
                            <button
                                className="btn btn-ghost btn-icon"
                                onClick={() => setDarkMode(!darkMode)}
                            >
                                {darkMode ? <Sun size={20} /> : <Moon size={20} />}
                            </button>
                            {user ? (
                                <>
                                    <Link
                                        to={
                                            user.role === 'admin' ? '/admin/dashboard' :
                                                user.role === 'provider' ? '/provider/dashboard' :
                                                    user.role === 'beautician' ? '/beautician/dashboard' :
                                                        '/client/dashboard'
                                        }
                                        className="btn btn-ghost btn-sm"
                                    >
                                        Dashboard
                                    </Link>
                                </>
                            ) : (
                                <>
                                    <Link to="/register?type=beautician" className="btn btn-ghost btn-sm">Become a Beautician</Link>
                                    <Link to="/login" className="btn btn-primary btn-sm">Sign In</Link>
                                </>
                            )}
                        </div>
                    </div>
                </div>
            </header>

            <section className="search-section">
                <div className="container">
                    <motion.div
                        className="search-content"
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                    >
                        <button
                            onClick={() => navigate('/choose-service')}
                            className="btn btn-ghost btn-sm back-btn"
                        >
                            <ArrowLeft size={18} />
                            Back to Services
                        </button>
                        <div className="header-with-icon">
                            <Navigation size={40} color="#ec4899" />
                            <div>
                                <h1>On-Route Beauty Services</h1>
                                <p>Professional beauticians come to your location • {filteredBeauticians.length} available nearby</p>
                            </div>
                        </div>

                        <div className="search-bar">
                            <Search className="search-icon" />
                            <input
                                type="text"
                                placeholder="Search beauticians by name or service..."
                                value={searchQuery}
                                onChange={(e) => setSearchQuery(e.target.value)}
                            />
                        </div>

                        <div className="service-filters">
                            {serviceCategories.map(category => (
                                <button
                                    key={category}
                                    className={`filter-btn ${selectedService === category ? 'active' : ''}`}
                                    onClick={() => setSelectedService(category)}
                                >
                                    {category.charAt(0).toUpperCase() + category.slice(1)}
                                </button>
                            ))}
                        </div>
                    </motion.div>
                </div>
            </section>

            <section className="beauticians-section">
                <div className="container">
                    {filteredBeauticians.length === 0 ? (
                        <div className="no-results">
                            <p>No beauticians found. Try adjusting your search criteria.</p>
                        </div>
                    ) : (
                        <div className="beauticians-grid">
                            {filteredBeauticians.map((beautician, index) => (
                                <motion.div
                                    key={beautician.id}
                                    className={`beautician-card ${!beautician.isAvailable ? 'unavailable' : ''}`}
                                    initial={{ opacity: 0, y: 20 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    transition={{ delay: index * 0.05 }}
                                    whileHover={{ y: -8 }}
                                >
                                    <div className="card-header">
                                        <div className="beautician-avatar">
                                            <img src={beautician.avatar} alt={beautician.name} />
                                            <span className={`status-badge ${beautician.isAvailable ? 'available' : 'busy'}`}>
                                                {beautician.isAvailable ? 'Available' : 'Busy'}
                                            </span>
                                        </div>
                                        <div className="beautician-info">
                                            <h3>{beautician.name}</h3>
                                            <div className="rating">
                                                <Star size={16} fill="currentColor" />
                                                <span>{beautician.rating}</span>
                                                <span className="review-count">({beautician.reviewCount} reviews)</span>
                                            </div>
                                            <p className="completed-bookings">{beautician.completedBookings} completed services</p>
                                        </div>
                                    </div>

                                    <div className="beautician-portfolio">
                                        {beautician.portfolio.slice(0, 3).map((img, i) => (
                                            <img key={i} src={img} alt={`Work ${i + 1}`} />
                                        ))}
                                    </div>

                                    <p className="bio">{beautician.bio}</p>

                                    <div className="specializations">
                                        {beautician.specializations.map((spec, i) => (
                                            <span key={i} className="spec-tag">{spec}</span>
                                        ))}
                                    </div>

                                    <div className="beautician-details">
                                        <div className="detail-item">
                                            <MapPin size={16} />
                                            <span>{beautician.distance} away • {beautician.eta} ETA</span>
                                        </div>
                                        <div className="detail-item">
                                            <Navigation size={16} />
                                            <span>{beautician.serviceArea}</span>
                                        </div>
                                        <div className="detail-item">
                                            <DollarSign size={16} />
                                            <span>KES {beautician.priceRange}</span>
                                        </div>
                                    </div>

                                    <div className="card-actions">
                                        <Link
                                            to={`/providers/${beautician.id}`}
                                            className="btn btn-outline"
                                        >
                                            View Profile
                                        </Link>
                                        <Link
                                            to={`/providers/${beautician.id}`}
                                            state={{ openBooking: true }}
                                            className="btn btn-primary"
                                            disabled={!beautician.isAvailable}
                                        >
                                            {beautician.isAvailable ? 'Book Now' : 'Unavailable'}
                                        </Link>
                                    </div>
                                </motion.div>
                            ))}
                        </div>
                    )}
                </div>
            </section>
        </div>
    );
};

export default OnRouteServicesPage;
