import { motion } from 'framer-motion';
import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Home, MapPin, ArrowRight, Star, Shield, Clock } from 'lucide-react';
import './ServicesPage.css';

const ServicesPage = () => {
    const navigate = useNavigate();
    const [selectedType, setSelectedType] = useState(null);

    const serviceTypes = [
        {
            id: 'on-site',
            title: 'On-Site Services',
            subtitle: 'Visit Our Salons & Studios',
            description: 'Book appointments at professional salons and beauty studios in your area',
            icon: Home,
            features: [
                'Professional salon equipment',
                'Relaxing studio environment',
                'Wide range of services',
                'Premium products'
            ],
            color: '#8b5cf6',
            image: 'https://images.unsplash.com/photo-1560066984-138dadb4c035?w=600&h=400&fit=crop'
        },
        {
            id: 'on-route',
            title: 'On-Route Services',
            subtitle: 'Beauty Comes to You',
            description: 'Professional beauticians travel to your location for personalized service',
            icon: MapPin,
            features: [
                'Service at your location',
                'Flexible scheduling',
                'Verified mobile beauticians',
                'Real-time tracking'
            ],
            color: '#ec4899',
            image: 'https://images.unsplash.com/photo-1487412912498-0447578fcca8?w=600&h=400&fit=crop'
        }
    ];

    const handleSelectType = (typeId) => {
        if (typeId === 'on-site') {
            navigate('/services?serviceType=on-site'); // Redirect to providers with on-site filter
        } else {
            navigate('/on-route-services'); // Redirect to beauticians (en-route)
        }
    };

    return (
        <div className="services-page">
            <header className="services-header">
                <div className="container">
                    <Link to="/" className="logo">
                        <img src="/assets/logo.png" alt="ZOO Beauty Palace" />
                        <span className="logo-text">
                            <span className="logo-top">ZOO</span>
                            <span className="logo-bottom">beauty Palace</span>
                        </span>
                    </Link>
                    <nav>
                        <Link to="/" className="btn btn-ghost">Home</Link>
                        <Link to="/login" className="btn btn-primary">Sign In</Link>
                    </nav>
                </div>
            </header>

            <section className="hero-section">
                <div className="container">
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="hero-content"
                    >
                        <h1>Choose Your Service Type</h1>
                        <p>Select how you'd like to experience our beauty services</p>
                    </motion.div>
                </div>
            </section>

            <section className="service-types-section">
                <div className="container">
                    <div className="service-types-grid">
                        {serviceTypes.map((type, index) => {
                            const Icon = type.icon;
                            return (
                                <motion.div
                                    key={type.id}
                                    className={`service-type-card ${selectedType === type.id ? 'selected' : ''}`}
                                    initial={{ opacity: 0, y: 30 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    transition={{ delay: index * 0.1 }}
                                    whileHover={{ y: -10 }}
                                    onClick={() => setSelectedType(type.id)}
                                >
                                    <div className="card-image">
                                        <img src={type.image} alt={type.title} />
                                        <div className="card-overlay" style={{ background: `linear-gradient(135deg, ${type.color}99, ${type.color}cc)` }}>
                                            <Icon size={48} color="white" />
                                        </div>
                                    </div>

                                    <div className="card-content">
                                        <h2>{type.title}</h2>
                                        <p className="subtitle">{type.subtitle}</p>
                                        <p className="description">{type.description}</p>

                                        <ul className="features-list">
                                            {type.features.map((feature, i) => (
                                                <li key={i}>
                                                    <Star size={16} fill={type.color} color={type.color} />
                                                    <span>{feature}</span>
                                                </li>
                                            ))}
                                        </ul>

                                        <button
                                            className="btn btn-primary btn-block"
                                            style={{ background: type.color }}
                                            onClick={(e) => {
                                                e.stopPropagation();
                                                handleSelectType(type.id);
                                            }}
                                        >
                                            Browse {type.title}
                                            <ArrowRight size={20} />
                                        </button>
                                    </div>
                                </motion.div>
                            );
                        })}
                    </div>

                    <div className="trust-badges">
                        <div className="badge">
                            <Shield size={24} color="#10b981" />
                            <div>
                                <strong>Verified Professionals</strong>
                                <p>All beauticians are background-checked</p>
                            </div>
                        </div>
                        <div className="badge">
                            <Star size={24} color="#f59e0b" />
                            <div>
                                <strong>Top Rated</strong>
                                <p>4.8+ average rating across all services</p>
                            </div>
                        </div>
                        <div className="badge">
                            <Clock size={24} color="#8b5cf6" />
                            <div>
                                <strong>Flexible Booking</strong>
                                <p>Book instantly or schedule in advance</p>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    );
};

export default ServicesPage;
