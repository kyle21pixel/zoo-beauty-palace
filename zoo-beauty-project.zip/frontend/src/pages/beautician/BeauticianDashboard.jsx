import { motion, AnimatePresence } from 'framer-motion';
import { useState, useEffect, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
    Navigation, MapPin, DollarSign, Clock, User, Star,
    Calendar, CheckCircle, XCircle, Phone,
    Menu, X, LogOut, Settings, Bell,
    ChevronRight, Award, Target, Zap, Moon, Sun, Camera, Plus
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useNotification } from '../../context/NotificationContext';
import {
    getProviderStats, getProviderProfile, getProviderBookings,
    acceptBooking, rejectBooking, updateProviderProfile
} from '../../services/providerService';
import { getMyAssignments } from '../../services/assignmentService';
import './BeauticianDashboard.css';
import './BeauticianProfileStyles.css';
import './BeauticianInteractive.css';

const BeauticianDashboard = () => {
    const navigate = useNavigate();
    const { user, logout } = useAuth();
    const { notifications, unreadCount, markAsRead } = useNotification();
    const avatarInputRef = useRef(null);
    const portfolioInputRef = useRef(null);

    const [activeTab, setActiveTab] = useState('requests');
    const [isOnline, setIsOnline] = useState(true);
    const [showMenu, setShowMenu] = useState(false);
    const [darkMode, setDarkMode] = useState(false);

    const [bookingRequests, setBookingRequests] = useState([]);
    const [activeBookings, setActiveBookings] = useState([]);
    const [completedBookings, setCompletedBookings] = useState([]);
    const [assignments, setAssignments] = useState([]);
    const [stats, setStats] = useState({
        todayEarnings: 0,
        weekEarnings: 0,
        monthEarnings: 0,
        completedToday: 0,
        rating: 0,
        totalBookings: 0,
        acceptanceRate: 0
    });
    const [loading, setLoading] = useState(true);

    // Profile state
    const [profileData, setProfileData] = useState({
        fullName: '',
        phoneNumber: '',
        serviceArea: '',
        bio: '',
        avatar: ''
    });
    const [services, setServices] = useState(['Bridal Makeup', 'Hair Styling', 'Nail Art']);
    const [portfolioImages, setPortfolioImages] = useState([
        'https://images.unsplash.com/photo-1487412912498?w=300&h=300&fit=crop',
        'https://images.unsplash.com/photo-1596462502278?w=300&h=300&fit=crop',
        'https://images.unsplash.com/photo-1522337360788?w=300&h=300&fit=crop',
        'https://images.unsplash.com/photo-1560066984-138dadb4c035?w=300&h=300&fit=crop',
        'https://images.unsplash.com/photo-1583900985737?w=300&h=300&fit=crop',
        'https://images.unsplash.com/photo-1512496015851?w=300&h=300&fit=crop'
    ]);
    const [newService, setNewService] = useState('');
    const [showAddService, setShowAddService] = useState(false);
    const [isSaving, setIsSaving] = useState(false);

    useEffect(() => {
        fetchDashboardData();
        // Initialize profile data from user
        if (user) {
            setProfileData({
                fullName: user.firstName ? `${user.firstName} ${user.lastName}` : 'Sarah Njeri',
                phoneNumber: '+254 712 345 678',
                serviceArea: 'Westlands, Kilimani, Lavington',
                bio: 'Professional makeup artist with 5 years of experience specializing in bridal and event makeup. Passionate about making every client feel beautiful and confident.',
                avatar: user.avatar || 'https://i.pravatar.cc/150?img=1'
            });
        }
    }, [user]);

    const fetchDashboardData = async () => {
        setLoading(true);
        try {
            const [profileRes, statsRes, bookingsRes, assignmentsRes] = await Promise.all([
                getProviderProfile().catch(() => ({ success: false })),
                getProviderStats().catch(() => ({ success: false })),
                getProviderBookings({ limit: 100 }).catch(() => ({ success: false })),
                getMyAssignments({ limit: 100 }).catch(() => ({ success: false }))
            ]);

            if (statsRes.success) {
                setStats({
                    ...stats,
                    ...statsRes.data.stats,
                    rating: profileRes.data?.providerProfile?.rating || 0
                });
            }

            if (bookingsRes.success) {
                const allBookings = bookingsRes.data.bookings;
                setBookingRequests(allBookings.filter(b => b.status === 'pending'));
                setActiveBookings(allBookings.filter(b => ['confirmed', 'en-route', 'in-progress'].includes(b.status)));
                setCompletedBookings(allBookings.filter(b => b.status === 'completed'));
            }

            if (assignmentsRes.success) {
                setAssignments(assignmentsRes.data.assignments);
            }
        } catch (error) {
            console.error('Error fetching dashboard data:', error);
        } finally {
            setLoading(false);
        }
    };

    // Profile management functions
    const handleProfileChange = (field, value) => {
        setProfileData(prev => ({
            ...prev,
            [field]: value
        }));
    };

    const handleAddService = () => {
        if (newService.trim() && !services.includes(newService.trim())) {
            setServices(prev => [...prev, newService.trim()]);
            setNewService('');
            setShowAddService(false);
        }
    };

    const handleRemoveService = (serviceToRemove) => {
        if (services.length > 1) {
            setServices(prev => prev.filter(s => s !== serviceToRemove));
        } else {
            alert('You must have at least one service!');
        }
    };

    const handleAvatarClick = () => {
        avatarInputRef.current?.click();
    };

    const handleAvatarUpload = (e) => {
        const file = e.target.files[0];
        if (file) {
            if (file.size > 5 * 1024 * 1024) {
                alert('File size must be less than 5MB');
                return;
            }
            const reader = new FileReader();
            reader.onloadend = () => {
                setProfileData(prev => ({
                    ...prev,
                    avatar: reader.result
                }));
            };
            reader.readAsDataURL(file);
        }
    };

    const handlePortfolioClick = () => {
        portfolioInputRef.current?.click();
    };

    const handlePortfolioUpload = (e) => {
        const file = e.target.files[0];
        if (file) {
            if (file.size > 5 * 1024 * 1024) {
                alert('File size must be less than 5MB');
                return;
            }
            if (portfolioImages.length >= 12) {
                alert('Maximum 12 portfolio images allowed');
                return;
            }
            const reader = new FileReader();
            reader.onloadend = () => {
                setPortfolioImages(prev => [...prev, reader.result]);
            };
            reader.readAsDataURL(file);
        }
    };

    const handleRemovePortfolioImage = (index) => {
        if (window.confirm('Remove this image from your portfolio?')) {
            setPortfolioImages(prev => prev.filter((_, i) => i !== index));
        }
    };

    const handleSaveProfile = async () => {
        setIsSaving(true);
        try {
            // Validate data
            if (!profileData.fullName.trim()) {
                alert('Please enter your full name');
                setIsSaving(false);
                return;
            }
            if (!profileData.phoneNumber.trim()) {
                alert('Please enter your phone number');
                setIsSaving(false);
                return;
            }
            if (services.length === 0) {
                alert('Please add at least one service');
                setIsSaving(false);
                return;
            }

            // In a real app, you would call the API here
            const profileUpdateData = {
                ...profileData,
                services,
                portfolioImages
            };

            console.log('Saving profile:', profileUpdateData);

            // Simulate API call
            await new Promise(resolve => setTimeout(resolve, 1500));

            alert('✅ Profile saved successfully!');
        } catch (error) {
            console.error('Error saving profile:', error);
            alert('❌ Failed to save profile. Please try again.');
        } finally {
            setIsSaving(false);
        }
    };

    const handleAcceptBooking = async (bookingId) => {
        try {
            await acceptBooking(bookingId);
            fetchDashboardData();
            alert('Booking accepted!');
        } catch (error) {
            console.error('Error accepting booking:', error);
            alert('Failed to accept booking');
        }
    };

    const handleRejectBooking = async (bookingId) => {
        if (window.confirm('Are you sure you want to reject this booking?')) {
            try {
                await rejectBooking(bookingId);
                fetchDashboardData();
            } catch (error) {
                console.error('Error rejecting booking:', error);
                alert('Failed to reject booking');
            }
        }
    };

    const handleStartNavigation = (booking) => {
        alert(`Starting navigation to ${booking.location || 'Client Location'}`);
    };

    const handleCompleteBooking = async (bookingId) => {
        alert('Please mark as completed in the detailed view (functionality to be added)');
    };

    const getServiceColor = (index) => {
        const colors = ['bridal', 'hair', 'nails', 'makeup', 'skincare'];
        return colors[index % colors.length];
    };

    return (
        <div className={`beautician-dashboard ${darkMode ? 'dark-mode' : ''}`}>
            {/* Hidden file inputs */}
            <input
                ref={avatarInputRef}
                type="file"
                accept="image/*"
                style={{ display: 'none' }}
                onChange={handleAvatarUpload}
            />
            <input
                ref={portfolioInputRef}
                type="file"
                accept="image/*"
                style={{ display: 'none' }}
                onChange={handlePortfolioUpload}
            />

            {/* Header */}
            <header className="dashboard-header">
                <div className="header-left">
                    <button className="menu-btn" onClick={() => setShowMenu(!showMenu)}>
                        <Menu size={24} />
                    </button>
                    <Link to="/" className="logo">
                        <img src="/assets/logo.png" alt="ZOO Beauty Palace" />
                        <div className="logo-text">
                            <span className="logo-top">ZOO</span>
                            <span className="logo-bottom">beauty Palace</span>
                        </div>
                    </Link>
                    <span className="beautician-badge">Beautician</span>
                </div>
                <div className="header-right">
                    <button
                        className="btn btn-ghost btn-icon"
                        onClick={() => setDarkMode(!darkMode)}
                        title={darkMode ? "Light Mode" : "Dark Mode"}
                    >
                        {darkMode ? <Sun size={20} /> : <Moon size={20} />}
                    </button>
                    <div className="notification-dropdown">
                        <button className="notification-btn">
                            <Bell size={20} />
                            {unreadCount > 0 && (
                                <span className="notification-badge">{unreadCount}</span>
                            )}
                        </button>
                        {notifications.length > 0 && (
                            <div className="notification-list">
                                {notifications.slice(0, 5).map(notification => (
                                    <div
                                        key={notification.id}
                                        className="notification-item"
                                        onClick={() => markAsRead(notification.id)}
                                    >
                                        <div className="notification-content">
                                            <h4>{notification.title}</h4>
                                            <p>{notification.message}</p>
                                            <small>{new Date(notification.createdAt).toLocaleTimeString()}</small>
                                        </div>
                                    </div>
                                ))}
                                <div className="notification-footer">
                                    <button>View All Notifications</button>
                                </div>
                            </div>
                        )}
                    </div>
                    <div className="online-toggle">
                        <span className={`status-indicator ${isOnline ? 'online' : 'offline'}`}></span>
                        <span>{isOnline ? 'Online' : 'Offline'}</span>
                        <label className="switch">
                            <input
                                type="checkbox"
                                checked={isOnline}
                                onChange={() => setIsOnline(!isOnline)}
                            />
                            <span className="slider"></span>
                        </label>
                    </div>
                </div>
            </header>

            {/* Side Menu */}
            <AnimatePresence>
                {showMenu && (
                    <>
                        <motion.div
                            className="menu-overlay"
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            exit={{ opacity: 0 }}
                            onClick={() => setShowMenu(false)}
                        />
                        <motion.div
                            className="side-menu"
                            initial={{ x: -300 }}
                            animate={{ x: 0 }}
                            exit={{ x: -300 }}
                        >
                            <div className="menu-header">
                                <div className="user-info">
                                    <img src={profileData.avatar} alt="Profile" />
                                    <div>
                                        <h3>{profileData.fullName}</h3>
                                        <p>Mobile Beautician</p>
                                    </div>
                                </div>
                                <button onClick={() => setShowMenu(false)}>
                                    <X size={24} />
                                </button>
                            </div>
                            <nav className="menu-nav">
                                <button onClick={() => { setActiveTab('profile'); setShowMenu(false); }}>
                                    <User size={20} />
                                    <span>My Profile</span>
                                    <ChevronRight size={16} />
                                </button>
                                <button onClick={() => { setActiveTab('earnings'); setShowMenu(false); }}>
                                    <DollarSign size={20} />
                                    <span>Earnings</span>
                                    <ChevronRight size={16} />
                                </button>
                                <button onClick={() => { setActiveTab('settings'); setShowMenu(false); }}>
                                    <Settings size={20} />
                                    <span>Settings</span>
                                    <ChevronRight size={16} />
                                </button>
                                <button onClick={() => {
                                    logout();
                                    navigate('/');
                                }} className="logout-btn">
                                    <LogOut size={20} />
                                    <span>Logout</span>
                                </button>
                            </nav>
                        </motion.div>
                    </>
                )}
            </AnimatePresence>

            {/* Stats Cards */}
            <div className="stats-section">
                <div className="stats-grid">
                    <motion.div
                        className="stat-card primary"
                        whileHover={{ scale: 1.05 }}
                        transition={{ type: "spring", stiffness: 300 }}
                    >
                        <div className="stat-icon">
                            <DollarSign size={24} />
                        </div>
                        <div className="stat-content">
                            <p className="stat-label">Today's Earnings</p>
                            <h3 className="stat-value">KES {stats.todayEarnings.toLocaleString()}</h3>
                        </div>
                    </motion.div>
                    <motion.div
                        className="stat-card success"
                        whileHover={{ scale: 1.05 }}
                        transition={{ type: "spring", stiffness: 300 }}
                    >
                        <div className="stat-icon">
                            <CheckCircle size={24} />
                        </div>
                        <div className="stat-content">
                            <p className="stat-label">Completed Today</p>
                            <h3 className="stat-value">{stats.completedToday}</h3>
                        </div>
                    </motion.div>
                    <motion.div
                        className="stat-card warning"
                        whileHover={{ scale: 1.05 }}
                        transition={{ type: "spring", stiffness: 300 }}
                    >
                        <div className="stat-icon">
                            <Star size={24} />
                        </div>
                        <div className="stat-content">
                            <p className="stat-label">Rating</p>
                            <h3 className="stat-value">{stats.rating} ⭐</h3>
                        </div>
                    </motion.div>
                    <motion.div
                        className="stat-card info"
                        whileHover={{ scale: 1.05 }}
                        transition={{ type: "spring", stiffness: 300 }}
                    >
                        <div className="stat-icon">
                            <Target size={24} />
                        </div>
                        <div className="stat-content">
                            <p className="stat-label">Acceptance Rate</p>
                            <h3 className="stat-value">{stats.acceptanceRate}%</h3>
                        </div>
                    </motion.div>
                </div>
            </div>

            {/* Tabs */}
            {['requests', 'active', 'completed', 'assignments'].includes(activeTab) && (
                <div className="tabs-section">
                    <div className="tabs">
                        <button
                            className={`tab ${activeTab === 'requests' ? 'active' : ''}`}
                            onClick={() => setActiveTab('requests')}
                        >
                            <Zap size={18} />
                            Requests ({bookingRequests.length})
                        </button>
                        <button
                            className={`tab ${activeTab === 'active' ? 'active' : ''}`}
                            onClick={() => setActiveTab('active')}
                        >
                            <Navigation size={18} />
                            Active ({activeBookings.length})
                        </button>
                        <button
                            className={`tab ${activeTab === 'completed' ? 'active' : ''}`}
                            onClick={() => setActiveTab('completed')}
                        >
                            <Award size={18} />
                            Completed
                        </button>
                        <button
                            className={`tab ${activeTab === 'assignments' ? 'active' : ''}`}
                            onClick={() => setActiveTab('assignments')}
                        >
                            <CheckCircle size={18} />
                            Assignments ({assignments.length})
                        </button>
                    </div>
                </div>
            )}

            {/* Content */}
            <div className="dashboard-content">
                <AnimatePresence mode="wait">
                    {/* Profile Tab - FULLY FUNCTIONAL */}
                    {activeTab === 'profile' && (
                        <motion.div
                            key="profile"
                            initial={{ opacity: 0, x: 20 }}
                            animate={{ opacity: 1, x: 0 }}
                            exit={{ opacity: 0, x: -20 }}
                            className="profile-section"
                        >
                            <div className="section-header">
                                <h2>My Profile</h2>
                                <p className="section-subtitle">Manage your professional information</p>
                            </div>

                            {/* Profile Header Card */}
                            <motion.div
                                className="card profile-header-card"
                                whileHover={{ y: -4 }}
                                transition={{ type: "spring", stiffness: 300 }}
                            >
                                <div className="profile-banner">
                                    <div className="banner-gradient"></div>
                                </div>
                                <div className="profile-avatar-section">
                                    <div className="avatar-container">
                                        <img
                                            src={profileData.avatar}
                                            alt="Profile"
                                            className="profile-avatar"
                                        />
                                        <button
                                            className="avatar-edit-btn"
                                            onClick={handleAvatarClick}
                                            title="Change profile picture"
                                        >
                                            <Camera size={18} />
                                        </button>
                                    </div>
                                    <div className="profile-quick-stats">
                                        <div className="quick-stat">
                                            <Star size={20} fill="#f59e0b" color="#f59e0b" />
                                            <div>
                                                <h4>{stats.rating || '0.0'}</h4>
                                                <p>Rating</p>
                                            </div>
                                        </div>
                                        <div className="quick-stat">
                                            <CheckCircle size={20} color="#10b981" />
                                            <div>
                                                <h4>{stats.totalBookings || '0'}</h4>
                                                <p>Completed</p>
                                            </div>
                                        </div>
                                        <div className="quick-stat">
                                            <Award size={20} color="#8b5cf6" />
                                            <div>
                                                <h4>{stats.acceptanceRate || '0'}%</h4>
                                                <p>Acceptance</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </motion.div>

                            {/* Personal Information Card */}
                            <motion.div
                                className="card profile-info-card"
                                initial={{ opacity: 0, y: 20 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ delay: 0.1 }}
                            >
                                <div className="card-header-section">
                                    <h3>
                                        <User size={20} />
                                        Personal Information
                                    </h3>
                                </div>
                                <div className="form-grid">
                                    <div className="form-group">
                                        <label className="form-label">
                                            <User size={16} />
                                            Full Name
                                        </label>
                                        <input
                                            type="text"
                                            value={profileData.fullName}
                                            onChange={(e) => handleProfileChange('fullName', e.target.value)}
                                            className="input-field-modern"
                                            placeholder="Enter your full name"
                                        />
                                    </div>
                                    <div className="form-group">
                                        <label className="form-label">
                                            <Phone size={16} />
                                            Phone Number
                                        </label>
                                        <input
                                            type="tel"
                                            value={profileData.phoneNumber}
                                            onChange={(e) => handleProfileChange('phoneNumber', e.target.value)}
                                            className="input-field-modern"
                                            placeholder="+254 XXX XXX XXX"
                                        />
                                    </div>
                                </div>
                                <div className="form-group">
                                    <label className="form-label">
                                        <MapPin size={16} />
                                        Service Area
                                    </label>
                                    <input
                                        type="text"
                                        value={profileData.serviceArea}
                                        onChange={(e) => handleProfileChange('serviceArea', e.target.value)}
                                        className="input-field-modern"
                                        placeholder="Areas you serve"
                                    />
                                </div>
                                <div className="form-group">
                                    <label className="form-label">
                                        <Star size={16} />
                                        Professional Bio
                                    </label>
                                    <textarea
                                        value={profileData.bio}
                                        onChange={(e) => handleProfileChange('bio', e.target.value)}
                                        className="input-field-modern textarea-modern"
                                        rows="4"
                                        placeholder="Tell clients about yourself..."
                                    ></textarea>
                                </div>
                            </motion.div>

                            {/* Services Offered Card */}
                            <motion.div
                                className="card services-card"
                                initial={{ opacity: 0, y: 20 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ delay: 0.2 }}
                            >
                                <div className="card-header-section">
                                    <h3>
                                        <Zap size={20} />
                                        Services Offered
                                    </h3>
                                    <p className="card-subtitle">Add or remove your specializations</p>
                                </div>
                                <div className="services-tags-modern">
                                    {services.map((service, index) => (
                                        <motion.span
                                            key={service}
                                            className={`service-tag ${getServiceColor(index)}`}
                                            whileHover={{ scale: 1.05 }}
                                            whileTap={{ scale: 0.95 }}
                                        >
                                            {service}
                                            <button
                                                className="remove-tag"
                                                onClick={() => handleRemoveService(service)}
                                                title="Remove service"
                                            >
                                                <X size={14} />
                                            </button>
                                        </motion.span>
                                    ))}

                                    {showAddService ? (
                                        <div className="add-service-input-container">
                                            <input
                                                type="text"
                                                value={newService}
                                                onChange={(e) => setNewService(e.target.value)}
                                                onKeyPress={(e) => e.key === 'Enter' && handleAddService()}
                                                placeholder="Enter service name"
                                                className="add-service-input"
                                                autoFocus
                                            />
                                            <button
                                                className="add-service-confirm"
                                                onClick={handleAddService}
                                            >
                                                <CheckCircle size={16} />
                                            </button>
                                            <button
                                                className="add-service-cancel"
                                                onClick={() => {
                                                    setShowAddService(false);
                                                    setNewService('');
                                                }}
                                            >
                                                <XCircle size={16} />
                                            </button>
                                        </div>
                                    ) : (
                                        <motion.button
                                            className="add-service-btn"
                                            whileHover={{ scale: 1.05 }}
                                            whileTap={{ scale: 0.95 }}
                                            onClick={() => setShowAddService(true)}
                                        >
                                            <span className="plus-icon">+</span>
                                            Add Service
                                        </motion.button>
                                    )}
                                </div>
                            </motion.div>

                            {/* Portfolio Card */}
                            <motion.div
                                className="card portfolio-card"
                                initial={{ opacity: 0, y: 20 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ delay: 0.3 }}
                            >
                                <div className="card-header-section">
                                    <h3>
                                        <Award size={20} />
                                        Portfolio
                                    </h3>
                                    <p className="card-subtitle">Showcase your best work ({portfolioImages.length}/12 images)</p>
                                </div>
                                <div className="portfolio-grid">
                                    {portfolioImages.map((img, index) => (
                                        <motion.div
                                            key={index}
                                            className="portfolio-item"
                                            whileHover={{ scale: 1.05 }}
                                            transition={{ type: "spring", stiffness: 300 }}
                                        >
                                            <img
                                                src={img}
                                                alt={`Portfolio ${index + 1}`}
                                            />
                                            <button
                                                className="remove-portfolio-btn"
                                                onClick={() => handleRemovePortfolioImage(index)}
                                                title="Remove image"
                                            >
                                                <X size={16} />
                                            </button>
                                        </motion.div>
                                    ))}
                                    {portfolioImages.length < 12 && (
                                        <motion.button
                                            className="add-portfolio-btn"
                                            whileHover={{ scale: 1.05 }}
                                            whileTap={{ scale: 0.95 }}
                                            onClick={handlePortfolioClick}
                                        >
                                            <span className="plus-icon-large">+</span>
                                            <span>Add Photo</span>
                                        </motion.button>
                                    )}
                                </div>
                            </motion.div>

                            {/* Save Button */}
                            <motion.button
                                className="btn btn-primary btn-save-profile"
                                whileHover={{ scale: 1.02 }}
                                whileTap={{ scale: 0.98 }}
                                onClick={handleSaveProfile}
                                disabled={isSaving}
                            >
                                {isSaving ? (
                                    <>
                                        <div className="spinner"></div>
                                        Saving...
                                    </>
                                ) : (
                                    <>
                                        <CheckCircle size={20} />
                                        Save Changes
                                    </>
                                )}
                            </motion.button>
                        </motion.div>
                    )}


                    {/* Requests Tab */}
                    {activeTab === 'requests' && (
                        <motion.div
                            key="requests"
                            initial={{ opacity: 0, x: 20 }}
                            animate={{ opacity: 1, x: 0 }}
                            exit={{ opacity: 0, x: -20 }}
                            className="requests-section"
                        >
                            <div className="section-header">
                                <h2>Booking Requests</h2>
                                <p className="section-subtitle">Manage incoming appointment requests</p>
                            </div>

                            {bookingRequests.length === 0 ? (
                                <div className="empty-state">
                                    <div className="empty-icon"><Zap size={48} /></div>
                                    <h3>No New Requests</h3>
                                    <p>You're all caught up! Enable "Online" status to receive more.</p>
                                </div>
                            ) : (
                                <div className="requests-grid">
                                    {bookingRequests.map(booking => (
                                        <div key={booking._id} className="request-card card">
                                            <div className="request-header">
                                                <div className="client-info">
                                                    <div className="client-avatar">{booking.clientId?.firstName?.charAt(0)}</div>
                                                    <div>
                                                        <h4>{booking.clientId?.firstName} {booking.clientId?.lastName}</h4>
                                                        <div className="rating-badge">
                                                            <Star size={12} fill="currentColor" />
                                                            <span>New Client</span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <span className="time-badge">
                                                    <Clock size={14} />
                                                    Just now
                                                </span>
                                            </div>

                                            <div className="request-details">
                                                <div className="detail-row">
                                                    <Calendar size={16} />
                                                    <span>{new Date(booking.date).toLocaleDateString()}</span>
                                                </div>
                                                <div className="detail-row">
                                                    <Clock size={16} />
                                                    <span>{booking.time}</span>
                                                </div>
                                                <div className="detail-row">
                                                    <MapPin size={16} />
                                                    <span className="location-text">{booking.location}</span>
                                                </div>
                                                <div className="detail-row highlight">
                                                    <DollarSign size={16} />
                                                    <span>KES {booking.amount}</span>
                                                </div>
                                                <div className="service-tag">{booking.service}</div>
                                            </div>

                                            <div className="request-actions">
                                                <button
                                                    className="btn btn-reject"
                                                    onClick={() => handleRejectBooking(booking._id)}
                                                >
                                                    Decline
                                                </button>
                                                <button
                                                    className="btn btn-accept"
                                                    onClick={() => handleAcceptBooking(booking._id)}
                                                >
                                                    Accept Request
                                                </button>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            )}
                        </motion.div>
                    )}

                    {/* Active Bookings Tab */}
                    {activeTab === 'active' && (
                        <motion.div
                            key="active"
                            initial={{ opacity: 0, x: 20 }}
                            animate={{ opacity: 1, x: 0 }}
                            exit={{ opacity: 0, x: -20 }}
                        >
                            <div className="section-header">
                                <h2>Active Bookings</h2>
                                <p className="section-subtitle">Manage upcoming and ongoing appointments</p>
                            </div>

                            {activeBookings.length === 0 ? (
                                <div className="empty-state">
                                    <div className="empty-icon"><Calendar size={48} /></div>
                                    <h3>No Active Bookings</h3>
                                    <p>Check your requests tab to accept new bookings.</p>
                                </div>
                            ) : (
                                <div className="active-bookings-list">
                                    {activeBookings.map(booking => (
                                        <div key={booking._id} className="active-booking-card card">
                                            <div className="booking-status-strip"></div>
                                            <div className="booking-main-content">
                                                <div className="booking-header">
                                                    <div className="booking-service">
                                                        <h3>{booking.service}</h3>
                                                        <span className={`status-badge ${booking.status}`}>{booking.status}</span>
                                                    </div>
                                                    <div className="booking-price">KES {booking.amount}</div>
                                                </div>

                                                <div className="booking-client-details">
                                                    <div className="detail-block">
                                                        <span className="label">Client</span>
                                                        <div className="value-with-icon">
                                                            <User size={16} />
                                                            {booking.clientId?.firstName} {booking.clientId?.lastName}
                                                        </div>
                                                    </div>
                                                    <div className="detail-block">
                                                        <span className="label">Date & Time</span>
                                                        <div className="value-with-icon">
                                                            <Calendar size={16} />
                                                            {new Date(booking.date).toLocaleDateString()} at {booking.time}
                                                        </div>
                                                    </div>
                                                    <div className="detail-block full-width">
                                                        <span className="label">Location</span>
                                                        <div className="value-with-icon">
                                                            <MapPin size={16} />
                                                            {booking.location}
                                                        </div>
                                                    </div>
                                                </div>

                                                <div className="booking-footer-actions">
                                                    <button className="btn btn-outline btn-sm">
                                                        <Phone size={16} /> Call Client
                                                    </button>
                                                    {booking.status === 'confirmed' && (
                                                        <button
                                                            className="btn btn-primary btn-sm"
                                                            onClick={() => handleStartNavigation(booking)}
                                                        >
                                                            <Navigation size={16} /> Start Navigation
                                                        </button>
                                                    )}
                                                    {booking.status === 'in-progress' && (
                                                        <button
                                                            className="btn btn-success btn-sm"
                                                            onClick={() => handleCompleteBooking(booking._id)}
                                                        >
                                                            <CheckCircle size={16} /> Mark Completed
                                                        </button>
                                                    )}
                                                </div>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            )}
                        </motion.div>
                    )}

                    {/* Completed Bookings Tab */}
                    {activeTab === 'completed' && (
                        <motion.div
                            key="completed"
                            initial={{ opacity: 0, x: 20 }}
                            animate={{ opacity: 1, x: 0 }}
                            exit={{ opacity: 0, x: -20 }}
                        >
                            <div className="section-header">
                                <h2>Completed Jobs</h2>
                                <p className="section-subtitle">History of your past appointments</p>
                            </div>

                            <div className="card table-card">
                                <table className="modern-table">
                                    <thead>
                                        <tr>
                                            <th>Date</th>
                                            <th>Client</th>
                                            <th>Service</th>
                                            <th>Amount</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {completedBookings.map(booking => (
                                            <tr key={booking._id}>
                                                <td>{new Date(booking.date).toLocaleDateString()}</td>
                                                <td>{booking.clientId?.firstName}</td>
                                                <td>{booking.service}</td>
                                                <td>KES {booking.amount}</td>
                                                <td><span className="status-pill completed">Completed</span></td>
                                            </tr>
                                        ))}
                                        {completedBookings.length === 0 && (
                                            <tr>
                                                <td colSpan="5" className="text-center">No completed bookings yet</td>
                                            </tr>
                                        )}
                                    </tbody>
                                </table>
                            </div>
                        </motion.div>
                    )}

                    {/* Assignments Tab */}
                    {activeTab === 'assignments' && (
                        <motion.div
                            key="assignments"
                            initial={{ opacity: 0, x: 20 }}
                            animate={{ opacity: 1, x: 0 }}
                            exit={{ opacity: 0, x: -20 }}
                        >
                            <div className="section-header">
                                <h2>Task Assignments</h2>
                                <p className="section-subtitle">Tasks assigned to you by Admin or Providers</p>
                            </div>

                            {assignments.length === 0 ? (
                                <div className="empty-state">
                                    <div className="empty-icon"><CheckCircle size={48} /></div>
                                    <h3>No Assignments</h3>
                                    <p>You don't have any assigned tasks yet.</p>
                                </div>
                            ) : (
                                <div className="card table-card">
                                    <table className="modern-table">
                                        <thead>
                                            <tr>
                                                <th>Task ID</th>
                                                <th>Title</th>
                                                <th>Assigned By</th>
                                                <th>Provider</th>
                                                <th>Status</th>
                                                <th>Priority</th>
                                                <th>Due Date</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {assignments.map(assignment => (
                                                <tr key={assignment.id}>
                                                    <td>{assignment.taskId}</td>
                                                    <td>{assignment.title}</td>
                                                    <td>{assignment.assignedBy?.firstName} {assignment.assignedBy?.lastName}</td>
                                                    <td>{assignment.provider?.businessName || 'N/A'}</td>
                                                    <td><span className={`status-badge ${assignment.status}`}>{assignment.status}</span></td>
                                                    <td><span className={`priority-badge ${assignment.priority}`}>{assignment.priority}</span></td>
                                                    <td>{assignment.dueDate ? new Date(assignment.dueDate).toLocaleDateString() : 'N/A'}</td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                </div>
                            )}
                        </motion.div>
                    )}

                    {/* Earnings Tab */}
                    {activeTab === 'earnings' && (
                        <motion.div
                            key="earnings"
                            initial={{ opacity: 0, x: 20 }}
                            animate={{ opacity: 1, x: 0 }}
                            exit={{ opacity: 0, x: -20 }}
                        >
                            <div className="section-header">
                                <h2>Earnings Overview</h2>
                                <p className="section-subtitle">Track your financial performance</p>
                            </div>

                            <div className="earnings-summary card">
                                <div className="earnings-total">
                                    <span className="label">Total Revenue</span>
                                    <h1 className="amount">KES {stats.monthEarnings ? stats.monthEarnings.toLocaleString() : '0'}</h1>
                                    <p className="period">This Month</p>
                                </div>
                                <div className="earnings-chart-placeholder">
                                    {/* Placeholder for a chart */}
                                    <div className="chart-bars">
                                        {[40, 65, 30, 80, 55, 90, 45].map((h, i) => (
                                            <div key={i} className="bar" style={{ height: `${h}%` }}></div>
                                        ))}
                                    </div>
                                    <div className="chart-labels">
                                        <span>Mon</span><span>Tue</span><span>Wed</span><span>Thu</span><span>Fri</span><span>Sat</span><span>Sun</span>
                                    </div>
                                </div>
                            </div>
                        </motion.div>
                    )}

                    {/* Settings Tab */}
                    {activeTab === 'settings' && (
                        <motion.div
                            key="settings"
                            initial={{ opacity: 0, x: 20 }}
                            animate={{ opacity: 1, x: 0 }}
                            exit={{ opacity: 0, x: -20 }}
                        >
                            <div className="section-header">
                                <h2>App Settings</h2>
                                <p className="section-subtitle">Customize your experience</p>
                            </div>

                            <div className="settings-grid" style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '1.5rem' }}>
                                {/* Notifications Card */}
                                <div className="card settings-card">
                                    <h3 style={{ marginBottom: '1.5rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                                        <Bell size={20} /> Notifications
                                    </h3>
                                    <div className="setting-item">
                                        <div className="setting-info">
                                            <h4>Push Notifications</h4>
                                            <p>Receive alerts for new bookings immediately</p>
                                        </div>
                                        <label className="switch">
                                            <input type="checkbox" defaultChecked />
                                            <span className="slider round"></span>
                                        </label>
                                    </div>
                                    <div className="setting-item">
                                        <div className="setting-info">
                                            <h4>SMS Alerts</h4>
                                            <p>Get text messages for critical updates</p>
                                        </div>
                                        <label className="switch">
                                            <input type="checkbox" defaultChecked />
                                            <span className="slider round"></span>
                                        </label>
                                    </div>
                                    <div className="setting-item">
                                        <div className="setting-info">
                                            <h4>Email Summaries</h4>
                                            <p>Weekly performance report</p>
                                        </div>
                                        <label className="switch">
                                            <input type="checkbox" />
                                            <span className="slider round"></span>
                                        </label>
                                    </div>
                                </div>

                                {/* Preferences Card */}
                                <div className="card settings-card">
                                    <h3 style={{ marginBottom: '1.5rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                                        <Settings size={20} /> Preferences
                                    </h3>
                                    <div className="setting-item">
                                        <div className="setting-info">
                                            <h4>Navigation App</h4>
                                            <p>Default map for client directions</p>
                                        </div>
                                        <select className="select-modern" defaultValue="Google Maps">
                                            <option>Google Maps</option>
                                            <option>Waze</option>
                                            <option>Apple Maps</option>
                                        </select>
                                    </div>
                                    <div className="setting-item">
                                        <div className="setting-info">
                                            <h4>Language</h4>
                                            <p>App display language</p>
                                        </div>
                                        <select className="select-modern" defaultValue="English">
                                            <option>English</option>
                                            <option>Swahili</option>
                                        </select>
                                    </div>
                                    <div className="setting-item">
                                        <div className="setting-info">
                                            <h4>Theme</h4>
                                            <p>Light/Dark mode preference</p>
                                        </div>
                                        <div style={{ display: 'flex', gap: '0.5rem' }}>
                                            <button className={`btn-sm ${!darkMode ? 'btn-primary' : 'btn-outline'}`} onClick={() => setDarkMode(false)}>
                                                <Sun size={14} /> Light
                                            </button>
                                            <button className={`btn-sm ${darkMode ? 'btn-primary' : 'btn-outline'}`} onClick={() => setDarkMode(true)}>
                                                <Moon size={14} /> Dark
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </motion.div>
                    )}
                </AnimatePresence>
            </div>
        </div>
    );
};

export default BeauticianDashboard;
