import { useEffect, useState, useRef } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { useNotification } from '../../context/NotificationContext';
import { debounce } from '../../utils/debounce';
import {
    Sparkles, Users, Briefcase, Calendar, DollarSign, TrendingUp,
    Settings, LogOut, Bell, Shield, AlertTriangle, CheckCircle,
    Moon, Sun, Eye, Edit, Trash2, UserCheck, UserX, Ban, CheckCircle2,
    Download, BarChart2
} from 'lucide-react';
import {
    getDashboardStats, getUsers, createUser, updateUser, deleteUser, getBookings,
    getDisputes, resolveDispute, getProviders, resetUserPassword, getAnalytics, getBeauticians
} from '../../services/adminService';
import { assignTask, getAssignments, bulkUpdateAssignmentStatus, bulkDeleteAssignments, updateAssignmentStatus } from '../../services/assignmentService';
import { mockProviders, mockDashboardStats, mockBookings, mockUsers, mockNotifications } from '../../data/mockData';
import { SkeletonDashboardOverview, SkeletonTable, SkeletonStatCard } from '../../components/Skeleton';
import { EmptyTable, EmptyUsers, EmptyBookings, EmptyDisputes, EmptyAssignments } from '../../components/EmptyState';
import { BarChart, LineChart, PieChart } from '../../components/ChartComponents';
import Pagination from '../../components/Pagination';
import { io } from 'socket.io-client';
import { setStats, setRecentUsers, setRecentBookings, setProviders, setBookings, setUsers, setLoading, setError, incrementTotalBookings, updatePlatformRevenue, addRecentBooking, updateRecentBooking } from '../../store/dashboardSlice';
import './AdminDashboard.css';

const AdminDashboard = () => {
    const dispatch = useDispatch();
    const { logout } = useAuth();
    const { showSuccess, showError, showInfo } = useToast();
    const { notifications, unreadCount, markAsRead, markAllAsRead } = useNotification();

    // Select state from Redux store
    const {
        stats,
        recentUsers,
        recentBookings,
        providers,
        bookings,
        users,
        loading,
        error
    } = useSelector(state => state.dashboard);

    // Debugging: Log state to console
    useEffect(() => {
        console.log('Dashboard state:', { stats, recentUsers, recentBookings, providers, bookings, users, loading, error });
        console.log('Filtered users:', filterUsers(users));
    }, [stats, recentUsers, recentBookings, providers, bookings, users, loading, error]);

    // Debugging: Log Redux state changes
    useEffect(() => {
        console.log('Users in Redux store:', users);
    }, [users]);

    const [activeTab, setActiveTab] = useState('overview');
    const [darkMode, setDarkMode] = useState(false);
    const [showNotificationDropdown, setShowNotificationDropdown] = useState(false);
    const [showAddUserModal, setShowAddUserModal] = useState(false);
    const [showEditUserModal, setShowEditUserModal] = useState(false);
    const [selectedUser, setSelectedUser] = useState(null);
    const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
    const [newUser, setNewUser] = useState({
        firstName: '',
        lastName: '',
        email: '',
        password: '',
        phone: '',
        role: 'provider',
        businessName: '',
        serviceType: 'studio'
    });
    const [editUser, setEditUser] = useState({
        firstName: '',
        lastName: '',
        phone: '',
        role: '',
        isActive: true
    });

    // Pagination states
    const [userPagination, setUserPagination] = useState({ page: 1, limit: 20, total: 0, pages: 1 });
    const [providerPagination, setProviderPagination] = useState({ page: 1, limit: 20, total: 0, pages: 1 });
    const [bookingPagination, setBookingPagination] = useState({ page: 1, limit: 20, total: 0, pages: 1 });
    const [disputePagination, setDisputePagination] = useState({ page: 1, limit: 20, total: 0, pages: 1 });
    const [assignmentPagination, setAssignmentPagination] = useState({ page: 1, limit: 20, total: 0, pages: 1 });

    // Search states
    const [userSearch, setUserSearch] = useState('');
    const [providerSearch, setProviderSearch] = useState('');
    const [bookingSearch, setBookingSearch] = useState('');
    const [disputeSearch, setDisputeSearch] = useState('');
    const [assignmentSearch, setAssignmentSearch] = useState('');

    // User selection and filters
    const [selectedUsers, setSelectedUsers] = useState([]);
    const [userFilters, setUserFilters] = useState({
        role: '',
        status: '' // Empty string means no filter applied
    });

    const [revenue, setRevenue] = useState([
        { month: 'January 2024', bookings: 145, revenue: 725000, platformFee: 72500 },
        { month: 'February 2024', bookings: 167, revenue: 835000, platformFee: 83500 },
        { month: 'March 2024', bookings: 189, revenue: 945000, platformFee: 94500 },
        { month: 'April 2024', bookings: 203, revenue: 1015000, platformFee: 101500 },
        { month: 'May 2024', bookings: 221, revenue: 1105000, platformFee: 110500 },
        { month: 'June 2024', bookings: 245, revenue: 1225000, platformFee: 122500 }
    ]);

    // Analytics state
    const [analyticsData, setAnalyticsData] = useState({
        period: { startDate: '', endDate: '' },
        summary: { totalRevenue: 0, platformFees: 0, newUserRegistrations: 0, newProviders: 0, totalBookings: 0 },
        userStats: [],
        bookingStats: [],
        dailyMetrics: []
    });
    const [analyticsFilters, setAnalyticsFilters] = useState({
        startDate: '',
        endDate: ''
    });

    // Assignment state
    const [assignments, setAssignments] = useState([]);
    const [beauticians, setBeauticians] = useState([]);
    const [showAssignTaskModal, setShowAssignTaskModal] = useState(false);
    const [assignmentData, setAssignmentData] = useState({
        title: '',
        description: '',
        assignedToId: '',
        providerId: '',
        priority: 'medium',
        dueDate: ''
    });

    // WebSocket connection
    const socketRef = useRef(null);

    // Initialize WebSocket connection
    useEffect(() => {
        // Initialize socket connection
        const socket = io(import.meta.env.VITE_API_URL || 'http://localhost:5000', {
            reconnection: true,
            reconnectionAttempts: 3,
            reconnectionDelay: 1000,
            timeout: 5000
        });

        socketRef.current = socket;

        // Listen for new bookings
        socket.on('booking_created', (data) => {
            // Update stats
            dispatch(incrementTotalBookings());

            // Add to recent bookings if we're on the overview tab
            if (activeTab === 'overview') {
                dispatch(addRecentBooking(data.booking));
            }

            // Show notification
            showInfo(`New booking created: ${data.booking.serviceName}`);
        });

        // Listen for booking updates
        socket.on('booking_updated', (data) => {
            // If a booking is completed, update stats
            if (data.booking.status === 'completed') {
                // Update platform revenue (assuming 10% fee)
                const platformFee = data.booking.amount * 0.1;
                dispatch(updatePlatformRevenue({
                    platformFee: platformFee,
                    totalRevenue: data.booking.amount
                }));

                showInfo(`Booking completed: ${data.booking.serviceName}`);
            }

            // Update recent bookings if we're on the overview tab
            if (activeTab === 'overview') {
                dispatch(updateRecentBooking(data.booking));
            }
        });

        // Handle socket errors gracefully
        socket.on('connect_error', (error) => {
            console.warn('Socket connection error:', error.message);
        });

        return () => {
            socket.disconnect();
        };
    }, []);

    // Assignment filters and selection
    const [assignmentFilters, setAssignmentFilters] = useState({
        status: '',
        priority: '',
        assignedToId: '',
        providerId: ''
    });
    const [selectedAssignments, setSelectedAssignments] = useState([]);

    useEffect(() => {
        fetchDashboardData();
    }, []);

    // Debounced search functions
    const debouncedUserSearch = debounce((searchTerm) => {
        fetchUsers(1);
    }, 500);

    const debouncedProviderSearch = debounce((searchTerm) => {
        if (activeTab === 'beauticians') {
            fetchBeauticians(1);
        } else {
            fetchProviders(1);
        }
    }, 500);

    const debouncedBookingSearch = debounce((searchTerm) => {
        fetchBookings(1);
    }, 500);

    const debouncedDisputeSearch = debounce((searchTerm) => {
        fetchDisputes(1);
    }, 500);

    const debouncedAssignmentSearch = debounce((searchTerm) => {
        fetchAssignments(assignmentFilters, 1);
    }, 500);

    // Real-time search effects
    useEffect(() => {
        if (activeTab === 'users' && userSearch) {
            debouncedUserSearch(userSearch);
        } else if (activeTab === 'users') {
            fetchUsers(1);
        }
    }, [userSearch, activeTab]);

    useEffect(() => {
        if (activeTab === 'providers' && providerSearch) {
            debouncedProviderSearch(providerSearch);
        } else if (activeTab === 'providers') {
            fetchProviders(1);
        } else if (activeTab === 'beauticians' && providerSearch) {
            debouncedProviderSearch(providerSearch);
        } else if (activeTab === 'beauticians') {
            fetchBeauticians(1);
        }
    }, [providerSearch, activeTab]);

    useEffect(() => {
        if (activeTab === 'bookings' && bookingSearch) {
            debouncedBookingSearch(bookingSearch);
        } else if (activeTab === 'bookings') {
            fetchBookings(1);
        }
    }, [bookingSearch, activeTab]);

    useEffect(() => {
        if (activeTab === 'disputes' && disputeSearch) {
            debouncedDisputeSearch(disputeSearch);
        } else if (activeTab === 'disputes') {
            fetchDisputes(1);
        }
    }, [disputeSearch, activeTab]);

    useEffect(() => {
        if (activeTab === 'assignments' && assignmentSearch) {
            debouncedAssignmentSearch(assignmentSearch);
        } else if (activeTab === 'assignments') {
            fetchAssignments(assignmentFilters, 1);
        }
    }, [assignmentSearch, activeTab]);

    const fetchDashboardData = async () => {
        dispatch(setLoading(true));
        try {
            await Promise.all([
                fetchStats(),
                fetchUsers(1),
                fetchProviders(1),
                fetchBookings(1),
                fetchDisputes(1),
                fetchAssignments(assignmentFilters, 1),
                fetchDetailedAnalytics()
            ]);
        } catch (error) {
            console.error('Error fetching dashboard data:', error);
            dispatch(setError(error.message));
        } finally {
            dispatch(setLoading(false));
        }
    };

    const fetchStats = async () => {
        try {
            const data = await getDashboardStats();
            if (data.success) {
                dispatch(setStats(data.data));
            }
        } catch (error) {
            console.error('Error fetching stats:', error);
        }
    };

    const fetchUsers = async (page = 1) => {
        try {
            const params = { page, limit: userPagination.limit };
            if (userFilters.role) params.role = userFilters.role;
            // Only send isActive param if a filter is explicitly set
            if (userFilters.status !== '' && userFilters.status !== undefined) {
                params.isActive = userFilters.status === 'true';
            }
            if (userSearch) params.search = userSearch;

            console.log('Fetching users with params:', params);
            const data = await getUsers(params);
            console.log('Users data received:', data);

            if (data.success) {
                // Filter out clients from the users list
                const filteredUsers = data.data.users.filter(user => user.role !== 'client');
                console.log('Filtered users:', filteredUsers);
                dispatch(setUsers(filteredUsers));
                dispatch(setRecentUsers(filteredUsers.slice(0, 5)));
                setUserPagination({
                    page: data.data.pagination.page,
                    limit: data.data.pagination.limit,
                    total: data.data.pagination.total,
                    pages: data.data.pagination.pages
                });
            }
        } catch (error) {
            console.error('Error fetching users:', error);
            showError('Failed to fetch users');
        }
    };

    const fetchProviders = async (page = 1) => {
        try {
            const params = { page, limit: providerPagination.limit };
            if (providerSearch) params.search = providerSearch;

            const data = await getProviders(params);
            if (data.success) {
                dispatch(setProviders(data.data.providers));
                setProviderPagination({
                    page: data.data.pagination.page,
                    limit: data.data.pagination.limit,
                    total: data.data.pagination.total,
                    pages: data.data.pagination.pages
                });
            }
        } catch (error) {
            console.error('Error fetching providers:', error);
        }
    };

    const fetchBeauticians = async (page = 1) => {
        try {
            const params = { page, limit: providerPagination.limit };
            if (providerSearch) params.search = providerSearch;

            const data = await getBeauticians(params);
            if (data.success) {
                setBeauticians(data.data.users);
                setProviderPagination({
                    page: data.data.pagination.page,
                    limit: data.data.pagination.limit,
                    total: data.data.pagination.total,
                    pages: data.data.pagination.pages
                });
            }
        } catch (error) {
            console.error('Error fetching beauticians:', error);
        }
    };

    const fetchBookings = async (page = 1) => {
        try {
            const params = { page, limit: bookingPagination.limit };
            if (bookingSearch) params.search = bookingSearch;

            const data = await getBookings(params);
            if (data.success) {
                dispatch(setBookings(data.data.bookings));
                dispatch(setRecentBookings(data.data.bookings.slice(0, 5)));
                setBookingPagination({
                    page: data.data.pagination.page,
                    limit: data.data.pagination.limit,
                    total: data.data.pagination.total,
                    pages: data.data.pagination.pages
                });
            }
        } catch (error) {
            console.error('Error fetching bookings:', error);
        }
    };

    const fetchDisputes = async (page = 1) => {
        try {
            const params = { page, limit: disputePagination.limit };
            if (disputeSearch) params.search = disputeSearch;

            const data = await getDisputes(params);
            if (data.success) {
                setDisputes(data.data.disputes);
                setDisputePagination({
                    page: data.data.pagination.page,
                    limit: data.data.pagination.limit,
                    total: data.data.pagination.total,
                    pages: data.data.pagination.pages
                });
            } else {
                setDisputes([]);
            }
        } catch (error) {
            console.error('Error fetching disputes:', error);
            setDisputes([]);
        }
    };

    const fetchDetailedAnalytics = async (filters = {}) => {
        try {
            const data = await getAnalytics(filters);
            if (data.success) {
                setAnalyticsData(data.data);
            }
        } catch (error) {
            console.error('Error fetching analytics:', error);
        }
    };

    const exportAnalyticsReport = async (format = 'csv') => {
        try {
            const params = {
                startDate: analyticsFilters.startDate,
                endDate: analyticsFilters.endDate,
                format
            };

            // Create URL for export
            const url = `${process.env.REACT_APP_API_URL || 'http://localhost:5000'}/api/admin/analytics/export?${new URLSearchParams(params).toString()}`;

            // Create a temporary link and trigger download
            const link = document.createElement('a');
            link.href = url;
            link.download = `analytics-report.${format}`;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);

            showSuccess(`Analytics report exported as ${format.toUpperCase()} successfully!`);
        } catch (error) {
            console.error('Error exporting analytics report:', error);
            showError('Failed to export analytics report');
        }
    };

    const fetchAssignments = async (filters = {}, page = 1) => {
        try {
            const params = { page, limit: assignmentPagination.limit, ...filters };
            if (assignmentSearch) params.search = assignmentSearch;

            const data = await getAssignments(params);
            if (data.success) {
                setAssignments(data.data.assignments);
                setAssignmentPagination({
                    page: data.data.pagination.page,
                    limit: data.data.pagination.limit,
                    total: data.data.pagination.total,
                    pages: data.data.pagination.pages
                });
            }
        } catch (error) {
            console.error('Error fetching assignments:', error);
        }
    };

    const handleResolveDispute = async (disputeId, action) => {
        try {
            await resolveDispute(disputeId, { action, note: 'Resolved via dashboard' });
            showSuccess('Dispute resolved successfully!');
            fetchDisputes();
        } catch (error) {
            console.error('Error resolving dispute:', error);
            showError('Failed to resolve dispute');
        }
    };

    const handleAssignTask = async (e) => {
        e.preventDefault();
        try {
            const result = await assignTask(assignmentData);
            if (result.success) {
                showSuccess('Task assigned successfully!');
                setShowAssignTaskModal(false);
                setAssignmentData({
                    title: '',
                    description: '',
                    assignedToId: '',
                    providerId: '',
                    priority: 'medium',
                    dueDate: ''
                });
                fetchAssignments();
            } else {
                showError(result.message || 'Failed to assign task');
            }
        } catch (error) {
            console.error('Error assigning task:', error);
            showError(error.response?.data?.message || 'Failed to assign task');
        }
    };

    const handleAddUser = async (e) => {
        e.preventDefault();
        try {
            const result = await createUser(newUser);
            if (result.success) {
                showSuccess('User created successfully!');
                setShowAddUserModal(false);
                setNewUser({
                    firstName: '',
                    lastName: '',
                    email: '',
                    password: '',
                    phone: '',
                    role: 'provider'
                });
                fetchUsers();
            } else {
                showError(result.message || 'Failed to create user');
            }
        } catch (error) {
            console.error('Error creating user:', error);
            showError(error.response?.data?.message || 'Failed to create user');
        }
    };

    const handleEditUser = async (e) => {
        e.preventDefault();
        try {
            // Use the correct user ID property (id instead of _id)
            const result = await updateUser(selectedUser.id, editUser);
            if (result.success) {
                showSuccess('User updated successfully!');
                setShowEditUserModal(false);
                setSelectedUser(null);
                fetchUsers();
                fetchProviders();
            } else {
                showError(result.message || 'Failed to update user');
            }
        } catch (error) {
            console.error('Error updating user:', error);
            showError(error.response?.data?.message || 'Failed to update user');
        }
    };

    const handleToggleUserStatus = async (user) => {
        const action = user.isActive ? 'disable' : 'enable';
        const message = user.isActive
            ? 'Are you sure you want to disable this user? They will not be able to access the platform (e.g., for subscription non-payment).'
            : 'Are you sure you want to enable this user?';

        if (window.confirm(message)) {
            try {
                // Use the correct user ID property (id instead of _id)
                const result = await updateUser(user.id, { isActive: !user.isActive });
                if (result.success) {
                    showSuccess(`User ${action}d successfully!`);
                    fetchUsers();
                    fetchProviders();
                } else {
                    showError(result.message || `Failed to ${action} user`);
                }
            } catch (error) {
                console.error(`Error ${action}ing user:`, error);
                showError(error.response?.data?.message || `Failed to ${action} user`);
            }
        }
    };

    const handleBulkStatusUpdate = async (status) => {
        if (selectedAssignments.length === 0) {
            showError('Please select assignments to update');
            return;
        }

        if (window.confirm(`Are you sure you want to update ${selectedAssignments.length} assignments to ${status}?`)) {
            try {
                const result = await bulkUpdateAssignmentStatus(selectedAssignments, status);
                if (result.success) {
                    showSuccess(`${result.data.updatedCount} assignments updated successfully!`);
                    setSelectedAssignments([]);
                    fetchAssignments(assignmentFilters);
                } else {
                    showError(result.message || 'Failed to update assignments');
                }
            } catch (error) {
                console.error('Error updating assignments:', error);
                showError(error.response?.data?.message || 'Failed to update assignments');
            }
        }
    };

    const handleBulkDelete = async () => {
        if (selectedAssignments.length === 0) {
            showError('Please select assignments to delete');
            return;
        }

        if (window.confirm(`Are you sure you want to delete ${selectedAssignments.length} assignments? This action cannot be undone.`)) {
            try {
                const result = await bulkDeleteAssignments(selectedAssignments);
                if (result.success) {
                    showSuccess(`${result.data.deletedCount} assignments deleted successfully!`);
                    setSelectedAssignments([]);
                    fetchAssignments(assignmentFilters);
                } else {
                    showError(result.message || 'Failed to delete assignments');
                }
            } catch (error) {
                console.error('Error deleting assignments:', error);
                showError(error.response?.data?.message || 'Failed to delete assignments');
            }
        }
    };

    const handleAssignmentStatusUpdate = async (id, status) => {
        try {
            const result = await updateAssignmentStatus(id, status);
            if (result.success) {
                showSuccess('Assignment status updated successfully!');
                fetchAssignments(assignmentFilters);
            } else {
                showError(result.message || 'Failed to update assignment status');
            }
        } catch (error) {
            console.error('Error updating assignment status:', error);
            showError(error.response?.data?.message || 'Failed to update assignment status');
        }
    };

    const handleAssignmentDelete = async (id) => {
        if (window.confirm('Are you sure you want to delete this assignment? This action cannot be undone.')) {
            try {
                const result = await bulkDeleteAssignments([id]);
                if (result.success) {
                    showSuccess('Assignment deleted successfully!');
                    fetchAssignments(assignmentFilters);
                } else {
                    showError(result.message || 'Failed to delete assignment');
                }
            } catch (error) {
                console.error('Error deleting assignment:', error);
                showError(error.response?.data?.message || 'Failed to delete assignment');
            }
        }
    };

    // Bulk user actions
    const handleBulkUserStatusUpdate = async (isActive) => {
        if (selectedUsers.length === 0) {
            showError('Please select users to update');
            return;
        }

        const action = isActive ? 'enable' : 'disable';
        const message = isActive
            ? `Are you sure you want to enable ${selectedUsers.length} users?`
            : `Are you sure you want to disable ${selectedUsers.length} users? They will not be able to access the platform.`;

        if (window.confirm(message)) {
            try {
                let successCount = 0;
                for (const userId of selectedUsers) {
                    const result = await updateUser(userId, { isActive });
                    if (result.success) {
                        successCount++;
                    }
                }
                showSuccess(`${successCount} users ${action}d successfully!`);
                setSelectedUsers([]);
                fetchUsers();
                fetchProviders();
            } catch (error) {
                console.error(`Error ${action}ing users:`, error);
                showError(error.response?.data?.message || `Failed to ${action} users`);
            }
        }
    };

    const handleBulkUserDelete = async () => {
        if (selectedUsers.length === 0) {
            showError('Please select users to delete');
            return;
        }

        if (window.confirm(`Are you sure you want to delete ${selectedUsers.length} users? This action cannot be undone.`)) {
            try {
                let successCount = 0;
                for (const userId of selectedUsers) {
                    const result = await deleteUser(userId);
                    if (result.success) {
                        successCount++;
                    }
                }
                showSuccess(`${successCount} users deleted successfully!`);
                setSelectedUsers([]);
                fetchUsers();
                fetchProviders();
            } catch (error) {
                console.error('Error deleting users:', error);
                showError(error.response?.data?.message || 'Failed to delete users');
            }
        }
    };

    const handleBulkUserPasswordReset = async () => {
        if (selectedUsers.length === 0) {
            showError('Please select users to reset passwords');
            return;
        }

        if (window.confirm(`Are you sure you want to reset passwords for ${selectedUsers.length} users?`)) {
            try {
                let successCount = 0;
                let tempPasswords = [];
                for (const userId of selectedUsers) {
                    const result = await resetUserPassword(userId);
                    if (result.success) {
                        successCount++;
                        tempPasswords.push(result.data.temporaryPassword);
                    }
                }

                // Create a temporary textarea to copy to clipboard
                const tempInput = document.createElement("textarea");
                tempInput.value = tempPasswords.join('\n');
                document.body.appendChild(tempInput);
                tempInput.select();
                document.execCommand("copy");
                document.body.removeChild(tempInput);

                showSuccess(`${successCount} user passwords reset successfully! Temporary passwords copied to clipboard.`);
                setSelectedUsers([]);
            } catch (error) {
                console.error('Error resetting user passwords:', error);
                showError(error.response?.data?.message || 'Failed to reset user passwords');
            }
        }
    };

    // Filter users
    const filterUsers = (users) => {
        console.log('Filtering users with filters:', userFilters);
        console.log('Raw users:', users);
        const filtered = users.filter(user => {
            console.log('Checking user:', user);
            if (userFilters.role && user.role !== userFilters.role) {
                console.log('Filtered out by role');
                return false;
            }
            // Only apply status filter if it's explicitly set (not empty)
            if (userFilters.status !== '' && userFilters.status !== undefined) {
                // Compare boolean values properly
                const filterStatusBool = userFilters.status === 'true';
                if (user.isActive !== filterStatusBool) {
                    console.log('Filtered out by status');
                    return false;
                }
            }
            console.log('User passed filters');
            return true;
        });
        console.log('Filtered users result:', filtered);
        return filtered;
    };

    const handleResetPassword = async (user) => {
        if (window.confirm(`Are you sure you want to reset the password for ${user.firstName} ${user.lastName}?`)) {
            try {
                const result = await resetUserPassword(user.id);
                if (result.success) {
                    // Create a temporary textarea to copy to clipboard
                    const tempInput = document.createElement("textarea");
                    tempInput.value = result.data.temporaryPassword;
                    document.body.appendChild(tempInput);
                    tempInput.select();
                    document.execCommand("copy");
                    document.body.removeChild(tempInput);

                    showSuccess(`Password reset successfully! Temporary Password: ${result.data.temporaryPassword} (Copied to clipboard)`);
                } else {
                    showError(result.message || 'Failed to reset password');
                }
            } catch (error) {
                console.error('Error resetting password:', error);
                showError(error.response?.data?.message || 'Failed to reset password');
            }
        }
    };

    const openEditModal = (user) => {
        setSelectedUser(user);
        setEditUser({
            firstName: user.firstName,
            lastName: user.lastName,
            phone: user.phone,
            role: user.role,
            isActive: user.isActive
        });
        setShowEditUserModal(true);
    };

    return (
        <div className={`admin-dashboard ${darkMode ? 'dark-mode' : ''}`}>
            {/* Mobile Menu Overlay */}
            {isMobileMenuOpen && (
                <div
                    className="mobile-menu-overlay"
                    onClick={() => setIsMobileMenuOpen(false)}
                />
            )}

            {/* Sidebar */}
            <aside className={`dashboard-sidebar ${isMobileMenuOpen ? 'mobile-open' : ''}`}>
                <div className="sidebar-header">
                    <h2>ZOO Beauty</h2>
                    <div className="admin-badge">
                        <Shield size={14} />
                        Admin
                    </div>
                </div>                <nav className="sidebar-nav">
                    <button className={`nav-item ${activeTab === 'overview' ? 'active' : ''}`} onClick={() => setActiveTab('overview')}>
                        <TrendingUp size={20} />
                        Overview
                    </button>
                    <button className={`nav-item ${activeTab === 'users' ? 'active' : ''}`} onClick={() => setActiveTab('users')}>
                        <Users size={20} />
                        Users
                    </button>
                    <button className={`nav-item ${activeTab === 'providers' ? 'active' : ''}`} onClick={() => setActiveTab('providers')}>
                        <Briefcase size={20} />
                        Providers
                    </button>
                    <button className={`nav-item ${activeTab === 'beauticians' ? 'active' : ''}`} onClick={() => setActiveTab('beauticians')}>
                        <Sparkles size={20} />
                        Beauticians
                    </button>
                    <button className={`nav-item ${activeTab === 'bookings' ? 'active' : ''}`} onClick={() => setActiveTab('bookings')}>
                        <Calendar size={20} />
                        Bookings
                    </button>
                    <button className={`nav-item ${activeTab === 'revenue' ? 'active' : ''}`} onClick={() => setActiveTab('revenue')}>
                        <DollarSign size={20} />
                        Revenue
                    </button>
                    <button className={`nav-item ${activeTab === 'disputes' ? 'active' : ''}`} onClick={() => setActiveTab('disputes')}>
                        <AlertTriangle size={20} />
                        Disputes
                        {stats.pendingDisputes > 0 && (
                            <span className="badge">{stats.pendingDisputes}</span>
                        )}
                    </button>
                    <button className={`nav-item ${activeTab === 'assignments' ? 'active' : ''}`} onClick={() => setActiveTab('assignments')}>
                        <CheckCircle2 size={20} />
                        Assignments
                        {assignments.length > 0 && (
                            <span className="badge">{assignments.length}</span>
                        )}
                    </button>
                    <button className={`nav-item ${activeTab === 'notifications' ? 'active' : ''}`} onClick={() => setActiveTab('notifications')}>
                        <Bell size={20} />
                        Notifications
                        {unreadCount > 0 && (
                            <span className="badge">{unreadCount}</span>
                        )}
                    </button>
                    <button className={`nav-item ${activeTab === 'analytics' ? 'active' : ''}`} onClick={() => setActiveTab('analytics')}>
                        <BarChart2 size={20} />
                        Analytics
                    </button>
                    <button className={`nav-item ${activeTab === 'activity' ? 'active' : ''}`} onClick={() => setActiveTab('activity')}>
                        <BarChart2 size={20} />
                        Activity Logs
                    </button>
                    <button className={`nav-item ${activeTab === 'settings' ? 'active' : ''}`} onClick={() => setActiveTab('settings')}>
                        <Settings size={20} />
                        Settings
                    </button>
                </nav>

                <div className="sidebar-footer">
                    <Link to="/admin/login" className="nav-item" onClick={() => logout()}>
                        <LogOut size={20} />
                        Logout
                    </Link>
                </div>
            </aside>

            {/* Main Content */}
            <main className="dashboard-main">
                {/* Header */}
                <header className="dashboard-header">
                    <div className="header-left">
                        <button
                            className="mobile-menu-toggle"
                            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                        >
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M3 12H21" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                                <path d="M3 6H21" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                                <path d="M3 18H21" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                            </svg>
                        </button>
                        <h1>Admin Dashboard</h1>
                        <p>Manage your platform</p>
                    </div>
                    <div className="header-right">
                        <button className="btn btn-ghost" onClick={() => setDarkMode(!darkMode)}>
                            {darkMode ? <Sun size={20} /> : <Moon size={20} />}
                        </button>                        <div className="notification-dropdown">
                            <button
                                className="btn btn-ghost"
                                onClick={() => setShowNotificationDropdown(!showNotificationDropdown)}
                            >
                                <Bell size={20} />
                                {unreadCount > 0 && (
                                    <span className="notification-badge">{unreadCount}</span>
                                )}
                            </button>
                            {showNotificationDropdown && (
                                <div className="notification-list">
                                    {notifications.length > 0 ? (
                                        <>
                                            {notifications.slice(0, 5).map(notification => (
                                                <div
                                                    key={notification.id}
                                                    className="notification-item"
                                                    onClick={() => {
                                                        markAsRead(notification.id);
                                                        setShowNotificationDropdown(false);
                                                        if (notification.actionUrl) {
                                                            window.location.href = notification.actionUrl;
                                                        }
                                                    }}
                                                >
                                                    <div className="notification-content">
                                                        <div className="notification-header">
                                                            <h4>{notification.title}</h4>
                                                            <span className={`notification-type ${notification.type}`}>{notification.type}</span>
                                                        </div>
                                                        <p>{notification.message}</p>
                                                        <div className="notification-meta">
                                                            <small>{new Date(notification.createdAt).toLocaleString()}</small>
                                                            {!notification.isRead && <span className="unread-indicator">●</span>}
                                                        </div>
                                                    </div>
                                                </div>
                                            ))}
                                            <div className="notification-footer">
                                                <button onClick={() => { setActiveTab('notifications'); setShowNotificationDropdown(false); }}>
                                                    View All Notifications ({notifications.length})
                                                </button>
                                                <button onClick={() => { markAllAsRead(); setShowNotificationDropdown(false); }} className="mark-all-read">
                                                    Mark All as Read
                                                </button>
                                            </div>
                                        </>
                                    ) : (
                                        <div className="notification-empty">
                                            <Bell size={32} />
                                            <p>No notifications</p>
                                        </div>
                                    )}
                                </div>
                            )}
                        </div>
                        <div className="profile-menu">
                            <div className="admin-avatar">
                                <Shield size={20} />
                            </div>
                        </div>
                    </div>
                </header>

                {/* Overview Tab */}
                {activeTab === 'overview' && (
                    loading ? (
                        <SkeletonDashboardOverview />
                    ) : (
                        <div className="dashboard-content">
                            <div className="stats-grid">
                                <div className="stat-card card">
                                    <div className="stat-icon" style={{ background: 'linear-gradient(135deg, #3b82f6 0%, #2563eb 100%)' }}>
                                        <Users size={24} />
                                    </div>
                                    <div className="stat-info">
                                        <p className="stat-label">Total Users</p>
                                        <h3 className="stat-value">{(stats?.totalUsers || 0).toLocaleString()}</h3>
                                        <p className="stat-change positive">+12% this month</p>
                                    </div>
                                </div>
                                <div className="stat-card card">
                                    <div className="stat-icon" style={{ background: 'linear-gradient(135deg, #d946ef 0%, #9333ea 100%)' }}>
                                        <Briefcase size={24} />
                                    </div>
                                    <div className="stat-info">
                                        <p className="stat-label">Total Providers</p>
                                        <h3 className="stat-value">{(stats?.totalProviders || 0).toLocaleString()}</h3>
                                        <p className="stat-change positive">+8% this month</p>
                                    </div>
                                </div>
                                <div className="stat-card card">
                                    <div className="stat-icon" style={{ background: 'linear-gradient(135deg, #14b8a6 0%, #0d9488 100%)' }}>
                                        <Calendar size={24} />
                                    </div>
                                    <div className="stat-info">
                                        <p className="stat-label">Total Bookings</p>
                                        <h3 className="stat-value">{(stats?.totalBookings || 0).toLocaleString()}</h3>
                                        <p className="stat-change positive">+15% this month</p>
                                    </div>
                                </div>
                                <div className="stat-card card">
                                    <div className="stat-icon" style={{ background: 'linear-gradient(135deg, #f59e0b 0%, #d97706 100%)' }}>
                                        <DollarSign size={24} />
                                    </div>
                                    <div className="stat-info">
                                        <p className="stat-label">Platform Revenue</p>
                                        <h3 className="stat-value">KES {(stats?.platformFee || 0).toLocaleString()}</h3>
                                        <p className="stat-change positive">+18% this month</p>
                                    </div>
                                </div>
                            </div>

                            <div className="activity-grid">
                                <div className="section card">
                                    <div className="section-header">
                                        <h2>Recent Users</h2>
                                        <button className="btn btn-ghost btn-sm" onClick={() => setActiveTab('users')}>View All</button>
                                    </div>
                                    <div className="table-container">
                                        <table className="data-table">
                                            <thead>
                                                <tr>
                                                    <th>Name</th>
                                                    <th>Email</th>
                                                    <th>Role</th>
                                                    <th>Status</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {recentUsers.length > 0 ? (
                                                    recentUsers.map(user => (
                                                        <tr key={user.id}>
                                                            <td>{user.firstName} {user.lastName}</td>
                                                            <td>{user.email}</td>
                                                            <td><span className={`role-badge ${user.role}`}>{user.role}</span></td>
                                                            <td><span className={`status-badge ${user.isActive ? 'active' : 'inactive'}`}>{user.isActive ? 'Active' : 'Inactive'}</span></td>
                                                        </tr>
                                                    ))
                                                ) : (
                                                    <EmptyTable colSpan={4} icon="users" title="No users yet" description="Add providers or beauticians to get started." />
                                                )}
                                            </tbody>
                                        </table>
                                    </div>
                                </div>

                                <div className="section card">
                                    <div className="section-header">
                                        <h2>Recent Bookings</h2>
                                        <button className="btn btn-ghost btn-sm" onClick={() => setActiveTab('bookings')}>View All</button>
                                    </div>
                                    <div className="table-container">
                                        <table className="data-table">
                                            <thead>
                                                <tr>
                                                    <th>Client</th>
                                                    <th>Provider</th>
                                                    <th>Amount</th>
                                                    <th>Status</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {recentBookings.length > 0 ? (
                                                    recentBookings.map(booking => (
                                                        <tr key={booking._id}>
                                                            <td>{booking.clientId?.firstName} {booking.clientId?.lastName}</td>
                                                            <td>{booking.providerId?.firstName} {booking.providerId?.lastName}</td>
                                                            <td>KES {booking.amount}</td>
                                                            <td><span className={`status-badge ${booking.status}`}>{booking.status}</span></td>
                                                        </tr>
                                                    ))
                                                ) : (
                                                    <EmptyTable colSpan={4} icon="calendar" title="No bookings yet" description="Bookings will appear here." />
                                                )}
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    )
                )}

                {/* Users Tab */}
                {activeTab === 'users' && (
                    <div className="dashboard-content">
                        <div className="section-header">
                            <h2>All Users (Providers & Beauticians)</h2>
                            <div className="filter-buttons">
                                <button className="btn btn-primary" onClick={() => setShowAddUserModal(true)}>+ Add User</button>
                            </div>
                        </div>
                        {error && (
                            <div className="alert alert-error">
                                <p>Error: {error}</p>
                                <button onClick={() => dispatch(setError(null))}>Dismiss</button>
                            </div>
                        )}

                        {/* Filters */}
                        <div className="section card">
                            <div className="filter-section">
                                <div className="form-row">
                                    <div className="form-group">
                                        <label>Search</label>
                                        <input
                                            type="text"
                                            className="input"
                                            placeholder="Search by name or email"
                                            value={userSearch}
                                            onChange={(e) => setUserSearch(e.target.value)}
                                        />
                                    </div>
                                    <div className="form-group">
                                        <label>Role</label>
                                        <select
                                            className="input"
                                            value={userFilters.role}
                                            onChange={(e) => setUserFilters({ ...userFilters, role: e.target.value })}
                                        >
                                            <option value="">All Roles</option>
                                            <option value="provider">Provider</option>
                                            <option value="beautician">Beautician</option>
                                        </select>
                                    </div>
                                    <div className="form-group">
                                        <label>Status</label>
                                        <select
                                            className="input"
                                            value={userFilters.status}
                                            onChange={(e) => setUserFilters({ ...userFilters, status: e.target.value })}
                                        >
                                            <option value="">All Statuses</option>
                                            <option value="true">Active</option>
                                            <option value="false">Inactive</option>
                                        </select>
                                    </div>
                                </div>
                                <div className="filter-actions">
                                    <button
                                        className="btn btn-secondary"
                                        onClick={() => {
                                            setUserFilters({
                                                role: '',
                                                status: ''
                                            });
                                            setUserSearch('');
                                            fetchUsers(1);
                                        }}
                                    >
                                        Clear Filters
                                    </button>
                                    <button
                                        className="btn btn-primary"
                                        onClick={() => fetchUsers(1)}
                                    >
                                        Apply Filters
                                    </button>
                                </div>
                            </div>
                        </div>

                        {/* Bulk Actions */}
                        {selectedUsers.length > 0 && (
                            <div className="section card">
                                <div className="bulk-actions">
                                    <span>{selectedUsers.length} users selected</span>
                                    <div className="bulk-action-buttons">
                                        <button
                                            className="btn btn-success"
                                            onClick={() => handleBulkUserStatusUpdate(true)}
                                        >
                                            Enable Selected
                                        </button>
                                        <button
                                            className="btn btn-warning"
                                            onClick={() => handleBulkUserStatusUpdate(false)}
                                        >
                                            Disable Selected
                                        </button>
                                        <button
                                            className="btn btn-secondary"
                                            onClick={handleBulkUserPasswordReset}
                                        >
                                            Reset Passwords
                                        </button>
                                        <button
                                            className="btn btn-danger"
                                            onClick={handleBulkUserDelete}
                                        >
                                            Delete Selected
                                        </button>
                                    </div>
                                </div>
                            </div>
                        )}

                        <div className="section card">
                            <div className="table-container">
                                <table className="data-table">
                                    <thead>
                                        <tr>
                                            <th>
                                                <input
                                                    type="checkbox"
                                                    checked={selectedUsers.length === users.length && users.length > 0}
                                                    onChange={(e) => {
                                                        if (e.target.checked) {
                                                            setSelectedUsers(users.map(u => u.id));
                                                        } else {
                                                            setSelectedUsers([]);
                                                        }
                                                    }}
                                                />
                                            </th>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Role</th>
                                            <th>Joined</th>
                                            <th>Status</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {(() => {
                                            const filteredUsers = filterUsers(users);
                                            return filteredUsers.length > 0 ? (
                                                filteredUsers.map(user => (
                                                    <tr key={user.id}>
                                                        <td>
                                                            <input
                                                                type="checkbox"
                                                                checked={selectedUsers.includes(user.id)}
                                                                onChange={(e) => {
                                                                    if (e.target.checked) {
                                                                        setSelectedUsers([...selectedUsers, user.id]);
                                                                    } else {
                                                                        setSelectedUsers(selectedUsers.filter(id => id !== user.id));
                                                                    }
                                                                }}
                                                            />
                                                        </td>
                                                        <td>{user.firstName} {user.lastName}</td>
                                                        <td>{user.email}</td>
                                                        <td><span className={`role-badge ${user.role}`}>{user.role}</span></td>
                                                        <td>{new Date(user.createdAt).toLocaleDateString()}</td>
                                                        <td><span className={`status-badge ${user.isActive ? 'active' : 'inactive'}`}>{user.isActive ? 'Active' : 'Inactive'}</span></td>
                                                        <td>
                                                            <div className="action-buttons">
                                                                <button
                                                                    className="btn btn-ghost btn-sm"
                                                                    onClick={() => openEditModal(user)}
                                                                    title="Edit user"
                                                                >
                                                                    <Edit size={14} />
                                                                </button>
                                                                <button
                                                                    className="btn btn-ghost btn-sm btn-warning"
                                                                    onClick={() => handleResetPassword(user)}
                                                                    title="Reset Password"
                                                                >
                                                                    <Settings size={14} />
                                                                </button>
                                                                {user.isActive ? (
                                                                    <button
                                                                        className="btn btn-ghost btn-sm btn-danger"
                                                                        onClick={() => handleToggleUserStatus(user)}
                                                                        title="Disable user (e.g., non-payment)"
                                                                    >
                                                                        <Ban size={14} />
                                                                    </button>
                                                                ) : (
                                                                    <button
                                                                        className="btn btn-ghost btn-sm btn-success"
                                                                        onClick={() => handleToggleUserStatus(user)}
                                                                        title="Enable user"
                                                                    >
                                                                        <CheckCircle2 size={14} />
                                                                    </button>
                                                                )}
                                                            </div>
                                                        </td>
                                                    </tr>
                                                ))
                                            ) : (
                                                <EmptyTable
                                                    colSpan={7}
                                                    icon="users"
                                                    title={userSearch || userFilters.role || userFilters.status ? "No users found" : "No users yet"}
                                                    description={userSearch || userFilters.role || userFilters.status ? "No users match your current filters." : "Start by adding providers or beauticians to your platform."}
                                                />
                                            );
                                        })()}
                                    </tbody>
                                </table>
                            </div>
                            <Pagination
                                currentPage={userPagination.page}
                                totalPages={userPagination.pages}
                                totalItems={userPagination.total}
                                itemsPerPage={userPagination.limit}
                                onPageChange={(page) => fetchUsers(page)}
                            />
                        </div>
                    </div>
                )}

                {/* Providers Tab */}
                {activeTab === 'providers' && (
                    <div className="dashboard-content">
                        <div className="section-header">
                            <h2>All Providers</h2>
                        </div>
                        <div className="section card">
                            <div className="filter-section">
                                <div className="form-row">
                                    <div className="form-group">
                                        <label>Search</label>
                                        <input
                                            type="text"
                                            className="input"
                                            placeholder="Search by business name"
                                            value={providerSearch}
                                            onChange={(e) => setProviderSearch(e.target.value)}
                                        />
                                    </div>
                                </div>
                                <div className="filter-actions">
                                    <button
                                        className="btn btn-secondary"
                                        onClick={() => {
                                            setProviderSearch('');
                                            fetchProviders(1);
                                        }}
                                    >
                                        Clear Search
                                    </button>
                                </div>
                            </div>
                            <div className="table-container">
                                <table className="data-table">
                                    <thead>
                                        <tr>
                                            <th>Name</th>
                                            <th>Business</th>
                                            <th>Services</th>
                                            <th>Rating</th>
                                            <th>Bookings</th>
                                            <th>Earnings</th>
                                            <th>Status</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {providers.filter(p => p.userId?.role !== 'beautician').map(provider => (
                                            <tr key={provider.id}>
                                                <td>{provider.userId?.firstName} {provider.userId?.lastName}</td>
                                                <td>{provider.businessName}</td>
                                                <td>{(Array.isArray(provider.services) ? provider.services : JSON.parse(provider.services || '[]')).length} services</td>
                                                <td>{(typeof provider.rating === 'object' ? provider.rating.average : JSON.parse(provider.rating || '{}').average) || 0} ⭐</td>
                                                <td>{provider.stats?.totalBookings || 0}</td>
                                                <td>KES {provider.stats?.totalEarnings || 0}</td>
                                                <td><span className={`status-badge ${provider.userId?.isActive ? 'active' : 'inactive'}`}>{provider.userId?.isActive ? 'Active' : 'Inactive'}</span></td>
                                                <td>
                                                    <div className="action-buttons">
                                                        <button className="btn btn-ghost btn-sm"><Eye size={14} /></button>
                                                    </div>
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                            <Pagination
                                currentPage={providerPagination.page}
                                totalPages={providerPagination.pages}
                                totalItems={providerPagination.total}
                                itemsPerPage={providerPagination.limit}
                                onPageChange={(page) => activeTab === 'beauticians' ? fetchBeauticians(page) : fetchProviders(page)}
                            />
                        </div>
                    </div>
                )}

                {/* Beauticians Tab */}
                {activeTab === 'beauticians' && (
                    <div className="dashboard-content">
                        <div className="section-header">
                            <h2>All Beauticians</h2>
                        </div>
                        <div className="section card">
                            <div className="table-container">
                                <table className="data-table">
                                    <thead>
                                        <tr>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Role</th>
                                            <th>Joined</th>
                                            <th>Status</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {beauticians.map(user => (
                                            <tr key={user.id}>
                                                <td>{user.firstName} {user.lastName}</td>
                                                <td>{user.email}</td>
                                                <td><span className={`role-badge ${user.role}`}>{user.role}</span></td>
                                                <td>{new Date(user.createdAt).toLocaleDateString()}</td>
                                                <td><span className={`status-badge ${user.isActive ? 'active' : 'inactive'}`}>{user.isActive ? 'Active' : 'Inactive'}</span></td>
                                                <td>
                                                    <div className="action-buttons">
                                                        <button className="btn btn-ghost btn-sm"><Eye size={14} /></button>
                                                    </div>
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                )}

                {/* Bookings Tab */}
                {activeTab === 'bookings' && (
                    <div className="dashboard-content">
                        <div className="section-header">
                            <h2>All Bookings</h2>
                        </div>
                        <div className="section card">
                            <div className="filter-section">
                                <div className="form-row">
                                    <div className="form-group">
                                        <label>Search</label>
                                        <input
                                            type="text"
                                            className="input"
                                            placeholder="Search by service name"
                                            value={bookingSearch}
                                            onChange={(e) => setBookingSearch(e.target.value)}
                                        />
                                    </div>
                                </div>
                                <div className="filter-actions">
                                    <button
                                        className="btn btn-secondary"
                                        onClick={() => {
                                            setBookingSearch('');
                                            fetchBookings(1);
                                        }}
                                    >
                                        Clear Search
                                    </button>
                                </div>
                            </div>
                            <div className="table-container">
                                <table className="data-table">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Client</th>
                                            <th>Provider</th>
                                            <th>Assigned To</th>
                                            <th>Service</th>
                                            <th>Date</th>
                                            <th>Amount</th>
                                            <th>Status</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {bookings.map(booking => (
                                            <tr key={booking.id || booking._id}>
                                                <td>#{String(booking.id || booking._id).substring(0, 6)}</td>
                                                <td>{booking.client?.firstName} {booking.client?.lastName}</td>
                                                <td>{booking.provider?.businessName || booking.provider?.user?.firstName}</td>
                                                <td>
                                                    {booking.beautician ? (
                                                        <span className="flex items-center gap-1">
                                                            <Sparkles size={14} className="text-purple-500" />
                                                            {booking.beautician.firstName} {booking.beautician.lastName}
                                                        </span>
                                                    ) : (
                                                        <span className="text-gray-400">-</span>
                                                    )}
                                                </td>
                                                <td>{booking.serviceName || booking.service}</td>
                                                <td>{new Date(booking.scheduledDate || booking.date).toLocaleDateString()}</td>
                                                <td>KES {booking.totalAmount || booking.amount}</td>
                                                <td><span className={`status-badge ${booking.status}`}>{booking.status}</span></td>
                                                <td>
                                                    <div className="action-buttons">
                                                        <button className="btn btn-ghost btn-sm"><Eye size={14} /></button>
                                                    </div>
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                            <Pagination
                                currentPage={bookingPagination.page}
                                totalPages={bookingPagination.pages}
                                totalItems={bookingPagination.total}
                                itemsPerPage={bookingPagination.limit}
                                onPageChange={(page) => fetchBookings(page)}
                            />
                        </div>
                    </div>
                )}

                {/* Revenue Tab */}
                {activeTab === 'revenue' && (
                    <div className="dashboard-content">
                        <div className="stats-grid" style={{ gridTemplateColumns: 'repeat(3, 1fr)' }}>
                            <div className="stat-card card">
                                <div className="stat-info">
                                    <p className="stat-label">Total Revenue</p>
                                    <h3 className="stat-value">KES {(stats?.totalRevenue || 0).toLocaleString()}</h3>
                                    <p className="stat-change positive">All time</p>
                                </div>
                            </div>
                            <div className="stat-card card">
                                <div className="stat-info">
                                    <p className="stat-label">Platform Fee (10%)</p>
                                    <h3 className="stat-value">KES {(stats?.platformFee || 0).toLocaleString()}</h3>
                                    <p className="stat-change positive">All time</p>
                                </div>
                            </div>
                            <div className="stat-card card">
                                <div className="stat-info">
                                    <p className="stat-label">This Month</p>
                                    <h3 className="stat-value">KES {(revenue[0]?.platformFee || 0).toLocaleString()}</h3>
                                    <p className="stat-change positive">+18% from last month</p>
                                </div>
                            </div>
                        </div>
                        <div className="section card">
                            <h2>Monthly Revenue</h2>
                            <div className="table-container">
                                <table className="data-table">
                                    <thead>
                                        <tr>
                                            <th>Month</th>
                                            <th>Bookings</th>
                                            <th>Total Revenue</th>
                                            <th>Platform Fee (10%)</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {revenue.map((item, index) => (
                                            <tr key={index}>
                                                <td>{item.month}</td>
                                                <td>{item.bookings.toLocaleString()}</td>
                                                <td>KES {item.revenue.toLocaleString()}</td>
                                                <td>KES {item.platformFee.toLocaleString()}</td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                )}

                {/* Disputes Tab */}
                {activeTab === 'disputes' && (
                    <div className="dashboard-content">
                        <div className="section-header">
                            <h2>Disputes</h2>
                        </div>
                        <div className="section card">
                            <div className="filter-section">
                                <div className="form-row">
                                    <div className="form-group">
                                        <label>Search</label>
                                        <input
                                            type="text"
                                            className="input"
                                            placeholder="Search by reason or description"
                                            value={disputeSearch}
                                            onChange={(e) => setDisputeSearch(e.target.value)}
                                        />
                                    </div>
                                </div>
                                <div className="filter-actions">
                                    <button
                                        className="btn btn-secondary"
                                        onClick={() => {
                                            setDisputeSearch('');
                                            fetchDisputes(1);
                                        }}
                                    >
                                        Clear Search
                                    </button>
                                </div>
                            </div>
                            <div className="table-container">
                                <table className="data-table">
                                    <thead>
                                        <tr>
                                            <th>Booking ID</th>
                                            <th>Client</th>
                                            <th>Provider</th>
                                            <th>Reason</th>
                                            <th>Date</th>
                                            <th>Status</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {disputes.map(dispute => (
                                            <tr key={dispute._id}>
                                                <td>{dispute.bookingId}</td>
                                                <td>{dispute.reportedBy?.firstName}</td>
                                                <td>{dispute.reportedAgainst?.firstName}</td>
                                                <td>{dispute.reason}</td>
                                                <td>{new Date(dispute.createdAt).toLocaleDateString()}</td>
                                                <td><span className={`status-badge ${dispute.status}`}>{dispute.status}</span></td>
                                                <td>
                                                    <div className="action-buttons">
                                                        <button className="btn btn-ghost btn-sm"><Eye size={14} /></button>
                                                        {dispute.status === 'pending' && (
                                                            <button className="btn btn-primary btn-sm" onClick={() => handleResolveDispute(dispute._id, 'refund')}>Resolve</button>
                                                        )}
                                                    </div>
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                            <Pagination
                                currentPage={disputePagination.page}
                                totalPages={disputePagination.pages}
                                totalItems={disputePagination.total}
                                itemsPerPage={disputePagination.limit}
                                onPageChange={(page) => fetchDisputes(page)}
                            />
                        </div>
                    </div>
                )}

                {/* Add User Modal */}
                {showAddUserModal && (
                    <div className="modal-overlay" onClick={() => setShowAddUserModal(false)}>
                        <div className="modal-content" onClick={(e) => e.stopPropagation()}>
                            <div className="modal-header">
                                <h2>Add New User</h2>
                                <button className="btn btn-ghost" onClick={() => setShowAddUserModal(false)}>×</button>
                            </div>
                            <form onSubmit={handleAddUser} className="modal-form">
                                <div className="form-row">
                                    <div className="form-group">
                                        <label>First Name *</label>
                                        <input
                                            type="text"
                                            className="input"
                                            value={newUser.firstName}
                                            onChange={(e) => setNewUser({ ...newUser, firstName: e.target.value })}
                                            required
                                        />
                                    </div>
                                    <div className="form-group">
                                        <label>Last Name *</label>
                                        <input
                                            type="text"
                                            className="input"
                                            value={newUser.lastName}
                                            onChange={(e) => setNewUser({ ...newUser, lastName: e.target.value })}
                                            required
                                        />
                                    </div>
                                </div>
                                <div className="form-group">
                                    <label>Email *</label>
                                    <input
                                        type="email"
                                        className="input"
                                        value={newUser.email}
                                        onChange={(e) => setNewUser({ ...newUser, email: e.target.value })}
                                        required
                                    />
                                </div>
                                <div className="form-group">
                                    <label>Phone *</label>
                                    <input
                                        type="tel"
                                        className="input"
                                        value={newUser.phone}
                                        onChange={(e) => setNewUser({ ...newUser, phone: e.target.value })}
                                        required
                                    />
                                </div>
                                <div className="form-group">
                                    <label>Password *</label>
                                    <input
                                        type="password"
                                        className="input"
                                        value={newUser.password}
                                        onChange={(e) => setNewUser({ ...newUser, password: e.target.value })}
                                        required
                                        minLength="6"
                                    />
                                </div>
                                <div className="form-group">
                                    <label>User Type *</label>
                                    <select
                                        className="input"
                                        value={newUser.role}
                                        onChange={(e) => setNewUser({ ...newUser, role: e.target.value })}
                                        required
                                    >
                                        <option value="provider">Provider</option>
                                        <option value="beautician">Beautician</option>
                                    </select>
                                </div>
                                {(newUser.role === 'provider' || newUser.role === 'beautician') && (
                                    <>
                                        <div className="form-group">
                                            <label>Business Name</label>
                                            <input
                                                type="text"
                                                className="input"
                                                value={newUser.businessName || ''}
                                                onChange={(e) => setNewUser({ ...newUser, businessName: e.target.value })}
                                                placeholder="Enter business name"
                                            />
                                        </div>
                                        <div className="form-group">
                                            <label>Service Type</label>
                                            <select
                                                className="input"
                                                value={newUser.serviceType || (newUser.role === 'beautician' ? 'mobile' : 'studio')}
                                                onChange={(e) => setNewUser({ ...newUser, serviceType: e.target.value })}
                                            >
                                                <option value="mobile">Mobile Service</option>
                                                <option value="studio">Studio Service</option>
                                                <option value="both">Both</option>
                                            </select>
                                        </div>
                                    </>
                                )}
                                <div className="modal-actions">
                                    <button type="button" className="btn btn-ghost" onClick={() => setShowAddUserModal(false)}>Cancel</button>
                                    <button type="submit" className="btn btn-primary">Create User</button>
                                </div>
                            </form>
                        </div>
                    </div>
                )}

                {/* Edit User Modal */}
                {showEditUserModal && (
                    <div className="modal-overlay" onClick={() => setShowEditUserModal(false)}>
                        <div className="modal-content" onClick={(e) => e.stopPropagation()}>
                            <div className="modal-header">
                                <h2>Edit User</h2>
                                <button className="btn btn-ghost" onClick={() => setShowEditUserModal(false)}>×</button>
                            </div>
                            <form onSubmit={handleEditUser} className="modal-form">
                                <div className="form-row">
                                    <div className="form-group">
                                        <label>First Name *</label>
                                        <input
                                            type="text"
                                            className="input"
                                            value={editUser.firstName}
                                            onChange={(e) => setEditUser({ ...editUser, firstName: e.target.value })}
                                            required
                                        />
                                    </div>
                                    <div className="form-group">
                                        <label>Last Name *</label>
                                        <input
                                            type="text"
                                            className="input"
                                            value={editUser.lastName}
                                            onChange={(e) => setEditUser({ ...editUser, lastName: e.target.value })}
                                            required
                                        />
                                    </div>
                                </div>
                                <div className="form-group">
                                    <label>Phone *</label>
                                    <input
                                        type="tel"
                                        className="input"
                                        value={editUser.phone}
                                        onChange={(e) => setEditUser({ ...editUser, phone: e.target.value })}
                                        required
                                    />
                                </div>
                                <div className="form-group">
                                    <label>User Type *</label>
                                    <select
                                        className="input"
                                        value={editUser.role}
                                        onChange={(e) => setEditUser({ ...editUser, role: e.target.value })}
                                        required
                                    >
                                        <option value="provider">Provider</option>
                                        <option value="beautician">Beautician</option>
                                    </select>
                                </div>
                                <div className="form-group">
                                    <label>Account Status</label>
                                    <select
                                        className="input"
                                        value={editUser.isActive ? 'active' : 'inactive'}
                                        onChange={(e) => setEditUser({ ...editUser, isActive: e.target.value === 'active' })}
                                    >
                                        <option value="active">Active</option>
                                        <option value="inactive">Disabled</option>
                                    </select>
                                    <small style={{ color: '#6b7280', marginTop: '0.5rem', display: 'block' }}>
                                        Disabled users cannot access the platform (e.g., for subscription non-payment)
                                    </small>
                                </div>
                                <div className="modal-actions">
                                    <button type="button" className="btn btn-ghost" onClick={() => setShowEditUserModal(false)}>Cancel</button>
                                    <button type="submit" className="btn btn-primary">Update User</button>
                                </div>
                            </form>
                        </div>
                    </div>
                )}

                {/* Settings Tab */}
                {activeTab === 'settings' && (
                    <div className="dashboard-content">
                        <div className="section-header">
                            <h2>Platform Settings</h2>
                            <button className="btn btn-primary">Save Changes</button>
                        </div>

                        <div className="settings-grid">
                            {/* General Settings */}
                            <div className="section card">
                                <h3>General Settings</h3>
                                <div className="settings-form">
                                    <div className="form-group">
                                        <label>Platform Name</label>
                                        <input type="text" className="input" defaultValue="ZOO Beauty Palace" />
                                    </div>
                                    <div className="form-group">
                                        <label>Support Email</label>
                                        <input type="email" className="input" defaultValue="support@zoobeauty.com" />
                                    </div>
                                    <div className="form-group">
                                        <label>Contact Phone</label>
                                        <input type="tel" className="input" defaultValue="+254 700 000 000" />
                                    </div>
                                    <div className="form-group">
                                        <label>Platform URL</label>
                                        <input type="url" className="input" defaultValue="https://zoobeauty.com" />
                                    </div>
                                </div>
                            </div>

                            {/* Financial Settings */}
                            <div className="section card">
                                <h3>Financial Settings</h3>
                                <div className="settings-form">
                                    <div className="form-group">
                                        <label>Platform Fee (%)</label>
                                        <input type="number" className="input" defaultValue="10" min="0" max="100" step="0.1" />
                                        <small className="form-help">Commission percentage charged on bookings</small>
                                    </div>
                                    <div className="form-group">
                                        <label>Currency</label>
                                        <select className="input" defaultValue="KES">
                                            <option value="KES">Kenyan Shilling (KES)</option>
                                            <option value="USD">US Dollar (USD)</option>
                                            <option value="EUR">Euro (EUR)</option>
                                        </select>
                                    </div>
                                    <div className="form-group">
                                        <label>Minimum Withdrawal Amount</label>
                                        <input type="number" className="input" defaultValue="1000" min="0" />
                                        <small className="form-help">Minimum amount providers can withdraw</small>
                                    </div>
                                    <div className="form-group">
                                        <label>Withdrawal Processing Time</label>
                                        <select className="input" defaultValue="3">
                                            <option value="1">1 Business Day</option>
                                            <option value="3">3 Business Days</option>
                                            <option value="5">5 Business Days</option>
                                            <option value="7">7 Business Days</option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            {/* Booking Settings */}
                            <div className="section card">
                                <h3>Booking Settings</h3>
                                <div className="settings-form">
                                    <div className="form-group">
                                        <label>Booking Cancellation Window</label>
                                        <select className="input" defaultValue="24">
                                            <option value="1">1 Hour</option>
                                            <option value="2">2 Hours</option>
                                            <option value="6">6 Hours</option>
                                            <option value="12">12 Hours</option>
                                            <option value="24">24 Hours</option>
                                            <option value="48">48 Hours</option>
                                        </select>
                                        <small className="form-help">Time window for free cancellations</small>
                                    </div>
                                    <div className="form-group">
                                        <label>Auto-Accept Bookings</label>
                                        <div className="toggle-switch">
                                            <input type="checkbox" id="auto-accept" />
                                            <label htmlFor="auto-accept"></label>
                                        </div>
                                        <small className="form-help">Automatically accept all bookings</small>
                                    </div>
                                    <div className="form-group">
                                        <label>Booking Confirmation Required</label>
                                        <div className="toggle-switch">
                                            <input type="checkbox" id="confirmation-required" defaultChecked />
                                            <label htmlFor="confirmation-required"></label>
                                        </div>
                                        <small className="form-help">Require client confirmation for bookings</small>
                                    </div>
                                </div>
                            </div>

                            {/* System Settings */}
                            <div className="section card">
                                <h3>System Settings</h3>
                                <div className="settings-form">
                                    <div className="form-group">
                                        <label>Maintenance Mode</label>
                                        <div className="toggle-switch">
                                            <input type="checkbox" id="maintenance" />
                                            <label htmlFor="maintenance"></label>
                                        </div>
                                        <small className="form-help">Temporarily disable platform access</small>
                                    </div>
                                    <div className="form-group">
                                        <label>User Registration</label>
                                        <div className="toggle-switch">
                                            <input type="checkbox" id="registration" defaultChecked />
                                            <label htmlFor="registration"></label>
                                        </div>
                                        <small className="form-help">Allow new user registrations</small>
                                    </div>
                                    <div className="form-group">
                                        <label>Email Notifications</label>
                                        <div className="toggle-switch">
                                            <input type="checkbox" id="email-notifications" defaultChecked />
                                            <label htmlFor="email-notifications"></label>
                                        </div>
                                        <small className="form-help">Send email notifications for platform events</small>
                                    </div>
                                    <div className="form-group">
                                        <label>SMS Notifications</label>
                                        <div className="toggle-switch">
                                            <input type="checkbox" id="sms-notifications" />
                                            <label htmlFor="sms-notifications"></label>
                                        </div>
                                        <small className="form-help">Send SMS notifications for critical events</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                )}

                {/* Analytics Tab */}
                {activeTab === 'analytics' && (
                    <div className="dashboard-content">
                        <div className="section-header">
                            <h2>Analytics & Reports</h2>
                            <div className="filter-buttons">
                                <button className="btn btn-secondary" onClick={() => exportAnalyticsReport('csv')}>
                                    <Download size={16} /> Export CSV
                                </button>
                                <button className="btn btn-secondary" onClick={() => exportAnalyticsReport('json')}>
                                    <Download size={16} /> Export JSON
                                </button>
                            </div>
                        </div>

                        {/* Analytics Filters */}
                        <div className="section card">
                            <div className="filter-section">
                                <div className="form-row">
                                    <div className="form-group">
                                        <label>Start Date</label>
                                        <input
                                            type="date"
                                            className="input"
                                            value={analyticsFilters.startDate}
                                            onChange={(e) => setAnalyticsFilters({ ...analyticsFilters, startDate: e.target.value })}
                                        />
                                    </div>
                                    <div className="form-group">
                                        <label>End Date</label>
                                        <input
                                            type="date"
                                            className="input"
                                            value={analyticsFilters.endDate}
                                            onChange={(e) => setAnalyticsFilters({ ...analyticsFilters, endDate: e.target.value })}
                                        />
                                    </div>
                                </div>
                                <div className="filter-actions">
                                    <button
                                        className="btn btn-secondary"
                                        onClick={() => {
                                            setAnalyticsFilters({
                                                startDate: '',
                                                endDate: ''
                                            });
                                            fetchDetailedAnalytics();
                                        }}
                                    >
                                        Clear Filters
                                    </button>
                                    <button
                                        className="btn btn-primary"
                                        onClick={() => fetchDetailedAnalytics(analyticsFilters)}
                                    >
                                        Apply Filters
                                    </button>
                                </div>
                            </div>
                        </div>

                        {/* Summary Stats */}
                        <div className="stats-grid" style={{ gridTemplateColumns: 'repeat(5, 1fr)' }}>
                            <div className="stat-card card">
                                <div className="stat-info">
                                    <p className="stat-label">Total Revenue</p>
                                    <h3 className="stat-value">KES {(analyticsData.summary.totalRevenue || 0).toLocaleString()}</h3>
                                </div>
                            </div>
                            <div className="stat-card card">
                                <div className="stat-info">
                                    <p className="stat-label">Platform Fees</p>
                                    <h3 className="stat-value">KES {(analyticsData.summary.platformFees || 0).toLocaleString()}</h3>
                                </div>
                            </div>
                            <div className="stat-card card">
                                <div className="stat-info">
                                    <p className="stat-label">New Users</p>
                                    <h3 className="stat-value">{(analyticsData.summary.newUserRegistrations || 0).toLocaleString()}</h3>
                                </div>
                            </div>
                            <div className="stat-card card">
                                <div className="stat-info">
                                    <p className="stat-label">New Providers</p>
                                    <h3 className="stat-value">{(analyticsData.summary.newProviders || 0).toLocaleString()}</h3>
                                </div>
                            </div>
                            <div className="stat-card card">
                                <div className="stat-info">
                                    <p className="stat-label">Total Bookings</p>
                                    <h3 className="stat-value">{(analyticsData.summary.totalBookings || 0).toLocaleString()}</h3>
                                </div>
                            </div>
                        </div>

                        {/* User Statistics */}
                        <div className="section card">
                            <h2>User Statistics</h2>
                            <div className="table-container">
                                <table className="data-table">
                                    <thead>
                                        <tr>
                                            <th>User Role</th>
                                            <th>Count</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {analyticsData.userStats.map((stat, index) => (
                                            <tr key={index}>
                                                <td>{stat.role}</td>
                                                <td>{stat.count}</td>
                                            </tr>
                                        ))}
                                        {analyticsData.userStats.length === 0 && (
                                            <tr>
                                                <td colSpan="2" className="text-center">No user statistics available</td>
                                            </tr>
                                        )}
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        {/* Booking Statistics */}
                        <div className="section card">
                            <h2>Booking Statistics</h2>
                            <div className="table-container">
                                <table className="data-table">
                                    <thead>
                                        <tr>
                                            <th>Booking Status</th>
                                            <th>Count</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {analyticsData.bookingStats.map((stat, index) => (
                                            <tr key={index}>
                                                <td>{stat.status}</td>
                                                <td>{stat.count}</td>
                                            </tr>
                                        ))}
                                        {analyticsData.bookingStats.length === 0 && (
                                            <tr>
                                                <td colSpan="2" className="text-center">No booking statistics available</td>
                                            </tr>
                                        )}
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        {/* Daily Metrics */}
                        <div className="section card">
                            <h2>Daily Metrics</h2>
                            <div className="table-container">
                                <table className="data-table">
                                    <thead>
                                        <tr>
                                            <th>Date</th>
                                            <th>New Users</th>
                                            <th>New Providers</th>
                                            <th>New Clients</th>
                                            <th>Total Bookings</th>
                                            <th>Completed</th>
                                            <th>Cancelled</th>
                                            <th>Revenue</th>
                                            <th>Platform Fees</th>
                                            <th>Active Subscriptions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {analyticsData.dailyMetrics.map((metric, index) => (
                                            <tr key={index}>
                                                <td>{metric.date}</td>
                                                <td>{metric.newUsers || 0}</td>
                                                <td>{metric.newProviders || 0}</td>
                                                <td>{metric.newClients || 0}</td>
                                                <td>{metric.totalBookings || 0}</td>
                                                <td>{metric.completedBookings || 0}</td>
                                                <td>{metric.cancelledBookings || 0}</td>
                                                <td>KES {(metric.revenue || 0).toLocaleString()}</td>
                                                <td>KES {(metric.platformFees || 0).toLocaleString()}</td>
                                                <td>{metric.activeSubscriptions || 0}</td>
                                            </tr>
                                        ))}
                                        {analyticsData.dailyMetrics.length === 0 && (
                                            <tr>
                                                <td colSpan="10" className="text-center">No daily metrics available</td>
                                            </tr>
                                        )}
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        {/* Charts */}
                        <div className="analytics-charts">
                            <BarChart
                                data={analyticsData.dailyMetrics.map(metric => ({
                                    date: metric.date,
                                    revenue: metric.revenue || 0
                                }))}
                                dataKey="revenue"
                                xAxisKey="date"
                                title="Daily Revenue"
                                color="#10b981"
                            />

                            <LineChart
                                data={analyticsData.dailyMetrics.map(metric => ({
                                    date: metric.date,
                                    bookings: metric.totalBookings || 0,
                                    completed: metric.completedBookings || 0,
                                    cancelled: metric.cancelledBookings || 0
                                }))}
                                dataKeys={["bookings", "completed", "cancelled"]}
                                xAxisKey="date"
                                title="Booking Trends"
                            />

                            <PieChart
                                data={analyticsData.userStats.map(stat => ({
                                    name: stat.role,
                                    value: stat.count
                                }))}
                                dataKey="value"
                                nameKey="name"
                                title="User Distribution by Role"
                            />
                        </div>
                    </div>
                )}

                {/* Notifications Tab */}
                {activeTab === 'notifications' && (
                    <div className="dashboard-content">
                        <div className="section-header">
                            <h2>Notifications</h2>
                            <div className="filter-buttons">
                                <button className="btn btn-secondary" onClick={markAllAsRead}>
                                    Mark All as Read
                                </button>
                            </div>
                        </div>
                        <div className="section card">
                            <div className="table-container">
                                <table className="data-table">
                                    <thead>
                                        <tr>
                                            <th>Type</th>
                                            <th>Title</th>
                                            <th>Message</th>
                                            <th>Date</th>
                                            <th>Status</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {notifications.map(notification => (
                                            <tr key={notification.id} className={!notification.isRead ? 'unread' : ''}>
                                                <td>
                                                    <span className={`notification-type ${notification.type}`}>
                                                        {notification.type}
                                                    </span>
                                                </td>
                                                <td>{notification.title}</td>
                                                <td>{notification.message}</td>
                                                <td>{new Date(notification.createdAt).toLocaleString()}</td>
                                                <td>
                                                    <span className={`status-badge ${notification.isRead ? 'success' : 'warning'}`}>
                                                        {notification.isRead ? 'Read' : 'Unread'}
                                                    </span>
                                                </td>
                                                <td>
                                                    <div className="action-buttons">
                                                        {!notification.isRead && (
                                                            <button
                                                                className="btn btn-ghost btn-sm"
                                                                onClick={() => markAsRead(notification.id)}
                                                                title="Mark as read"
                                                            >
                                                                <CheckCircle size={14} />
                                                            </button>
                                                        )}
                                                        {notification.actionUrl && (
                                                            <button
                                                                className="btn btn-ghost btn-sm"
                                                                onClick={() => window.location.href = notification.actionUrl}
                                                                title="Go to action"
                                                            >
                                                                <Eye size={14} />
                                                            </button>
                                                        )}
                                                        <button
                                                            className="btn btn-ghost btn-sm btn-danger"
                                                            onClick={() => {
                                                                // TODO: Implement delete notification
                                                                console.log('Delete notification', notification.id);
                                                            }}
                                                            title="Delete notification"
                                                        >
                                                            <Trash2 size={14} />
                                                        </button>
                                                    </div>
                                                </td>
                                            </tr>
                                        ))}
                                        {notifications.length === 0 && (
                                            <tr>
                                                <td colSpan="6" className="text-center">No notifications found</td>
                                            </tr>
                                        )}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                )}

                {/* Assign Task Modal */}
                {showAssignTaskModal && (
                    <div className="modal-overlay" onClick={() => setShowAssignTaskModal(false)}>
                        <div className="modal-content" onClick={e => e.stopPropagation()}>
                            <div className="modal-header">
                                <h3>Assign Task</h3>
                                <button className="modal-close" onClick={() => setShowAssignTaskModal(false)}>×</button>
                            </div>
                            <form onSubmit={handleAssignTask}>
                                <div className="form-group">
                                    <label>Title *</label>
                                    <input
                                        type="text"
                                        className="input"
                                        value={assignmentData.title}
                                        onChange={(e) => setAssignmentData({ ...assignmentData, title: e.target.value })}
                                        required
                                    />
                                </div>
                                <div className="form-group">
                                    <label>Description</label>
                                    <textarea
                                        className="input"
                                        rows="3"
                                        value={assignmentData.description}
                                        onChange={(e) => setAssignmentData({ ...assignmentData, description: e.target.value })}
                                    ></textarea>
                                </div>
                                <div className="form-row">
                                    <div className="form-group">
                                        <label>Assign To (Beautician) *</label>
                                        <select
                                            className="input"
                                            value={assignmentData.assignedToId}
                                            onChange={(e) => setAssignmentData({ ...assignmentData, assignedToId: e.target.value })}
                                            required
                                        >
                                            <option value="">Select Beautician</option>
                                            {users.filter(user => user.role === 'beautician').map(user => (
                                                <option key={user.id} value={user.id}>
                                                    {user.firstName} {user.lastName}
                                                </option>
                                            ))}
                                        </select>
                                    </div>
                                    <div className="form-group">
                                        <label>Provider</label>
                                        <select
                                            className="input"
                                            value={assignmentData.providerId}
                                            onChange={(e) => setAssignmentData({ ...assignmentData, providerId: e.target.value })}
                                        >
                                            <option value="">Select Provider</option>
                                            {providers.map(provider => (
                                                <option key={provider.id} value={provider.id}>
                                                    {provider.businessName}
                                                </option>
                                            ))}
                                        </select>
                                    </div>
                                </div>
                                <div className="form-row">
                                    <div className="form-group">
                                        <label>Priority</label>
                                        <select
                                            className="input"
                                            value={assignmentData.priority}
                                            onChange={(e) => setAssignmentData({ ...assignmentData, priority: e.target.value })}
                                        >
                                            <option value="low">Low</option>
                                            <option value="medium">Medium</option>
                                            <option value="high">High</option>
                                            <option value="urgent">Urgent</option>
                                        </select>
                                    </div>
                                    <div className="form-group">
                                        <label>Due Date</label>
                                        <input
                                            type="date"
                                            className="input"
                                            value={assignmentData.dueDate}
                                            onChange={(e) => setAssignmentData({ ...assignmentData, dueDate: e.target.value })}
                                        />
                                    </div>
                                </div>
                                <div className="modal-actions">
                                    <button type="button" className="btn btn-ghost" onClick={() => setShowAssignTaskModal(false)}>Cancel</button>
                                    <button type="submit" className="btn btn-primary">Assign Task</button>
                                </div>
                            </form>
                        </div>
                    </div>
                )}

                {/* Assignments Tab */}
                {activeTab === 'assignments' && (
                    <div className="dashboard-content">
                        <div className="section-header">
                            <h2>Task Assignments</h2>
                            <div className="filter-buttons">
                                <button className="btn btn-primary" onClick={() => setShowAssignTaskModal(true)}>+ Assign Task</button>
                            </div>
                        </div>

                        {/* Filters */}
                        <div className="section card">
                            <div className="filter-section">
                                <div className="form-row">
                                    <div className="form-group">
                                        <label>Search</label>
                                        <input
                                            type="text"
                                            className="input"
                                            placeholder="Search by title or description"
                                            value={assignmentSearch}
                                            onChange={(e) => setAssignmentSearch(e.target.value)}
                                        />
                                    </div>
                                    <div className="form-group">
                                        <label>Status</label>
                                        <select
                                            className="input"
                                            value={assignmentFilters.status}
                                            onChange={(e) => setAssignmentFilters({ ...assignmentFilters, status: e.target.value })}
                                        >
                                            <option value="">All Statuses</option>
                                            <option value="pending">Pending</option>
                                            <option value="accepted">Accepted</option>
                                            <option value="in-progress">In Progress</option>
                                            <option value="completed">Completed</option>
                                            <option value="cancelled">Cancelled</option>
                                        </select>
                                    </div>
                                    <div className="form-group">
                                        <label>Priority</label>
                                        <select
                                            className="input"
                                            value={assignmentFilters.priority}
                                            onChange={(e) => setAssignmentFilters({ ...assignmentFilters, priority: e.target.value })}
                                        >
                                            <option value="">All Priorities</option>
                                            <option value="low">Low</option>
                                            <option value="medium">Medium</option>
                                            <option value="high">High</option>
                                            <option value="urgent">Urgent</option>
                                        </select>
                                    </div>
                                    <div className="form-group">
                                        <label>Assigned To</label>
                                        <select
                                            className="input"
                                            value={assignmentFilters.assignedToId}
                                            onChange={(e) => setAssignmentFilters({ ...assignmentFilters, assignedToId: e.target.value })}
                                        >
                                            <option value="">All Beauticians</option>
                                            {users.filter(user => user.role === 'beautician').map(user => (
                                                <option key={user.id} value={user.id}>
                                                    {user.firstName} {user.lastName}
                                                </option>
                                            ))}
                                        </select>
                                    </div>
                                    <div className="form-group">
                                        <label>Provider</label>
                                        <select
                                            className="input"
                                            value={assignmentFilters.providerId}
                                            onChange={(e) => setAssignmentFilters({ ...assignmentFilters, providerId: e.target.value })}
                                        >
                                            <option value="">All Providers</option>
                                            {providers.map(provider => (
                                                <option key={provider.id} value={provider.id}>
                                                    {provider.businessName}
                                                </option>
                                            ))}
                                        </select>
                                    </div>
                                </div>
                                <div className="filter-actions">
                                    <button
                                        className="btn btn-secondary"
                                        onClick={() => {
                                            setAssignmentFilters({
                                                status: '',
                                                priority: '',
                                                assignedToId: '',
                                                providerId: ''
                                            });
                                            setAssignmentSearch('');
                                            fetchAssignments({}, 1);
                                        }}
                                    >
                                        Clear Filters
                                    </button>
                                    <button
                                        className="btn btn-primary"
                                        onClick={() => fetchAssignments(assignmentFilters, 1)}
                                    >
                                        Apply Filters
                                    </button>
                                </div>
                            </div>
                        </div>

                        {/* Bulk Actions */}
                        {selectedAssignments.length > 0 && (
                            <div className="section card">
                                <div className="bulk-actions">
                                    <span>{selectedAssignments.length} assignments selected</span>
                                    <div className="bulk-action-buttons">
                                        <select
                                            className="input"
                                            onChange={(e) => {
                                                if (e.target.value) {
                                                    handleBulkStatusUpdate(e.target.value);
                                                    e.target.value = '';
                                                }
                                            }}
                                        >
                                            <option value="">Bulk Status Update</option>
                                            <option value="pending">Set to Pending</option>
                                            <option value="accepted">Set to Accepted</option>
                                            <option value="in-progress">Set to In Progress</option>
                                            <option value="completed">Set to Completed</option>
                                            <option value="cancelled">Set to Cancelled</option>
                                        </select>
                                        <button
                                            className="btn btn-danger"
                                            onClick={handleBulkDelete}
                                        >
                                            Delete Selected
                                        </button>
                                    </div>
                                </div>
                            </div>
                        )}

                        <div className="section card">
                            <div className="table-container">
                                <table className="data-table">
                                    <thead>
                                        <tr>
                                            <th>
                                                <input
                                                    type="checkbox"
                                                    checked={selectedAssignments.length === assignments.length && assignments.length > 0}
                                                    onChange={(e) => {
                                                        if (e.target.checked) {
                                                            setSelectedAssignments(assignments.map(a => a.id));
                                                        } else {
                                                            setSelectedAssignments([]);
                                                        }
                                                    }}
                                                />
                                            </th>
                                            <th>Task ID</th>
                                            <th>Title</th>
                                            <th>Assigned To</th>
                                            <th>Provider</th>
                                            <th>Status</th>
                                            <th>Priority</th>
                                            <th>Due Date</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {assignments.map(assignment => (
                                            <tr key={assignment.id}>
                                                <td>
                                                    <input
                                                        type="checkbox"
                                                        checked={selectedAssignments.includes(assignment.id)}
                                                        onChange={(e) => {
                                                            if (e.target.checked) {
                                                                setSelectedAssignments([...selectedAssignments, assignment.id]);
                                                            } else {
                                                                setSelectedAssignments(selectedAssignments.filter(id => id !== assignment.id));
                                                            }
                                                        }}
                                                    />
                                                </td>
                                                <td>{assignment.taskId}</td>
                                                <td>{assignment.title}</td>
                                                <td>{assignment.assignedTo?.firstName} {assignment.assignedTo?.lastName}</td>
                                                <td>{assignment.provider?.businessName}</td>
                                                <td><span className={`status-badge ${assignment.status}`}>{assignment.status}</span></td>
                                                <td><span className={`priority-badge ${assignment.priority}`}>{assignment.priority}</span></td>
                                                <td>{assignment.dueDate ? new Date(assignment.dueDate).toLocaleDateString() : 'N/A'}</td>
                                                <td>
                                                    <div className="action-buttons">
                                                        <button
                                                            className="btn btn-ghost btn-sm"
                                                            onClick={() => handleAssignmentStatusUpdate(assignment.id, 'completed')}
                                                            title="Mark as completed"
                                                        >
                                                            <CheckCircle size={14} />
                                                        </button>
                                                        <button
                                                            className="btn btn-ghost btn-sm btn-danger"
                                                            onClick={() => handleAssignmentDelete(assignment.id)}
                                                            title="Delete assignment"
                                                        >
                                                            <Trash2 size={14} />
                                                        </button>
                                                    </div>
                                                </td>
                                            </tr>
                                        ))}
                                        {assignments.length === 0 && (
                                            <tr>
                                                <td colSpan="9" className="text-center">No assignments found</td>
                                            </tr>
                                        )}
                                    </tbody>
                                </table>
                            </div>
                            <Pagination
                                currentPage={assignmentPagination.page}
                                totalPages={assignmentPagination.pages}
                                totalItems={assignmentPagination.total}
                                itemsPerPage={assignmentPagination.limit}
                                onPageChange={(page) => fetchAssignments(assignmentFilters, page)}
                            />
                        </div>
                    </div>
                )}

                {/* Activity Logs Tab */}
                {activeTab === 'activity' && (
                    <div className="dashboard-content">
                        <div className="section-header">
                            <h2>Activity Logs</h2>
                            <div className="filter-buttons">
                                <button className="btn btn-secondary" onClick={() => {
                                    // TODO: Implement export functionality
                                    console.log('Export activity logs');
                                }}>
                                    <Download size={16} /> Export CSV
                                </button>
                            </div>
                        </div>

                        <div className="section card">
                            <div className="table-container">
                                <table className="data-table">
                                    <thead>
                                        <tr>
                                            <th>Action</th>
                                            <th>User</th>
                                            <th>Entity</th>
                                            <th>Description</th>
                                            <th>Date</th>
                                            <th>IP Address</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td colSpan="6" className="text-center">Activity logs will appear here</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                )}
            </main>
        </div>
    );
};

export default AdminDashboard;
