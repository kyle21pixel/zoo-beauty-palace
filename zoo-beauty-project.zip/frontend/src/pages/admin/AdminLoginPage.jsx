import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { motion } from 'framer-motion';
import { Mail, Lock, Shield, Home, Moon, Sun, Sparkles } from 'lucide-react';
import '../AuthPages.css';
import './AdminLoginPage.css';

const AdminLoginPage = () => {
    const navigate = useNavigate();
    const [darkMode, setDarkMode] = useState(false);
    const [formData, setFormData] = useState({
        email: '',
        password: ''
    });
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');

    const { login } = useAuth();

    useEffect(() => {
        if (darkMode) {
            document.body.classList.add('dark-mode');
        } else {
            document.body.classList.remove('dark-mode');
        }
    }, [darkMode]);

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');
        setLoading(true);

        const result = await login(formData.email, formData.password);

        if (result.success) {
            const user = JSON.parse(localStorage.getItem('user'));
            if (user?.role === 'admin') {
                navigate('/admin/dashboard');
            } else {
                setError('Access denied. Admin credentials required.');
                localStorage.removeItem('token');
                localStorage.removeItem('user');
            }
        } else {
            setError(result.message || 'Invalid credentials. Please try again.');
        }
        setLoading(false);
    };

    return (
        <div className="auth-page admin-login-page">
            <div className="admin-login-background">
                <div className="admin-login-pattern"></div>
            </div>
            <div className="auth-container">
                <motion.div
                    className="auth-card card card-glass admin-login-card"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                >
                    <div className="auth-header admin-login-header">
                        <div className="admin-logo-section">
                            <div className="admin-icon-wrapper">
                                <Shield size={32} className="admin-icon" />
                                <Sparkles size={16} className="sparkle-icon" />
                            </div>
                            <Link to="/" className="logo">
                                <img src="/assets/logo.png" alt="ZOO beauty Palace" className="logo-image" />
                                <span className="logo-text">
                                    <span className="logo-top">ZOO</span>
                                    <span className="logo-bottom">beauty Palace</span>
                                </span>
                            </Link>
                        </div>
                        <div className="auth-controls">
                            <button
                                className="icon-btn"
                                onClick={() => setDarkMode(!darkMode)}
                                title={darkMode ? "Switch to Light Mode" : "Switch to Dark Mode"}
                            >
                                {darkMode ? <Sun size={20} /> : <Moon size={20} />}
                            </button>
                        </div>
                        <div className="admin-login-title">
                            <h1>Admin Portal</h1>
                            <p>Secure access to the administration dashboard</p>
                        </div>
                    </div>

                    {error && (
                        <motion.div
                            className="error-message"
                            initial={{ opacity: 0, y: -10 }}
                            animate={{ opacity: 1, y: 0 }}
                        >
                            <Shield size={18} />
                            {error}
                        </motion.div>
                    )}

                    <form onSubmit={handleSubmit} className="auth-form">
                        <div className="form-group">
                            <label htmlFor="admin-email">
                                <Mail size={18} />
                                Admin Email
                            </label>
                            <input
                                type="email"
                                id="admin-email"
                                className="input"
                                placeholder="admin@zoobeauty.com"
                                value={formData.email}
                                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                                required
                            />
                        </div>

                        <div className="form-group">
                            <label htmlFor="admin-password">
                                <Lock size={18} />
                                Password
                            </label>
                            <input
                                type="password"
                                id="admin-password"
                                className="input"
                                placeholder="••••••••"
                                value={formData.password}
                                onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                                required
                            />
                        </div>

                        <div className="form-footer">
                            <label className="checkbox-label">
                                <input type="checkbox" />
                                <span>Remember me</span>
                            </label>
                            <Link to="/forgot-password" className="link">Forgot password?</Link>
                        </div>

                        <button type="submit" className="btn btn-primary admin-login-btn" disabled={loading}>
                            {loading ? (
                                <>
                                    <span className="spinner"></span>
                                    Authenticating...
                                </>
                            ) : (
                                <>
                                    <Shield size={18} />
                                    Access Admin Dashboard
                                </>
                            )}
                        </button>
                    </form>

                    <div className="auth-footer admin-login-footer">
                        <p>Not an admin? <Link to="/login" className="link">Regular Login</Link></p>
                        <p className="admin-note">
                            <Shield size={14} />
                            This portal is restricted to authorized personnel only
                        </p>
                    </div>
                </motion.div>
            </div>
        </div>
    );
};

export default AdminLoginPage;

