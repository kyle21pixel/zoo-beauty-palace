import { motion } from 'framer-motion';
import { Calendar, User, ArrowRight, Tag, Instagram, Facebook, Twitter, Youtube } from 'lucide-react';
import './JournalPage.css';
import { Link } from 'react-router-dom';

const JournalPage = () => {
    const featuredPost = {
        id: 1,
        title: "The Ultimate Guide to Kenyan Bridal Makeup Trends 2025",
        excerpt: "From soft glam to bold traditional looks, discover what's trending for brides in Nairobi and beyond this season.",
        image: "https://images.unsplash.com/photo-1487412912498-0447578fcca8?w=800",
        author: "Sarah Kamau",
        date: "Nov 28, 2025",
        category: "Trends"
    };

    const posts = [
        {
            id: 2,
            title: "5 Tips for Maintaining Your Braids",
            excerpt: "Keep your protective style looking fresh and neat for weeks with these expert tips from top stylists.",
            image: "https://images.unsplash.com/photo-1583900985737-6d0495555783?w=400",
            author: "Amina Abdi",
            date: "Nov 25, 2025",
            category: "Hair Care"
        },
        {
            id: 3,
            title: "Skincare Routine for Nairobi Weather",
            excerpt: "Combat the city pollution and changing weather with a routine tailored for glowing skin.",
            image: "https://images.unsplash.com/photo-1570172619644-dfd03ed5d881?w=400",
            author: "Dr. Smith",
            date: "Nov 22, 2025",
            category: "Skincare"
        },
        {
            id: 4,
            title: "Top 10 Nail Art Designs to Try This Month",
            excerpt: "Get inspired by these creative and chic nail art ideas perfect for any occasion.",
            image: "https://images.unsplash.com/photo-1560066984-138dadb4c035?w=400",
            author: "Jasmine Lee",
            date: "Nov 20, 2025",
            category: "Nails"
        },
        {
            id: 5,
            title: "Why You Should Book a Mobile Barber",
            excerpt: "Experience the convenience and luxury of having a professional barber come to you.",
            image: "https://images.unsplash.com/photo-1503951914875-452162b0f3f1?w=400",
            author: "David Ochieng",
            date: "Nov 18, 2025",
            category: "Men's Grooming"
        },
        {
            id: 6,
            title: "Understanding Your Hair Porosity",
            excerpt: "The key to choosing the right products for your natural hair journey.",
            image: "https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?w=400",
            author: "Grace W.",
            date: "Nov 15, 2025",
            category: "Hair Care"
        }
    ];

    const categories = ["All", "Trends", "Hair Care", "Skincare", "Makeup", "Nails", "Men's Grooming"];

    return (
        <div className="journal-page">
            {/* Navbar */}
            <nav className="navbar">
                <div className="container nav-content">
                    <Link to="/" className="logo-container">
                        <img src="/assets/logo.png" alt="ZOO beauty Palace" className="logo-image" />
                        <span className="logo-text">
                            <span className="logo-top">ZOO</span>
                            <span className="logo-bottom">beauty Palace</span>
                        </span>
                    </Link>

                    <div className="nav-center">
                        <Link to="/services" className="nav-link">Services</Link>
                        <Link to="/about" className="nav-link">About</Link>
                        <Link to="/journal" className="nav-link active">Journal</Link>
                    </div>

                    <div className="nav-actions">
                        <Link to="/login" className="nav-link" style={{ marginRight: '1rem' }}>Sign In</Link>
                        <Link to="/register?type=provider" className="btn btn-outline" style={{ padding: '0.5rem 1rem', fontSize: '0.9rem' }}>Join as Pro</Link>
                        <Link to="/services" className="btn btn-primary" style={{ padding: '0.5rem 1.5rem', fontSize: '0.9rem' }}>Book Now</Link>
                    </div>
                </div>
            </nav>

            {/* Header */}
            <header className="journal-header">
                <div className="container">
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                    >
                        <h1>Beauty Journal</h1>
                        <p>Expert advice, trends, and inspiration from ZOO beauty Palace</p>
                    </motion.div>
                </div>
            </header>

            <div className="container">
                {/* Featured Post */}
                <section className="featured-section">
                    <motion.div
                        className="featured-card"
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ delay: 0.2 }}
                    >
                        <div className="featured-image">
                            <img src={featuredPost.image} alt={featuredPost.title} />
                            <span className="category-badge">{featuredPost.category}</span>
                        </div>
                        <div className="featured-content">
                            <div className="post-meta">
                                <span><Calendar size={14} /> {featuredPost.date}</span>
                                <span><User size={14} /> {featuredPost.author}</span>
                            </div>
                            <h2>{featuredPost.title}</h2>
                            <p>{featuredPost.excerpt}</p>
                            <Link to={`/journal/${featuredPost.id}`} className="read-more-btn">
                                Read Article <ArrowRight size={16} />
                            </Link>
                        </div>
                    </motion.div>
                </section>

                {/* Categories */}
                <section className="categories-bar">
                    {categories.map((cat, index) => (
                        <button key={index} className={`category-chip ${index === 0 ? 'active' : ''}`}>
                            {cat}
                        </button>
                    ))}
                </section>

                {/* Recent Posts Grid */}
                <section className="posts-grid">
                    {posts.map((post, index) => (
                        <motion.div
                            key={post.id}
                            className="post-card"
                            initial={{ opacity: 0, y: 20 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            viewport={{ once: true }}
                            transition={{ delay: index * 0.1 }}
                        >
                            <div className="post-image">
                                <img src={post.image} alt={post.title} />
                                <span className="category-badge-sm">{post.category}</span>
                            </div>
                            <div className="post-content">
                                <div className="post-meta">
                                    <span>{post.date}</span>
                                    <span>•</span>
                                    <span>{post.author}</span>
                                </div>
                                <h3>{post.title}</h3>
                                <p>{post.excerpt}</p>
                                <Link to={`/journal/${post.id}`} className="read-link">
                                    Read More
                                </Link>
                            </div>
                        </motion.div>
                    ))}
                </section>

                {/* Newsletter */}
                <section className="newsletter-section">
                    <div className="newsletter-box">
                        <h2>Subscribe to our Newsletter</h2>
                        <p>Get the latest beauty trends and exclusive offers delivered to your inbox.</p>
                        <div className="subscribe-form">
                            <input type="email" placeholder="Enter your email address" />
                            <button className="btn btn-primary">Subscribe</button>
                        </div>
                    </div>
                </section>
            </div>

            {/* Footer */}
            <footer className="footer">
                <div className="container">
                    <div className="footer-content">
                        <div className="footer-section">
                            <div className="logo-container mb-4">
                                <img src="/assets/logo.png" alt="ZOO beauty Palace" className="logo-image" style={{ width: '40px', height: '40px' }} />
                                <span className="logo-text" style={{ color: 'white' }}>
                                    <span className="logo-top">ZOO</span>
                                    <span className="logo-bottom">beauty Palace</span>
                                </span>
                            </div>
                            <p className="text-rose-200 mb-6">Redefining luxury beauty services on demand. Connect with the best.</p>
                            <div className="flex gap-4 social-links">
                                <a href="#" className="hover:text-white transition-colors"><Instagram size={20} /></a>
                                <a href="#" className="hover:text-white transition-colors"><Facebook size={20} /></a>
                                <a href="#" className="hover:text-white transition-colors"><Twitter size={20} /></a>
                                <a href="#" className="hover:text-white transition-colors"><Youtube size={20} /></a>
                            </div>
                        </div>

                        <div className="footer-section">
                            <h4>Discover</h4>
                            <Link to="/services/makeup">Makeup Artists</Link>
                            <Link to="/services/hair">Hair Stylists</Link>
                            <Link to="/services/nails">Nail Technicians</Link>
                            <Link to="/services/skincare">Skincare Experts</Link>
                        </div>

                        <div className="footer-section">
                            <h4>Company</h4>
                            <Link to="/about">Our Story</Link>
                            <Link to="/about">Careers</Link>
                            <Link to="/about">Press</Link>
                            <Link to="/about">Contact Us</Link>
                        </div>

                        <div className="footer-section">
                            <h4>Legal</h4>
                            <Link to="/about">Terms of Service</Link>
                            <Link to="/about">Privacy Policy</Link>
                            <Link to="/about">Cookie Policy</Link>
                        </div>
                    </div>

                    <div className="footer-bottom mt-12 pt-8 border-t border-rose-900 text-center text-rose-300">
                        <p>&copy; 2025 ZOO beauty Palace. All rights reserved.</p>
                    </div>
                </div>
            </footer>
        </div>
    );
};

export default JournalPage;
