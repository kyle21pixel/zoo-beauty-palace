import { useState, useEffect } from 'react';
import { useParams, Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { motion, AnimatePresence } from 'framer-motion';
import {
    MapPin, Star, Calendar, Clock, DollarSign, Check,
    ChevronLeft, ChevronRight, X, Sun, Moon, Shield,
    MessageSquare, Share2, Heart
} from 'lucide-react';
import api from '../lib/axios';
import { mockProviders } from '../data/mockData';
import './ProviderProfile.css';

const ProviderProfile = () => {
    const { id } = useParams();
    const navigate = useNavigate();
    const location = useLocation();
    const { user } = useAuth();
    const [darkMode, setDarkMode] = useState(false);
    const [activeTab, setActiveTab] = useState('services');
    const [showBookingModal, setShowBookingModal] = useState(false);
    const [selectedService, setSelectedService] = useState(null);
    const [bookingStep, setBookingStep] = useState(1);
    const [provider, setProvider] = useState(null);
    const [loading, setLoading] = useState(true);

    // Booking State
    const [bookingDate, setBookingDate] = useState(null);
    const [bookingTime, setBookingTime] = useState(null);
    const [clientDetails, setClientDetails] = useState({
        name: user ? `${user.firstName || ''} ${user.lastName || ''}`.trim() : '',
        email: user?.email || '',
        phone: user?.phone || '',
        notes: ''
    });
    const [isFavorite, setIsFavorite] = useState(false);

    const handleShare = () => {
        if (navigator.share) {
            navigator.share({
                title: `${provider.businessName} - ${provider.name}`,
                text: `Check out ${provider.businessName} on ZOO Beauty Palace!`,
                url: window.location.href
            }).catch(err => console.log('Error sharing:', err));
        } else {
            // Fallback: Copy to clipboard
            navigator.clipboard.writeText(window.location.href);
            alert('Link copied to clipboard!');
        }
    };

    const handleFavorite = () => {
        setIsFavorite(!isFavorite);
        // Here you would typically save to backend or localStorage
        if (!isFavorite) {
            alert('Added to favorites!');
        } else {
            alert('Removed from favorites!');
        }
    };

    useEffect(() => {
        fetchProviderData();
    }, [id]);

    useEffect(() => {
        // Auto-open booking modal if requested via navigation state
        if (location.state?.openBooking && provider?.services?.length > 0) {
            // Auto-select the first service
            setSelectedService(provider.services[0]);
            setBookingStep(1);
            setShowBookingModal(true);
        }
    }, [location.state, provider]);

    const fetchProviderData = async () => {
        try {
            const response = await api.get(`/providers/${id}`);
            if (response.data.success) {
                const providerData = response.data.data.provider;
                setProvider({
                    ...providerData,
                    name: `${providerData.userId?.firstName || ''} ${providerData.userId?.lastName || ''}`.trim(),
                    avatar: providerData.userId?.avatar || 'https://i.pravatar.cc/150?img=1',
                    coverImage: 'https://images.unsplash.com/photo-1487412912498-0447578fcca8?w=1200&h=400&fit=crop',
                    location: providerData.location?.address || 'Location not specified',
                    reviewCount: providerData.rating?.count || 0,
                    rating: providerData.rating?.average || 0,
                    reviews: []
                });
            }
        } catch (error) {
            console.error('Error fetching provider:', error);

            // Fallback to mock data
            const mockProvider = mockProviders.find(p => p.id === id);
            if (mockProvider) {
                const parsedServices = JSON.parse(mockProvider.services);
                const parsedPortfolio = JSON.parse(mockProvider.portfolio);

                setProvider({
                    id: mockProvider.id,
                    _id: mockProvider.id,
                    name: `${mockProvider.userId.firstName} ${mockProvider.userId.lastName}`,
                    businessName: mockProvider.businessName,
                    avatar: mockProvider.userId.avatar,
                    coverImage: 'https://images.unsplash.com/photo-1487412912498-0447578fcca8?w=1200&h=400&fit=crop',
                    location: JSON.parse(mockProvider.location).address,
                    bio: mockProvider.bio,
                    rating: JSON.parse(mockProvider.rating).average,
                    reviewCount: JSON.parse(mockProvider.rating).count,
                    services: parsedServices.map((service, index) => ({
                        ...service,
                        _id: `${mockProvider.id}-service-${index}`,
                        id: `${mockProvider.id}-service-${index}`
                    })),
                    portfolio: parsedPortfolio.map((item, index) => ({
                        url: item,
                        _id: `${mockProvider.id}-portfolio-${index}`,
                        id: `${mockProvider.id}-portfolio-${index}`
                    })),
                    reviews: []
                });
            }
        } finally {
            setLoading(false);
        }
    };

    const handleBookClick = (service) => {
        setSelectedService(service);
        setBookingStep(1);
        setShowBookingModal(true);
    };

    const handleNextStep = () => {
        setBookingStep(prev => prev + 1);
    };

    const handlePrevStep = () => {
        setBookingStep(prev => prev - 1);
    };

    const [serviceType, setServiceType] = useState('studio'); // 'studio' or 'mobile'
    const [clientLocation, setClientLocation] = useState('');

    const handleBookingSubmit = async () => {
        try {
            // Validate required fields
            if (!bookingDate || !bookingTime || !selectedService) {
                alert('Please select date, time and service');
                return;
            }

            if (!clientDetails.name || !clientDetails.email || !clientDetails.phone) {
                alert('Please fill in all your contact details');
                return;
            }

            if (serviceType === 'mobile' && !clientLocation) {
                alert('Please provide your location for mobile service');
                return;
            }

            const bookingData = {
                providerId: provider.id || provider._id,
                serviceId: selectedService.id || selectedService._id,
                scheduledDate: bookingDate,
                scheduledTime: bookingTime,
                location: serviceType === 'mobile' ? clientLocation : provider.location,
                serviceType: serviceType === 'mobile' ? 'en-route' : 'on-site',
                notes: clientDetails.notes,
                // Guest booking details
                guestName: clientDetails.name,
                guestEmail: clientDetails.email,
                guestPhone: clientDetails.phone
            };

            // Log booking data for demo purposes
            console.log('Guest Booking Created:', bookingData);

            // Simulate API delay
            await new Promise(resolve => setTimeout(resolve, 1000));

            // Show success
            handleNextStep();

            // Optionally: Try to send to backend (will fail but that's okay for guest bookings)
            try {
                await api.post('/bookings', bookingData);
            } catch (error) {
                // Silently fail - guest booking simulation succeeded anyway
                console.log('Backend booking failed (expected for guest bookings):', error.message);
            }
        } catch (error) {
            console.error('Error creating booking:', error);
            alert('Failed to create booking. Please try again.');
        }
    };

    const getNextDays = () => {
        const days = [];
        for (let i = 0; i < 7; i++) {
            const d = new Date();
            d.setDate(d.getDate() + i);
            days.push(d);
        }
        return days;
    };

    const timeSlots = [
        '09:00 AM', '10:00 AM', '11:00 AM',
        '01:00 PM', '02:00 PM', '03:00 PM', '04:00 PM'
    ];

    if (loading) {
        return <div className="loading">Loading...</div>;
    }

    if (!provider) {
        return <div className="error">Provider not found</div>;
    }

    return (
        <div className={`provider-profile ${darkMode ? 'dark-mode' : ''}`}>
            <nav className="profile-header-nav">
                <button
                    onClick={() => navigate(-1)}
                    className="btn btn-ghost btn-sm"
                    style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}
                >
                    <ChevronLeft size={20} /> Back
                </button>
                <div className="flex gap-2">
                    <button
                        className="btn btn-ghost btn-icon"
                        onClick={() => setDarkMode(!darkMode)}
                        title={darkMode ? "Light Mode" : "Dark Mode"}
                    >
                        {darkMode ? <Sun size={20} /> : <Moon size={20} />}
                    </button>
                    <button
                        className="btn btn-ghost btn-icon"
                        onClick={handleShare}
                        title="Share Profile"
                    >
                        <Share2 size={20} />
                    </button>
                    <button
                        className={`btn btn-ghost btn-icon ${isFavorite ? 'text-red-500' : ''}`}
                        onClick={handleFavorite}
                        title={isFavorite ? "Remove from Favorites" : "Add to Favorites"}
                    >
                        <Heart size={20} fill={isFavorite ? "currentColor" : "none"} />
                    </button>
                </div>
            </nav>

            <img src={provider.coverImage} alt="Cover" className="profile-cover" />

            <div className="profile-info-container">
                <div className="profile-card">
                    <img src={provider.avatar} alt={provider.name} className="profile-avatar" />
                    <div className="profile-details">
                        <span className="business-badge">{provider.businessName}</span>
                        <h1>{provider.name}</h1>
                        <div className="flex items-center gap-2 text-sm text-gray-500 mb-4">
                            <MapPin size={16} /> {provider.location}
                        </div>
                        <p>{provider.bio}</p>

                        <div className="profile-stats">
                            <div className="stat-item">
                                <Star size={20} fill="#f59e0b" color="#f59e0b" />
                                <span><strong>{provider.rating?.toFixed(1) || 0}</strong> ({provider.reviewCount} reviews)</span>
                            </div>
                            <div className="stat-item">
                                <Shield size={20} color="#10b981" />
                                <span><strong>Verified</strong> Provider</span>
                            </div>
                            <div className="stat-item">
                                <MessageSquare size={20} />
                                <span><strong>High</strong> Response Rate</span>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="profile-content">
                    <div className="content-left">
                        <div className="content-tabs">
                            <button
                                className={`tab-btn ${activeTab === 'services' ? 'active' : ''}`}
                                onClick={() => setActiveTab('services')}
                            >
                                Services
                            </button>
                            <button
                                className={`tab-btn ${activeTab === 'portfolio' ? 'active' : ''}`}
                                onClick={() => setActiveTab('portfolio')}
                            >
                                Portfolio
                            </button>
                            <button
                                className={`tab-btn ${activeTab === 'reviews' ? 'active' : ''}`}
                                onClick={() => setActiveTab('reviews')}
                            >
                                Reviews
                            </button>
                        </div>

                        <AnimatePresence mode="wait">
                            {activeTab === 'services' && (
                                <motion.div
                                    key="services"
                                    initial={{ opacity: 0, y: 10 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    exit={{ opacity: 0, y: -10 }}
                                >
                                    {provider.services && provider.services.length > 0 ? (
                                        provider.services.map(service => (
                                            <div key={service._id} className="service-item">
                                                <div className="service-info">
                                                    <h3>{service.name}</h3>
                                                    <p className="text-sm text-gray-500 mb-2">{service.description}</p>
                                                    <div className="service-meta">
                                                        <span className="flex items-center gap-1"><Clock size={14} /> {service.duration} min</span>
                                                    </div>
                                                </div>
                                                <div className="text-right">
                                                    <div className="service-price">KES {service.price}</div>
                                                    <button
                                                        className="btn btn-primary btn-sm mt-2"
                                                        onClick={() => handleBookClick(service)}
                                                    >
                                                        Book Now
                                                    </button>
                                                </div>
                                            </div>
                                        ))
                                    ) : (
                                        <p>No services available</p>
                                    )}
                                </motion.div>
                            )}

                            {activeTab === 'portfolio' && (
                                <motion.div
                                    key="portfolio"
                                    className="grid grid-cols-2 gap-4"
                                    initial={{ opacity: 0, y: 10 }}
                                    animate={{ opacity: 1, y: 0 }}
                                >
                                    {provider.portfolio && provider.portfolio.length > 0 ? (
                                        provider.portfolio.map((item, i) => (
                                            <img key={i} src={item.url || item} alt="Portfolio" className="w-full h-48 object-cover rounded-lg" />
                                        ))
                                    ) : (
                                        <p>No portfolio items</p>
                                    )}
                                </motion.div>
                            )}

                            {activeTab === 'reviews' && (
                                <motion.div
                                    key="reviews"
                                    initial={{ opacity: 0, y: 10 }}
                                    animate={{ opacity: 1, y: 0 }}
                                >
                                    {provider.reviews && provider.reviews.length > 0 ? (
                                        provider.reviews.map(review => (
                                            <div key={review.id} className="bg-white p-4 rounded-lg border border-gray-200 mb-4 dark:bg-slate-800 dark:border-slate-700">
                                                <div className="flex justify-between mb-2">
                                                    <span className="font-bold">{review.user}</span>
                                                    <span className="text-sm text-gray-500">{review.date}</span>
                                                </div>
                                                <div className="flex mb-2">
                                                    {[...Array(5)].map((_, i) => (
                                                        <Star key={i} size={14} fill={i < review.rating ? "#f59e0b" : "none"} color={i < review.rating ? "#f59e0b" : "currentColor"} />
                                                    ))}
                                                </div>
                                                <p>{review.text}</p>
                                            </div>
                                        ))
                                    ) : (
                                        <p>No reviews yet</p>
                                    )}
                                </motion.div>
                            )}
                        </AnimatePresence>
                    </div>

                    <div className="content-right hidden md:block">
                        <div className="bg-white p-6 rounded-xl border border-gray-200 sticky top-24 dark:bg-slate-800 dark:border-slate-700">
                            <h3 className="font-bold mb-4">Business Hours</h3>
                            <div className="space-y-2 text-sm">
                                <div className="flex justify-between"><span>Monday - Friday</span> <span>9:00 AM - 6:00 PM</span></div>
                                <div className="flex justify-between"><span>Saturday</span> <span>10:00 AM - 4:00 PM</span></div>
                                <div className="flex justify-between text-red-500"><span>Sunday</span> <span>Closed</span></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <AnimatePresence>
                {showBookingModal && (
                    <div className="booking-modal-overlay">
                        <motion.div
                            className="booking-modal"
                            initial={{ scale: 0.9, opacity: 0 }}
                            animate={{ scale: 1, opacity: 1 }}
                            exit={{ scale: 0.9, opacity: 0 }}
                        >
                            <div className="modal-header">
                                <h2>Book Appointment</h2>
                                <button className="btn btn-ghost btn-sm" onClick={() => setShowBookingModal(false)}><X size={20} /></button>
                            </div>

                            <div className="step-indicator">
                                {[1, 2, 3, 4].map(step => (
                                    <div
                                        key={step}
                                        className={`step-dot ${bookingStep === step ? 'active' : ''} ${bookingStep > step ? 'completed' : ''}`}
                                    />
                                ))}
                            </div>

                            {bookingStep === 1 && selectedService && (
                                <div className="step-content">
                                    <h3 className="text-xl font-bold mb-4">Selected Service</h3>
                                    <div className="service-item border-2 border-blue-500 bg-blue-50 dark:bg-blue-900/20 dark:border-blue-400">
                                        <div className="service-info">
                                            <h3>{selectedService.name}</h3>
                                            <p className="text-sm text-gray-500">{selectedService.description}</p>
                                            <div className="service-meta mt-2">
                                                <span className="flex items-center gap-1"><Clock size={14} /> {selectedService.duration} min</span>
                                            </div>
                                        </div>
                                        <div className="service-price">KES {selectedService.price}</div>
                                    </div>
                                    <div className="mt-6 flex justify-end">
                                        <button className="btn btn-primary" onClick={handleNextStep}>Continue</button>
                                    </div>
                                </div>
                            )}

                            {bookingStep === 2 && (
                                <div className="step-content">
                                    <h3 className="text-xl font-bold mb-4">Select Date & Time</h3>
                                    <div className="calendar-grid">
                                        {getNextDays().map((date, i) => (
                                            <div
                                                key={i}
                                                className={`calendar-day ${bookingDate?.toDateString() === date.toDateString() ? 'selected' : ''}`}
                                                onClick={() => setBookingDate(date)}
                                            >
                                                <div className="text-xs uppercase">{date.toLocaleDateString('en-US', { weekday: 'short' })}</div>
                                                <div className="font-bold text-lg">{date.getDate()}</div>
                                            </div>
                                        ))}
                                    </div>

                                    {bookingDate && (
                                        <>
                                            <h4 className="font-semibold mb-2">Available Slots</h4>
                                            <div className="time-slots">
                                                {timeSlots.map((time, i) => (
                                                    <div
                                                        key={i}
                                                        className={`time-slot ${bookingTime === time ? 'selected' : ''}`}
                                                        onClick={() => setBookingTime(time)}
                                                    >
                                                        {time}
                                                    </div>
                                                ))}
                                            </div>
                                        </>
                                    )}

                                    <div className="mt-6 flex justify-between">
                                        <button className="btn btn-ghost" onClick={handlePrevStep}>Back</button>
                                        <button
                                            className="btn btn-primary"
                                            disabled={!bookingDate || !bookingTime}
                                            onClick={handleNextStep}
                                        >
                                            Continue
                                        </button>
                                    </div>
                                </div>
                            )}

                            {bookingStep === 3 && (
                                <div className="step-content">
                                    <h3 className="text-xl font-bold mb-4">Your Details</h3>
                                    <div className="space-y-4">
                                        <div>
                                            <label className="block text-sm font-medium mb-1">Full Name *</label>
                                            <input
                                                type="text"
                                                className="input w-full"
                                                value={clientDetails.name}
                                                onChange={e => setClientDetails({ ...clientDetails, name: e.target.value })}
                                                placeholder="John Doe"
                                                required
                                            />
                                        </div>
                                        <div>
                                            <label className="block text-sm font-medium mb-1">Email *</label>
                                            <input
                                                type="email"
                                                className="input w-full"
                                                value={clientDetails.email}
                                                onChange={e => setClientDetails({ ...clientDetails, email: e.target.value })}
                                                placeholder="john@example.com"
                                                required
                                            />
                                        </div>
                                        <div>
                                            <label className="block text-sm font-medium mb-1">Phone *</label>
                                            <input
                                                type="tel"
                                                className="input w-full"
                                                value={clientDetails.phone}
                                                onChange={e => setClientDetails({ ...clientDetails, phone: e.target.value })}
                                                placeholder="+254 712 345 678"
                                                required
                                            />
                                        </div>
                                        <div>
                                            <label className="block text-sm font-medium mb-2">Service Location</label>
                                            <div className="flex gap-4 mb-3">
                                                <label className={`flex items-center gap-2 p-3 border rounded-lg cursor-pointer transition-all ${serviceType === 'studio' ? 'border-primary-500 bg-primary-50 dark:bg-primary-900/20' : 'border-gray-200'}`}>
                                                    <input
                                                        type="radio"
                                                        name="serviceType"
                                                        value="studio"
                                                        checked={serviceType === 'studio'}
                                                        onChange={() => setServiceType('studio')}
                                                        className="accent-primary-600"
                                                    />
                                                    <div>
                                                        <span className="block font-medium">Studio Visit</span>
                                                        <span className="text-xs text-gray-500">Go to {provider.name}'s place</span>
                                                    </div>
                                                </label>
                                                <label className={`flex items-center gap-2 p-3 border rounded-lg cursor-pointer transition-all ${serviceType === 'mobile' ? 'border-primary-500 bg-primary-50 dark:bg-primary-900/20' : 'border-gray-200'}`}>
                                                    <input
                                                        type="radio"
                                                        name="serviceType"
                                                        value="mobile"
                                                        checked={serviceType === 'mobile'}
                                                        onChange={() => setServiceType('mobile')}
                                                        className="accent-primary-600"
                                                    />
                                                    <div>
                                                        <span className="block font-medium">Mobile Service</span>
                                                        <span className="text-xs text-gray-500">We come to you (On Route)</span>
                                                    </div>
                                                </label>
                                            </div>

                                            {serviceType === 'mobile' && (
                                                <motion.div
                                                    initial={{ opacity: 0, height: 0 }}
                                                    animate={{ opacity: 1, height: 'auto' }}
                                                    className="mb-4"
                                                >
                                                    <label className="block text-sm font-medium mb-1">Your Location address *</label>
                                                    <input
                                                        type="text"
                                                        className="input w-full"
                                                        value={clientLocation}
                                                        onChange={e => setClientLocation(e.target.value)}
                                                        placeholder="e.g. 123 Main St, Apartment 4B"
                                                        required
                                                    />
                                                </motion.div>
                                            )}
                                        </div>
                                        <div>
                                            <label className="block text-sm font-medium mb-1">Notes (Optional)</label>
                                            <textarea
                                                className="input w-full"
                                                rows="3"
                                                value={clientDetails.notes}
                                                onChange={e => setClientDetails({ ...clientDetails, notes: e.target.value })}
                                                placeholder="Any special requests?"
                                            />
                                        </div>
                                    </div>

                                    <div className="mt-6 flex justify-between">
                                        <button className="btn btn-ghost" onClick={handlePrevStep}>Back</button>
                                        <button
                                            className="btn btn-primary"
                                            disabled={!clientDetails.name || !clientDetails.email || !clientDetails.phone}
                                            onClick={handleBookingSubmit}
                                        >
                                            Confirm Booking
                                        </button>
                                    </div>
                                </div>
                            )}

                            {bookingStep === 4 && (
                                <div className="step-content success-animation">
                                    <motion.div
                                        initial={{ scale: 0 }}
                                        animate={{ scale: 1 }}
                                        className="success-icon"
                                    >
                                        <Check size={40} />
                                    </motion.div>
                                    <h3 className="text-2xl font-bold mb-2">Booking Confirmed!</h3>
                                    <p className="text-gray-500 mb-6">
                                        Your appointment for <strong>{selectedService?.name}</strong> with <strong>{provider.name}</strong> has been scheduled for <strong>{bookingDate?.toLocaleDateString()} at {bookingTime}</strong>.
                                    </p>
                                    <p className="text-sm text-gray-600 mb-6">
                                        A confirmation email will be sent to <strong>{clientDetails.email}</strong>
                                    </p>
                                    <div className="flex justify-center gap-4">
                                        <button className="btn btn-primary" onClick={() => {
                                            setShowBookingModal(false);
                                            setBookingStep(1);
                                        }}>Close</button>
                                        <Link to="/services" className="btn btn-outline">Browse More Services</Link>
                                    </div>
                                </div>
                            )}
                        </motion.div>
                    </div>
                )}
            </AnimatePresence>
        </div>
    );
};

export default ProviderProfile;
