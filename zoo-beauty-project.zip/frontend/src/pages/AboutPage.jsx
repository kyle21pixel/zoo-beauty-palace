import { motion } from 'framer-motion';
import { Heart, Users, Star, Award, Sparkles, Instagram, Facebook, Twitter, Youtube } from 'lucide-react';
import './AboutPage.css';
import { Link } from 'react-router-dom';

const AboutPage = () => {
    const team = [
        {
            name: 'Sarah Kamau',
            role: 'Founder & CEO',
            image: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400',
            bio: 'Visionary leader with a passion for transforming the beauty industry in Kenya.'
        },
        {
            name: 'David Ochieng',
            role: 'Head of Operations',
            image: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=400',
            bio: 'Ensuring seamless experiences for both our clients and providers.'
        },
        {
            name: 'Amina Abdi',
            role: 'Creative Director',
            image: 'https://images.unsplash.com/photo-1589156280159-27698a70f29e?w=400',
            bio: 'Curating the premium aesthetic that defines ZOO beauty Palace.'
        }
    ];

    return (
        <div className="about-page">
            {/* Navbar */}
            <nav className="navbar">
                <div className="container nav-content">
                    <Link to="/" className="logo-container">
                        <img src="/assets/logo.png" alt="ZOO beauty Palace" className="logo-image" />
                        <span className="logo-text">
                            <span className="logo-top">ZOO</span>
                            <span className="logo-bottom">beauty Palace</span>
                        </span>
                    </Link>

                    <div className="nav-center">
                        <Link to="/services" className="nav-link">Services</Link>
                        <Link to="/about" className="nav-link active">About</Link>
                        <Link to="/journal" className="nav-link">Journal</Link>
                    </div>

                    <div className="nav-actions">
                        <Link to="/login" className="nav-link" style={{ marginRight: '1rem' }}>Sign In</Link>
                        <Link to="/register?type=provider" className="btn btn-outline" style={{ padding: '0.5rem 1rem', fontSize: '0.9rem' }}>Join as Pro</Link>
                        <Link to="/services" className="btn btn-primary" style={{ padding: '0.5rem 1.5rem', fontSize: '0.9rem' }}>Book Now</Link>
                    </div>
                </div>
            </nav>

            {/* Hero Section */}
            <section className="about-hero">
                <div className="container">
                    <motion.div
                        className="hero-content"
                        initial={{ opacity: 0, y: 30 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.8 }}
                    >
                        <h1>Our Story</h1>
                        <p className="subtitle">Redefining Beauty Services in Kenya</p>
                    </motion.div>
                </div>
            </section>

            {/* Mission Section */}
            <section className="mission-section">
                <div className="container">
                    <div className="mission-grid">
                        <motion.div
                            className="mission-content"
                            initial={{ opacity: 0, x: -30 }}
                            whileInView={{ opacity: 1, x: 0 }}
                            viewport={{ once: true }}
                        >
                            <h2>Empowering Beauty Professionals</h2>
                            <p>
                                At ZOO beauty Palace, we believe that beauty is an art form. Our mission is to connect talented beauty professionals with clients who appreciate quality and convenience. We are building a community where skill meets opportunity.
                            </p>
                            <p>
                                Whether you're a freelance makeup artist, a mobile barber, or a salon owner, ZOO beauty Palace provides the platform you need to grow your business and reach new heights.
                            </p>
                            <div className="stats-row">
                                <div className="stat-item">
                                    <span className="stat-number">500+</span>
                                    <span className="stat-label">Providers</span>
                                </div>
                                <div className="stat-item">
                                    <span className="stat-number">10k+</span>
                                    <span className="stat-label">Bookings</span>
                                </div>
                                <div className="stat-item">
                                    <span className="stat-number">4.9</span>
                                    <span className="stat-label">Rating</span>
                                </div>
                            </div>
                        </motion.div>
                        <motion.div
                            className="mission-image"
                            initial={{ opacity: 0, x: 30 }}
                            whileInView={{ opacity: 1, x: 0 }}
                            viewport={{ once: true }}
                        >
                            <img src="https://images.unsplash.com/photo-1522337660859-02fbefca4702?w=800" alt="Beauty Professional" />
                        </motion.div>
                    </div>
                </div>
            </section>

            {/* Values Section */}
            <section className="values-section">
                <div className="container">
                    <div className="section-header text-center">
                        <h2>Our Core Values</h2>
                        <p>The principles that guide everything we do</p>
                    </div>
                    <div className="values-grid">
                        <div className="value-card">
                            <div className="value-icon"><Heart /></div>
                            <h3>Passion</h3>
                            <p>We are driven by a deep love for the beauty industry and the people in it.</p>
                        </div>
                        <div className="value-card">
                            <div className="value-icon"><Award /></div>
                            <h3>Excellence</h3>
                            <p>We set high standards for our providers to ensure top-tier service for every client.</p>
                        </div>
                        <div className="value-card">
                            <div className="value-icon"><Users /></div>
                            <h3>Community</h3>
                            <p>We foster a supportive network where professionals can learn, grow, and thrive together.</p>
                        </div>
                        <div className="value-card">
                            <div className="value-icon"><Sparkles /></div>
                            <h3>Innovation</h3>
                            <p>We embrace technology to make beauty services more accessible and efficient.</p>
                        </div>
                    </div>
                </div>
            </section>

            {/* Team Section */}
            <section className="team-section">
                <div className="container">
                    <div className="section-header text-center">
                        <h2>Meet The Team</h2>
                        <p>The minds behind the magic</p>
                    </div>
                    <div className="team-grid">
                        {team.map((member, index) => (
                            <motion.div
                                key={index}
                                className="team-card"
                                initial={{ opacity: 0, y: 20 }}
                                whileInView={{ opacity: 1, y: 0 }}
                                viewport={{ once: true }}
                                transition={{ delay: index * 0.1 }}
                            >
                                <div className="member-image">
                                    <img src={member.image} alt={member.name} />
                                </div>
                                <h3>{member.name}</h3>
                                <span className="member-role">{member.role}</span>
                                <p>{member.bio}</p>
                            </motion.div>
                        ))}
                    </div>
                </div>
            </section>

            {/* CTA Section */}
            <section className="about-cta">
                <div className="container">
                    <div className="cta-box">
                        <h2>Join the Revolution</h2>
                        <p>Be a part of Kenya's fastest-growing beauty network.</p>
                        <div className="cta-buttons">
                            <Link to="/services" className="btn btn-white">Find a Pro</Link>
                            <Link to="/register?type=provider" className="btn btn-outline-white">Join as Artist</Link>
                        </div>
                    </div>
                </div>
            </section>

            {/* Footer */}
            <footer className="footer">
                <div className="container">
                    <div className="footer-content">
                        <div className="footer-section">
                            <div className="logo-container mb-4">
                                <img src="/assets/logo.png" alt="ZOO beauty Palace" className="logo-image" style={{ width: '40px', height: '40px' }} />
                                <span className="logo-text" style={{ color: 'white' }}>
                                    <span className="logo-top">ZOO</span>
                                    <span className="logo-bottom">beauty Palace</span>
                                </span>
                            </div>
                            <p className="text-rose-200 mb-6">Redefining luxury beauty services on demand. Connect with the best.</p>
                            <div className="flex gap-4 social-links">
                                <a href="#" className="hover:text-white transition-colors"><Instagram size={20} /></a>
                                <a href="#" className="hover:text-white transition-colors"><Facebook size={20} /></a>
                                <a href="#" className="hover:text-white transition-colors"><Twitter size={20} /></a>
                                <a href="#" className="hover:text-white transition-colors"><Youtube size={20} /></a>
                            </div>
                        </div>

                        <div className="footer-section">
                            <h4>Discover</h4>
                            <Link to="/services/makeup">Makeup Artists</Link>
                            <Link to="/services/hair">Hair Stylists</Link>
                            <Link to="/services/nails">Nail Technicians</Link>
                            <Link to="/services/skincare">Skincare Experts</Link>
                        </div>

                        <div className="footer-section">
                            <h4>Company</h4>
                            <Link to="/about">Our Story</Link>
                            <Link to="/about">Careers</Link>
                            <Link to="/about">Press</Link>
                            <Link to="/about">Contact Us</Link>
                        </div>

                        <div className="footer-section">
                            <h4>Legal</h4>
                            <Link to="/about">Terms of Service</Link>
                            <Link to="/about">Privacy Policy</Link>
                            <Link to="/about">Cookie Policy</Link>
                        </div>
                    </div>

                    <div className="footer-bottom mt-12 pt-8 border-t border-rose-900 text-center text-rose-300">
                        <p>&copy; 2025 ZOO beauty Palace. All rights reserved.</p>
                    </div>
                </div>
            </footer>
        </div>
    );
};

export default AboutPage;
