# 🎨 Zoo Beauty - Complete System Setup Guide

## 🚀 Quick Start (Automated)

### Option 1: One-Click Setup (Recommended)
1. Make sure XAMPP is installed and MySQL is stopped
2. Double-click: `SETUP_COMPLETE_SYSTEM.bat`
3. Follow the prompts
4. Done! Visit http://localhost:5173/services

### Option 2: Manual Setup

#### Step 1: Fix MySQL Authentication
```bash
# Run this if you get authentication errors
.\fix_mysql.bat
# Then restart MySQL from XAMPP Control Panel
```

#### Step 2: Setup Database
```bash
.\setup_complete_database.bat
```

#### Step 3: Start Backend Server
```bash
cd backend
npm install
npm run dev
```

#### Step 4: Frontend is Already Running
The frontend should already be running on http://localhost:5173

---

## 📋 System Overview

### Database: `zoobeauty`
- **Tables**: 12 tables (users, providers, bookings, reviews, payments, etc.)
- **Sample Data**: 4 providers with services

### Sample Providers
1. **Sarah Johnson** - Glam by Sarah
   - Services: Bridal Makeup ($150), Soft Glam ($80), Wig Installation ($120)
   
2. **Michael Chen** - Chen's Barbershop
   - Services: Classic Haircut ($50), Beard Trim ($35), Full Grooming ($100)
   
3. **Amara Okonkwo** - Amara's Braiding Studio
   - Services: Box Braids ($180), Cornrows ($120), Knotless Braids ($220)
   
4. **David Martinez** - Martinez Nail Art
   - Services: Gel Manicure ($55), Custom Nail Art ($85), Acrylic Extensions ($95)

---

## 🌐 Application URLs

- **Frontend**: http://localhost:5173
- **Backend API**: http://localhost:5000
- **Search Providers**: http://localhost:5173/services
- **Admin Dashboard**: http://localhost:5173/admin/dashboard
- **phpMyAdmin**: http://localhost/phpmyadmin

---

## 🔑 Test Credentials

### Admin Account
- Email: admin@zoobeauty.com
- Password: password123

### Provider Accounts
- sarah@example.com / password123
- michael@example.com / password123
- amara@example.com / password123
- david@example.com / password123

---

## ✅ Features Implemented

### For Clients:
- ✅ Browse providers by service type
- ✅ View provider profiles with services
- ✅ See provider portfolios and reviews
- ✅ Book appointments
- ✅ Search and filter providers

### For Providers:
- ✅ Unique profile pages
- ✅ Individual service listings
- ✅ Portfolio management
- ✅ Booking management
- ✅ Dashboard with stats

### For Admins:
- ✅ View all providers with their services
- ✅ See provider statistics (bookings, earnings, ratings)
- ✅ Manage users and providers
- ✅ View bookings and disputes
- ✅ Analytics dashboard

---

## 🛠️ Troubleshooting

### "Provider not found" Error
- Run: `.\setup_complete_database.bat`
- This adds the sample provider data

### MySQL Authentication Error
- Run: `.\fix_mysql.bat`
- Restart MySQL from XAMPP Control Panel
- Run: `.\setup_complete_database.bat`

### Backend Not Starting
```bash
cd backend
npm install
npm run dev
```

### Frontend Not Loading
```bash
cd frontend
npm install
npm run dev
```

### Database Connection Issues
- Check XAMPP: MySQL must be running
- Check `.env` file in backend folder:
  ```
  DB_HOST=localhost
  DB_USER=root
  DB_PASS=
  DB_NAME=zoobeauty
  ```

---

## 📁 Project Structure

```
zoo beauty/
├── backend/
│   ├── controllers/      # API logic
│   ├── models/          # Database models
│   ├── routes/          # API routes
│   ├── middleware/      # Auth, error handling
│   ├── config/          # Database config
│   ├── server.js        # Main server file
│   └── .env             # Environment variables
│
├── frontend/
│   ├── src/
│   │   ├── pages/       # React pages
│   │   ├── components/  # Reusable components
│   │   ├── services/    # API calls
│   │   └── context/     # State management
│   └── public/
│
└── SETUP_COMPLETE_SYSTEM.bat  # One-click setup
```

---

## 🎯 Next Steps

1. **Test the System**:
   - Visit http://localhost:5173/services
   - Click on any provider
   - Try booking an appointment

2. **Admin Dashboard**:
   - Visit http://localhost:5173/admin/dashboard
   - Login with admin credentials
   - View provider data and statistics

3. **Customize**:
   - Add more providers via phpMyAdmin
   - Update provider services
   - Customize styling in CSS files

---

## 📞 Support

If you encounter any issues:
1. Check the troubleshooting section above
2. Verify XAMPP services are running
3. Check browser console for errors
4. Check backend terminal for API errors

---

**Enjoy your Zoo Beauty platform! 🎨✨**
