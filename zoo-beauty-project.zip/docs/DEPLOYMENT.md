# 🚀 Deployment Guide

## Overview

This guide covers deploying the Zoo Beauty platform to production using modern cloud infrastructure.

---

## Prerequisites

- Node.js 18+ installed
- MongoDB Atlas account (or self-hosted MongoDB)
- Domain name configured
- SSL certificate
- Cloud provider account (AWS/DigitalOcean/Heroku)
- Stripe/PayStack account
- Cloudinary account
- Mapbox account
- SMTP service (SendGrid/Mailgun)

---

## Environment Variables

### Backend (.env)

```bash
# Server Configuration
NODE_ENV=production
PORT=5000
API_URL=https://api.zoobeauty.com

# Database
MONGODB_URI=mongodb+srv://username:password@cluster.mongodb.net/zoobeauty?retryWrites=true&w=majority

# JWT
JWT_SECRET=your_super_secret_jwt_key_min_32_characters
JWT_EXPIRE=7d

# Redis (Optional - for caching)
REDIS_URL=redis://localhost:6379

# Cloudinary
CLOUDINARY_CLOUD_NAME=your_cloud_name
CLOUDINARY_API_KEY=your_api_key
CLOUDINARY_API_SECRET=your_api_secret

# Payment Gateway
STRIPE_SECRET_KEY=sk_live_xxx
STRIPE_PUBLISHABLE_KEY=pk_live_xxx
STRIPE_WEBHOOK_SECRET=whsec_xxx

# Or PayStack
PAYSTACK_SECRET_KEY=sk_live_xxx
PAYSTACK_PUBLIC_KEY=pk_live_xxx

# Email Service
SMTP_HOST=smtp.sendgrid.net
SMTP_PORT=587
SMTP_USER=apikey
SMTP_PASSWORD=your_sendgrid_api_key
FROM_EMAIL=noreply@zoobeauty.com
FROM_NAME=Zoo Beauty

# SMS Service (Twilio)
TWILIO_ACCOUNT_SID=your_account_sid
TWILIO_AUTH_TOKEN=your_auth_token
TWILIO_PHONE_NUMBER=+1234567890

# Mapbox
MAPBOX_ACCESS_TOKEN=pk.xxx

# Frontend URL
FRONTEND_URL=https://zoobeauty.com

# File Upload
MAX_FILE_SIZE=10485760
ALLOWED_FILE_TYPES=image/jpeg,image/png,image/webp,video/mp4

# Rate Limiting
RATE_LIMIT_WINDOW=15
RATE_LIMIT_MAX_REQUESTS=100

# Session
SESSION_SECRET=your_session_secret_min_32_characters

# Logging
LOG_LEVEL=info
```

### Frontend (.env)

```bash
# API Configuration
VITE_API_URL=https://api.zoobeauty.com/api/v1
VITE_WS_URL=wss://api.zoobeauty.com

# Mapbox
VITE_MAPBOX_TOKEN=pk.xxx

# Stripe
VITE_STRIPE_PUBLISHABLE_KEY=pk_live_xxx

# Google Analytics (Optional)
VITE_GA_TRACKING_ID=UA-XXXXXXXXX-X

# Environment
VITE_ENV=production
```

---

## Deployment Options

### Option 1: Docker Deployment (Recommended)

#### 1. Create Dockerfile for Backend

```dockerfile
# backend/Dockerfile
FROM node:18-alpine

WORKDIR /app

COPY package*.json ./
RUN npm ci --only=production

COPY . .

EXPOSE 5000

CMD ["node", "server.js"]
```

#### 2. Create Dockerfile for Frontend

```dockerfile
# frontend/Dockerfile
FROM node:18-alpine as build

WORKDIR /app

COPY package*.json ./
RUN npm ci

COPY . .
RUN npm run build

FROM nginx:alpine
COPY --from=build /app/dist /usr/share/nginx/html
COPY nginx.conf /etc/nginx/conf.d/default.conf

EXPOSE 80

CMD ["nginx", "-g", "daemon off;"]
```

#### 3. Create docker-compose.yml

```yaml
version: '3.8'

services:
  backend:
    build: ./backend
    ports:
      - "5000:5000"
    environment:
      - NODE_ENV=production
    env_file:
      - ./backend/.env
    depends_on:
      - mongodb
      - redis
    restart: unless-stopped

  frontend:
    build: ./frontend
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./ssl:/etc/nginx/ssl
    depends_on:
      - backend
    restart: unless-stopped

  mongodb:
    image: mongo:6
    ports:
      - "27017:27017"
    volumes:
      - mongodb_data:/data/db
    environment:
      - MONGO_INITDB_ROOT_USERNAME=admin
      - MONGO_INITDB_ROOT_PASSWORD=secure_password
    restart: unless-stopped

  redis:
    image: redis:alpine
    ports:
      - "6379:6379"
    volumes:
      - redis_data:/data
    restart: unless-stopped

volumes:
  mongodb_data:
  redis_data:
```

#### 4. Deploy with Docker

```bash
# Build and start containers
docker-compose up -d

# View logs
docker-compose logs -f

# Stop containers
docker-compose down
```

---

### Option 2: AWS Deployment

#### Architecture

```
┌─────────────────────────────────────────────────────────┐
│                      Route 53 (DNS)                      │
└─────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────┐
│              CloudFront (CDN) + SSL/TLS                  │
└─────────────────────────────────────────────────────────┘
                            ↓
        ┌───────────────────┴───────────────────┐
        ↓                                       ↓
┌──────────────────┐                  ┌──────────────────┐
│   S3 Bucket      │                  │  Application     │
│   (Frontend)     │                  │  Load Balancer   │
└──────────────────┘                  └──────────────────┘
                                                ↓
                                      ┌──────────────────┐
                                      │   EC2 Instances  │
                                      │   (Backend API)  │
                                      └──────────────────┘
                                                ↓
                        ┌───────────────────────┴───────────────────┐
                        ↓                                           ↓
              ┌──────────────────┐                        ┌──────────────────┐
              │  MongoDB Atlas   │                        │  ElastiCache     │
              │  (Database)      │                        │  (Redis)         │
              └──────────────────┘                        └──────────────────┘
```

#### Steps

1. **Setup MongoDB Atlas**
```bash
# Create cluster
# Configure network access
# Create database user
# Get connection string
```

2. **Deploy Frontend to S3 + CloudFront**
```bash
# Build frontend
cd frontend
npm run build

# Create S3 bucket
aws s3 mb s3://zoobeauty-frontend

# Upload build files
aws s3 sync dist/ s3://zoobeauty-frontend --delete

# Create CloudFront distribution
# Configure SSL certificate
# Point to S3 bucket
```

3. **Deploy Backend to EC2**
```bash
# Launch EC2 instance (t3.medium or larger)
# Install Node.js, PM2, Nginx

# Clone repository
git clone https://github.com/yourusername/zoo-beauty.git
cd zoo-beauty/backend

# Install dependencies
npm ci --only=production

# Setup environment variables
nano .env

# Start with PM2
pm2 start server.js --name zoo-beauty-api
pm2 save
pm2 startup

# Configure Nginx as reverse proxy
sudo nano /etc/nginx/sites-available/zoo-beauty
```

4. **Nginx Configuration**
```nginx
server {
    listen 80;
    server_name api.zoobeauty.com;

    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

5. **Setup SSL with Let's Encrypt**
```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d api.zoobeauty.com
```

---

### Option 3: DigitalOcean Deployment

#### 1. Create Droplet
- Choose Ubuntu 22.04 LTS
- Select appropriate size (2GB RAM minimum)
- Add SSH key
- Enable monitoring

#### 2. Initial Server Setup
```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt install -y nodejs

# Install PM2
sudo npm install -g pm2

# Install Nginx
sudo apt install -y nginx

# Install MongoDB (or use MongoDB Atlas)
wget -qO - https://www.mongodb.org/static/pgp/server-6.0.asc | sudo apt-key add -
echo "deb [ arch=amd64,arm64 ] https://repo.mongodb.org/apt/ubuntu jammy/mongodb-org/6.0 multiverse" | sudo tee /etc/apt/sources.list.d/mongodb-org-6.0.list
sudo apt update
sudo apt install -y mongodb-org
sudo systemctl start mongod
sudo systemctl enable mongod
```

#### 3. Deploy Application
```bash
# Clone repository
cd /var/www
sudo git clone https://github.com/yourusername/zoo-beauty.git
cd zoo-beauty

# Backend setup
cd backend
sudo npm ci --only=production
sudo nano .env  # Add environment variables
sudo pm2 start server.js --name zoo-beauty-api
sudo pm2 save
sudo pm2 startup

# Frontend setup
cd ../frontend
sudo npm ci
sudo npm run build

# Copy build to Nginx
sudo cp -r dist/* /var/www/html/
```

#### 4. Configure Nginx
```bash
sudo nano /etc/nginx/sites-available/zoo-beauty
```

```nginx
# Frontend
server {
    listen 80;
    server_name zoobeauty.com www.zoobeauty.com;
    root /var/www/html;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }

    gzip on;
    gzip_types text/plain text/css application/json application/javascript text/xml application/xml application/xml+rss text/javascript;
}

# Backend API
server {
    listen 80;
    server_name api.zoobeauty.com;

    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

```bash
# Enable site
sudo ln -s /etc/nginx/sites-available/zoo-beauty /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

#### 5. Setup SSL
```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d zoobeauty.com -d www.zoobeauty.com -d api.zoobeauty.com
```

---

### Option 4: Heroku Deployment

#### Backend

```bash
# Login to Heroku
heroku login

# Create app
heroku create zoo-beauty-api

# Add MongoDB addon
heroku addons:create mongolab:sandbox

# Add Redis addon
heroku addons:create heroku-redis:hobby-dev

# Set environment variables
heroku config:set NODE_ENV=production
heroku config:set JWT_SECRET=your_secret
# ... set all other env vars

# Deploy
git push heroku main

# Scale dynos
heroku ps:scale web=1
```

#### Frontend

```bash
# Build frontend
npm run build

# Deploy to Netlify/Vercel
# Or use Heroku static buildpack
```

---

## Database Setup

### MongoDB Atlas

1. Create cluster
2. Configure network access (allow all IPs for production)
3. Create database user
4. Create database: `zoobeauty`
5. Get connection string
6. Add to backend `.env`

### Indexes

Run these commands in MongoDB shell:

```javascript
// Users collection
db.users.createIndex({ email: 1 }, { unique: true });
db.users.createIndex({ role: 1 });
db.users.createIndex({ isActive: 1 });

// Providers collection
db.providers.createIndex({ userId: 1 }, { unique: true });
db.providers.createIndex({ location: "2dsphere" });
db.providers.createIndex({ "subscription.status": 1 });
db.providers.createIndex({ isVisible: 1 });
db.providers.createIndex({ "rating.average": -1 });

// Bookings collection
db.bookings.createIndex({ bookingNumber: 1 }, { unique: true });
db.bookings.createIndex({ clientId: 1 });
db.bookings.createIndex({ providerId: 1 });
db.bookings.createIndex({ status: 1 });
db.bookings.createIndex({ scheduledDate: 1 });

// Reviews collection
db.reviews.createIndex({ bookingId: 1 }, { unique: true });
db.reviews.createIndex({ providerId: 1 });
db.reviews.createIndex({ rating: -1 });

// Messages collection
db.messages.createIndex({ conversationId: 1 });
db.messages.createIndex({ senderId: 1 });
db.messages.createIndex({ receiverId: 1 });
db.messages.createIndex({ createdAt: -1 });

// Payments collection
db.payments.createIndex({ transactionId: 1 }, { unique: true });
db.payments.createIndex({ userId: 1 });
db.payments.createIndex({ status: 1 });
```

---

## CI/CD Pipeline

### GitHub Actions

Create `.github/workflows/deploy.yml`:

```yaml
name: Deploy to Production

on:
  push:
    branches: [ main ]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - name: Setup Node.js
        uses: actions/setup-node@v3
        with:
          node-version: '18'
      - name: Install dependencies
        run: |
          cd backend && npm ci
          cd ../frontend && npm ci
      - name: Run tests
        run: |
          cd backend && npm test
          cd ../frontend && npm test

  deploy-backend:
    needs: test
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - name: Deploy to server
        uses: appleboy/ssh-action@master
        with:
          host: ${{ secrets.SERVER_HOST }}
          username: ${{ secrets.SERVER_USER }}
          key: ${{ secrets.SSH_PRIVATE_KEY }}
          script: |
            cd /var/www/zoo-beauty
            git pull origin main
            cd backend
            npm ci --only=production
            pm2 restart zoo-beauty-api

  deploy-frontend:
    needs: test
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - name: Build frontend
        run: |
          cd frontend
          npm ci
          npm run build
      - name: Deploy to S3
        uses: jakejarvis/s3-sync-action@master
        with:
          args: --delete
        env:
          AWS_S3_BUCKET: ${{ secrets.AWS_S3_BUCKET }}
          AWS_ACCESS_KEY_ID: ${{ secrets.AWS_ACCESS_KEY_ID }}
          AWS_SECRET_ACCESS_KEY: ${{ secrets.AWS_SECRET_ACCESS_KEY }}
          SOURCE_DIR: 'frontend/dist'
```

---

## Monitoring & Logging

### PM2 Monitoring

```bash
# View logs
pm2 logs zoo-beauty-api

# Monitor resources
pm2 monit

# View process info
pm2 info zoo-beauty-api
```

### Application Monitoring

Use services like:
- **Sentry** - Error tracking
- **New Relic** - Performance monitoring
- **LogRocket** - Session replay
- **DataDog** - Infrastructure monitoring

### Setup Sentry

```bash
npm install @sentry/node @sentry/tracing
```

```javascript
// backend/server.js
const Sentry = require("@sentry/node");

Sentry.init({
  dsn: process.env.SENTRY_DSN,
  environment: process.env.NODE_ENV,
  tracesSampleRate: 1.0,
});
```

---

## Backup Strategy

### Database Backups

```bash
# Daily backup script
#!/bin/bash
DATE=$(date +%Y%m%d_%H%M%S)
mongodump --uri="$MONGODB_URI" --out="/backups/mongodb_$DATE"

# Upload to S3
aws s3 sync /backups s3://zoo-beauty-backups/

# Keep only last 30 days
find /backups -type d -mtime +30 -exec rm -rf {} \;
```

### Automated Backups with Cron

```bash
# Edit crontab
crontab -e

# Add daily backup at 2 AM
0 2 * * * /path/to/backup-script.sh
```

---

## Security Checklist

- [ ] SSL/TLS certificates installed
- [ ] Environment variables secured
- [ ] Database access restricted
- [ ] Rate limiting enabled
- [ ] CORS configured properly
- [ ] Helmet.js middleware added
- [ ] Input validation on all endpoints
- [ ] SQL injection prevention
- [ ] XSS protection
- [ ] CSRF tokens implemented
- [ ] Secure password hashing (bcrypt)
- [ ] JWT tokens with expiration
- [ ] File upload restrictions
- [ ] API authentication required
- [ ] Regular security updates
- [ ] Firewall configured
- [ ] DDoS protection enabled
- [ ] Regular backups automated
- [ ] Monitoring and alerts setup
- [ ] Error messages sanitized

---

## Performance Optimization

### Backend

- Enable gzip compression
- Implement Redis caching
- Use database indexes
- Optimize queries with aggregation
- Enable connection pooling
- Use CDN for static assets
- Implement lazy loading
- Minify responses

### Frontend

- Code splitting
- Lazy load components
- Image optimization
- Enable browser caching
- Use service workers (PWA)
- Minimize bundle size
- Tree shaking
- Preload critical resources

---

## Scaling Strategy

### Horizontal Scaling

```yaml
# docker-compose.scale.yml
version: '3.8'

services:
  backend:
    build: ./backend
    deploy:
      replicas: 3
    environment:
      - NODE_ENV=production
    env_file:
      - ./backend/.env

  nginx:
    image: nginx:alpine
    ports:
      - "80:80"
    volumes:
      - ./nginx-lb.conf:/etc/nginx/nginx.conf
    depends_on:
      - backend
```

### Load Balancer Configuration

```nginx
upstream backend {
    least_conn;
    server backend_1:5000;
    server backend_2:5000;
    server backend_3:5000;
}

server {
    listen 80;
    
    location / {
        proxy_pass http://backend;
    }
}
```

---

## Post-Deployment

1. **Test all functionalities**
   - User registration/login
   - Provider search
   - Booking creation
   - Payment processing
   - Chat messaging
   - Notifications

2. **Monitor performance**
   - Response times
   - Error rates
   - Resource usage
   - Database queries

3. **Setup alerts**
   - Server downtime
   - High error rates
   - Payment failures
   - Database issues

4. **Regular maintenance**
   - Update dependencies
   - Review logs
   - Optimize queries
   - Clean up old data

---

**Last Updated:** 2025-11-27
