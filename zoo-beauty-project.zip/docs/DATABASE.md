# 🗄️ Database Schema Documentation

## Overview

Zoo Beauty uses MongoDB as the primary database. This document outlines all collections, their schemas, relationships, and indexes.

## Collections

### 1. Users Collection

Base collection for all user types (Admin, Provider, Client)

```javascript
{
  _id: ObjectId,
  email: String (unique, required),
  password: String (hashed, required),
  role: String (enum: ['admin', 'provider', 'client'], required),
  firstName: String (required),
  lastName: String (required),
  phone: String (required),
  avatar: String (URL),
  isActive: Boolean (default: true),
  isVerified: Boolean (default: false),
  verificationToken: String,
  resetPasswordToken: String,
  resetPasswordExpires: Date,
  preferences: {
    language: String (default: 'en'),
    theme: String (enum: ['light', 'dark'], default: 'light'),
    notifications: {
      email: Boolean (default: true),
      push: Boolean (default: true),
      sms: Boolean (default: false)
    }
  },
  createdAt: Date,
  updatedAt: Date,
  lastLogin: Date
}
```

**Indexes:**
- `email` (unique)
- `role`
- `isActive`
- `createdAt`

---

### 2. Providers Collection

Extended profile for service providers

```javascript
{
  _id: ObjectId,
  userId: ObjectId (ref: 'Users', required),
  businessName: String (required),
  bio: String (max: 500),
  specializations: [String] (required),
  // e.g., ['Makeup', 'Wig Installation', 'Nails']
  
  location: {
    type: String (enum: ['Point'], required),
    coordinates: [Number] (required), // [longitude, latitude]
    address: String (required),
    city: String (required),
    state: String,
    country: String (required),
    zipCode: String
  },
  
  serviceType: String (enum: ['on-site', 'remote', 'both'], required),
  studioAddress: String, // If remote service is offered
  
  portfolio: [{
    type: String (enum: ['image', 'video']),
    url: String (required),
    caption: String,
    uploadedAt: Date
  }],
  
  services: [{
    serviceId: ObjectId (ref: 'Services'),
    customName: String,
    price: Number (required),
    duration: Number (required), // in minutes
    description: String
  }],
  
  availability: {
    monday: { isAvailable: Boolean, slots: [{ start: String, end: String }] },
    tuesday: { isAvailable: Boolean, slots: [{ start: String, end: String }] },
    wednesday: { isAvailable: Boolean, slots: [{ start: String, end: String }] },
    thursday: { isAvailable: Boolean, slots: [{ start: String, end: String }] },
    friday: { isAvailable: Boolean, slots: [{ start: String, end: String }] },
    saturday: { isAvailable: Boolean, slots: [{ start: String, end: String }] },
    sunday: { isAvailable: Boolean, slots: [{ start: String, end: String }] }
  },
  
  rating: {
    average: Number (default: 0, min: 0, max: 5),
    count: Number (default: 0)
  },
  
  subscription: {
    planId: ObjectId (ref: 'SubscriptionPlans'),
    status: String (enum: ['active', 'expired', 'cancelled'], default: 'expired'),
    startDate: Date,
    endDate: Date,
    autoRenew: Boolean (default: true)
  },
  
  isOnline: Boolean (default: false),
  isVisible: Boolean (default: false), // Controlled by subscription status
  
  stats: {
    totalBookings: Number (default: 0),
    completedBookings: Number (default: 0),
    cancelledBookings: Number (default: 0),
    totalEarnings: Number (default: 0)
  },
  
  bankDetails: {
    accountName: String,
    accountNumber: String,
    bankName: String,
    routingNumber: String
  },
  
  documents: [{
    type: String (enum: ['license', 'certification', 'insurance']),
    url: String,
    verifiedAt: Date,
    verifiedBy: ObjectId (ref: 'Users')
  }],
  
  socialMedia: {
    instagram: String,
    facebook: String,
    twitter: String,
    tiktok: String,
    website: String
  },
  
  createdAt: Date,
  updatedAt: Date
}
```

**Indexes:**
- `userId` (unique)
- `location` (2dsphere)
- `specializations`
- `subscription.status`
- `isVisible`
- `rating.average`
- `createdAt`

---

### 3. Services Collection

Master list of available service categories

```javascript
{
  _id: ObjectId,
  name: String (required, unique),
  slug: String (required, unique),
  description: String,
  category: String (enum: ['hair', 'makeup', 'nails', 'skin', 'body', 'other']),
  icon: String (URL),
  isActive: Boolean (default: true),
  suggestedPrice: {
    min: Number,
    max: Number
  },
  suggestedDuration: Number, // in minutes
  createdAt: Date,
  updatedAt: Date
}
```

**Indexes:**
- `slug` (unique)
- `category`
- `isActive`

**Sample Services:**
- Wig Installation
- Makeup Application
- Barbering
- Tattoo Art
- Hair Coloring
- Manicure/Pedicure
- Facial Treatment
- Dreadlock Installation
- Hair Braiding
- Massage Therapy
- Eyelash Extensions
- Eyebrow Shaping

---

### 4. Bookings Collection

All service bookings

```javascript
{
  _id: ObjectId,
  bookingNumber: String (unique, auto-generated),
  
  clientId: ObjectId (ref: 'Users', required),
  providerId: ObjectId (ref: 'Providers', required),
  
  service: {
    serviceId: ObjectId (ref: 'Services'),
    name: String (required),
    price: Number (required),
    duration: Number (required)
  },
  
  scheduledDate: Date (required),
  scheduledTime: String (required),
  
  location: {
    type: String (enum: ['on-site', 'remote'], required),
    address: String, // Client's address for on-site
    coordinates: [Number], // [longitude, latitude]
    notes: String
  },
  
  status: String (
    enum: ['pending', 'accepted', 'in-progress', 'completed', 'cancelled', 'rejected'],
    default: 'pending'
  ),
  
  payment: {
    amount: Number (required),
    platformFee: Number,
    providerEarnings: Number,
    status: String (enum: ['pending', 'paid', 'refunded'], default: 'pending'),
    method: String (enum: ['card', 'wallet', 'cash']),
    transactionId: String,
    paidAt: Date
  },
  
  timeline: [{
    status: String,
    timestamp: Date,
    note: String
  }],
  
  cancellation: {
    cancelledBy: ObjectId (ref: 'Users'),
    reason: String,
    cancelledAt: Date
  },
  
  notes: String,
  
  createdAt: Date,
  updatedAt: Date
}
```

**Indexes:**
- `bookingNumber` (unique)
- `clientId`
- `providerId`
- `status`
- `scheduledDate`
- `createdAt`

---

### 5. Reviews Collection

Client reviews for providers

```javascript
{
  _id: ObjectId,
  bookingId: ObjectId (ref: 'Bookings', required),
  clientId: ObjectId (ref: 'Users', required),
  providerId: ObjectId (ref: 'Providers', required),
  
  rating: Number (required, min: 1, max: 5),
  
  review: {
    quality: Number (min: 1, max: 5),
    punctuality: Number (min: 1, max: 5),
    professionalism: Number (min: 1, max: 5),
    value: Number (min: 1, max: 5)
  },
  
  comment: String (max: 1000),
  
  images: [String], // URLs
  
  response: {
    text: String,
    respondedAt: Date
  },
  
  isModerated: Boolean (default: false),
  moderatedBy: ObjectId (ref: 'Users'),
  moderationNote: String,
  
  isVisible: Boolean (default: true),
  
  helpfulCount: Number (default: 0),
  
  createdAt: Date,
  updatedAt: Date
}
```

**Indexes:**
- `bookingId` (unique)
- `providerId`
- `clientId`
- `rating`
- `createdAt`

---

### 6. SubscriptionPlans Collection

Available subscription plans for providers

```javascript
{
  _id: ObjectId,
  name: String (required),
  slug: String (required, unique),
  description: String,
  
  price: Number (required),
  currency: String (default: 'USD'),
  
  duration: Number (required), // in days
  
  features: [{
    name: String,
    included: Boolean,
    limit: Number // null for unlimited
  }],
  
  benefits: {
    maxPortfolioItems: Number,
    maxServices: Number,
    priorityListing: Boolean,
    analyticsAccess: Boolean,
    featuredBadge: Boolean,
    customBranding: Boolean
  },
  
  isActive: Boolean (default: true),
  isPopular: Boolean (default: false),
  
  sortOrder: Number (default: 0),
  
  createdAt: Date,
  updatedAt: Date
}
```

**Indexes:**
- `slug` (unique)
- `isActive`
- `sortOrder`

**Sample Plans:**
- Basic (30 days - $29.99)
- Professional (30 days - $49.99)
- Premium (30 days - $79.99)

---

### 7. Payments Collection

All financial transactions

```javascript
{
  _id: ObjectId,
  transactionId: String (unique, required),
  
  type: String (enum: ['booking', 'subscription', 'refund', 'payout'], required),
  
  userId: ObjectId (ref: 'Users', required),
  relatedId: ObjectId, // Booking or Subscription ID
  
  amount: Number (required),
  currency: String (default: 'USD'),
  
  platformFee: Number,
  netAmount: Number,
  
  status: String (
    enum: ['pending', 'processing', 'completed', 'failed', 'refunded'],
    default: 'pending'
  ),
  
  paymentMethod: String (enum: ['card', 'wallet', 'bank_transfer', 'cash']),
  
  gateway: String (enum: ['stripe', 'paystack', 'paypal']),
  gatewayTransactionId: String,
  
  metadata: {
    cardLast4: String,
    cardBrand: String,
    receiptUrl: String
  },
  
  refund: {
    amount: Number,
    reason: String,
    refundedAt: Date,
    refundTransactionId: String
  },
  
  createdAt: Date,
  updatedAt: Date
}
```

**Indexes:**
- `transactionId` (unique)
- `userId`
- `type`
- `status`
- `createdAt`

---

### 8. Messages Collection

Chat messages between clients and providers

```javascript
{
  _id: ObjectId,
  conversationId: String (required),
  
  senderId: ObjectId (ref: 'Users', required),
  receiverId: ObjectId (ref: 'Users', required),
  
  message: String (required, max: 2000),
  
  type: String (enum: ['text', 'image', 'file'], default: 'text'),
  attachments: [{
    type: String,
    url: String,
    filename: String,
    size: Number
  }],
  
  isRead: Boolean (default: false),
  readAt: Date,
  
  isDeleted: Boolean (default: false),
  deletedBy: [ObjectId],
  
  createdAt: Date,
  updatedAt: Date
}
```

**Indexes:**
- `conversationId`
- `senderId`
- `receiverId`
- `createdAt`

---

### 9. Notifications Collection

System notifications

```javascript
{
  _id: ObjectId,
  userId: ObjectId (ref: 'Users', required),
  
  type: String (
    enum: [
      'booking_created',
      'booking_accepted',
      'booking_cancelled',
      'payment_received',
      'subscription_expiring',
      'subscription_expired',
      'new_review',
      'new_message',
      'system_announcement'
    ],
    required
  ),
  
  title: String (required),
  message: String (required),
  
  data: {}, // Additional context data
  
  isRead: Boolean (default: false),
  readAt: Date,
  
  actionUrl: String,
  
  createdAt: Date
}
```

**Indexes:**
- `userId`
- `isRead`
- `createdAt`

---

### 10. Favorites Collection

Client's favorite providers

```javascript
{
  _id: ObjectId,
  clientId: ObjectId (ref: 'Users', required),
  providerId: ObjectId (ref: 'Providers', required),
  createdAt: Date
}
```

**Indexes:**
- Compound: `{ clientId: 1, providerId: 1 }` (unique)

---

### 11. Analytics Collection

Platform analytics and metrics

```javascript
{
  _id: ObjectId,
  date: Date (required),
  
  metrics: {
    newUsers: Number,
    newProviders: Number,
    newClients: Number,
    totalBookings: Number,
    completedBookings: Number,
    cancelledBookings: Number,
    revenue: Number,
    platformFees: Number,
    activeSubscriptions: Number
  },
  
  topProviders: [{
    providerId: ObjectId,
    bookings: Number,
    earnings: Number,
    rating: Number
  }],
  
  topServices: [{
    serviceId: ObjectId,
    bookings: Number,
    revenue: Number
  }],
  
  geographicData: [{
    city: String,
    bookings: Number,
    providers: Number,
    clients: Number
  }],
  
  createdAt: Date
}
```

**Indexes:**
- `date` (unique)
- `createdAt`

---

### 12. Disputes Collection

Booking disputes and resolution

```javascript
{
  _id: ObjectId,
  bookingId: ObjectId (ref: 'Bookings', required),
  
  reportedBy: ObjectId (ref: 'Users', required),
  reportedAgainst: ObjectId (ref: 'Users', required),
  
  reason: String (
    enum: [
      'no_show',
      'poor_service',
      'payment_issue',
      'unprofessional_behavior',
      'other'
    ],
    required
  ),
  
  description: String (required),
  evidence: [String], // URLs to images/documents
  
  status: String (
    enum: ['open', 'investigating', 'resolved', 'closed'],
    default: 'open'
  ),
  
  assignedTo: ObjectId (ref: 'Users'), // Admin
  
  resolution: {
    action: String,
    note: String,
    resolvedBy: ObjectId (ref: 'Users'),
    resolvedAt: Date
  },
  
  createdAt: Date,
  updatedAt: Date
}
```

**Indexes:**
- `bookingId`
- `status`
- `createdAt`

---

## Relationships

```
Users (1) ──→ (1) Providers
Users (1) ──→ (N) Bookings (as client)
Providers (1) ──→ (N) Bookings
Bookings (1) ──→ (0..1) Reviews
Providers (1) ──→ (N) Reviews
Users (1) ──→ (N) Messages
Users (1) ──→ (N) Payments
Users (1) ──→ (N) Notifications
Providers (1) ──→ (1) SubscriptionPlans
Services (1) ──→ (N) Providers.services
Bookings (1) ──→ (0..1) Disputes
```

## Data Integrity Rules

1. **Cascade Deletes:**
   - Deleting a User → Soft delete (set isActive: false)
   - Deleting a Provider → Soft delete, cancel active bookings
   - Deleting a Booking → Keep for records, mark as deleted

2. **Validation Rules:**
   - Provider can't be visible without active subscription
   - Booking can't be created for past dates
   - Review can only be created after booking completion
   - Payment must be completed before booking confirmation

3. **Business Rules:**
   - Provider subscription expires → isVisible = false
   - Booking cancelled within 24h → Full refund
   - Provider rating updates → Recalculate average from all reviews
   - Subscription auto-renewal → Check 1 day before expiry

## Performance Optimization

1. **Caching Strategy:**
   - Cache provider search results (5 minutes)
   - Cache service categories (1 hour)
   - Cache subscription plans (1 hour)
   - Cache user sessions (Redis)

2. **Query Optimization:**
   - Use projection to limit returned fields
   - Implement pagination for all lists
   - Use aggregation pipeline for analytics
   - Denormalize frequently accessed data

3. **Geospatial Queries:**
   ```javascript
   db.providers.find({
     location: {
       $near: {
         $geometry: { type: "Point", coordinates: [lng, lat] },
         $maxDistance: 10000 // 10km
       }
     },
     isVisible: true
   })
   ```

## Backup Strategy

- **Daily backups** at 2 AM UTC
- **Retention:** 30 days
- **Incremental backups** every 6 hours
- **Disaster recovery plan** with 4-hour RTO

---

**Last Updated:** 2025-11-27
