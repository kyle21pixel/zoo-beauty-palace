# 🔄 User Flows Documentation

## Overview

This document outlines the complete user journeys for all three user types in the Zoo Beauty platform.

---

## 1. 👤 Client User Flows

### 1.1 Registration & Onboarding

```
START
  ↓
Landing Page
  ↓
Click "Sign Up as Client"
  ↓
Registration Form
  ├─ Email
  ├─ Password
  ├─ First Name
  ├─ Last Name
  └─ Phone Number
  ↓
Email Verification
  ├─ Receive verification email
  └─ Click verification link
  ↓
Complete Profile
  ├─ Upload profile photo
  ├─ Add location
  └─ Set preferences
  ↓
Onboarding Tutorial
  ├─ How to search providers
  ├─ How to book services
  └─ How to make payments
  ↓
Client Dashboard
END
```

### 1.2 Searching & Booking a Service

```
START (Client Dashboard)
  ↓
Search for Service
  ├─ Enter service type (e.g., "Makeup")
  ├─ Set location/radius
  ├─ Apply filters:
  │   ├─ Price range
  │   ├─ Rating
  │   ├─ Service type (on-site/remote)
  │   └─ Availability
  └─ View results on map/list
  ↓
Browse Provider Profiles
  ├─ View portfolio
  ├─ Check ratings & reviews
  ├─ See pricing
  └─ Check availability
  ↓
Select Provider
  ↓
Choose Service Details
  ├─ Select specific service
  ├─ Choose date & time
  ├─ Select location type
  │   ├─ On-site → Enter address
  │   └─ Remote → View provider location
  └─ Add special notes
  ↓
Review Booking Summary
  ├─ Service details
  ├─ Provider info
  ├─ Date & time
  ├─ Location
  └─ Total price
  ↓
Payment
  ├─ Select payment method
  │   ├─ Credit/Debit card
  │   ├─ Wallet
  │   └─ Cash (if allowed)
  └─ Complete payment
  ↓
Booking Confirmation
  ├─ Receive confirmation email
  ├─ Receive SMS notification
  └─ View booking in dashboard
  ↓
Wait for Provider Acceptance
  ├─ Accepted → Booking confirmed
  └─ Rejected → Refund initiated
END
```

### 1.3 Managing Active Booking

```
START (Active Booking)
  ↓
View Booking Details
  ├─ Service info
  ├─ Provider contact
  ├─ Date & time
  └─ Location
  ↓
Available Actions:
  ├─ Chat with Provider
  │   ├─ Send message
  │   ├─ Share images
  │   └─ Get updates
  │
  ├─ Reschedule Booking
  │   ├─ Select new date/time
  │   ├─ Provider approval required
  │   └─ Confirmation
  │
  ├─ Cancel Booking
  │   ├─ Select cancellation reason
  │   ├─ Confirm cancellation
  │   └─ Refund processing
  │       ├─ >24h before → Full refund
  │       └─ <24h before → Partial/No refund
  │
  └─ Track Provider (on booking day)
      ├─ View provider location (on-site)
      ├─ Estimated arrival time
      └─ Real-time updates
  ↓
Service Completion
  ↓
Leave Review
  ├─ Rate overall (1-5 stars)
  ├─ Rate categories:
  │   ├─ Quality
  │   ├─ Punctuality
  │   ├─ Professionalism
  │   └─ Value
  ├─ Write comment
  └─ Upload photos (optional)
  ↓
Submit Review
END
```

### 1.4 Managing Favorites

```
START
  ↓
Browse Providers
  ↓
Find Provider to Favorite
  ↓
Click "Add to Favorites"
  ↓
Provider Added to Favorites List
  ↓
Access Favorites
  ├─ View all favorite providers
  ├─ Quick book from favorites
  └─ Remove from favorites
END
```

---

## 2. 💼 Service Provider User Flows

### 2.1 Registration & Subscription

```
START
  ↓
Landing Page
  ↓
Click "Become a Provider"
  ↓
Registration Form
  ├─ Email
  ├─ Password
  ├─ First Name
  ├─ Last Name
  ├─ Phone Number
  └─ Business Name
  ↓
Email Verification
  ↓
Complete Provider Profile
  ├─ Upload profile photo
  ├─ Add bio
  ├─ Select specializations
  ├─ Set location
  ├─ Choose service type (on-site/remote/both)
  └─ Add studio address (if remote)
  ↓
Upload Documents (Optional)
  ├─ Business license
  ├─ Certifications
  └─ Insurance
  ↓
Choose Subscription Plan
  ├─ View plan comparison
  │   ├─ Basic - $29.99/month
  │   ├─ Professional - $49.99/month
  │   └─ Premium - $79.99/month
  ├─ Select plan
  └─ Complete payment
  ↓
Subscription Activated
  ├─ Profile becomes visible
  └─ Can receive bookings
  ↓
Setup Services & Pricing
  ├─ Add services offered
  ├─ Set prices
  ├─ Set duration
  └─ Add descriptions
  ↓
Set Availability
  ├─ Configure weekly schedule
  ├─ Set working hours
  └─ Block specific dates
  ↓
Upload Portfolio
  ├─ Add photos of work
  ├─ Add videos
  └─ Add captions
  ↓
Provider Dashboard
END
```

### 2.2 Managing Bookings

```
START (Provider Dashboard)
  ↓
Receive Booking Request
  ├─ Push notification
  ├─ Email notification
  └─ SMS notification
  ↓
View Booking Details
  ├─ Client information
  ├─ Service requested
  ├─ Date & time
  ├─ Location
  ├─ Price
  └─ Special notes
  ↓
Check Availability
  ↓
Decision:
  ├─ ACCEPT
  │   ├─ Confirm booking
  │   ├─ Client notified
  │   └─ Add to calendar
  │
  └─ DECLINE
      ├─ Select reason
      ├─ Client notified
      └─ Refund initiated
  ↓
(If Accepted) Manage Booking
  ├─ Chat with Client
  │   ├─ Discuss details
  │   ├─ Share portfolio
  │   └─ Confirm requirements
  │
  ├─ View Client Location (on-site)
  │   ├─ Get directions
  │   └─ Navigate to location
  │
  ├─ Update Booking Status
  │   ├─ Mark "In Progress"
  │   └─ Mark "Completed"
  │
  └─ Request Reschedule
      ├─ Propose new time
      ├─ Client approval
      └─ Update confirmed
  ↓
Complete Service
  ├─ Mark as completed
  ├─ Payment released
  └─ Earnings updated
  ↓
Receive Review
  ├─ View rating
  ├─ Read comment
  └─ Respond to review (optional)
END
```

### 2.3 Managing Portfolio

```
START (Provider Dashboard)
  ↓
Navigate to Portfolio Section
  ↓
Add New Item
  ├─ Upload image/video
  ├─ Add caption
  ├─ Tag services
  └─ Save
  ↓
Organize Portfolio
  ├─ Reorder items
  ├─ Edit captions
  └─ Delete items
  ↓
Portfolio Updated
  ├─ Visible to clients
  └─ Enhances profile
END
```

### 2.4 Subscription Management

```
START
  ↓
View Subscription Status
  ├─ Current plan
  ├─ Expiry date
  ├─ Days remaining
  └─ Auto-renewal status
  ↓
Receive Expiry Notifications
  ├─ 7 days before
  ├─ 3 days before
  └─ 1 day before
  ↓
Actions:
  ├─ Renew Subscription
  │   ├─ Same plan
  │   └─ Upgrade plan
  │
  ├─ Enable/Disable Auto-Renewal
  │
  └─ Cancel Subscription
      ├─ Confirm cancellation
      ├─ Service until expiry
      └─ Profile becomes invisible
  ↓
(If Expired & Not Renewed)
  ├─ Profile hidden from search
  ├─ Cannot receive new bookings
  ├─ Can still complete existing bookings
  └─ Prompted to renew
END
```

### 2.5 Earnings & Payouts

```
START (Provider Dashboard)
  ↓
View Earnings Dashboard
  ├─ Total earnings
  ├─ This month
  ├─ Pending payments
  └─ Completed bookings
  ↓
View Transaction History
  ├─ Filter by date
  ├─ Filter by status
  └─ Export report
  ↓
Request Payout
  ├─ Check minimum threshold
  ├─ Select payout method
  ├─ Confirm bank details
  └─ Submit request
  ↓
Payout Processing
  ├─ Admin approval
  ├─ Processing (2-5 days)
  └─ Completed
  ↓
Receive Payout Confirmation
END
```

---

## 3. 🔧 Admin User Flows

### 3.1 Dashboard Overview

```
START (Admin Login)
  ↓
Admin Dashboard
  ├─ Key Metrics
  │   ├─ Total users
  │   ├─ Active providers
  │   ├─ Total bookings
  │   ├─ Revenue
  │   └─ Growth charts
  │
  ├─ Recent Activity
  │   ├─ New registrations
  │   ├─ Recent bookings
  │   ├─ Pending disputes
  │   └─ System alerts
  │
  └─ Quick Actions
      ├─ Manage users
      ├─ View reports
      ├─ Handle disputes
      └─ System settings
END
```

### 3.2 User Management

```
START (Admin Dashboard)
  ↓
Navigate to User Management
  ↓
View All Users
  ├─ Filter by role
  │   ├─ Clients
  │   ├─ Providers
  │   └─ Admins
  ├─ Search by name/email
  └─ Sort by date/status
  ↓
Select User
  ↓
View User Details
  ├─ Personal information
  ├─ Account status
  ├─ Activity history
  ├─ Bookings (if client)
  ├─ Earnings (if provider)
  └─ Reviews
  ↓
Available Actions:
  ├─ Edit User
  │   ├─ Update information
  │   └─ Save changes
  │
  ├─ Suspend Account
  │   ├─ Select reason
  │   ├─ Set duration
  │   ├─ Notify user
  │   └─ Confirm suspension
  │
  ├─ Activate Account
  │   └─ Restore access
  │
  ├─ Delete Account
  │   ├─ Confirm deletion
  │   ├─ Handle active bookings
  │   └─ Archive data
  │
  └─ View Activity Log
      ├─ Login history
      ├─ Transactions
      └─ Actions taken
END
```

### 3.3 Subscription Plan Management

```
START (Admin Dashboard)
  ↓
Navigate to Subscription Plans
  ↓
View All Plans
  ├─ Basic
  ├─ Professional
  └─ Premium
  ↓
Actions:
  ├─ Create New Plan
  │   ├─ Set name & description
  │   ├─ Set price & duration
  │   ├─ Define features
  │   ├─ Set limits
  │   └─ Activate plan
  │
  ├─ Edit Existing Plan
  │   ├─ Update pricing
  │   ├─ Modify features
  │   ├─ Change limits
  │   └─ Save changes
  │
  ├─ Deactivate Plan
  │   ├─ Hide from new subscriptions
  │   └─ Existing subscriptions continue
  │
  └─ View Plan Analytics
      ├─ Active subscribers
      ├─ Revenue per plan
      └─ Conversion rates
END
```

### 3.4 Service Category Management

```
START (Admin Dashboard)
  ↓
Navigate to Service Categories
  ↓
View All Services
  ├─ Hair services
  ├─ Makeup services
  ├─ Nail services
  └─ Other categories
  ↓
Actions:
  ├─ Add New Service
  │   ├─ Enter name
  │   ├─ Add description
  │   ├─ Select category
  │   ├─ Upload icon
  │   ├─ Set suggested pricing
  │   └─ Activate service
  │
  ├─ Edit Service
  │   ├─ Update details
  │   └─ Save changes
  │
  ├─ Deactivate Service
  │   └─ Hide from listings
  │
  └─ Reorder Services
      └─ Drag & drop to sort
END
```

### 3.5 Dispute Resolution

```
START (Admin Dashboard)
  ↓
Navigate to Disputes
  ↓
View All Disputes
  ├─ Filter by status
  │   ├─ Open
  │   ├─ Investigating
  │   └─ Resolved
  └─ Sort by date/priority
  ↓
Select Dispute
  ↓
View Dispute Details
  ├─ Booking information
  ├─ Parties involved
  ├─ Reason for dispute
  ├─ Evidence submitted
  └─ Communication history
  ↓
Investigate
  ├─ Review evidence
  ├─ Contact parties
  ├─ Check booking history
  └─ Review policies
  ↓
Take Action:
  ├─ Issue Refund
  │   ├─ Full refund
  │   └─ Partial refund
  │
  ├─ Penalize Provider
  │   ├─ Warning
  │   ├─ Temporary suspension
  │   └─ Permanent ban
  │
  ├─ Penalize Client
  │   ├─ Warning
  │   └─ Account suspension
  │
  └─ No Action Required
      └─ Close dispute
  ↓
Document Resolution
  ├─ Add resolution notes
  ├─ Notify parties
  └─ Close dispute
END
```

### 3.6 Analytics & Reports

```
START (Admin Dashboard)
  ↓
Navigate to Analytics
  ↓
Select Report Type:
  ├─ User Growth
  │   ├─ New registrations
  │   ├─ Active users
  │   └─ Churn rate
  │
  ├─ Booking Analytics
  │   ├─ Total bookings
  │   ├─ Completion rate
  │   ├─ Cancellation rate
  │   └─ Popular services
  │
  ├─ Revenue Reports
  │   ├─ Total revenue
  │   ├─ Platform fees
  │   ├─ Revenue by service
  │   └─ Revenue trends
  │
  ├─ Provider Performance
  │   ├─ Top providers
  │   ├─ Average ratings
  │   ├─ Booking frequency
  │   └─ Earnings distribution
  │
  └─ Geographic Analysis
      ├─ Bookings by location
      ├─ Provider distribution
      └─ Market penetration
  ↓
Customize Report
  ├─ Select date range
  ├─ Apply filters
  └─ Choose visualization
  ↓
View Report
  ├─ Interactive charts
  ├─ Data tables
  └─ Key insights
  ↓
Export Report
  ├─ PDF
  ├─ Excel
  └─ CSV
END
```

### 3.7 Review Moderation

```
START (Admin Dashboard)
  ↓
Navigate to Reviews
  ↓
View All Reviews
  ├─ Filter by rating
  ├─ Filter by status
  └─ Search by provider
  ↓
Flagged Reviews
  ├─ Inappropriate content
  ├─ Spam
  └─ Fake reviews
  ↓
Review Details
  ├─ Rating
  ├─ Comment
  ├─ Images
  ├─ Booking details
  └─ Provider response
  ↓
Moderate:
  ├─ Approve Review
  │   └─ Make visible
  │
  ├─ Hide Review
  │   ├─ Select reason
  │   └─ Notify parties
  │
  ├─ Edit Review
  │   ├─ Remove inappropriate content
  │   └─ Save changes
  │
  └─ Delete Review
      ├─ Confirm deletion
      └─ Log action
END
```

### 3.8 Platform Announcements

```
START (Admin Dashboard)
  ↓
Navigate to Announcements
  ↓
Create New Announcement
  ├─ Enter title
  ├─ Write message
  ├─ Select target audience
  │   ├─ All users
  │   ├─ Providers only
  │   ├─ Clients only
  │   └─ Specific users
  ├─ Set priority
  ├─ Schedule delivery
  └─ Add banner (optional)
  ↓
Preview Announcement
  ↓
Publish
  ├─ Send notifications
  ├─ Display in dashboards
  └─ Send emails
  ↓
Track Engagement
  ├─ Views
  ├─ Click-through rate
  └─ Responses
END
```

---

## 4. 🔔 Notification Flows

### 4.1 Client Notifications

- **Booking Confirmed:** "Your booking with [Provider] is confirmed for [Date/Time]"
- **Booking Accepted:** "[Provider] has accepted your booking request"
- **Booking Rejected:** "Your booking request was declined. Refund initiated."
- **Provider En Route:** "[Provider] is on the way to your location"
- **Service Starting:** "Your service is about to begin"
- **Service Completed:** "Service completed. Please leave a review"
- **New Message:** "New message from [Provider]"
- **Favorite Provider Available:** "[Provider] has new availability"

### 4.2 Provider Notifications

- **New Booking Request:** "New booking request from [Client]"
- **Booking Cancelled:** "[Client] has cancelled the booking"
- **Payment Received:** "Payment of $[Amount] received"
- **New Review:** "[Client] left you a review"
- **Subscription Expiring:** "Your subscription expires in [X] days"
- **Subscription Expired:** "Your subscription has expired. Renew now"
- **Payout Processed:** "Payout of $[Amount] has been processed"
- **New Message:** "New message from [Client]"

### 4.3 Admin Notifications

- **New User Registration:** "New [Role] registered: [Name]"
- **New Dispute:** "New dispute filed for booking #[ID]"
- **Subscription Payment Failed:** "[Provider] subscription payment failed"
- **Flagged Review:** "Review flagged for moderation"
- **System Alert:** Various system health alerts

---

## 5. 💳 Payment Flows

### 5.1 Client Payment Flow

```
Booking Created
  ↓
Select Payment Method
  ├─ Saved Card
  ├─ New Card
  └─ Wallet
  ↓
Enter Payment Details
  ↓
Process Payment
  ├─ Success → Booking Confirmed
  └─ Failed → Retry/Cancel
  ↓
Payment Held in Escrow
  ↓
Service Completed
  ↓
Payment Released to Provider
  ↓
Platform Fee Deducted
  ↓
Provider Receives Net Amount
```

### 5.2 Provider Subscription Payment

```
Select Plan
  ↓
Enter Payment Details
  ↓
Process Payment
  ├─ Success → Subscription Activated
  └─ Failed → Retry
  ↓
Auto-Renewal (if enabled)
  ├─ 1 day before expiry
  ├─ Charge saved card
  ├─ Success → Renewed
  └─ Failed → Notify provider
```

### 5.3 Refund Flow

```
Cancellation/Dispute
  ↓
Determine Refund Amount
  ├─ Full refund
  ├─ Partial refund
  └─ No refund
  ↓
Initiate Refund
  ↓
Process Refund (2-5 business days)
  ↓
Client Notified
  ↓
Amount Returned to Original Payment Method
```

---

## 6. 🗺️ Geolocation Flow

### 6.1 Provider Search with Location

```
Client Enters Location
  ↓
Get Coordinates (lat/lng)
  ↓
Query Database
  ├─ Find providers within radius
  ├─ Filter by availability
  ├─ Filter by subscription status
  └─ Sort by distance/rating
  ↓
Display on Map
  ├─ Provider markers
  ├─ Cluster nearby providers
  └─ Show provider cards on click
  ↓
Client Selects Provider
```

### 6.2 On-Site Service Tracking

```
Booking Day
  ↓
Provider Marks "En Route"
  ↓
Enable Location Sharing
  ↓
Client Sees Real-Time Location
  ├─ Provider position on map
  ├─ Estimated arrival time
  └─ Route visualization
  ↓
Provider Arrives
  ↓
Mark "Arrived"
  ↓
Client Notified
```

---

**Last Updated:** 2025-11-27
