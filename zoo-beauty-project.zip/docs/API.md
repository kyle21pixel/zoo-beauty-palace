# 🔌 API Documentation

## Base URL

```
Development: http://localhost:5000/api/v1
Production: https://api.zoobeauty.com/api/v1
```

## Authentication

All authenticated endpoints require a JWT token in the Authorization header:

```
Authorization: Bearer <token>
```

## Response Format

### Success Response
```json
{
  "success": true,
  "data": { ... },
  "message": "Operation successful"
}
```

### Error Response
```json
{
  "success": false,
  "error": {
    "code": "ERROR_CODE",
    "message": "Error description"
  }
}
```

---

## 1. Authentication Endpoints

### 1.1 Register User

**POST** `/auth/register`

Register a new user (client or provider)

**Request Body:**
```json
{
  "email": "user@example.com",
  "password": "SecurePass123!",
  "firstName": "John",
  "lastName": "Doe",
  "phone": "+1234567890",
  "role": "client" // or "provider"
}
```

**Response:** `201 Created`
```json
{
  "success": true,
  "data": {
    "user": {
      "_id": "user_id",
      "email": "user@example.com",
      "firstName": "John",
      "lastName": "Doe",
      "role": "client"
    },
    "token": "jwt_token"
  },
  "message": "Registration successful. Please verify your email."
}
```

---

### 1.2 Login

**POST** `/auth/login`

**Request Body:**
```json
{
  "email": "user@example.com",
  "password": "SecurePass123!"
}
```

**Response:** `200 OK`
```json
{
  "success": true,
  "data": {
    "user": { ... },
    "token": "jwt_token"
  }
}
```

---

### 1.3 Verify Email

**GET** `/auth/verify-email/:token`

**Response:** `200 OK`

---

### 1.4 Forgot Password

**POST** `/auth/forgot-password`

**Request Body:**
```json
{
  "email": "user@example.com"
}
```

**Response:** `200 OK`

---

### 1.5 Reset Password

**POST** `/auth/reset-password/:token`

**Request Body:**
```json
{
  "password": "NewSecurePass123!"
}
```

**Response:** `200 OK`

---

### 1.6 Get Current User

**GET** `/auth/me`

**Headers:** `Authorization: Bearer <token>`

**Response:** `200 OK`
```json
{
  "success": true,
  "data": {
    "user": { ... }
  }
}
```

---

### 1.7 Update Profile

**PUT** `/auth/profile`

**Headers:** `Authorization: Bearer <token>`

**Request Body:**
```json
{
  "firstName": "John",
  "lastName": "Doe",
  "phone": "+1234567890",
  "avatar": "url_to_avatar"
}
```

**Response:** `200 OK`

---

### 1.8 Change Password

**PUT** `/auth/change-password`

**Headers:** `Authorization: Bearer <token>`

**Request Body:**
```json
{
  "currentPassword": "OldPass123!",
  "newPassword": "NewPass123!"
}
```

**Response:** `200 OK`

---

## 2. Provider Endpoints

### 2.1 Complete Provider Profile

**POST** `/providers/profile`

**Headers:** `Authorization: Bearer <token>`

**Request Body:**
```json
{
  "businessName": "Glam Studio",
  "bio": "Professional makeup artist with 10 years experience",
  "specializations": ["Makeup", "Wig Installation"],
  "location": {
    "type": "Point",
    "coordinates": [-73.935242, 40.730610],
    "address": "123 Beauty St",
    "city": "New York",
    "state": "NY",
    "country": "USA",
    "zipCode": "10001"
  },
  "serviceType": "both",
  "studioAddress": "123 Beauty St, New York, NY"
}
```

**Response:** `201 Created`

---

### 2.2 Get Provider Profile

**GET** `/providers/:providerId`

**Response:** `200 OK`
```json
{
  "success": true,
  "data": {
    "provider": {
      "_id": "provider_id",
      "businessName": "Glam Studio",
      "bio": "...",
      "rating": {
        "average": 4.8,
        "count": 125
      },
      "portfolio": [...],
      "services": [...],
      "availability": {...}
    }
  }
}
```

---

### 2.3 Update Provider Profile

**PUT** `/providers/profile`

**Headers:** `Authorization: Bearer <token>`

**Request Body:** (Same as 2.1, partial updates allowed)

**Response:** `200 OK`

---

### 2.4 Add Portfolio Item

**POST** `/providers/portfolio`

**Headers:** `Authorization: Bearer <token>`

**Request Body:**
```json
{
  "type": "image",
  "url": "https://cloudinary.com/...",
  "caption": "Bridal makeup for Sarah"
}
```

**Response:** `201 Created`

---

### 2.5 Delete Portfolio Item

**DELETE** `/providers/portfolio/:itemId`

**Headers:** `Authorization: Bearer <token>`

**Response:** `200 OK`

---

### 2.6 Add Service

**POST** `/providers/services`

**Headers:** `Authorization: Bearer <token>`

**Request Body:**
```json
{
  "serviceId": "service_id",
  "customName": "Bridal Makeup Package",
  "price": 150,
  "duration": 120,
  "description": "Complete bridal makeup with trial"
}
```

**Response:** `201 Created`

---

### 2.7 Update Service

**PUT** `/providers/services/:serviceId`

**Headers:** `Authorization: Bearer <token>`

**Request Body:** (Same as 2.6, partial updates allowed)

**Response:** `200 OK`

---

### 2.8 Delete Service

**DELETE** `/providers/services/:serviceId`

**Headers:** `Authorization: Bearer <token>`

**Response:** `200 OK`

---

### 2.9 Update Availability

**PUT** `/providers/availability`

**Headers:** `Authorization: Bearer <token>`

**Request Body:**
```json
{
  "monday": {
    "isAvailable": true,
    "slots": [
      { "start": "09:00", "end": "12:00" },
      { "start": "14:00", "end": "18:00" }
    ]
  },
  "tuesday": { ... },
  ...
}
```

**Response:** `200 OK`

---

### 2.10 Search Providers

**GET** `/providers/search`

**Query Parameters:**
- `lat` (required): Latitude
- `lng` (required): Longitude
- `radius`: Search radius in meters (default: 10000)
- `service`: Service type filter
- `minRating`: Minimum rating (1-5)
- `maxPrice`: Maximum price
- `serviceType`: 'on-site' | 'remote' | 'both'
- `page`: Page number (default: 1)
- `limit`: Results per page (default: 20)

**Example:**
```
GET /providers/search?lat=40.730610&lng=-73.935242&radius=5000&service=Makeup&minRating=4
```

**Response:** `200 OK`
```json
{
  "success": true,
  "data": {
    "providers": [...],
    "pagination": {
      "page": 1,
      "limit": 20,
      "total": 45,
      "pages": 3
    }
  }
}
```

---

### 2.11 Get Provider Stats

**GET** `/providers/stats`

**Headers:** `Authorization: Bearer <token>`

**Response:** `200 OK`
```json
{
  "success": true,
  "data": {
    "stats": {
      "totalBookings": 150,
      "completedBookings": 142,
      "cancelledBookings": 8,
      "totalEarnings": 15420.50,
      "averageRating": 4.8,
      "reviewCount": 125
    }
  }
}
```

---

## 3. Booking Endpoints

### 3.1 Create Booking

**POST** `/bookings`

**Headers:** `Authorization: Bearer <token>`

**Request Body:**
```json
{
  "providerId": "provider_id",
  "service": {
    "serviceId": "service_id",
    "name": "Bridal Makeup",
    "price": 150,
    "duration": 120
  },
  "scheduledDate": "2025-12-01",
  "scheduledTime": "14:00",
  "location": {
    "type": "on-site",
    "address": "456 Client Ave, New York, NY",
    "coordinates": [-73.935242, 40.730610],
    "notes": "Apartment 5B, ring doorbell"
  },
  "notes": "Please bring false lashes"
}
```

**Response:** `201 Created`
```json
{
  "success": true,
  "data": {
    "booking": {
      "_id": "booking_id",
      "bookingNumber": "ZB-20251127-001",
      "status": "pending",
      ...
    }
  }
}
```

---

### 3.2 Get Booking Details

**GET** `/bookings/:bookingId`

**Headers:** `Authorization: Bearer <token>`

**Response:** `200 OK`

---

### 3.3 Get User Bookings

**GET** `/bookings`

**Headers:** `Authorization: Bearer <token>`

**Query Parameters:**
- `status`: Filter by status
- `page`: Page number
- `limit`: Results per page

**Response:** `200 OK`
```json
{
  "success": true,
  "data": {
    "bookings": [...],
    "pagination": {...}
  }
}
```

---

### 3.4 Accept Booking (Provider)

**PUT** `/bookings/:bookingId/accept`

**Headers:** `Authorization: Bearer <token>`

**Response:** `200 OK`

---

### 3.5 Reject Booking (Provider)

**PUT** `/bookings/:bookingId/reject`

**Headers:** `Authorization: Bearer <token>`

**Request Body:**
```json
{
  "reason": "Not available at that time"
}
```

**Response:** `200 OK`

---

### 3.6 Cancel Booking

**PUT** `/bookings/:bookingId/cancel`

**Headers:** `Authorization: Bearer <token>`

**Request Body:**
```json
{
  "reason": "Schedule conflict"
}
```

**Response:** `200 OK`

---

### 3.7 Update Booking Status

**PUT** `/bookings/:bookingId/status`

**Headers:** `Authorization: Bearer <token>`

**Request Body:**
```json
{
  "status": "in-progress" // or "completed"
}
```

**Response:** `200 OK`

---

### 3.8 Reschedule Booking

**PUT** `/bookings/:bookingId/reschedule`

**Headers:** `Authorization: Bearer <token>`

**Request Body:**
```json
{
  "scheduledDate": "2025-12-02",
  "scheduledTime": "15:00"
}
```

**Response:** `200 OK`

---

## 4. Review Endpoints

### 4.1 Create Review

**POST** `/reviews`

**Headers:** `Authorization: Bearer <token>`

**Request Body:**
```json
{
  "bookingId": "booking_id",
  "providerId": "provider_id",
  "rating": 5,
  "review": {
    "quality": 5,
    "punctuality": 5,
    "professionalism": 5,
    "value": 4
  },
  "comment": "Amazing service! Highly recommend.",
  "images": ["url1", "url2"]
}
```

**Response:** `201 Created`

---

### 4.2 Get Provider Reviews

**GET** `/reviews/provider/:providerId`

**Query Parameters:**
- `page`: Page number
- `limit`: Results per page
- `rating`: Filter by rating

**Response:** `200 OK`
```json
{
  "success": true,
  "data": {
    "reviews": [...],
    "stats": {
      "average": 4.8,
      "count": 125,
      "distribution": {
        "5": 95,
        "4": 20,
        "3": 7,
        "2": 2,
        "1": 1
      }
    },
    "pagination": {...}
  }
}
```

---

### 4.3 Respond to Review (Provider)

**POST** `/reviews/:reviewId/respond`

**Headers:** `Authorization: Bearer <token>`

**Request Body:**
```json
{
  "response": "Thank you for your kind words!"
}
```

**Response:** `200 OK`

---

### 4.4 Mark Review Helpful

**POST** `/reviews/:reviewId/helpful`

**Headers:** `Authorization: Bearer <token>`

**Response:** `200 OK`

---

## 5. Payment Endpoints

### 5.1 Create Payment Intent

**POST** `/payments/intent`

**Headers:** `Authorization: Bearer <token>`

**Request Body:**
```json
{
  "bookingId": "booking_id",
  "amount": 150
}
```

**Response:** `200 OK`
```json
{
  "success": true,
  "data": {
    "clientSecret": "stripe_client_secret",
    "paymentIntentId": "pi_xxx"
  }
}
```

---

### 5.2 Confirm Payment

**POST** `/payments/confirm`

**Headers:** `Authorization: Bearer <token>`

**Request Body:**
```json
{
  "paymentIntentId": "pi_xxx",
  "bookingId": "booking_id"
}
```

**Response:** `200 OK`

---

### 5.3 Get Payment History

**GET** `/payments`

**Headers:** `Authorization: Bearer <token>`

**Query Parameters:**
- `type`: Filter by type
- `status`: Filter by status
- `page`: Page number
- `limit`: Results per page

**Response:** `200 OK`

---

### 5.4 Request Refund

**POST** `/payments/:paymentId/refund`

**Headers:** `Authorization: Bearer <token>`

**Request Body:**
```json
{
  "reason": "Service not provided",
  "amount": 150 // optional, defaults to full amount
}
```

**Response:** `200 OK`

---

### 5.5 Request Payout (Provider)

**POST** `/payments/payout`

**Headers:** `Authorization: Bearer <token>`

**Request Body:**
```json
{
  "amount": 1000,
  "bankDetails": {
    "accountNumber": "1234567890",
    "routingNumber": "987654321"
  }
}
```

**Response:** `200 OK`

---

## 6. Subscription Endpoints

### 6.1 Get Subscription Plans

**GET** `/subscriptions/plans`

**Response:** `200 OK`
```json
{
  "success": true,
  "data": {
    "plans": [
      {
        "_id": "plan_id",
        "name": "Basic",
        "price": 29.99,
        "duration": 30,
        "features": [...],
        "benefits": {...}
      },
      ...
    ]
  }
}
```

---

### 6.2 Subscribe to Plan

**POST** `/subscriptions/subscribe`

**Headers:** `Authorization: Bearer <token>`

**Request Body:**
```json
{
  "planId": "plan_id",
  "paymentMethodId": "pm_xxx",
  "autoRenew": true
}
```

**Response:** `201 Created`

---

### 6.3 Get Current Subscription

**GET** `/subscriptions/current`

**Headers:** `Authorization: Bearer <token>`

**Response:** `200 OK`
```json
{
  "success": true,
  "data": {
    "subscription": {
      "plan": {...},
      "status": "active",
      "startDate": "2025-11-01",
      "endDate": "2025-12-01",
      "daysRemaining": 4,
      "autoRenew": true
    }
  }
}
```

---

### 6.4 Cancel Subscription

**POST** `/subscriptions/cancel`

**Headers:** `Authorization: Bearer <token>`

**Response:** `200 OK`

---

### 6.5 Renew Subscription

**POST** `/subscriptions/renew`

**Headers:** `Authorization: Bearer <token>`

**Request Body:**
```json
{
  "planId": "plan_id" // optional, defaults to current plan
}
```

**Response:** `200 OK`

---

### 6.6 Toggle Auto-Renewal

**PUT** `/subscriptions/auto-renew`

**Headers:** `Authorization: Bearer <token>`

**Request Body:**
```json
{
  "autoRenew": false
}
```

**Response:** `200 OK`

---

## 7. Chat/Messaging Endpoints

### 7.1 Get Conversations

**GET** `/messages/conversations`

**Headers:** `Authorization: Bearer <token>`

**Response:** `200 OK`
```json
{
  "success": true,
  "data": {
    "conversations": [
      {
        "conversationId": "conv_id",
        "participant": {...},
        "lastMessage": {...},
        "unreadCount": 3
      },
      ...
    ]
  }
}
```

---

### 7.2 Get Messages

**GET** `/messages/:conversationId`

**Headers:** `Authorization: Bearer <token>`

**Query Parameters:**
- `page`: Page number
- `limit`: Results per page

**Response:** `200 OK`

---

### 7.3 Send Message

**POST** `/messages`

**Headers:** `Authorization: Bearer <token>`

**Request Body:**
```json
{
  "receiverId": "user_id",
  "message": "Hello, I have a question about the service",
  "type": "text"
}
```

**Response:** `201 Created`

---

### 7.4 Mark as Read

**PUT** `/messages/:conversationId/read`

**Headers:** `Authorization: Bearer <token>`

**Response:** `200 OK`

---

## 8. Favorites Endpoints

### 8.1 Add to Favorites

**POST** `/favorites`

**Headers:** `Authorization: Bearer <token>`

**Request Body:**
```json
{
  "providerId": "provider_id"
}
```

**Response:** `201 Created`

---

### 8.2 Get Favorites

**GET** `/favorites`

**Headers:** `Authorization: Bearer <token>`

**Response:** `200 OK`

---

### 8.3 Remove from Favorites

**DELETE** `/favorites/:providerId`

**Headers:** `Authorization: Bearer <token>`

**Response:** `200 OK`

---

## 9. Service Categories Endpoints

### 9.1 Get All Services

**GET** `/services`

**Query Parameters:**
- `category`: Filter by category
- `isActive`: Filter by active status

**Response:** `200 OK`
```json
{
  "success": true,
  "data": {
    "services": [
      {
        "_id": "service_id",
        "name": "Makeup Application",
        "slug": "makeup-application",
        "category": "makeup",
        "icon": "url",
        "suggestedPrice": { "min": 50, "max": 200 }
      },
      ...
    ]
  }
}
```

---

### 9.2 Get Service by ID

**GET** `/services/:serviceId`

**Response:** `200 OK`

---

## 10. Admin Endpoints

### 10.1 Get Dashboard Stats

**GET** `/admin/dashboard`

**Headers:** `Authorization: Bearer <token>` (Admin only)

**Response:** `200 OK`
```json
{
  "success": true,
  "data": {
    "stats": {
      "totalUsers": 5420,
      "activeProviders": 342,
      "totalBookings": 8932,
      "totalRevenue": 234567.89,
      "platformFees": 23456.78,
      "growth": {
        "users": 12.5,
        "bookings": 8.3,
        "revenue": 15.7
      }
    },
    "recentActivity": [...],
    "topProviders": [...],
    "popularServices": [...]
  }
}
```

---

### 10.2 Get All Users

**GET** `/admin/users`

**Headers:** `Authorization: Bearer <token>` (Admin only)

**Query Parameters:**
- `role`: Filter by role
- `status`: Filter by status
- `search`: Search by name/email
- `page`: Page number
- `limit`: Results per page

**Response:** `200 OK`

---

### 10.3 Get User Details

**GET** `/admin/users/:userId`

**Headers:** `Authorization: Bearer <token>` (Admin only)

**Response:** `200 OK`

---

### 10.4 Update User

**PUT** `/admin/users/:userId`

**Headers:** `Authorization: Bearer <token>` (Admin only)

**Request Body:** (Partial updates allowed)

**Response:** `200 OK`

---

### 10.5 Suspend User

**POST** `/admin/users/:userId/suspend`

**Headers:** `Authorization: Bearer <token>` (Admin only)

**Request Body:**
```json
{
  "reason": "Violation of terms",
  "duration": 30 // days, null for permanent
}
```

**Response:** `200 OK`

---

### 10.6 Activate User

**POST** `/admin/users/:userId/activate`

**Headers:** `Authorization: Bearer <token>` (Admin only)

**Response:** `200 OK`

---

### 10.7 Delete User

**DELETE** `/admin/users/:userId`

**Headers:** `Authorization: Bearer <token>` (Admin only)

**Response:** `200 OK`

---

### 10.8 Manage Subscription Plans

**POST** `/admin/subscription-plans`

**Headers:** `Authorization: Bearer <token>` (Admin only)

**Request Body:**
```json
{
  "name": "Premium",
  "slug": "premium",
  "description": "Full access to all features",
  "price": 79.99,
  "duration": 30,
  "features": [...],
  "benefits": {...}
}
```

**Response:** `201 Created`

---

### 10.9 Get All Disputes

**GET** `/admin/disputes`

**Headers:** `Authorization: Bearer <token>` (Admin only)

**Query Parameters:**
- `status`: Filter by status
- `page`: Page number
- `limit`: Results per page

**Response:** `200 OK`

---

### 10.10 Resolve Dispute

**PUT** `/admin/disputes/:disputeId/resolve`

**Headers:** `Authorization: Bearer <token>` (Admin only)

**Request Body:**
```json
{
  "action": "refund",
  "note": "Full refund issued to client",
  "refundAmount": 150
}
```

**Response:** `200 OK`

---

### 10.11 Get Analytics

**GET** `/admin/analytics`

**Headers:** `Authorization: Bearer <token>` (Admin only)

**Query Parameters:**
- `startDate`: Start date (YYYY-MM-DD)
- `endDate`: End date (YYYY-MM-DD)
- `type`: Analytics type (users|bookings|revenue|providers)

**Response:** `200 OK`

---

### 10.12 Moderate Review

**PUT** `/admin/reviews/:reviewId/moderate`

**Headers:** `Authorization: Bearer <token>` (Admin only)

**Request Body:**
```json
{
  "action": "hide", // or "approve", "delete"
  "reason": "Inappropriate content"
}
```

**Response:** `200 OK`

---

### 10.13 Create Announcement

**POST** `/admin/announcements`

**Headers:** `Authorization: Bearer <token>` (Admin only)

**Request Body:**
```json
{
  "title": "Platform Maintenance",
  "message": "Scheduled maintenance on Dec 1st",
  "targetAudience": "all", // or "providers", "clients"
  "priority": "high",
  "scheduledFor": "2025-12-01T00:00:00Z"
}
```

**Response:** `201 Created`

---

## 11. Notification Endpoints

### 11.1 Get Notifications

**GET** `/notifications`

**Headers:** `Authorization: Bearer <token>`

**Query Parameters:**
- `isRead`: Filter by read status
- `page`: Page number
- `limit`: Results per page

**Response:** `200 OK`

---

### 11.2 Mark as Read

**PUT** `/notifications/:notificationId/read`

**Headers:** `Authorization: Bearer <token>`

**Response:** `200 OK`

---

### 11.3 Mark All as Read

**PUT** `/notifications/read-all`

**Headers:** `Authorization: Bearer <token>`

**Response:** `200 OK`

---

### 11.4 Delete Notification

**DELETE** `/notifications/:notificationId`

**Headers:** `Authorization: Bearer <token>`

**Response:** `200 OK`

---

## 12. Upload Endpoints

### 12.1 Upload Image

**POST** `/upload/image`

**Headers:** 
- `Authorization: Bearer <token>`
- `Content-Type: multipart/form-data`

**Request Body:**
```
file: <image file>
folder: "portfolio" // or "avatar", "documents"
```

**Response:** `200 OK`
```json
{
  "success": true,
  "data": {
    "url": "https://cloudinary.com/...",
    "publicId": "public_id"
  }
}
```

---

### 12.2 Upload Video

**POST** `/upload/video`

**Headers:** 
- `Authorization: Bearer <token>`
- `Content-Type: multipart/form-data`

**Request Body:**
```
file: <video file>
folder: "portfolio"
```

**Response:** `200 OK`

---

### 12.3 Delete Upload

**DELETE** `/upload/:publicId`

**Headers:** `Authorization: Bearer <token>`

**Response:** `200 OK`

---

## WebSocket Events

### Connection

```javascript
const socket = io('wss://api.zoobeauty.com', {
  auth: {
    token: 'jwt_token'
  }
});
```

### Events

#### Client → Server

- `join_conversation`: Join a chat conversation
- `send_message`: Send a chat message
- `typing`: Indicate typing status
- `location_update`: Update provider location (on-site service)

#### Server → Client

- `new_message`: Receive new chat message
- `booking_update`: Booking status changed
- `provider_location`: Provider location update
- `notification`: New notification
- `typing_indicator`: Other user is typing

---

## Rate Limiting

- **General endpoints:** 100 requests per 15 minutes
- **Authentication endpoints:** 5 requests per 15 minutes
- **Search endpoints:** 30 requests per minute

## Error Codes

| Code | Description |
|------|-------------|
| `UNAUTHORIZED` | Invalid or missing authentication token |
| `FORBIDDEN` | Insufficient permissions |
| `NOT_FOUND` | Resource not found |
| `VALIDATION_ERROR` | Invalid request data |
| `DUPLICATE_ENTRY` | Resource already exists |
| `PAYMENT_FAILED` | Payment processing error |
| `SUBSCRIPTION_EXPIRED` | Provider subscription expired |
| `BOOKING_CONFLICT` | Time slot not available |
| `RATE_LIMIT_EXCEEDED` | Too many requests |
| `SERVER_ERROR` | Internal server error |

---

**API Version:** v1  
**Last Updated:** 2025-11-27
