# 🎨 UI/UX Design System

## Design Philosophy

Zoo Beauty embraces a **modern, premium, and vibrant** design language that reflects the beauty industry's creativity and professionalism. The interface should feel luxurious, trustworthy, and easy to use.

---

## Color Palette

### Primary Colors
```css
--primary-50: #fdf4ff;
--primary-100: #fae8ff;
--primary-200: #f5d0fe;
--primary-300: #f0abfc;
--primary-400: #e879f9;
--primary-500: #d946ef;  /* Main Brand Color */
--primary-600: #c026d3;
--primary-700: #a21caf;
--primary-800: #86198f;
--primary-900: #701a75;
```

### Secondary Colors
```css
--secondary-50: #f0fdfa;
--secondary-100: #ccfbf1;
--secondary-200: #99f6e4;
--secondary-300: #5eead4;
--secondary-400: #2dd4bf;
--secondary-500: #14b8a6;  /* Accent Color */
--secondary-600: #0d9488;
--secondary-700: #0f766e;
--secondary-800: #115e59;
--secondary-900: #134e4a;
```

### Neutral Colors
```css
--gray-50: #fafafa;
--gray-100: #f5f5f5;
--gray-200: #e5e5e5;
--gray-300: #d4d4d4;
--gray-400: #a3a3a3;
--gray-500: #737373;
--gray-600: #525252;
--gray-700: #404040;
--gray-800: #262626;
--gray-900: #171717;
```

### Semantic Colors
```css
--success: #10b981;
--warning: #f59e0b;
--error: #ef4444;
--info: #3b82f6;
```

### Dark Mode
```css
--dark-bg-primary: #0f0f0f;
--dark-bg-secondary: #1a1a1a;
--dark-bg-tertiary: #262626;
--dark-text-primary: #fafafa;
--dark-text-secondary: #a3a3a3;
```

---

## Typography

### Font Families
```css
--font-primary: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
--font-heading: 'Outfit', 'Inter', sans-serif;
--font-mono: 'JetBrains Mono', 'Courier New', monospace;
```

### Font Sizes
```css
--text-xs: 0.75rem;      /* 12px */
--text-sm: 0.875rem;     /* 14px */
--text-base: 1rem;       /* 16px */
--text-lg: 1.125rem;     /* 18px */
--text-xl: 1.25rem;      /* 20px */
--text-2xl: 1.5rem;      /* 24px */
--text-3xl: 1.875rem;    /* 30px */
--text-4xl: 2.25rem;     /* 36px */
--text-5xl: 3rem;        /* 48px */
--text-6xl: 3.75rem;     /* 60px */
```

### Font Weights
```css
--font-light: 300;
--font-normal: 400;
--font-medium: 500;
--font-semibold: 600;
--font-bold: 700;
--font-extrabold: 800;
```

---

## Spacing System

```css
--space-1: 0.25rem;   /* 4px */
--space-2: 0.5rem;    /* 8px */
--space-3: 0.75rem;   /* 12px */
--space-4: 1rem;      /* 16px */
--space-5: 1.25rem;   /* 20px */
--space-6: 1.5rem;    /* 24px */
--space-8: 2rem;      /* 32px */
--space-10: 2.5rem;   /* 40px */
--space-12: 3rem;     /* 48px */
--space-16: 4rem;     /* 64px */
--space-20: 5rem;     /* 80px */
--space-24: 6rem;     /* 96px */
```

---

## Border Radius

```css
--radius-sm: 0.375rem;   /* 6px */
--radius-md: 0.5rem;     /* 8px */
--radius-lg: 0.75rem;    /* 12px */
--radius-xl: 1rem;       /* 16px */
--radius-2xl: 1.5rem;    /* 24px */
--radius-full: 9999px;   /* Full circle */
```

---

## Shadows

```css
--shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
--shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1);
--shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1);
--shadow-xl: 0 20px 25px -5px rgb(0 0 0 / 0.1);
--shadow-2xl: 0 25px 50px -12px rgb(0 0 0 / 0.25);
--shadow-glow: 0 0 20px rgb(217 70 239 / 0.3);
```

---

## Animations

### Transitions
```css
--transition-fast: 150ms cubic-bezier(0.4, 0, 0.2, 1);
--transition-base: 200ms cubic-bezier(0.4, 0, 0.2, 1);
--transition-slow: 300ms cubic-bezier(0.4, 0, 0.2, 1);
```

### Keyframes
```css
@keyframes fadeIn {
  from { opacity: 0; }
  to { opacity: 1; }
}

@keyframes slideUp {
  from { transform: translateY(20px); opacity: 0; }
  to { transform: translateY(0); opacity: 1; }
}

@keyframes slideDown {
  from { transform: translateY(-20px); opacity: 0; }
  to { transform: translateY(0); opacity: 1; }
}

@keyframes scaleIn {
  from { transform: scale(0.95); opacity: 0; }
  to { transform: scale(1); opacity: 1; }
}

@keyframes shimmer {
  0% { background-position: -1000px 0; }
  100% { background-position: 1000px 0; }
}

@keyframes pulse {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.5; }
}
```

---

## Component Styles

### Buttons

#### Primary Button
```css
.btn-primary {
  background: linear-gradient(135deg, var(--primary-500), var(--primary-600));
  color: white;
  padding: 0.75rem 1.5rem;
  border-radius: var(--radius-lg);
  font-weight: var(--font-semibold);
  transition: all var(--transition-base);
  box-shadow: var(--shadow-md);
}

.btn-primary:hover {
  transform: translateY(-2px);
  box-shadow: var(--shadow-lg), var(--shadow-glow);
}
```

#### Secondary Button
```css
.btn-secondary {
  background: var(--gray-100);
  color: var(--gray-900);
  padding: 0.75rem 1.5rem;
  border-radius: var(--radius-lg);
  font-weight: var(--font-semibold);
  transition: all var(--transition-base);
}

.btn-secondary:hover {
  background: var(--gray-200);
}
```

#### Outline Button
```css
.btn-outline {
  background: transparent;
  border: 2px solid var(--primary-500);
  color: var(--primary-500);
  padding: 0.75rem 1.5rem;
  border-radius: var(--radius-lg);
  font-weight: var(--font-semibold);
  transition: all var(--transition-base);
}

.btn-outline:hover {
  background: var(--primary-500);
  color: white;
}
```

### Cards

#### Glass Card
```css
.card-glass {
  background: rgba(255, 255, 255, 0.7);
  backdrop-filter: blur(10px);
  border: 1px solid rgba(255, 255, 255, 0.3);
  border-radius: var(--radius-2xl);
  padding: var(--space-6);
  box-shadow: var(--shadow-xl);
}
```

#### Elevated Card
```css
.card-elevated {
  background: white;
  border-radius: var(--radius-xl);
  padding: var(--space-6);
  box-shadow: var(--shadow-lg);
  transition: all var(--transition-base);
}

.card-elevated:hover {
  transform: translateY(-4px);
  box-shadow: var(--shadow-2xl);
}
```

### Inputs

```css
.input {
  width: 100%;
  padding: 0.875rem 1rem;
  border: 2px solid var(--gray-200);
  border-radius: var(--radius-lg);
  font-size: var(--text-base);
  transition: all var(--transition-base);
  background: white;
}

.input:focus {
  outline: none;
  border-color: var(--primary-500);
  box-shadow: 0 0 0 3px rgba(217, 70, 239, 0.1);
}
```

### Badges

```css
.badge {
  display: inline-flex;
  align-items: center;
  padding: 0.375rem 0.75rem;
  border-radius: var(--radius-full);
  font-size: var(--text-sm);
  font-weight: var(--font-medium);
}

.badge-success {
  background: rgba(16, 185, 129, 0.1);
  color: var(--success);
}

.badge-warning {
  background: rgba(245, 158, 11, 0.1);
  color: var(--warning);
}

.badge-error {
  background: rgba(239, 68, 68, 0.1);
  color: var(--error);
}
```

---

## Layout Patterns

### Dashboard Layout
```
┌─────────────────────────────────────────────────────────┐
│  Header (Fixed)                                         │
├──────────┬──────────────────────────────────────────────┤
│          │                                              │
│ Sidebar  │  Main Content Area                           │
│ (Fixed)  │  (Scrollable)                                │
│          │                                              │
│          │                                              │
└──────────┴──────────────────────────────────────────────┘
```

### Landing Page Layout
```
┌─────────────────────────────────────────────────────────┐
│  Navigation (Transparent/Fixed)                         │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  Hero Section (Full Height)                             │
│  - Gradient Background                                  │
│  - CTA Buttons                                          │
│                                                         │
├─────────────────────────────────────────────────────────┤
│  Features Section                                       │
│  - 3 Column Grid                                        │
├─────────────────────────────────────────────────────────┤
│  How It Works                                           │
│  - Step-by-step Cards                                   │
├─────────────────────────────────────────────────────────┤
│  Testimonials                                           │
│  - Carousel/Grid                                        │
├─────────────────────────────────────────────────────────┤
│  Footer                                                 │
└─────────────────────────────────────────────────────────┘
```

---

## Page-Specific Designs

### Client Dashboard
- **Hero Section**: Search bar with location input
- **Map View**: Interactive map showing nearby providers
- **Provider Cards**: Grid/List view with ratings, pricing
- **Quick Actions**: Favorite providers, booking history
- **Notifications**: Real-time updates

### Provider Dashboard
- **Stats Overview**: Earnings, bookings, ratings
- **Calendar View**: Availability and upcoming bookings
- **Portfolio Management**: Image/video upload with preview
- **Subscription Status**: Plan details, renewal date
- **Chat Interface**: Client communications

### Admin Dashboard
- **Analytics**: Charts and graphs
- **User Management**: Table with search/filter
- **Dispute Resolution**: Ticket-style interface
- **System Settings**: Form-based configuration

---

## Responsive Breakpoints

```css
--breakpoint-sm: 640px;   /* Mobile */
--breakpoint-md: 768px;   /* Tablet */
--breakpoint-lg: 1024px;  /* Desktop */
--breakpoint-xl: 1280px;  /* Large Desktop */
--breakpoint-2xl: 1536px; /* Extra Large */
```

---

## Accessibility

- **Contrast Ratio**: Minimum 4.5:1 for text
- **Focus States**: Visible focus indicators
- **Keyboard Navigation**: Full keyboard support
- **Screen Readers**: Proper ARIA labels
- **Touch Targets**: Minimum 44x44px

---

## Micro-interactions

1. **Button Hover**: Scale up slightly + shadow increase
2. **Card Hover**: Lift effect with shadow
3. **Input Focus**: Border color change + glow
4. **Loading States**: Shimmer effect
5. **Success Actions**: Checkmark animation
6. **Error States**: Shake animation
7. **Notifications**: Slide in from top-right
8. **Modal Open**: Fade in + scale up
9. **Dropdown**: Slide down with fade
10. **Toggle Switch**: Smooth slide animation

---

## Icon System

Use **Heroicons** or **Lucide Icons** for consistency:
- Outline style for navigation
- Solid style for active states
- Size: 20px (default), 24px (large), 16px (small)

---

## Loading States

### Skeleton Loaders
```css
.skeleton {
  background: linear-gradient(
    90deg,
    var(--gray-200) 0%,
    var(--gray-100) 50%,
    var(--gray-200) 100%
  );
  background-size: 200% 100%;
  animation: shimmer 1.5s infinite;
  border-radius: var(--radius-md);
}
```

### Spinner
```css
.spinner {
  border: 3px solid var(--gray-200);
  border-top-color: var(--primary-500);
  border-radius: 50%;
  width: 40px;
  height: 40px;
  animation: spin 0.8s linear infinite;
}

@keyframes spin {
  to { transform: rotate(360deg); }
}
```

---

## Empty States

- Friendly illustrations
- Clear messaging
- Call-to-action button
- Helpful suggestions

---

## Error States

- Red accent color
- Clear error message
- Suggested actions
- Retry button

---

## Success States

- Green accent color
- Checkmark icon
- Confirmation message
- Next steps

---

**Design Principles:**
1. **Consistency**: Use design tokens throughout
2. **Clarity**: Clear visual hierarchy
3. **Feedback**: Immediate user feedback
4. **Efficiency**: Minimize clicks
5. **Delight**: Subtle animations and transitions

---

**Last Updated:** 2025-11-27
